#!/bin/sh
PATH=/data/adb/ksu/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"

. "$MODDIR/utils.sh"

log_boot "=== post-fs-data START (kernel: $(uname -r 2>/dev/null), module: $(sed -n 's/^version=//p' $MODDIR/module.prop 2>/dev/null)) ==="

# v26.11.38 PHASE-0 RECON FIRST: capture the kernel's build facts to
# /data/adb/ReSuSFS/logs/kernel_facts.txt (+ kernel_kallsyms.txt,
# + kernel_config.txt) BEFORE any LKM action runs - even a boot that
# wedges later leaves the facts on disk for the next one, and the
# first successful boot hands us the compiler string, IKCONFIG config,
# kallsyms layout and KSU variant the port has been missing all along.
# (Implements Phase 0 of the LDPlayer port guide; bounded + gated.)
log_boot "post-fs-data: kernel_recon starting (gated, 60s)"
run_gated kernel-recon 60 sh -c ". $MODDIR/utils.sh; kernel_recon" >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: kernel_recon rc=$?"

# load the susfs LKM IMAGE. On custom (non-GKI) kernels like LDPlayer 14's
# 5.15.178+ this is a NO-OP unless the user opted in via
# /data/adb/ReSuSFS/enable_lkm (v26.11.23 safeguard - see utils.sh).
# The load is receipt-gated + timeout-bounded, so a wedged load attempt
# cannot block the boot chain AND is skipped on the next boot.
# v26.11.38: this is the PROVEN-SAFE zombie image state ONLY (v25..v37
# booted fine with the image loaded and init never running). The init
# trigger itself MOVED to boot-completed.sh: susfs_init now runs only
# AFTER the system is fully up, so a wedged init can never freeze the
# boot at 50% again - worst case the desktop freezes with all evidence
# already on disk, and the ladder below demotes the next boot.
log_boot "post-fs-data: LKM image load starting (gated, 150s; opt-in only on custom kernels)"
run_gated lkm-load 150 sh -c ". $MODDIR/utils.sh; load_susfs_lkm" >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: LKM load rc=$?"

if [ -e /proc/susfs_path ] || [ -d /sys/module/susfs_guard_lkm ]; then
        log_boot "post-fs-data: susfs LKM image is LIVE (image loaded)"
        # v26.11.38 LADDER, SPLIT ACROSS THE BOOT:
        #   post-fs-data.sh (HERE): demotion + caps - the EARLIEST reader of
        #     the stage_boot marker from the PREVIOUS boot. A "try N" marker
        #     whose boot_id is not this boot's means that boot's init
        #     (triggered at boot-completed time) never completed its witness:
        #     demote to a stage-0 evidence boot and cap stage_max below N.
        #   boot-completed.sh: seed the resolver from /proc/kallsyms, arm the
        #     stage, write the "try N" marker, trigger force_init, poll
        #     init_done while snapshotting diag_log, then witness ok/nok and
        #     raise the ladder by one rung.
        # Same-boot re-run safety is kept: markers written by THIS boot are
        # never demoted, and post-fs-data running twice in one boot is a
        # no-op (the marker check keys off the boot_id).
        STAGE_FILE="/data/adb/ReSuSFS/arm_stage"
        STAGE_MAX_FILE="/data/adb/ReSuSFS/stage_max"
        STAGE_BOOT_FILE="/data/adb/ReSuSFS/stage_boot"
        LADDER_VERSION_FILE="/data/adb/ReSuSFS/ladder_version"

        # ---- v26.11.45: ladder reset on MODULE VERSION CHANGE -----------------
        # The stage ladder's SEMANTICS are version-specific (v47 redefined the
        # rungs: 2=supercall observe on the NEW cold-arm transport, 3=accept,
        # 4/5 retired permanently; v46 had capped everything at 1; v45 had
        # 4=LSM class, 5=table writers).  A persisted stage_max/arm_stage from
        # an older version would clamp or mis-arm the new one (the v44
        # stage-3 wedge left stage_max capped at 2 on this box; the v45 wedges
        # left it capped at 3; v46 then hard-capped it to 1).  So: when
        # module.prop's version differs from ladder_version, re-base the
        # STAGE dimension (stage file 0, stage_max 3) and clear any stale
        # stage_boot marker; the SUBSTEP dimension (init_seq) is
        # version-independent and stays where it was, so the climb after an
        # upgrade is stage 0 -> 3 at substep 7.
        MODVER=$(sed -n 's/^version=//p' $MODDIR/module.prop 2>/dev/null)
        LADDER_VER=$(cat "$LADDER_VERSION_FILE" 2>/dev/null)
        if [ -n "$MODVER" ] && [ "$MODVER" != "$LADDER_VER" ]; then
                case "$LADDER_VER" in
                v26.11.47*)
                        # v26.11.48: TRANSPORT-FIX UPGRADE, NOT A NEW EXPERIMENT
                        # (historical case - only reachable if the box jumps
                        # v47 -> v49 without ever booting v48).
                        # The rung semantics are IDENTICAL to v47 (2 = transport
                        # observe, 3 = accept, 4/5 retired) and the 10 armed layers
                        # are unchanged - only WHERE the transport hooks moved
                        # (the live sys_call_table entry instead of the dead
                        # dispatcher arm) and the CLI install rule changed.
                        # Re-basing here would cost four needless boots on a
                        # campaign that already climbed to the ceiling: the
                        # ladder carries over, only the version stamp moves.
                        log_boot "post-fs-data: transport-fix upgrade ('$LADDER_VER' -> '$MODVER') - rung semantics unchanged, ladder PRESERVED (arm_stage stays, stage_max stays; the first v49 boot re-arms the transport at the parked rung)"
                        echo "$MODVER" > "$LADDER_VERSION_FILE" 2>/dev/null
                        ;;
                *)
                        # v26.11.49 -> any v48 ladder state is deliberately
                        # re-based here: v49 changes the TRANSPORT ITSELF (the
                        # installed entry now carries a replicated kCFI type-hash
                        # preamble - the v48 preamble-less entry killed the box at
                        # the first dispatch, five boots out of five), and every
                        # rung must re-validate with the new entry under the
                        # live-fire self-test before the ladder trusts it again.
                        # The v48 boots on this box all wedged at stage 3 AFTER
                        # writing their 'ok' markers (the v48 confirmation came
                        # before the self-test), so the persisted stage-3 state is
                        # exactly what must NOT carry over.  The substep dimension
                        # stays: the climb is stage 0 -> 1 -> 2 (observe) -> 3
                        # (accept), one boot per rung, each confirmed only after
                        # its self-test survives (v49 boot-completed.sh).
                        log_boot "post-fs-data: module version changed ('$LADDER_VER' -> '$MODVER') - re-basing the stage ladder (arm_stage=0, stage_max=3 - the v49 ceiling, stages 4/5 retired; stale marker cleared); the substep ladder stays"
                        # v54: the enforcement ladder re-bases with the stage
                        # ladder - a new binary is new evidence, so a stale
                        # 'try'/'ok'/'disabled' marker must not carry over
                        rm -f "/data/adb/ReSuSFS/gd64_stage" 2>/dev/null
                        echo "$MODVER" > "$LADDER_VERSION_FILE" 2>/dev/null
                        echo 3 > "$STAGE_MAX_FILE" 2>/dev/null
                        echo 0 > "$STAGE_FILE" 2>/dev/null
                        rm -f "$STAGE_BOOT_FILE" 2>/dev/null
                        ;;
                esac
        fi

        # ---- v26.11.48: CLI SELF-HEAL (every boot) ----------------------------
        # The v47 field verdict: the box's /data/adb/ksu/bin/ksu_susfs was the
        # STOCK reboot(169)-riding CLI (a symlink the old installer kept), so
        # every self-test invoked a binary that can never ride the transport.
        # The transport listens on syscall 173; the CLI that runs MUST be the
        # module's own 173-riding build. This is the same self-heal contract
        # the LKM payload stamp already has: verify the bytes every boot,
        # force-replace on mismatch (a manager-side refresh can never silently
        # re-dowse the channel). The stock binary is backed up ONCE.
        # (v26.11.49: the CLI itself is unchanged from v48 - it already rides
        # syscall 173 and reads payload.err.)
        CLI_MOD="$MODDIR/bin/x86_64/ksu_susfs"
        CLI_DST=/data/adb/ksu/bin/ksu_susfs
        CLI_BAK=/data/adb/ReSuSFS/ksu_susfs.pre-v48.bak
        if [ -f "$CLI_MOD" ]; then
                CLI_OK=0
                if [ ! -e "$CLI_DST" ] && [ ! -L "$CLI_DST" ]; then
                        log_boot "post-fs-data: ksu_susfs absent at $CLI_DST - installing the 173-riding CLI (v48+, unchanged in v49)"
                elif cmp -s "$CLI_MOD" "$CLI_DST" 2>/dev/null; then
                        CLI_OK=1
                else
                        [ -e "$CLI_BAK" ] || { cp -a "$CLI_DST" "$CLI_BAK" 2>/dev/null || true; readlink "$CLI_DST" > /data/adb/ReSuSFS/ksu_susfs.pre-v48.target 2>/dev/null || true; }
                        log_boot "post-fs-data: ksu_susfs at $CLI_DST does not match the module's 173-riding CLI (rode the old convention - this is what kept the v47 channel dark) - replacing it (previous copy backed up at $CLI_BAK)"
                        rm -f "$CLI_DST"
                fi
                if [ "$CLI_OK" = "0" ]; then
                        if cp -f "$CLI_MOD" "$CLI_DST" && chmod 755 "$CLI_DST"; then
                                log_boot "post-fs-data: v49 payload ksu_susfs installed at $CLI_DST (sha256 $(sha256sum "$CLI_MOD" 2>/dev/null | awk '{print $1}'))"
                                ln -sf ksu_susfs /data/adb/ksu/bin/susfs 2>/dev/null
                                ln -sf ksu_susfs /data/adb/ksu/bin/sus 2>/dev/null
                        else
                                log_boot "post-fs-data: WARNING - ksu_susfs install to $CLI_DST failed; the self-test will use the module's own copy"
                        fi
                fi
        fi

        # ---- v26.11.52: sc_probe SELF-HEAL (every boot) -----------------------
        # The v51 field run printed 'sc_probe: not bundled' every boot while
        # the probe sat right in the zip at bin/x86_64/sc_probe - the exec
        # bit was lost through module extraction, so the self-test's -x
        # check never passed. Install it the field-proven way (same contract
        # as the CLI above): copy to /data/adb/ksu/bin + chmod 755. The
        # self-test looks there first. sc_probe is the raw-syscall verifier
        # that carries the CORRECT cmd table (variant=0x555e3) - v51's
        # 'not bundled' is exactly why the e2/e3 swap survived to the field.
        PROBE_MOD="$MODDIR/bin/x86_64/sc_probe"
        PROBE_DST=/data/adb/ksu/bin/sc_probe
        if [ -f "$PROBE_MOD" ]; then
                if ! cmp -s "$PROBE_MOD" "$PROBE_DST" 2>/dev/null; then
                        if cp -f "$PROBE_MOD" "$PROBE_DST" && chmod 755 "$PROBE_DST"; then
                                log_boot "post-fs-data: sc_probe installed at $PROBE_DST (sha256 $(sha256sum "$PROBE_MOD" 2>/dev/null | awk '{print $1}'))"
                        else
                                log_boot "post-fs-data: WARNING - sc_probe install to $PROBE_DST failed; the self-test falls back to the module's own copy"
                        fi
                fi
        fi

        ARM_STAGE=0
        [ -f "$STAGE_FILE" ] && ARM_STAGE=$(cat "$STAGE_FILE" 2>/dev/null | tr -dc '0-9')
        [ -z "$ARM_STAGE" ] && ARM_STAGE=0
        case "$ARM_STAGE" in 0|1|2|3|4|5) ;; *) ARM_STAGE=0 ;; esac

        STAGE_MAX=5
        [ -f "$STAGE_MAX_FILE" ] && STAGE_MAX=$(cat "$STAGE_MAX_FILE" 2>/dev/null | tr -dc '0-9')
        [ -z "$STAGE_MAX" ] && STAGE_MAX=5
        case "$STAGE_MAX" in 0|1|2|3|4|5) ;; *) STAGE_MAX=5 ;; esac
        if [ "$ARM_STAGE" -gt "$STAGE_MAX" ]; then
                log_boot "post-fs-data: arm_stage $ARM_STAGE above stage_max $STAGE_MAX - clamping"
                ARM_STAGE=$STAGE_MAX
        fi

        # Wedge demotion: a "try N <boot_id>" marker from a PREVIOUS boot means
        # that boot's post-boot init never completed its witness - it wedged
        # the box (or the user pulled power mid-experiment). Demote to a
        # stage-0 evidence boot and cap the ladder below the wedging rung.
        # If the wedge was at stage 0 itself, the resolver class is broken on
        # this kernel even SEEDED and printk-less: stand down completely this
        # boot (no trigger - boot-completed.sh checks no_init_this_boot), and
        # remove BOTH opt-in flags so the next boot comes up without the
        # module image init attempt at all (the zombie image stays proven
        # safe; a deliberate re-touch of the flags gets one fresh attempt).
        CUR_BOOT="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d -)"
        MARKER=""
        [ -f "$STAGE_BOOT_FILE" ] && MARKER=$(cat "$STAGE_BOOT_FILE" 2>/dev/null)
        MARKER_BOOT=""
        case "$MARKER" in
        "try "*|"ok "*|"nok "*) MARKER_BOOT=$(echo "$MARKER" | awk '{print $3}') ;;
        esac
        if [ -n "$MARKER_BOOT" ] && [ "$MARKER_BOOT" != "$CUR_BOOT" ]; then
                case "$MARKER" in
                try*)
                        # v26.11.40/v41: the wedge dossier goes INTO boot.log first,
                        # so one paste back carries everything: the init_trace
                        # receipts name the exact substep the frozen boot had
                        # dispatched, and the diag snapshot is whatever the
                        # poller salvaged before the freeze.
                        {
                                echo "---- WEDGE DOSSIER (stale marker '$MARKER' from boot $MARKER_BOOT) ----"
                                if [ -f "$LOG_DIR/init_trace.txt" ]; then
                                        echo "---- init_trace.txt (receipts; last 60 lines) ----"
                                        tail -n 60 "$LOG_DIR/init_trace.txt" 2>/dev/null
                                else
                                        echo "---- init_trace.txt: ABSENT (the frozen boot was a pre-v40 image, or the trigger never dispatched) ----"
                                fi
                                if [ -f "$LOG_DIR/diag_last.txt" ]; then
                                        echo "---- diag_last.txt ----"
                                        cat "$LOG_DIR/diag_last.txt" 2>/dev/null
                                else
                                        echo "---- diag_last.txt: ABSENT (init produced no crumbs, or the poller froze with the box) ----"
                                fi
                                # v53.1: if the kernel kept the panic, it is here - collect it.
                                echo "---- pstore/last_kmsg (if the kernel kept the panic) ----"
                                if [ -d /sys/fs/pstore ] && [ "$(ls /sys/fs/pstore 2>/dev/null | head -n 1)" != "" ]; then
                                        for pf in /sys/fs/pstore/*; do
                                                [ -f "$pf" ] && { echo "== $pf (last 40 lines)"; tail -n 40 "$pf" 2>/dev/null; }
                                        done
                                else
                                        echo "/sys/fs/pstore empty or absent - no ramoops on this kernel; a hard FREEZE leaves no ring"
                                fi
                                if [ -f /proc/last_kmsg ]; then
                                        echo "== /proc/last_kmsg (last 40 lines)"
                                        tail -n 40 /proc/last_kmsg 2>/dev/null
                                fi
                                echo "FREEZE DRILL (do this BEFORE hard-resetting a frozen guest): adb shell su -c 'dmesg > /data/adb/ReSuSFS/logs/dmesg_freeze.txt; cat /sys/module/susfs_guard_lkm/parameters/diag_log > /data/adb/ReSuSFS/logs/diag_freeze.txt; cat /proc/modules > /data/adb/ReSuSFS/logs/modules_freeze.txt; sync' - and read the LDPlayer window for XYZDIAG EMERG breadcrumbs."
                                echo "---- end WEDGE DOSSIER ----"
                        } >> "$BOOT_LOG" 2>/dev/null
                        # v53.1 HONEST WEDGE ATTRIBUTION: the v53 field run
                        # (boot aab0e489, 2026-11-27) froze BETWEEN "diag_printk=1
                        # armed" and the force_init write - the module was the
                        # v38-proven inert zombie at that moment (all params the
                        # scripts touch are stock int/string stores), yet the old
                        # logic demoted stage_max 3->0 and disarmed susfs on that
                        # false premise. Now: demote ONLY when the wedged boot
                        # actually TRIGGERED init (its own init_trace section
                        # contains a "writing force_init" receipt). Otherwise the
                        # freeze is box-level (host/emulator flake): retry the same
                        # rung, up to 2 consecutive times, then demote to stay safe.
                        WEDGE_SECTION=""
                        [ -f "$LOG_DIR/init_trace.txt" ] && WEDGE_SECTION="$(awk -v b="$MARKER_BOOT" '
                                index($0, "---- boot " b " begin") == 1 { on = 1; next }
                                index($0, "---- boot ") == 1 { on = 0 }
                                on { print }' "$LOG_DIR/init_trace.txt" 2>/dev/null)"
                        INIT_TRIGGERED=0
                        case "$WEDGE_SECTION" in
                                *"writing force_init"*) INIT_TRIGGERED=1 ;;
                        esac
                        if [ "$INIT_TRIGGERED" = "1" ]; then
                                if [ "$ARM_STAGE" -le 0 ]; then
                                        log_boot "post-fs-data: a stage-0/substep boot never completed WITH init triggered (marker '$MARKER') - see the WEDGE DOSSIER above for the exact substep. Removing enable_lkm + enable_force_init and suppressing the trigger this boot (zombie image, proven safe); evidence: $LOG_DIR/init_trace.txt + diag_last.txt + boot.log + kernel_facts.txt. Send all four back."
                                        rm -f /data/adb/ReSuSFS/enable_lkm 2>/dev/null
                                        rm -f /data/adb/ReSuSFS/enable_force_init 2>/dev/null
                                        rm -f "$STAGE_BOOT_FILE" 2>/dev/null
                                        echo 1 > /data/adb/ReSuSFS/no_init_this_boot 2>/dev/null
                                else
                                        NEW_MAX=$((ARM_STAGE - 1))
                                        log_boot "post-fs-data: PREVIOUS BOOT never completed at stage $ARM_STAGE WITH init triggered (marker '$MARKER') - presumed real wedge: demoting to a stage-0 evidence boot, capping stage_max at $NEW_MAX (init_trace receipts above name the substep)"
                                        echo "$NEW_MAX" > "$STAGE_MAX_FILE" 2>/dev/null
                                fi
                                rm -f /data/adb/ReSuSFS/freeze_retries 2>/dev/null
                                ARM_STAGE=0
                                echo "0" > "$STAGE_FILE" 2>/dev/null
                        else
                                FREEZE_RETRIES=0
                                [ -f /data/adb/ReSuSFS/freeze_retries ] && FREEZE_RETRIES=$(cat /data/adb/ReSuSFS/freeze_retries 2>/dev/null | tr -dc '0-9')
                                [ -z "$FREEZE_RETRIES" ] && FREEZE_RETRIES=0
                                FREEZE_RETRIES=$((FREEZE_RETRIES + 1))
                                echo "$FREEZE_RETRIES" > /data/adb/ReSuSFS/freeze_retries 2>/dev/null
                                if [ "$FREEZE_RETRIES" -ge 2 ]; then
                                        if [ "$ARM_STAGE" -gt 0 ]; then
                                                NEW_MAX=$((ARM_STAGE - 1))
                                                log_boot "post-fs-data: freeze #$FREEZE_RETRIES at stage $ARM_STAGE with init NOT triggered (marker '$MARKER') - box-level flake twice in a row: demoting to stage-0 evidence boot anyway (stage_max $NEW_MAX) to stay safe"
                                                echo "$NEW_MAX" > "$STAGE_MAX_FILE" 2>/dev/null
                                        else
                                                log_boot "post-fs-data: freeze #$FREEZE_RETRIES at stage 0 with init NOT triggered (marker '$MARKER') - box-level flake twice in a row: standing down this boot"
                                                rm -f /data/adb/ReSuSFS/enable_lkm 2>/dev/null
                                                rm -f /data/adb/ReSuSFS/enable_force_init 2>/dev/null
                                                rm -f "$STAGE_BOOT_FILE" 2>/dev/null
                                                echo 1 > /data/adb/ReSuSFS/no_init_this_boot 2>/dev/null
                                        fi
                                        rm -f /data/adb/ReSuSFS/freeze_retries 2>/dev/null
                                        ARM_STAGE=0
                                        echo "0" > "$STAGE_FILE" 2>/dev/null
                                else
                                        log_boot "post-fs-data: freeze at stage $ARM_STAGE with init NOT triggered (marker '$MARKER'; no force_init receipt in that boot's init_trace section, module was the inert zombie) - NOT stage-attributable: retrying rung $ARM_STAGE unchanged (freeze retry $FREEZE_RETRIES/2). If this recurs, run the FREEZE DRILL above before hard-resetting."
                                fi
                        fi
                        ;;
                ok*)
                        # v53.1: a COMPLETED, witnessed boot resets the
                        # consecutive-freeze counter (freeze_retries counts
                        # back-to-back box-level freezes, not freezes spread
                        # across healthy boots).
                        rm -f /data/adb/ReSuSFS/freeze_retries 2>/dev/null
                        ;;
                nok*)
                        # The previous boot COMPLETED and was witnessed (the
                        # box came up fully) but its init did not finish: a
                        # slow or stalled init, NOT a wedge. Retry the same
                        # rung - demoting here would false-positive on every
                        # healthy-but-slow seeded-resolver pass.
                        log_boot "post-fs-data: previous boot completed but init at stage $ARM_STAGE did not (marker '$MARKER') - NOT a wedge: retrying the same rung"
                        ;;
                esac
        fi

        # ---- v26.11.47: THE TRANSPORT REBUILD LADDER -------------------------
        # v45 verdict convicted the kprobe-on-reboot transport; v46 parked at
        # stage 1. v47 ships a NEW transport class (a hardened-dispatcher
        # cold-arm redirect - see README-DIAGNOSTIC.md): the module redirects
        # x64_sys_call()'s COLD ioperm(2) arm (nr 173; nothing on Android
        # issues it) to its own wrapper via a 4-byte rel32 memory patch
        # (ksu_patch_text: fixmap + copy_to_kernel_nofault under stop_machine)
        # - the same class as KernelSU's own KSU_X86_PATCH_SYSCALL_DISPATCHER
        # on hardened-dispatcher kernels. NO kprobe is registered anywhere;
        # reboot(2) is not on the path, so KernelSU's own reboot kprobe is
        # untouched. ksu_susfs's syscall sites are patched 169 -> 173 to ride
        # the new arm (answers in payload.err AND the syscall return).
        #   stage 2 = transport installed, OBSERVE-ONLY (logs, passes through)
        #   stage 3 = transport ACCEPTS - ksu_susfs fully live, runtime
        #             configuration of the sus_map/sus_mount/open_redirect/
        #             prop_view lists works
        #   stages 4/5 = PERMANENTLY RETIRED on this kernel: the v45 field
        #             verdict froze the box with NO supercall involved at all
        #             (lsm_hook/sus_path/uname/hide_syms hot paths; and the
        #             stage-5 sys_call_table writes are inert on 5.15 anyway -
        #             dispatch is x64_sys_call's direct-call switch, not the
        #             table). The ceiling is 3.
        if [ "$STAGE_MAX" -gt 3 ]; then
                log_boot "post-fs-data: v26.11.47 ceiling: stage_max $STAGE_MAX -> 3 (stage 2/3 ride the NEW cold-arm transport; stages 4/5 are retired - v45 froze the box on their own layers, with no supercall fired at all)"
                echo 3 > "$STAGE_MAX_FILE" 2>/dev/null
                STAGE_MAX=3
                if [ "$ARM_STAGE" -gt 3 ]; then
                        ARM_STAGE=3
                        echo 3 > "$STAGE_FILE" 2>/dev/null
                fi
        fi

        # v26.11.27: capture the decisive evidence while the module's init
        # lines may still be in the dmesg ring (this is now post-LOAD only -
        # init has not even been triggered yet in v38; the poll+snapshot of
        # diag_log moved to boot-completed.sh, right next to the trigger).
        capture_lkm_live_evidence >> "$BOOT_LOG" 2>&1

        # ---- v26.11.42 trigger_mode=early ----------------------------------
        # The v35-v37 field triggers ran at post-fs-data time (system at
        # ~7s, boot quiet) and their module code verifiably EXECUTED; the
        # v39-v41 triggers ran at boot-completed and froze at the write.
        # trigger_mode=early moves the force_init write back to the v35-v37
        # context: if the early write survives where the late one froze,
        # the trigger CONTEXT (concurrency, ~20s of system state), not the
        # write itself, is the variable.  Receipts + recovery are identical
        # (a wedged early trigger leaves the stale "try" marker for the
        # next boot's stand-down; the init poll here is timeout-guarded).
        if [ -f /data/adb/ReSuSFS/enable_lkm ] && [ -f /data/adb/ReSuSFS/enable_force_init ] && [ ! -f /data/adb/ReSuSFS/no_init_this_boot ] && [ -d /sys/module/susfs_guard_lkm ]; then
                TRIGGER_MODE="set"
                [ -f /data/adb/ReSuSFS/trigger_mode ] && TRIGGER_MODE=$(head -n 1 /data/adb/ReSuSFS/trigger_mode 2>/dev/null | tr -d '[:space:]')
                if [ "$TRIGGER_MODE" = "early" ]; then
                        FORCE_INIT="/sys/module/susfs_guard_lkm/parameters/force_init"
                        LASTSTEP_PARAM="/sys/module/susfs_guard_lkm/parameters/init_laststep"
                        INIT_DONE="/sys/module/susfs_guard_lkm/parameters/init_done"
                        INIT_SEQ=0
                        [ -f /data/adb/ReSuSFS/init_seq ] && INIT_SEQ=$(cat /data/adb/ReSuSFS/init_seq 2>/dev/null | tr -dc '0-9')
                        [ -z "$INIT_SEQ" ] && INIT_SEQ=0
                        case "$INIT_SEQ" in 0|1|2|3|4|5|6|7) ;; *) INIT_SEQ=0 ;; esac
                        log_boot "post-fs-data: trigger_mode=early - writing force_init NOW (the v35-v37 trigger context; substep $INIT_SEQ)"
                        if [ -w "$FORCE_INIT" ]; then
                                echo 1 > "/sys/module/susfs_guard_lkm/parameters/diag_printk" 2>/dev/null
                                echo 1 > "$FORCE_INIT" 2>/dev/null
                                log_boot "post-fs-data: early force_init write returned (kworker scheduled; boot-completed.sh will NOT re-trigger - it skips when trigger_mode=early and init_done is set or the same boot already dispatched)"
                                echo "try $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null
                        else
                                log_boot "post-fs-data: early trigger skipped (force_init param not writable - old image?)"
                        fi
                fi
        fi
elif susfs_kernel_alive; then
        log_boot "post-fs-data: kernel susfs ALIVE (built-in or LKM) - full features enabled"
else
        log_boot "post-fs-data: no kernel susfs (stock kernel + LKM not loaded) - userspace-only mode"
fi

log_boot "post-fs-data: stage-early starting (gated, 120s)"
run_gated stage-early 120 sh "$MODDIR/ReSuSFS.sh" --stage-early >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: stage-early rc=$?"

log_boot "post-fs-data: postfs user scripts starting (gated, 90s)"
run_gated postfs-scripts 90 sh "$MODDIR/ReSuSFS.sh" --run-postfs-scripts >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: postfs scripts rc=$?"

log_boot "=== post-fs-data DONE ==="

# EOF
