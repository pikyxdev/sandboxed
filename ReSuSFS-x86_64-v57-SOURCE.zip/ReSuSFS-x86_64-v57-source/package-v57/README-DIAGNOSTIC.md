# v26.11.53 - THE FIRST FEATURE RUNG (2026-11-27)

## What v52 proved (the base this rung builds on)

Two consecutive clean-room 10-boot ladders (v51, v52), zero wedges. At
stage 3 the self-test answered all three SHOW commands and sc_probe (the
raw-syscall view) agreed. The transport, the wire ABI, the calibrated uid
gate and the ladder are all field-proven. Feature commands answered 126
("not handled") by design.

## What v53 adds

The first FEATURE commands, on the same transport, from the stock CLI's
own dispatch sites (decoded from the shipped ksu_susfs binary, never from
module source - the v52 lesson):

| cmd | command | wire payload | v53 behavior |
|-----|---------|--------------|--------------|
| 0x55550 | add_sus_path | path[256] + err@256 (260B) | validate -> dedupe -> store (32 slots) -> err=0 |
| 0x55553 | add_sus_path_loop | same | same, marked loop |
| 0x55561 | hide_sus_mnts_for_non_su_procs | on/off byte + err@4 (8B) | toggle recorded -> err=0 |
| 0x55f53 | (private, NOT a CLI id) | dump[8192] + err@8192 | the receipt: table + counters + toggle |

Error answers: bad shape -> err=-22 (-EINVAL), overlong path -> -36
(-ENAMETOOLONG), table full -> -28 (-ENOSPC), duplicate -> err=0 with no
re-store (idempotent apply). The stock CLI prints "susfs: <cmd> failed
(kernel err N)" for nonzero err and exits 0 silently on success.

## Why this cannot regress the box

The new code runs ONLY at stage 3 behind the same magic + calibrated-uid
gate. It lives in the clang-17 graft, imports nothing new (the 13-symbol
undefined set is asserted at build time), contributes zero .bss (storage
rides in .data; the android struct-module spill window .bss[0..0x40) stays
untouched), and calls NOTHING from the v49 base module - the only extern
calls are the kernel's own _copy_from_user/_copy_to_user, already
exercised under fire by the SHOW answers. No locks, no allocation, no
logging from the accept path; slot allocation is one capped lock-xadd.

## What is still NOT done (honest scope)

- The stored paths are not yet ENFORCED: the layers that consume sus_path
  rules are stage-4+ machinery that stays retired (the v49 ceiling).
  Wiring storage into enforcement is the next rung, after this one
  survives the field.
- The hide_sus_mnts toggle is recorded but does not yet drive the base's
  sus_mount machinery (no verified symbol contract in the exported tree;
  a data-only bridge is the candidate design for a later rung).
- set_uname (0x55590) and set_cmdline_or_bootconfig (0x555b0) stay
  not-handled (next rung after this one survives).

## Field procedure

Flash v53 over v52 (KernelSU or Magisk). The 52->53 upgrade re-bases the
stage ladder automatically: **4 reboots in-place** (0 -> 1 -> 2=OBSERVE ->
3=FULL). Fresh instance = the full 10-boot climb.

At stage 3 the self-test receipt should show, in order:

```
-- ksu_susfs show version:            v2.3.0        (unchanged)
-- ksu_susfs show variant:            GKI-LKM       (unchanged)
-- ksu_susfs show enabled_features:   the armed list (unchanged)
---- v53 FEATURE RUNG ----
-- add_sus_path /data/local/tmp/.resusfs_v53_selftest      exit=0
-- add_sus_path_loop /data/local/tmp/.resusfs_v53_selftest_loop  exit=0
-- hide_sus_mnts_for_non_su_procs 1                        exit=0
-- regression show version:           v2.3.0        (still answering)
---- sc_probe ... ----
v53_feature_readback cmd=0x55f53 -> rc=0 err=0
answer: v53-feature-rung add_calls=3 dups=0 toggle_calls=1 hide_mnts=1
[0] /data/local/tmp/.resusfs_v53_selftest
[1] /data/local/tmp/.resusfs_v53_selftest_loop (loop)
slots_used=2/32 loops=1
```

After the ladder completes you can also run the real apply flows:
`sh $MODDIR/ReSuSFS.sh --apply-sus-paths` (each line exits 0 now) and
`--apply-toggles late` (the hide_mnts line exits 0). One wedge boot
maximum by design; after ANY wedge send back the five logs.

# v26.11.52 - THE CMD-TABLE FIX (2026-11-25)

## What your v51 10-reboot run proved

The fresh-instance run completed the ENTIRE ladder with zero wedges:

| boot | rung | result |
|------|------|--------|
| 1-3  | substeps 0-2 (dispatch, imports, resolver) | healthy |
| 4-7  | substeps 3-6 (gs_off, deadman, crosscheck, patch) | healthy |
| 8    | substep 7 + arm_stage 1 (10 layers live) | healthy |
| 9    | arm_stage 2 (supercall transport, OBSERVE-ONLY) | healthy, self-test survived, sc_entry_count 0->3 |
| 10   | arm_stage 3 (FULL mode) | healthy - **`ksu_susfs show version` ANSWERED `v2.3.0`** |

The transport works. The accept path works. The calibration works. But
`show variant` and `show enabled_features` still printed "failed".

## The bug (found by disassembling the stock CLI the box actually runs)

All three calls provably entered the accept path (counter 0->3), version
answered - so the transport, magic check and uid gate were fine. The
difference was in the COMMAND IDS. The stock `ksu_susfs` binary's own
dispatch sites decode to:

| cmd | the stock CLI's command | payload shape |
|-----|-------------------------|---------------|
| 0x555e1 | show version | 20 bytes (str[16] + err@16) |
| 0x555e2 | show enabled_features | 8196 bytes (str[8192] + err@8192) |
| 0x555e3 | show variant | 20 bytes (str[16] + err@16) |

v51's graft had **variant and enabled_features swapped**: `0x555e2` got the
20-byte "GKI-LKM" answer (the CLI then read `err` at +8192, which still
held its own preset 126 -> "failed"), and `0x555e3` got the 8196-byte
feature dump (the CLI read `err` at +16 - feature-name bytes -> "failed").

How the error survived: the constants were "confirmed" by disassembling
**the module's own cmd switch** - circular proof. The v47-era report
(`gen_v47_report.js`: "0x555e1 / 0x555e3 / 0x555e2") and `sc_probe.c` both
carried the CORRECT table all along - but sc_probe never ran in the field
because its exec bit was lost through module extraction ("not bundled").

## The fix (v52)

1. **The two constants are corrected** to the CLI wire ABI. Nothing else
   in the accept path changes - same clang entry, same calibrated uid
   gate, same ladder, same self-test.
2. **A wire-dispatch lock** (`scripts/build_v52_verify.py`) now
   disassembles the merged .ko's `susfs_sc_entry` at build time and
   requires `0x555e2 -> sc_v51_answer_features` and
   `0x555e3 -> sc_v51_answer_str` in the machine code. Internal
   consistency can drift again; the wire cannot.
3. **The host test gained literal-id cases** (section 4b): the exact
   bytes the stock CLI sends, asserted against the exact answer shapes.
4. **sc_probe is now field-installed**: post-fs-data copies it to
   `/data/adb/ksu/bin/sc_probe` (chmod 755, the same field-proven
   contract as the CLI), and the self-test runs it from there first. The
   raw-syscall verifier that always had the right table finally runs on
   every box.

## Field procedure

Flash v52. The 51->52 upgrade re-bases the stage ladder automatically
(arm_stage=0, stage_max=3): **4 reboots in-place** (0 -> 1 -> 2=OBSERVE ->
3=FULL). On a fresh instance the substep ladder also starts from 0 - the
full 10-boot climb, exactly your standard test.

At stage 3 the self-test should print:

```
-- ksu_susfs show version (timeout 3):
v2.3.0
-- ksu_susfs show variant (timeout 3):
GKI-LKM
-- ksu_susfs show enabled_features (timeout 3):
SUSFS_LKM_MODULES
CONFIG_KSU_SUSFS_SUS_MOUNT
CONFIG_KSU_SUSFS_ENABLE_LOG
CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
CONFIG_KSU_SUSFS_OPEN_REDIRECT
CONFIG_KSU_SUSFS_SUS_MAP
```

(exact feature list depends on the armed layers; the five gated entries
above are the stage-3 armed set.) One wedge boot maximum by design; after
ANY wedge send back the five logs (logs/init_trace.txt + logs/diag_last.txt
+ logs/boot.log + logs/kernel_facts.txt + logs/sc_selftest.txt).

# v26.11.51 - THE CLANG ACCEPT PATH (2026-11-25)

## The v50 field verdict (your 10-reboot run)

The ladder did exactly what it was built to do:

- **Stage 2 (boot 440a678a) PROVED the clang entry under live fire**: the
  patched `sys_call_table[173]` entry ran for a whole boot (counter
  increments, `-EINVAL` answers, full 40s heartbeat window, clean handoff).
- **Stage 3 (boot 777e7068) died at the first `ksu_susfs show version` of
  the self-test** - i.e. at the FIRST EXECUTION of the v49 GCC-compiled
  `susfs_sc_wrapper`. The stand-down worked as designed: the next boot
  read the stale `try 3` marker, demoted to stage 0, capped stage_max at 2,
  and the box came back clean.
- v47's transport never went live (dead code), v48/v49 died at their first
  dispatched syscall(173) - which was ALSO the wrapper's first execution.
  **3 transport generations, 7 wedge boots, one common factor: the
  wrapper.**

## What the binary analysis found

The wrapper's common path contains exactly one never-field-proven memory
access: `current->cred` at a **hardcoded header offset (0x788)** compiled
from vanilla 5.15.178 `task_struct` layout. The target kernel is
LDPlayer 14's `5.15.178+` (Android clang-17, +LTO +PGO +BOLT, custom
config) - its struct layouts match no published tree. The module's 20+
other `0x788` readers all sit in code that never ran at runtime (the
passive gate layers, the retired stage-4/5 layers, the feature handlers),
and the module carries **no `__ex_table`**, so a wrong-slot read
dereferenced as a pointer is an unhandled kernel fault on a
panic-on-oops kernel. That is a precise, sufficient wedge mechanism, and
it is gone in v51 - whether or not it was THE one, because:

## The v51 fix

**The v49 GCC wrapper is never called.** The whole accept path is clang-17
(the compiler family that built the target kernel), grafted onto the
field-proven v49 object exactly like v50:

1. **Entry**: the v50 shape byte-for-byte (endbr64, genuine kCFI
   preamble, 16-byte clone of the original entry's window, locked
   counter, observe = `-EINVAL`).
2. **Magic check** on the same pt_regs offsets the ABI defines.
3. **uid gate through a RUNTIME-CALIBRATED cred offset** - no
   header-derived struct offsets on the syscall path:
   - scan `init_task` (kallsyms: 0xffffffff822127c0) for the one
     adjacent `(real_cred, cred)` pair both equal to `&init_cred`
     (0xffffffff82238f30) - true for the idle task for the whole boot;
   - verify `struct cred`'s uid offset against init_cred's own bytes
     (usage small-positive at +0, uid/gid/suid/sgid/euid/egid/fsuid/fsgid
     at +8..+0x28 all zero, because init_cred IS root:root);
   - every step leaves a diag receipt; ANY failure (symbol missing, not
     exactly one pair, sanity failed) just refuses to answer - the box
     stays alive and the receipts say why. The success receipt also
     prints whether the calibrated offset differs from the old hardcoded
     0x788 - direct evidence for the wedge attribution.
4. **SHOW_VERSION / SHOW_VARIANT / SHOW_ENABLED_FEATURES answered
   in-graft** through the kernel's own out-of-line
   `_copy_from_user`/`_copy_to_user` (both in this kernel's kallsyms;
   SMAP/SMEP are off on this box per /proc/cmdline). The 8196-byte
   features answer is copied in 256-byte chunks - no big stack frames on
   the syscall path.
5. **Feature commands answer not-handled this rung** (`-EINVAL`; the CLI
   keeps its pre-seeded 126 sentinel and exits nonzero; the apply scripts
   skip gracefully). Forwarding them to the v49 handlers is the NEXT
   rung, one class at a time, after this one survives.

Layout hardening the build verifier caught (and now enforces): the graft
contributes **zero `.bss`** - its two state vars ride in `.data` - so the
merged `.bss` stays byte-identical to the field-proven image and the
android struct-module spill window (`.bss[0..0x40)`, the v44 evidence)
keeps landing on the sacrificial stomp pad instead of on v51's
calibration vars.

Also: the default LKM candidate chain now tries the **vanilla image
first** - the android13 image ENOEXECs on this box on every single
attempt (one wasted insmod + a scary "Skipping invalid relocation" kernel
warning per boot). That noise is gone.

## Field procedure

Flash over v50. The 50->51 upgrade re-bases the ladder automatically
(arm_stage=0, stage_max=3). Keep `enable_lkm` + `enable_force_init`
present. **Expect 4 reboots**: stage 0 (evidence) -> 1 (layers) ->
2 (OBSERVE - the proven rung) -> 3 (FULL - `ksu_susfs show version`
ANSWERS for the first time on this box; the self-test receipt shows the
version string `v2.3.0`, variant `GKI-LKM`, and the armed feature list).
One wedge boot maximum by design; after ANY wedge send back the five logs
(logs/init_trace.txt + logs/diag_last.txt + logs/boot.log +
logs/kernel_facts.txt + logs/sc_selftest.txt).

The stage-3 boot's diag receipts to look for: `v51 calibrate:
task_struct.cred at +0x...` (the calibrated offset, and whether it
matches or differs from 0x788), and `v51 transport LIVE ... uid gate
CALIBRATED`.

# v26.11.50 - THE CLANG ENTRY (2026-11-25)

## What changed

- **The landing function is now compiled by clang-17.** All 27 prior builds
  were GCC products on a clang-17 LTO + kCFI kernel; the module's
  `.comment` section proves it (`GCC: (Debian 14.2.0-19) 14.2.0`). The v50
  entry (`susfs_sc_entry`) is a real clang function with a genuine kCFI
  preamble for `long (const struct pt_regs *)` - clang emits the 16-byte
  preamble block (nop padding + `movl $typeid, %eax`) exactly like the
  kernel's own syscall entries.
- **The installer clones the original entry's entire 16-byte preamble
  window.** v49 copied only the 4 bytes at `[entry-4]` (verified readback:
  0xebebffff) and the box still froze at the first dispatched syscall(173).
  Whatever the dispatch inspects - hash at -4, opcode at -5, a wider
  custom-offset pattern - the original entry passes it; v50 makes our
  entry's window byte-identical to the original's, so every check the
  original passes, ours passes. Clone + byte-exact readback happen BEFORE
  the table write.
- **Stage-2 observe is minimal.** Counter increment (`lock incl` on the
  `sc_entry_count` param) + `-EINVAL`. No printk, no `current` read, no
  forwarding, no dispatch. The full v45-proven wrapper (magic check, uid
  gate, command dispatch, payload.err answers) runs only from stage 3.
- **The installer refuses instead of guessing.** Any unproven condition
  (table not the live one, entry not the real ioperm, landing pad not
  intact, clone write failed/not sticking) logs a full receipt and leaves
  the module loaded with the transport not installed. Layer 17 returns 0
  on refusal (it is a FATAL layer; an error return would refuse the whole
  module load and un-arm every working layer).

## Graft mechanics (why the module is still the field-proven v49 object)

The v49 `.ko` is an ELF relocatable object. `build_v50_ko.sh` weakens the
three overridden symbols (`susfs_sc_entry`, `susfs_supercall_init`,
`susfs_supercall_exit`) in the base, globalizes four `.bss` state vars
(`sc_orig`, `sc_installed`, `sc_full_mode`, `susfs_sc_entry_count`), and
links the clang graft FIRST with `ld -r`: the linker keeps the first
definition of each symbol, so every reference - the `susfs_layers[]`
function pointers in `susfs_main.c` included - binds to the clang graft,
and the old (dead) definitions are dropped. Verified invariants
(`build_v50_verify.py`): vermagic byte-identical, this_module size
unchanged, imports EXACTLY the v49 124, `.bss` stomp pad at offset 0 with
all spill-window vars past +0x40, wrapper body untouched.

## Field procedure (unchanged from v49)

Flash over v49. The 49->50 upgrade re-bases the ladder automatically
(arm_stage=0, stage_max=3). Keep `enable_lkm` + `enable_force_init`
present (they are - the module never removes them unless a stage-0 boot
itself wedges). Expect 4 reboots: stage 0 (evidence) -> 1 (layers) ->
2 (OBSERVE - the first live fire through the clang entry; the self-test
reads sc_entry_count before/after) -> 3 (FULL - `ksu_susfs show version`
answers). One wedge boot maximum by design; after ANY wedge send back the
five logs (logs/init_trace.txt + logs/diag_last.txt + logs/boot.log +
logs/kernel_facts.txt + logs/sc_selftest.txt).

# ReSuSFS x86_64 - v26.11.49

## v26.11.49: THE kCFI PREAMBLE FIX - the five v48 first-dispatch deaths, convicted and closed

The v48 field run (five boots, 2026-11-24 11:00-11:11) ended in the tightest
failure signature of the whole campaign, and this build closes it:

1. **The signature.** Every v48 boot completed init (`RETURNING 0`,
   `transport LIVE`, 10 layers armed) and then died 2-5 seconds later. The
   last boot.log line of every single boot was
   `supercall self-test starting` - the box died at the FIRST
   `syscall(173)` ever dispatched through the patched
   `sys_call_table[173] = susfs_sc_entry`. The witness and the 5s heartbeats
   died with it (kernel-level death, not a userspace hang), and the frozen
   launcher on screen is the last framebuffer.
2. **The discriminator.** The v47 boots (x9/x10) issued the SAME syscalls
   through the SAME call site with the ORIGINAL entry and returned -EINVAL
   three times per boot, box healthy. The only difference in v48 was the
   TARGET of the indirect call - which means the call site inspects the
   target before calling it.
3. **The mechanism.** This clang-17 LTO kernel enforces kCFI (kallsyms
   carries `is_cfi_preamble_symbol` and `cfi_suffix` - the kCFI kallsyms
   machinery; the module's own `__nocfi` conventions exist for exactly this
   kernel). The LIVE dispatch path is KernelSU-Next's `my_x64_sys_call`
   (kernel/hook/x86_64/syscall_hook.c) - which is NOT `__nocfi` - so its
   `ksu_syscall_table[nr](regs)` is type-checked on every dispatch: each
   legitimate entry carries the 4-byte type hash immediately BEFORE its
   address. v48 installed a raw-asm thunk with NO preamble: the first
   dispatch read `[susfs_sc_entry - 4]` (arbitrary module text), the compare
   failed, and the kernel died - five out of five boots. (The alternative
   KSU patch target, `my_do_syscall_64`, IS `__nocfi` - but the field proves
   the checked `my_x64_sys_call` path is the live one on this box; the v49
   entry satisfies both shapes.)
4. **The fix.** `susfs_sc_entry` now has a 4-byte kCFI preamble slot
   (`susfs_sc_kcfi_preamble`) at exactly `entry - 4`. At install time the
   module reads the 4 bytes at `[original table[173] entry - 4]` - by
   construction the exact type hash this call site already accepts -
   cross-samples sibling entries for the receipt, replicates the hash into
   its own slot via `ksu_patch_text` (fixmap write; module .text is RO after
   load; verified read-back), and only then patches the table entry. On a
   kernel WITHOUT kCFI the replicated word is inert dead bytes before the
   entry, never executed - the transport is safe under both CFI regimes.
   Every step lands in `diag_log` (kCFI detection, the sampled hash, the
   replicated word, and now ALSO the table index where
   `ksu_syscall_dispatcher` sits).

### The v49 ladder hardening (the wedge-loop hole, closed)

- **Re-base on upgrade.** v47 -> v48 carried the ladder over (a transport-fix
  upgrade); v48 -> v49 deliberately RE-BASES it (`arm_stage=0`, `stage_max=3`):
  the transport itself changed, so every rung re-validates under the live-fire
  self-test. Expect FOUR reboots to re-climb: stage 0 (evidence), 1 (fp/umount/
  allow gates), 2 (transport OBSERVE - the self-test fires the first real
  syscall(173) through the patched entry, answers nothing by design, and
  `sc_entry_count` MUST move), 3 (transport FULL - `ksu_susfs show version`
  must answer).
- **Deferred confirmation.** The v48 wedge LOOPED because each wedged boot
  had already written its `ok` marker before the self-test ran (the
  confirmation preceded the risk). v49 boot-completed defers the ladder
  confirmation of any transport-armed boot (stage >= 2) until AFTER the
  supercall self-test survives. A wedge at the self-test leaves the `try`
  marker stale, and post-fs-data's existing demotion caps the ladder below
  the rung on the next boot: one wedge boot maximum, never a loop.
- Everything else is unchanged: the two-step opt-in
  (`enable_lkm` + `enable_force_init`), the substep ladder (already at 7),
  witness + heartbeats, the WEDGE DOSSIER, the CLI self-heal (rides syscall
  173, byte-identical to v48's), `sc_probe`, the vanilla-default +
  android13-rollback candidates (both rebuilt with the preamble).

### The honest limits (unchanged)

`sus_path` file-hiding, the LSM class, uname and kstat stay retired: the v45
field verdict convicted those layers on their own hot paths, with no supercall
involved. `ksu_susfs` answers only from stage 3 (accept). The stage-4
independent lethality stays unexplained and is NOT this build's question.

---

## v26.11.48: THE LIVE-TABLE TRANSPORT FIX (history - superseded by v49's kCFI preamble; the field convicted the missing preamble within five boots)

The v47 campaign (10 boots, 09/10 clean, 2026-11-24) ended with a split verdict
that this build resolves:

1. **The v47 transport installed and NEVER FIRED.** Both transport boots
   (stage 2 OBSERVE at 08:42, stage 3 FULL at 08:46) show `transport LIVE - 1
   arm(s) redirected (patched 1)` with a verified read-back - and
   `sc_entry_count` frozen at 0 before AND after the self-test, with no
   `sc OBSERVE` line anywhere in dmesg. The patched arm is dead code: this
   kernel's BUILT-IN KernelSU-Next carries
   `CONFIG_KSU_X86_PATCH_SYSCALL_DISPATCHER` (kallsyms: `x64_sys_call_patch_addr`,
   `do_syscall_64_patch_addr`, `my_x64_sys_call`, `my_do_syscall_64`,
   `ksu_syscall_dispatcher`), and at boot its `ksu_syscall_hook_init()`
   patch_abs_jump()'s `do_syscall_64` (and `x64_sys_call`) so that EVERY
   syscall dispatches through `my_do_syscall_64 -> my_do_syscall_x64 ->
   ksu_syscall_table[nr](regs)`. `x64_sys_call()` - whose ioperm arm v47
   patched - is bypassed entirely. The v47 premise "sys_call_table[] is no
   longer used for system calls" is vanilla-5.15 truth that KernelSU-Next
   itself inverted on this kernel: **the table IS the live dispatch path.**
2. **The CLI that ran was never ours.** The self-test invokes
   `/data/adb/ksu/bin/ksu_susfs`, which on this box is a symlink the old
   installer rule deliberately kept ("never overwrite what that LKM ships") -
   the STOCK reboot(169)-riding `ksu_susfs` from the pre-campaign
   susfs4ksu-module install. Proof from the CLI's own failure taxonomy: the
   field output was the BARE line `susfs: show version failed`, which our
   freestanding CLI prints only when the syscall returned 0 with an untouched
   payload (the 126 seed) - impossible for our 173-riding CLI in ANY transport
   state (real ioperm returns -EINVAL -> the suffixed line; observe-mode
   passthrough -> the suffixed line; full mode -> an answer).

### The v48 fixes

- **Kernel**: `sys_call_table[173] = susfs_sc_entry` - an 8-byte DATA write
  through the fp_hook layer's field-proven entry patcher (publish-orig, write
  via `ksu_patch_text`, verify read-back, restore-on-exit). This is the exact
  mechanism class KernelSU-Next itself uses on this kernel (its dispatcher
  slot is a patched table entry). A pre-patch liveness proof refuses the write
  unless `ksu_syscall_dispatcher` is found IN the table (proving the table is
  the live path); the v47 arm scan stays compiled in as a fallback for a
  hypothetical kernel where the table is inert. The wrapper is UNCHANGED -
  same signature as every table entry (`long (*)(const struct pt_regs *)`),
  entered via a 2-instruction endbr64 thunk, answers in `payload.err` and the
  syscall return, passthrough to the saved original entry. NO kprobe anywhere;
  KernelSU's reboot slot untouched, exactly as v47.
- **Userspace**: the installer no longer keeps a stale `ksu_susfs` at
  `/data/adb/ksu/bin` - it force-installs the module's own 173-riding CLI
  (one-time backup of whatever was there, at
  `/data/adb/ReSuSFS/ksu_susfs.pre-v48.bak`), and `post-fs-data` re-verifies
  the bytes EVERY boot (the same self-heal contract as the LKM payload stamp),
  so a manager-side refresh can never silently re-dowse the channel.
- **Receipts**: the self-test prints the invoked CLI's sha256 and also runs
  the bundled `sc_probe` (a freestanding binary that speaks the v48 ABI
  directly and prints the raw syscall rc, payload.err and the counter before/
  after - a CLI-independent view of the channel).
- **Ladder**: v26.11.47 -> v26.11.48 carried the rungs over (historical;
  v48 -> v49 re-bases instead - see the v49 section above: the carried-over
  stage-3 state is exactly what made the v48 wedge re-arm itself every boot).

### The honest limits (unchanged)

`sus_path` file-hiding, the LSM class, uname and kstat stay retired: the v45
field verdict convicted those layers on their own hot paths, with no supercall
involved. `ksu_susfs` answers only from stage 3 (accept). The stage-4
independent lethality stays unexplained and is NOT this build's question.

---

# ReSuSFS x86_64 - v26.11.47 (previous build, kept for the record)

## v26.11.47: THE TRANSPORT BUILD - the supercall channel goes live on a no-shared-slot inline memory hook

v46 parked the ladder at stage 1 with the supercall channel dark: every runtime
configuration list (sus_map, sus_mount, open_redirect, prop_view, ...) stayed
empty because the only transport that ever reached a live fire - a plain kprobe
on `__x64_sys_reboot` - froze the box sharing KernelSU's own kprobe slot.
v47 replaces the transport class outright so the ladder can re-open.

### Why the two obvious transports are dead on this kernel

1. **sys_call_table[] entry replacement** (the arm64 SUSFS/KernelSU technique,
   and this module's own fp_hook layer): INERT here. Since the Retbleed-era
   hardening (present in 5.15.178), `arch/x86/entry/common.c` does
   `regs->ax = x64_sys_call(regs, nr)` - and `x64_sys_call()` is a direct-call
   switch (see `arch/x86/entry/syscall_64.c`: *"The sys_call_table[] is no
   longer used for system calls, but kernel/trace/trace_syscalls.c still wants
   to know the system call address"*). Writing table[169] changes what a tracer
   reports, not what the CPU executes. (This also retro-explains why the
   stage-5 "table writer" layers could never have worked here.)
2. **An inline hook on `__x64_sys_reboot` itself**: KernelSU's reboot kprobe is
   JUMP-OPTIMIZED on this box (`kprobes: kprobe jump-optimization is enabled`),
   i.e. the wrapper's first bytes are already a kernel-rewritten detour jump -
   patching them is strictly worse than the shared kprobe slot we retired.
3. **A kprobe on any other syscall**: still probe-class - kprobe-context
   pre_handler, no copy_to_user, no sleeping, answers only via task_work.

### The v47 transport: redirect the hardened dispatcher's COLD arm

Same class as KernelSU's own `KSU_X86_PATCH_SYSCALL_DISPATCHER` ("dynamically
patches the hardened syscall dispatcher at runtime so the syscall hook can
work") - applied to ONE cold arm:

- The supercall's syscall number moves from reboot(2) (169 - hot, KernelSU's
  own supercall rides it) to **ioperm(2) (173)**: an x86-only legacy port-I/O
  syscall that nothing in Android userspace issues. `__x64_sys_ioperm` is a
  real standalone handler on this box (kallsyms `0xffffffff81027650`, its own
  `ksys_ioperm` at `0xffffffff810274a0`, not a `__do_sys_ni_syscall` alias).
  The dispatcher arm for it executes ONLY when something deliberately calls
  `syscall(173, ...)` - i.e. only our CLI.
- At init the module scans kernel text `[__stext, __etext]` for every E8/E9
  rel32 branch whose target is `__x64_sys_ioperm` - that is the dispatcher's
  arm wherever clang-LTO/BOLT laid it, in every dispatcher copy at once - and
  rewrites each 4-byte rel32 through `ksu_patch_text()` (phys_from_virt ->
  FIX_BTMAP fixmap -> copy_to_kernel_nofault under stop_machine - the same
  bmax121/KernelSU-Next primitive this module has carried since v40) so the
  arm tail-jumps into the module's `susfs_sc_wrapper`.
- The wrapper runs in REAL SYSCALL PROCESS CONTEXT (it is the tail callee of
  the dispatcher arm): `current` is the caller, copy_to_user works, and its
  return value lands in `regs->ax` exactly as the original handler's would.
  Magic mismatch / non-root / unarmed command -> tail-call the saved original
  handler (a genuine ioperm(2) behaves exactly as built). **No kprobe is
  registered anywhere; reboot(2) is not on this path at all.**
- The CLI moves with the number: ksu_susfs's nine syscall sites are patched
  `mov eax,0xa9` -> `mov eax,0xad` (169 -> 173, same instruction length);
  the payload.err answer contract is unchanged (v45 already taught the CLI to
  read payload.err; v47 additionally returns 0 for handled commands).

### The v47 ladder

- stage 2 = transport installed, OBSERVE-ONLY (logs sightings, passes
  everything through; the self-test proves the patch + first live fire).
- stage 3 = transport ACCEPTS: `ksu_susfs show version / variant /
  enabled_features` answer, and the runtime-configurable layers become
  drivable from the CLI (sus_map, sus_mount, open_redirect, prop_view,
  uname, kstat, cmdline, avc_spoof, enable_log).
- stages 4/5 = PERMANENTLY RETIRED: the v45 field verdict froze the box on
  those layers with NO supercall involved (lsm_hook/sus_path/uname/hide_syms
  hot paths), and the stage-5 table writes would be inert on this kernel
  anyway. `stage_max` is re-based to 3 on upgrade; the wedge responder and
  the stand-down machinery are unchanged.

### What to expect when flashing v47 over v46

1. First boot: module version changed -> ladder re-based to stage 0,
   substeps climb on the same proven cadence (substep 0..7, ~7 boots if the
   substep ladder was already complete, it re-runs at the current seq).
2. Then stage 1 (10 layers) -> stage 2 (OBSERVE transport boot; the self-test
   fires the first live supercall through the cold arm - watch dmesg for
   `sc OBSERVE: susfs supercall seen`) -> stage 3 (ACCEPT; the self-test
   receipt in logs/sc_selftest.txt now shows the version/variant/answers).
3. Parking: `arm_stage 3 healthy - at ladder max 3 (the v47 ceiling)`.

### If a v47 boot wedges

The stand-down machinery behaves exactly as v45/v46: the next boot writes the
WEDGE DOSSIER into boot.log, demotes to a stage-0 evidence boot and caps the
ladder below the wedging rung. Send back the five logs:
`logs/init_trace.txt`, `logs/diag_last.txt`, `logs/boot.log`,
`logs/kernel_facts.txt`, `logs/sc_selftest.txt`.

The module's own receipts (init_trace / diag_last) now name the transport
steps: `scanning kernel text [_stext ... _etext)`, `scan found N arm(s)`,
`arm at 0x... redirected -> susfs_sc_wrapper`, `transport LIVE - N arm(s)
redirected ... no kprobe registered anywhere`. A clean REFUSAL with a receipt
(`NO direct arm to __x64_sys_ioperm found`) means this kernel's dispatcher is
not direct-call shaped - that receipt is the input a v48 table-entry patch
would need.

---

# ReSuSFS x86_64 - v26.11.41

## v26.11.41: THE FREEZE NOW NAMES ITSELF (watchdog removed, codegen reverted, sentinel witness)

The v40 field result (2026-11-23 09:01:32, from your uploaded boot.log +
init_trace.txt): the box froze AT the `force_init` sysfs write.

```
[09:01:32] init-trace: writing force_init=1 (dispatching the deferred kworker)
[09:01:32] boot-completed: triggering force_init (deferred kworker; substep 0; ...)
                      <-- NOTHING AFTER THIS. No "force_init write returned",
                           no poller line, box hard-frozen, instance restart.
```

That write is the **first module code the whole boot executes**: under the
ksud zombie load `do_init_module` never ran the module's init, and the
earlier param writes (kr_seed, arm_stage, init_maxstep) are pure *kernel*
`param_ops_*` code, not this module's code. The v39 boot froze at the same
boundary with essentially the same image. The next boot's stand-down then
removed both flags, printed the WEDGE DOSSIER and suppressed the trigger -
**the recovery path is now field-proven**, and the module image itself
(loaded, zombie, init never triggered) has never taken a boot down.

What the v40 evidence could NOT do was say WHERE inside that boundary the
freeze sat: the receipts ended before the echo and the poller only starts
after it. v41 closes that gap and removes every identified suspect at once.

### What v26.11.41 changes

* **THE KERNEL-SIDE WATCHDOG IS REMOVED.** The v40 `panic`-on-stall delayed
  work (`wd_timeout_s`) never fired (the box froze *without* rebooting, so
  there was nothing for it to reboot), ran inside the very boundary it
  existed to instrument, and was the only unproven-call path in substep 0:
  `schedule_delayed_work`/`cancel_delayed_work_sync` pull
  `queue_delayed_work_on`, `cancel_delayed_work_sync`,
  `__msecs_to_jiffies` plus the brand-new `panic` import - none of them ever
  field-called before v40. Recovery is the proven userspace pair: the next
  boot's stand-down. `panic` drops out of the import set entirely.
* **THE CODEGEN IS REVERTED TO THE PROVEN PROFILE.** The v40 .ko was built
  with `RETHUNK=y`: all 446 function returns compiled as
  `cs jmp __x86_return_thunk` - i.e. every function return in the module
  jumps through a loader-absolutized import. The v26.11.26-37 vanilla image
  that ran module code live in the field (the v35 trigger ran the init body
  to ~50% of the layer loop) returned with plain `ret`. v41 builds with
  `RETPOLINE=n RETHUNK=n`: **zero return thunks**, plain `ret`s,
  `__x86_return_thunk` also drops out of the import set. The vermagic is
  unchanged (`5.15.178+ SMP preempt modversions`); the 123 remaining
  imports were all re-verified **present AND unique** against your uploaded
  field `kernel_kallsyms.txt` (99296 kernel records).
* **SENTINEL CODES + A BACKGROUND WITNESS.** `init_laststep` now carries
  boundary markers the userspace can see in real time:

  | value | meaning |
  |-------|---------|
  | `-1` | fresh module, trigger not run yet |
  | `-100` | the `force_init` setter ENTERED - the first module code |
  | `-101` | setter finished DIAG, about to `queue_work` the kworker |
  | `0` | the kworker is inside `susfs_init_body` |
  | `1..7` | inside substep N's own calls |

  `boot-completed.sh` now starts a **background witness BEFORE the
  `force_init` echo** (the v40 poller started after the echo that never
  returned) that mirrors every `init_laststep`/`init_done` change into
  `logs/init_trace.txt` with a `sync` per receipt, and snapshots
  `diag_log` to `logs/diag_last.txt`. A freeze therefore localizes itself
  ON DISK:
  witness stuck at `-1` = froze before any module code (kernel sysfs
  machinery, not the module); `-100` = in the setter's first calls;
  `-101` = at the `queue_work` dispatch; `0` = in the kworker's first
  statements; `N` = in substep N.
* **THE LADDER IS UNCHANGED.** `init_seq` 0..7 (0 = kworker dispatch proof
  only, 1 = +imports_guard, 2 = +resolver with the `kln=`/`gsoff=` seed,
  3 = +gs_off, 4 = +dead-man, 5 = +crosscheck, 6 = +patch_memory,
  7 = +layer loop with `arm_stage` 0..4), one rung per healthy boot,
  next-boot stand-down on a wedge, WEDGE DOSSIER into boot.log, payload
  stamp `v26.11.41` so a v41 flash refreshes the device image (the
  boot-time self-heal fires on stamp mismatch too).
* **THE COLLECTER'S `force_init` MISREAD IS FIXED.** `force_init` is
  deliberately `0200` (write-only): a *read* fails with EACCES, which the
  v40 collector printed as "param not exposed - fallback image". It now
  checks presence with `-e` and explains the mode. (`wd_timeout_s` is gone
  with the watchdog - reported as such.)

### Testing v26.11.41 (same two-step opt-in as v38..v40)

```
1. flash ReSuSFS-x86_64-v26.11.41.zip (KernelSU manager -> install from storage)
   - or adb:  adb push ReSuSFS-x86_64-v26.11.41.zip /data/adb/... then flash
2. adb shell "su -c 'touch /data/adb/ReSuSFS/enable_lkm'"
3. adb shell "su -c 'touch /data/adb/ReSuSFS/enable_force_init'"
4. reboot and let the boot COMPLETE (home screen visible)
5. watch:   adb shell "su -c 'tail -n 30 /data/adb/ReSuSFS/logs/init_trace.txt'"
```

Substep 0 runs on the first armed boot. Expected healthy sequence in
`init_trace.txt`:

```
STEP 0/7 DISPATCHING ...
seed v2 written: kln=... gsoff=...
writing arm_stage=0 (layer gate)
writing init_maxstep=0 (substep gate)
witness(bg): laststep=-1 init_done=0 @0s
writing force_init=1 (... sentinels: -100=setter entered, ...)
witness(bg): laststep=-100 init_done=0 @1s     <-- module code started
witness(bg): laststep=-101 init_done=0 @1s     <-- work queued
witness(bg): laststep=0 init_done=1 @2s        <-- kworker ran the body
force_init write returned (kworker scheduled)
STEP 0 COMPLETE (init_done=1 ...) - next boot runs substep 1/7
```

If the box freezes again, reboot/restart the instance - the next boot stands
down and prints the WEDGE DOSSIER, and the last `witness(bg)` receipt in
`init_trace.txt` names the exact boundary per the table above. Then send
back the four files: `logs/init_trace.txt`, `logs/diag_last.txt`,
`logs/boot.log`, `logs/kernel_facts.txt`.

---

# ReSuSFS x86_64 - v26.11.38

## v26.11.38: KERNEL-FACTS + SEEDED RESOLVER + POST-BOOT TRIGGER

The v26.11.37 result: a stage-0 evidence boot - imports guard, the kallrecon
auto-discovery SCAN and the DIAG printk, nothing else armed - STILL wedged the
box. Three conclusions drove this release:

1. The wedge lives inside that three-mechanism set. The scan is the only
   unbounded-ish, layout-guessy kernel-side work in it; the printk is the only
   thing that runs unconditionally before everything else; and the trigger
   itself ran DURING boot, which is why the boot animation froze at 50%.
2. The port has been building and debugging against a GUESSED kernel. The
   guide's Phase 0 (compiler string, IKCONFIG config, kallsyms layout, KSU
   variant) was never collected; Phase 1 (ymuuuu's prebuilt GKI
   android13-5.15 x64 ko) was never tried; Phase 2 (build against the exact
   android13-5.15-2025-03 source) was never done. v38 does all three.
3. Whatever wedges, the evidence now has to survive and the boot must not.

### What v26.11.38 changes

* **THE TRIGGER MOVED OUT OF THE BOOT.** `susfs_init` now runs in
  `boot-completed.sh` - after `sys.boot_completed`, on a fully booted,
  usable system. A wedged init can no longer freeze the boot animation at
  50%; the worst case is a frozen desktop with adb alive, evidence already
  on disk, and the ladder demotes + caps the next boot on its own.
  The trigger is additionally opt-in via a NEW second flag:
  `touch /data/adb/ReSuSFS/enable_force_init`
  (`enable_lkm` alone now keeps the module in its PROVEN-SAFE zombie image
  state, exactly the state v25..v37 booted fine with).
* **THE MEMORY SCAN IS OFF BY DEFAULT.** The resolver is SEEDED instead:
  `boot-completed.sh` greps the kernel's own kallsyms TABLE addresses out of
  `/proc/kallsyms` (they are public symbols: `kallsyms_offsets`/
  `kallsyms_addresses`, `kallsyms_relative_base`, `kallsyms_num_syms`,
  `kallsyms_names`, `kallsyms_markers`, `kallsyms_token_table`,
  `kallsyms_token_index`) and writes them into the new `kr_seed` module
  param. kallrecon then only VALIDATES the tables with bounded
  `copy_from_kernel_nofault` reads - no scanning. Without a seed and
  without an explicit `kr_scan=1` the resolver REFUSES (-ENODATA) instead
  of scanning. The v37 stage-0 wedge sat exactly in the class this removes.
* **MODULE PRINTK IS OFF BY DEFAULT.** `diag_printk` param (default 0) gates
  every DIAG/`pr_err`/raw-printk path, and `enable_log` now defaults OFF at
  load. The v35-era "printk is suppressed by KernelSU" observation was
  equally consistent with "printk wedged the kernel before dmesg could be
  read" - and printk is the ONE thing that ran unconditionally at step 1 in
  every wedged boot since v33. Crumbs now go to the `diag_log` param only,
  which the sysfs channel (proven working: every force_init write arrived)
  exposes.
* **PHASE-0 KERNEL RECON, EVERY BOOT.** post-fs-data writes
  `logs/kernel_facts.txt` (+`kernel_kallsyms.txt`, +`kernel_config.txt`):
  `/proc/version` compiler string, osrelease, taint, getenforce, key
  sysctls, ksud availability + variant hints, BTF dir, IKCONFIG config (when
  `/proc/config.gz` exists), `/proc/modules`, and the kallsyms layout
  markers (table symbols, `.cfi_jt` count, `current_task`/`fixed_percpu_data`
  ground truth). Collected BEFORE any LKM action, so even a wedged boot
  leaves the facts on disk.
* **THREE LKM CANDIDATES** switchable at runtime via
  `/data/adb/ReSuSFS/lkm_candidate` (default `android13`):

  | value | .ko | origin |
  |-------|-----|--------|
  | `android13` | `susfs_guard_lkm-x86_64-android13-5.15.ko` | **built against AOSP kernel/common `android13-5.15` at tag `ASB-2025-03-05_13-5.15`** - the March 2025 android13-5.15 release (5.15.178), the exact lineage the port guide identified for LDPlayer 14's `5.15.178+` kernel (Phase 2) |
  | `vanilla` | `susfs_guard_lkm-x86_64-vanilla-5.15.ko` | kernel.org linux-5.15.178 build - the v26.11.26..37 image, empirically config-matched (RETPOLINE/STACKPROTECTOR/HARDENED_USERCOPY/X86_5LEVEL/RANDOMIZE_MEMORY/MODULE_UNLOAD off, vermagic byte-identical) |
  | `ymuuu13` | `ymuuuu_android13-5.15_susfs_guard_lkm.ko` | ymuuuu's prebuilt GKI android13-5.15 x64 ko, live-tested on emulator GKI kernels (Phase 1 - "the cheap shot") |

  `echo vanilla > /data/adb/ReSuSFS/lkm_candidate` (or `android13`/`ymuuu13`)
  then reboot. Note: `ymuuu13` has NO `force_init`/`kr_seed` params (upstream
  image, normal init path) - it is the "does a known-good GKI x64 image even
  behave the same here" experiment, not a bring-up candidate for the ladder.

### The bring-up ladder (v37 semantics, relocated)

```
touch /data/adb/ReSuSFS/enable_lkm          # 1. load the image (zombie, safe)
touch /data/adb/ReSuSFS/enable_force_init  # 2. opt into the post-boot init
reboot                                     # 3. stage 0 runs AFTER the boot completes
# ... watch it climb one rung per healthy boot (~5 boots to full susfs):
adb shell su -c "cat /data/adb/ReSuSFS/arm_stage /data/adb/ReSuSFS/stage_max /data/adb/ReSuSFS/stage_boot"
adb shell su -c "tail -n 40 /data/adb/ReSuSFS/logs/boot.log"
```

Stage meanings (arm_stage): 0 = resolver-only evidence run (SEEDED,
printk-less); 1 = + resolve-only + `/proc` nodes; 2 = + supercall kretprobe
(the only kernel-text patch below 3); 3 = + lsm/sus_path/uname; 4 = full.

If a rung wedges the (already booted) box: power-cycle - the NEXT boot
demotes to stage 0 and caps `stage_max` below the wedging rung. If even a
stage-0 evidence run wedges, post-fs-data removes BOTH opt-in flags and
suppresses the trigger, so the box comes up clean with the evidence intact.

### Evidence to send back (from a wedged or healthy boot)

```
adb shell su -c "cat /data/adb/ReSuSFS/logs/kernel_facts.txt"   # Phase-0 facts (NEW - the big one)
adb shell su -c "cat /data/adb/ReSuSFS/logs/diag_last.txt"      # last breadcrumbs of the init
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"           # ladder transitions + seed + snapshots
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/diag_log"   # if the box is still alive
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/kr_seed"    # what was seeded
```

`kernel_facts.txt` finally answers the questions the port has been guessing
at: which compiler and config the LD kernel was built with (vanilla
kernel.org vs android13-5.15 lineage), whether BTF is available (exact
struct layouts at runtime), the kallsyms layout variant, and the KernelSU
variant - that picks the default LKM candidate for v39 and closes Phase 0.

### If a wedged init freezes the desktop (recovery)

```
adb root
adb shell rm -f /data/adb/ReSuSFS/enable_force_init   # stop the init experiment
adb shell rm -f /data/adb/ReSuSFS/enable_lkm          # also stand down the image load
adb reboot
```

Or just power-cycle: the ladder demotes + caps itself. If adb will not
connect, re-clone the LDPlayer instance - the evidence files survive under
`/data/adb/ReSuSFS/logs/` on the wedged instance's disk.

---

# ReSuSFS x86_64 - v26.11.37

## v26.11.37: EVIDENCE-FIRST STAGED BRING-UP

The v26.11.36 result: a fresh flash (no `/data/adb/ReSuSFS/arm_stage` file)
ran the stage-1 default - kallrecon resolver + `/proc` control nodes + the
supercall kretprobe on `__x64_sys_reboot` - and the boot **STILL wedged at
50%**. Two conclusions:

1. The wedge is inside the stage-1 set itself (resolver / current_task
   gs-off discovery / resolve-only layers / proc nodes / the kretprobe).
   Note the kretprobe had never been live-tested before v35: every earlier
   release loaded a zombie image whose init never ran at all.
2. Mechanism-class batching at that granularity could not attribute the
   wedge, and a default of 1 was too optimistic.

### What v26.11.37 changes

The old stage 1 is SPLIT, the kretprobe gets a rung of its own, and the
default drops to the floor that history has actually proven safe
(v25..v32: image load + params = boots fine; the resolver is read-only and
timeout-bounded):

| arm_stage | what arms | mechanism |
|-----------|-----------|-----------|
| 0 (DEFAULT) | nothing - imports guard, kallrecon resolver, current_task gs-off discovery, crosschecks | evidence mode, no layers, no kernel-text writes |
| 1 | + fp_hook (resolve only), ksu_umount_gate, ksu_allow_gate, sus_map, sus_mount, cmdline, open_redirect, prop_view, enable_log, avc_spoof | resolve-only + `/proc` nodes - no kernel text is touched |
| 2 | + supercall | **the `__x64_sys_reboot` kretprobe ALONE** - the only kernel-text patch below stage 3, on its own rung |
| 3 | + lsm_hook, sus_path (+ self-hide/relabel), uname, hide_syms | LSM hook insertion, kprobe on `kallsyms_op.s_show`, kretprobe on newuname |
| 4 | + create_gate, opath, dirent, kstat, sus_unix | full susfs - sys_call_table entry writes |

`arm_stage` defaults to **0 in the module image itself** (BSS, not `.data`),
so even a manual `insmod ... force_init=1` without the boot scripts lands on
the resolver-only floor.

### The ladder is self-managing (no more blind wedges)

* **service.sh** is the only writer of "healthy": after `sys.boot_completed`
  AND `init_done=1` it writes `ok N` to `/data/adb/ReSuSFS/stage_boot` and
  raises `arm_stage` by ONE rung (capped by `/data/adb/ReSuSFS/stage_max`).
  A wedge that manifests LATE in the boot (after init already reported done)
  can therefore never escalate past its rung.
* **post-fs-data.sh** writes `try N` before triggering `force_init`. If the
  next boot finds a leftover `try N` (the previous boot never completed),
  it demotes to a stage-0 evidence boot and caps `stage_max` at N-1 - the
  same wedge cannot recur blind, and the system regains function one proven
  rung per reboot.
* If even a stage-0 evidence boot wedges, the resolver class itself is
  broken on this kernel: post-fs-data removes `enable_lkm` automatically so
  the system boots without the module, and the evidence stays in the logs.

### Evidence survives the wedge now

While polling `init_done`, post-fs-data snapshots the module's `diag_log`
parameter to `/data/adb/ReSuSFS/logs/diag_last.txt` **every second it
changes** (and appends the final state to `boot.log`). printk from this
module is suppressed by KernelSU's hook and its `filp_open` is blocked, so
the module parameter is the only evidence channel - and it does not survive
a reboot unless copied out in time.

New breadcrumbs in v37 (all in `diag_log`):

* every init sub-step prints a crumb BEFORE running (so the last line
  always names the about-to-run function): `DIAG step 2/3/4a/4b/5/5a/6.N`
* the kallrecon resolver now drops phase crumbs: `resolver: pass 1
  starting`, `find_kallsyms_base() starting`, `pass 1 done`, `RETRY pass 2
  ...`, `resolver: ready (layout vN base=... num=...)`
* the supercall layer drops crumbs around the registration: `supercall:
  about to register_kretprobe on __x64_sys_reboot - THE ONLY text patch at
  stage 2` and `kretprobe REGISTERED (addr=...)`. If the box wedges right
  after the "about to" line, that layer is the culprit, identified.

### What to do

Flash, reboot, `touch /data/adb/ReSuSFS/enable_lkm`, then just REBOOT
REPEATEDLY. Each healthy boot raises the ladder one rung (~5 reboots to
full susfs). Watch it climb:

```
adb shell su -c "cat /data/adb/ReSuSFS/arm_stage /data/adb/ReSuSFS/stage_max /data/adb/ReSuSFS/stage_boot"
adb shell su -c "tail -n 30 /data/adb/ReSuSFS/logs/boot.log"
```

If a rung wedges: the boot stops there, `stage_boot` stays on `try N`, and
the NEXT reboot (no adb rescue needed - just reboot) comes up at stage 0
with `stage_max` capped at N-1. Then send back:

```
adb shell su -c "cat /data/adb/ReSuSFS/logs/diag_last.txt"       # last breadcrumbs of the wedged boot
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"           # stage transitions + diag_log final snapshot
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/diag_log"   # if the box is still alive
adb shell su -c "dmesg | grep -E 'XYZDIAG1|susfs_guard_lkm|ReSuSFS|DIAG step'"
```

The last breadcrumb before the wedge names the exact function that was
running when the kernel died.

### If a boot wedges (recovery)

```
adb root
adb shell rm /data/adb/ReSuSFS/enable_lkm
adb reboot
```

Keep `arm_stage` - the ladder self-manages (v37's demotion already resets it
to 0 on the boot after a wedge). If adb will not connect while stuck,
re-clone the LDPlayer instance; the evidence files survive under
`/data/adb/ReSuSFS/logs/` on the wedged instance's disk - grab
`diag_last.txt` + `boot.log` from the clone's disk image if you can, they
name the wedge point.

---

# ReSuSFS x86_64 - v26.11.36

## v26.11.36: STAGED BRING-UP (no more blind wedges)

The v26.11.35 boot was the FIRST TIME the module's init body ever ran on
this kernel (every earlier release either never ran init at all, or died
inside freed .init.text).  It ran the full layer surgery at once - LSM
hook insertion, sys_call_table entry writes, kprobes, /proc nodes - and
the boot wedged at 50%, with no evidence which step killed it.

The post-mortem ruled out every previously-known failure class:

* **Freed .init.text is ruled out.**  The deployed .ko has exactly one
  function in `.init.text`: the 17-byte `susfs_init` wrapper (and its
  `init_module` alias).  Nothing `force_init` reaches lives in freed
  memory - `susfs_init_body` is in `.text.unlikely`, and the three
  de-__init'd helpers are in `.text`.
* **NULL current->fs in the kworker is ruled out.**  5.15 creates every
  kthread with `CLONE_FS | CLONE_FILES` (`kernel/kthread.c:357`,
  `create_kthread()`), and kthreadd itself shares init's fs - so the
  kworker has a valid root and `kern_path("/proc/...")` in
  self-hide/relabel resolves normally.
* **The patching primitive is the stock stop_machine + fixmap +
  copy_to_kernel_nofault flow** (same lineage as KernelSU-Next's x86_64
  LKM), and the LSM hook insertion finds its list heads by IDENTITY
  (walking which list holds `selinux_<member>`), not by compiled
  offsets.

What remains: some step of the layer surgery on this LTO+PGO+BOLT
KernelSU-Next kernel wedges it - and it had never been live-tested,
because init never ran in any earlier release.

### What v26.11.36 changes

The layer loop is now gated by an `arm_stage` module parameter
(0644, set by post-fs-data.sh from `/data/adb/ReSuSFS/arm_stage`
BEFORE the `force_init` write).  Layers are grouped by what their init
actually DOES (audited per init function):

| arm_stage | what arms | mechanism |
|-----------|-----------|-----------|
| 0 | nothing (resolver + diagnostics only) | evidence mode |
| 1 (DEFAULT) | fp_hook (resolve only), ksu_umount_gate, ksu_allow_gate, sus_map, sus_mount, cmdline, open_redirect, prop_view, enable_log, avc_spoof, **supercall** | symbol resolution + /proc nodes + one kretprobe on `__x64_sys_reboot` (the same primitive KernelSU itself registers at boot; reboot is a cold path) |
| 2 | + lsm_hook, sus_path (+ the self-hide/relabel pass, which needs sus_path), uname, hide_syms | LSM hook insertion, kern_path-backed rule table, kprobe on `kallsyms_op.s_show`, kretprobe on newuname |
| 3 | + create_gate, opath, dirent, kstat, sus_unix | **sys_call_table entry writes** through stop_machine |

At stage 1 the supercall answers: `ksu_susfs show version` works, and
`diag_log` carries the full resolver evidence.  A stage-1 boot is the
safe default.

### The bring-up ladder

After a healthy stage-1 boot, escalate ONE mechanism class per boot:

```
adb shell su -c "echo 2 > /data/adb/ReSuSFS/arm_stage"   # + LSM/sus_path class
adb reboot
# ... check boot.log + diag_log, then:
adb shell su -c "echo 3 > /data/adb/ReSuSFS/arm_stage"   # full susfs
adb reboot
```

If a stage wedges, the mechanism class that caused it is known from
which stage you were on - and stage 1 always boots, so the module never
takes the system down blind.  Every skipped layer is named in
`diag_log`, and `init_done` polling now covers the full 2x10s kallrecon
retry path (25 seconds).

### If a boot wedges (recovery)

```
adb root
adb shell rm /data/adb/ReSuSFS/enable_lkm
adb shell rm -f /data/adb/ReSuSFS/arm_stage
adb reboot
```

If adb will not connect while stuck, re-clone the LDPlayer instance.

### Evidence to send back (especially from a wedged boot, before recovery)

```
adb shell su -c "dmesg | grep -E 'XYZDIAG1|susfs_guard_lkm|ReSuSFS|DIAG step'"
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/diag_log"
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/init_done /sys/module/susfs_guard_lkm/parameters/arm_stage /sys/module/susfs_guard_lkm/parameters/sc_entry_count"
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"
```

The last `DIAG step N` line in dmesg/diag_log names the exact function
that wedged the kernel.

---

# ReSuSFS x86_64 - v26.11.28

## v26.11.28: supercall path fixed (kprobe+skip+canary -> kretprobe)

The v26.11.27 boot.log proved the LKM loads and is stable, but every
`ksu_susfs` supercall came back with "no supercall answer".  Root cause
analysis of the v26.11.27 dmesg evidence (which the v27 capture filtered
too narrowly to show, but the failure mode was unambiguous):

1. **The canary's delayed recheck failed.**  `susfs_supercall_init()`
   first registers a kprobe on a self-test function (`susfs_sc_canary_fn`)
   and verifies the IP-write skip mechanism works (`susfs_kp_skip_return`
   sets `regs->ip = &susfs_just_return` so the probed function returns
   immediately with a forced value).  At init time the kprobe is still
   int3-based and the IP write is honored - canary passes, `sc_canary_ok`
   is set, `register_kprobe(&reboot_kp)` proceeds, the module loads.
   But `schedule_delayed_work(&canary_dw, msecs_to_jiffies(1000))` fires
   a recheck one second later, and by then the kprobe optimizer has armed
   (or the probe rides the ftrace trampoline on LDPlayer's clang-LTO
   kernel).  An optimized/ftrace probe IGNORES the IP write - the canary
   function returns its natural value, the recheck fails, `sc_canary_ok`
   goes false, and `reboot_pre` exits at its `if (!sc_canary_ok) return 0`
   gate.  Every subsequent `ksu_susfs` supercall hits that gate, the real
   `__x64_sys_reboot` runs with our magics, returns -EINVAL (our magics
   are not LINUX_REBOOT_MAGIC1/2), and the CLI reports "no supercall
   answer".

2. **A second latent crash bug on x86_64.**  Even if the canary had
   passed, `reboot_pre` followed an arm64 syscall-wrapper quirk:
   `real_regs = (struct pt_regs *)susfs_sc_arg(regs, 0)` dereferences
   magic1 (0xDEADBEEF) as a `struct pt_regs *`.  On arm64 the wrapper's
   first argument IS a nested pt_regs*; on x86_64 the syscall args live
   DIRECTLY in `regs->di/si/dx/r10`.  This would have been a page fault
   oops on the first supercall - masked only because `sc_canary_ok` was
   always false and the deref was never reached.

### The fix: kretprobe, not kprobe+skip

`v26.11.28` replaces the entire kprobe+IP-skip+canary mechanism with a
**kretprobe** on `__x64_sys_reboot`:

- **`susfs_sc_entry` (entry_handler)**: reads `magic1/magic2/cmd/payload`
  DIRECTLY from `regs` via `susfs_sc_arg(regs, N)` - no arm64 indirection.
  Returns 0 (arm the return handler) only for root callers with matching
  magics and a `susfs_cmd_handled()` command; returns -1 (don't arm)
  otherwise, so real `reboot(2)` calls and unsupported commands pass
  through untouched.

- **`susfs_sc_ret (return_handler)**: fires from the rethook trampoline
  AFTER `__x64_sys_reboot` returned -EINVAL for our magics (harmless:
  the kernel's reboot path does NOT act on bad magics).  Queues the
  actual command via `task_work_add(TWA_RESUME)` (process context,
  before the syscall returns to userspace), then overrides `regs->ax`
  to 0 via `susfs_kp_set_ret` so userspace sees success.

The rethook trampoline is reliable on EVERY kprobe backend (int3,
jump-optimized, ftrace) - there is no IP write to ignore, so no canary
is needed.  The `susfs_sc_canary_fn`/`canary_kp`/`canary_dw`/`sc_canary_ok`
symbols are all gone from the .ko.

### Verification

```
undefined symbols: 122  (same as v26.11.27 - all runtime-resolved)
vermagic: 5.15.178+ SMP preempt modversions   (byte-identical to kernel)
register_kretprobe, susfs_sc_entry, susfs_sc_ret, reboot_krp: present
canary/sc_canary/susfs_sc_canary/reboot_pre/reboot_kp: absent
try_module_get/module_put/find_vma/current_task/saved_boot_config: still absent
```

### What to expect when you flash v26.11.28

Flash, reboot, `touch /data/adb/ReSuSFS/enable_lkm`, reboot again, then
send `boot.log` + `diagnose.log`.  If the kretprobe registered and the
path works, you should see in the LKM live evidence block:

```
---- supercall live test (ksu_susfs show version / variant / enabled_features) ----
<the actual susfs version string, not "no supercall answer">
<the actual susfs variant string>
<the actual enabled_features list>
```

And in dmesg (now captured with a WIDER filter - the v27 `grep -i susfs`
missed `pr_warn("supercall delivery uses a kprobe path...")` because
"supercall" contains no "susfs" substring):

```
susfs supercall: armed (reboot ABI kretprobe, version ...)
susfs_guard_lkm: supercall delivery uses a kretprobe on __x64_sys_reboot - ...
```

If the supercall STILL doesn't answer, the widened dmesg capture will now
show exactly which layer failed (the v27 filter was the second bug after
the kprobe+skip design).  Next suspect in that case: `ksu_init_symbol_resolver()`
or `register_kretprobe` itself returning non-zero.

---

## Historical: v26.11.27

# ReSuSFS x86_64 - v26.11.27

## The v26.11.26 result: the LKM LOADS

The v26.11.26 boot.log is the breakthrough the port has been working
toward since v26.10.23:

```
susfs_insmod: resolved 122/122; unresolved 0
susfs_insmod: init_module(582192 bytes, 122 symbols absolutized, params "")
susfs_insmod: loaded (vermagic fixup not needed); checking /sys/module/susfs_guard_lkm
susfs_insmod: OK: /sys/module/susfs_guard_lkm exists
[+] LKM loaded successfully (susfs_insmod, custom-kernel path)
post-fs-data: LKM load rc=0
post-fs-data: susfs LKM is LIVE (/proc/susfs_path present)
```

The five-symbol fix worked exactly as designed: zero unresolved
imports, the kernel accepted the module WITHOUT the vermagic patch
("vermagic fixup not needed"), `/proc/susfs_path` was created at load
time, and the module shows Live in `/proc/modules`. The whole boot
completed in ~10s on TWO consecutive boots with the module loaded -
no freeze, no watchdog skips. The load wall is over.

## The remaining issue: the supercall path does not answer

Every `ksu_susfs` command reports "no supercall answer", and
stage-early's functional probe (`ksu_susfs show version`) failed one
second after the load - the path was dead from the start, not degraded
later. That keeps the module in userspace-only mode (kernel-side
features undriven; the WebUI's "Unsupported ksu_susfs version /
Unknown / no features" is the same symptom - the "3 Sus Kstat" there
is userspace bookkeeping from the apply scripts, not the kernel).
Two more observations point the same way: the module's own control
nodes disappear from stat minutes after the load (the `-e` check
passed at load time, `ls -l /proc/susfs_path` fails in diagnose), and
the module's self-hiding from `/proc/modules` is not active (its line
shows). Stealth layers that did not arm - the same failure class as
the supercall.

The kernel-side mechanism was verified in source: the supercall layer
is fatal, so a live module proves the canary and the reboot kprobe
registration both succeeded at init; the register mappings (di/si/dx/
r10) and the magic constants (0xDEADBEEF/0xFAFAFAFA) match between
the CLI and the handler. What the evidence must now separate: the
delayed canary recheck disarming the supercall, the reboot kprobe at a
wrong address (BOLT/LTO kallsyms quirk), the `current_task` %gs offset
assumption (kallsyms printed `0` for it under kptr_restrict=2, which
may be the restricted print rather than the true offset), or non-fatal
layers that failed to arm.

## What v26.11.27 changes: automatic evidence capture

The module's init-time lines (layer results, the current_task %gs
offset it chose, the canary state, non-fatal layer failures) all went
to dmesg - which nobody captured: `susfs_insmod` seeks /dev/kmsg to
the END before init_module, and diagnose.sh never dumped dmesg.
v26.11.27 captures it automatically. Right after every successful
load, post-fs-data now appends to boot.log:

- a **live supercall test** (`ksu_susfs show version / variant /
  enabled_features`, each timeout-bounded);
- the **module's own init-time dmesg** (the susfs-related lines of the
  last 400);
- the **kallsyms ground truth** for `current_task`, `__x64_sys_reboot`,
  `__per_cpu_start`, `fixed_percpu_data`, `init_task` - with
  kptr_restrict relaxed exactly the way the loader does (restored
  right after). An 'A' (per-CPU) record prints the symbol's true
  per-CPU offset, which directly validates the offset the module
  chose at init;
- the **kprobe registration state** (best effort via
  /sys/kernel/debug/kprobes/list);
- the module's **/proc/modules visibility** (self-hiding active or
  not);
- the **control-node state**: `-e` (existence) versus `ls /proc`
  (getdents view) - hidden from listing is the module's own stealth
  working as designed, missing from stat is a bug.

`diagnose.sh` STEP 00 dumps the same susfs-related dmesg tail, so the
user-triggered diagnose carries the module state too.

The bundled LKM is unchanged (byte-identical .ko to v26.11.26): it
loads and the system is stable - the next LKM change lands only after
this evidence names the dead layer.

## Flashing v26.11.27

Flash in KernelSU manager, reboot, and (for the LKM opt-in) `touch
/data/adb/ReSuSFS/enable_lkm` then reboot once more. After the boot,
send `/data/adb/ReSuSFS/logs/boot.log` (the live-evidence block will
be at the top of the LKM section) and, if convenient, the diagnose.log
from the Action button. `adb shell su -c "dmesg | grep -i susfs"`
right after a boot is an even faster shortcut.

---

# ReSuSFS x86_64 - v26.11.26 (historical, kept for reference)

## What the v26.11.25 log revealed

v26.11.25 got the LKM through the vermagic and `__versions` gates: the
loader parsed the module (42 sections, 1413 symbols, 127 imports), relaxed
`kptr_restrict`, resolved 122 of 127 imports to real kernel addresses from
`/proc/kallsyms`, patched the vermagic in place from
`"5.15.178+ SMP preempt mod_unload modversions "` (45 bytes) to
`"5.15.178+ SMP preempt modversions "` (34 bytes, the kernel's own), and
resubmitted. The kernel answered `ENOENT` (errno 2) and printed exactly
five rejects:

```
susfs_guard_lkm: Unknown symbol try_module_get (err -2)
susfs_guard_lkm: Unknown symbol find_vma (err -2)
susfs_guard_lkm: Unknown symbol module_put (err -2)
susfs_guard_lkm: Unknown symbol saved_boot_config (err -2)
```

(and `current_task`, the fifth, was named in the loader's own diagnostic).
No vermagic complaint, no `module_layout` rejection - the gate that
v26.11.25 fixed stays passed. The five names are the leftover: every one
of them is normally reachable through the kernel's export table or
kallsyms, and LDPlayer's `clang +pgo +bolt +lto` build removed the EXPORT
for each.

## What v26.11.26 changes

Each of the five names is eliminated at the source level - the compiler
no longer emits the corresponding `SHN_UNDEF` entry, so the kernel's
symbol-resolution pass has nothing to reject.

1. **`try_module_get` and `module_put`** - LDPlayer's kernel was built
   WITHOUT `CONFIG_MODULE_UNLOAD` (its required vermagic lacks the
   `mod_unload` token that v26.11.25 carried and had to patch out). The
   `extern` declarations of `try_module_get`/`module_put` in
   `<linux/module.h>` live behind `#ifdef CONFIG_MODULE_UNLOAD`, so
   building the LKM with `MODULE_UNLOAD=y` left them as real `extern`
   calls and the compiler emitted `R_X86_64_PLT32 try_module_get` /
   `module_put` relocations. Building with `MODULE_UNLOAD=n` turns both
   into `static inline` no-ops, the relocations vanish, and the resulting
   vermagic is byte-identical to the kernel's own
   (`5.15.178+ SMP preempt modversions ` - the loader's vermagic fixup is
   no longer needed for this token, though it stays as a safety net).
2. **`find_vma`** - replaced with the file-local `sus_map_find_vma(mm, addr)`
   already defined earlier in `sus_map.c` for the `walk_page_range` hook.
   Same contract (first VMA whose `vm_end > addr`), same maple-tree /
   linked-list walk under the `mmap_read_lock` the caller already holds.
   No semantic change; the `R_X86_64_PLT32 find_vma` relocation disappears.
3. **`current_task`** - the kernel's `<asm/current.h>` defines `current`
   as `this_cpu_read_stable(current_task)`, whose inline-asm expansion is
   `movq %gs:current_task_offset, %reg` - an `R_X86_64_32S current_task`
   relocation. The displacement is normally filled from
   `EXPORT_PER_CPU_SYMBOL(current_task)`, which LDPlayer's LTO+trim build
   removed. v26.11.26 overrides `<asm/current.h>` in the kbuild-x64 tree
   (only used for out-of-tree module builds - the kernel itself was never
   compiled against this tree) so `current` reads through
   `movq %%gs:0(,%1,1), %0` (SIB-only addressing), with the displacement
   loaded from a runtime global `susfs_current_task_gs_off`. That global
   is filled once at module init from `ksu_kallsyms_lookup_name("current_task")`
   (kernel/susfs_current.c, called right after `ksu_init_symbol_resolver()`
   returns). On LDPlayer kallsyms reports `current_task` at address 0,
   which is also the correct per-CPU displacement there; on a stock 5.15
   kernel where `current_task` is at offset 4096 (after `fixed_percpu_data`
   which is `__aligned(PAGE_SIZE)`) the same resolver sets the
   displacement to 4096. Either way the compiler never emits a
   `current_task` relocation.
4. **`saved_boot_config`** - the original code declared it `extern` and
   relied on ksud / susfs_insmod to relocate it from kallsyms (the
   variable is an fs/init-main.c static, never `EXPORT_SYMBOL`'d). The
   v26.11.25 boot log confirmed LDPlayer's kallsyms does not list
   `saved_boot_config` at all, so the import was left at `SHN_UNDEF/0`.
   v26.11.26 makes `saved_boot_config` a `static char *` local to
   `spoof_cmdline.c` and removes the matching `IMP_DATA` entry from
   `imports_guard.c`. The `spoof_cmdline` feature is now INERT on LDPlayer
   (`/proc/bootconfig` is not spoofed); the file header documents how to
   re-arm it on a kernel that does list the symbol.

## Verification

- `objdump -t susfs_guard_lkm.ko | grep -E 'try_module_get|find_vma|module_put|current_task|saved_boot_config'`
  returns no `*UND*` entries for any of the five names; `saved_boot_config`
  shows up as a local `.bss` symbol (the file-static), as expected.
- Undefined symbol count: 127 (v25) -> 122 (v26). Every remaining import
  was already resolvable on LDPlayer in the v25 boot log.
- Vermagic (from `strings`): `5.15.178+ SMP preempt modversions ` -
  byte-identical to what the v25 loader had to patch in place.
- Loader host simulation parses the new .ko (42 sections, 1409 symbols)
  without complaint; the kallsyms walk cannot run on the build host
  (non-root, kptr_restrict=2) but the parse / symbol-resolution-stage
  artifacts are identical to v25's.

## What to expect on the next opt-in boot

This is the first build that the kernel should accept: the vermagic
matches byte-for-byte, the `__versions` gate stays passed (unchanged from
v25), and every name the kernel refused in v25 is gone from the symbol
table. If the load still fails, the boot.log will say which layer is next
- most likely candidates are the kallrecon layout discovery (kernel
symbol-table variant detection, runs inside `ksu_init_symbol_resolver()`)
or the first kprobe registration in the layer init plan. Either way the
diagnostic block from v25 (dmesg tail + MODVERSIONS probe + per-name
kallsyms status) still ships and will print the evidence.

## Flashing v26.11.26

Same as v25: flash in KernelSU manager, reboot, and (for the LKM opt-in)
`touch /data/adb/ReSuSFS/enable_lkm` then reboot once more. The module
ships in userspace-only mode by default; the LKM is only attempted when
the opt-in flag is present.

---

# ReSuSFS x86_64 - v26.11.25 (historical, kept for reference)

## What the v26.11.24 log revealed

With the loader fixed, the opt-in boot finally ran the real load: the loader
parsed the module (51 sections, 1429 symbols, 141 imports), relaxed
kptr_restrict, resolved 124 imports to real kernel addresses from
/proc/kallsyms, and submitted the patched image. The kernel answered
ENOEXEC (errno 8) and printed NOTHING - no "Unknown symbol", no
"version magic ... should be ...". ksud failed identically. Reading the
exact 5.15.178 kernel/module.c source explains it completely:

- load_module() calls **check_modstruct_version() BEFORE the vermagic
  check** (module.c:4029 vs :3575).
- On a CONFIG_MODVERSIONS=y kernel (an Android 14 GKI-style build, which
  exports module_layout with a CRC), a module with **no __versions
  section** hits check_version()'s "versindex == 0" path, which calls
  try_to_force_load(), whose no-force-load branch is
  `return -ENOEXEC;` - **the single unprinted failure in the whole
  module loader**. Every earlier build of this port had MODVERSIONS off,
  so this is the wall every v26.11.22..24 load attempt died on.
- The same log named the other problem: 17 of 141 imports were unresolved.
  12 of them (7 retpoline thunks, __stack_chk_fail, __check_object_size,
  pgdir_shift, page_offset_base, ptrs_per_p4d) are imports for kernel
  features LDPlayer's kernel runs WITHOUT - build-config mismatches. The
  other 5 (try_module_get, module_put, find_vma, saved_boot_config,
  current_task) resolve kernel-side (export tables / kallsyms).

## What v26.11.25 changes

1. **The bundled LKM is rebuilt to pass the gate and match the kernel:**
   - a neutral single-entry `__versions` section (kernel/modver_dummy.c +
     tools/normalize_modver.py) turns the module_layout CRC check into the
     kernel's own escape hatch - `pr_warn_once("no symbol version for
     module_layout")` + accepted;
   - CONFIG_MODVERSIONS=y build, so the vermagic carries the "modversions"
     word the target expects ("5.15.178+ SMP preempt mod_unload
     modversions");
   - the 12 phantom imports are GONE: 141 -> 127 imports, all resolvable
     on the target (verified offline against the import list).
2. **Failed loads now dump decisive evidence** into boot.log: the
   MODVERSIONS probe (grep __crc_module_layout /proc/kallsyms - on a
   MODVERSIONS kernel the CRC is the printed address), per-name kallsyms
   status for the imports that matter, a raw dmesg tail, and the
   kernel-config snapshot when /proc/config.gz exists.
3. The loader no longer runs twice per opt-in boot, and errno-8 failures
   with an empty kernel log now print an explanation of the silent gate
   (for user-supplied or older .ko images).
4. Everything else is unchanged: opt-in-only LKM on custom kernels,
   functional built-in-susfs detection, userspace-only mode, safe
   defaults, receipt/hang-watchdog boot gating, diagnose.sh bisector.

Offline verification: a gate simulator that transcribes the exact
5.15.178 load_module order shows the OLD .ko failing silently at
check_modstruct_version (the device symptom, reproduced) and the NEW one
passing; 22/22 install simulation, 41/41 safeguard/watchdog tests.

## Flashing v26.11.25

Flash `ReSuSFS-x86_64-v26.11.25.zip` in the KernelSU manager (over the old
module is fine). Your `/data/adb/ReSuSFS/enable_lkm` flag and configs
survive the upgrade. Restart the instance.

Your `enable_lkm` flag is still in place, so the next boot's post-fs-data
runs the fixed loader over the NEW image. In boot.log you should see, in
order:

1. `[*] Trying susfs_insmod (custom-kernel primary path)...`
2. the loader's verbose report (127 undefined symbols now, and
   `resolved <n>/127` - expect only a handful unresolved: the exported
   names the kernel itself resolves, e.g. try_module_get, module_put,
   find_vma)
3. `init_module(...)` - and then, if the gate analysis is right, one of:
   - `[+] LKM loaded successfully (susfs_insmod, custom-kernel path)` -
     kernel susfs is live. Verify with `dmesg | grep -i susfs`,
     `ls /proc/susfs_path`, or re-run diagnose.sh (steps 01-08 start
     answering). Expect one harmless dmesg line:
     `susfs_guard_lkm: no symbol version for module_layout`.
   - a NEW kind of failure report - the loader's own lines plus the
     evidence block (MODVERSIONS probe, kallsyms status, raw dmesg tail)
     - send boot.log + dmesg back and the next fix targets exactly what
     the kernel names.

## If the system freezes after the load

The LKM is still a generic 5.15.178 x86_64 build (LDPlayer publishes no
kernel source/config), and it hooks live kernel paths - a mismatch can
wedge the kernel. Rollback: force-restart the instance, then immediately

```
adb shell su -c "rm /data/adb/ReSuSFS/enable_lkm"
```

(you have a window of several seconds before post-fs-data fires; if adb
is dead, connect right after the boot animation starts:
`adb connect 127.0.0.1:5555`). Last resort:
`adb shell su -c "touch /data/adb/modules/ReSuSFS/disable"`.

## Running the bisector (optional)

KernelSU manager -> module page -> **Action** button, or
`adb shell su -c "sh /data/adb/modules/ReSuSFS/diagnose.sh"`. On kernels
without susfs (LKM not loaded) steps 01-08 answer "not supported" - that
is expected. If a step freezes the system: force-restart; the watchdog
skips that step on the next run automatically.

## What to send back

```
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"     > boot.log
adb shell su -c "cat /data/adb/ReSuSFS/logs/diagnose.log" > diagnose.log
adb shell su -c "dmesg"                                   > dmesg.txt
```

## v26.11.46 verdict (read this before raising the arm ladder)

The v45 campaign proved, with receipts in boot.log, that on this kernel
(LDPlayer 5.15.178+, SukiSU-lineage KernelSU):

- **Stage 1 is the proven-safe ceiling.** 10 layers (fp_hook, ksu_umount_gate,
  ksu_allow_gate, sus_map, sus_mount, cmdline, open_redirect, prop_view,
  enable_log, avc_spoof) ran healthy across 8+ boots with full heartbeat
  windows. v46 hard-caps `stage_max` at 1 and parks the ladder there.
- **Stage 2 and 3 (supercall) wedge the box at the first live fire.** Layer 17
  is a kprobe on `__x64_sys_reboot` - the slot KernelSU's own reboot kprobe
  already occupies. Both the v44 kretprobe shape AND the v45 plain-kprobe
  shape froze the box within ~2s of the first supercall (the v45 self-test's
  receipt was never even written). A second module probe on that slot dies
  at first fire on this kernel.
- **Stage 4 wedges with no supercall at all** - one or more of
  lsm_hook/sus_path/uname/hide_syms is lethal on its own hot paths.
- Consequences of the dark supercall channel: `ksu_susfs show version` keeps
  failing **by design**, and the runtime-config layers
  (sus_map/sus_mount/open_redirect/prop_view lists) stay empty. The KSU gates,
  fp_hook, avc_spoof, enable_log and cmdline act on built-in defaults.

Re-opening the research ladder (expected: a HARD freeze requiring an instance
kill, possibly the host uCountStall dialog):

```
adb shell su -c "touch /data/adb/ReSuSFS/enable_sc_probe"
adb shell su -c "echo 5 > /data/adb/ReSuSFS/stage_max"
```

The wedge protocol still protects you: the next boot stands down
automatically, prints the dossier, and v46 re-imposes the stage-1 cap unless
the opt-in flag is present.
