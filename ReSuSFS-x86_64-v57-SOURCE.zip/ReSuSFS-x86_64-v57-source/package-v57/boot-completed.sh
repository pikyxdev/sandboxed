#!/bin/sh
PATH=/data/adb/ksu/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"

. "$MODDIR/utils.sh"

# ---- v26.11.42 POST-BOOT SUBSTEP LADDER TRIGGER --------------------------
# The v41 field boot (2026-11-23 17:51:30) froze the box AT the force_init
# echo WITH the witness running: one receipt at @0s (laststep=-1), then
# nothing - no "write returned", no further witness poll, no 30s-elapsed
# line, manual instance restart.  The witness itself was blind: its param
# reads need mod->param_lock, the same mutex the stuck write path holds.
#
# v42 changes the instrumentation contract:
#   - every param read below goes through `busybox timeout 1`, so a
#     param_lock deadlock prints "param read TIMEOUT" receipts instead of
#     hanging the witness silently (that was the v41 blind spot);
#   - a BOX HEARTBEAT subshell (file+sync only, NO module access) beats
#     every 5s for 40s across the trigger window: beats continuing after a
#     frozen trigger = kernel alive, only module-param traffic dead -> the
#     script prints the adb dmesg capture commands to run BEFORE rebooting;
#     beats stopping = the box itself died, window bounded to 5s;
#   - trigger modes via /data/adb/ReSuSFS/trigger_mode:
#       set   (default) - write force_init (the sysfs WRITE channel; v42's
#                         setter is BARE schedule_work, 3 instructions)
#       get           - write probe_arm=1 (pure kernel code), then cat the
#                       "probe" param: module code dispatched through the
#                       sysfs READ path, which no module code has ever run
#                       through on this box.  Survives where "set" froze ->
#                       the write path is the culprit; freezes too ->
#                       module code execution itself.
#       early         - post-fs-data.sh writes force_init instead (the
#                       v35-v37 trigger context that verifiably ran)
#   - kernel-side sentinels are in the KWORKER now (outside param_lock):
#       -1 = fresh module, trigger not run
#       -50 = kworker ENTERED (raw store first instruction - module code
#             executes, before vsnprintf/any call)
#       -51 = kworker saw init_done=1 (already initialized)
#       -60 = the probe .get ENTERED (read channel equivalent of -50)
#       0..7 = susfs_init_body substeps (0 also store-first now)
#
# Ladder witness semantics (same as v37-v41, unchanged):
#   "try N <boot_id>" written before triggering; init_done=1 within the
#   window -> "ok" + advance ONE substep; init_done=0 -> "nok" (same rung
#   retried next boot); a boot that never completes its witness leaves the
#   stale "try" for post-fs-data's stand-down/demotion on the next boot.
#
# The trigger still needs BOTH opt-in flags:
#   /data/adb/ReSuSFS/enable_lkm          (loads the image in post-fs-data)
#   /data/adb/ReSuSFS/enable_force_init   (runs the post-boot init experiment)
if [ -d /sys/module/susfs_guard_lkm ]; then
        if [ -f "$PERSISTENT_DIR/no_init_this_boot" ]; then
                log_boot "boot-completed: init suppressed this boot (stage-0 wedge recovery from post-fs-data) - trigger skipped, flags already removed"
                rm -f "$PERSISTENT_DIR/no_init_this_boot" 2>/dev/null
        elif [ -f "$PERSISTENT_DIR/enable_lkm" ] && [ -f "$PERSISTENT_DIR/enable_force_init" ]; then
                STAGE_FILE="/data/adb/ReSuSFS/arm_stage"
                STAGE_MAX_FILE="/data/adb/ReSuSFS/stage_max"
                STAGE_BOOT_FILE="/data/adb/ReSuSFS/stage_boot"
                INIT_SEQ_FILE="/data/adb/ReSuSFS/init_seq"
                INIT_TRACE="$LOG_DIR/init_trace.txt"
                STAGE_PARAM="/sys/module/susfs_guard_lkm/parameters/arm_stage"
                MAXSTEP_PARAM="/sys/module/susfs_guard_lkm/parameters/init_maxstep"
                LASTSTEP_PARAM="/sys/module/susfs_guard_lkm/parameters/init_laststep"
                FORCE_INIT="/sys/module/susfs_guard_lkm/parameters/force_init"
                INIT_DONE="/sys/module/susfs_guard_lkm/parameters/init_done"
                DIAG_PARAM="/sys/module/susfs_guard_lkm/parameters/diag_log"
                DIAG_SNAP="/data/adb/ReSuSFS/logs/diag_last.txt"
                PROBE_ARM="/sys/module/susfs_guard_lkm/parameters/probe_arm"
                PROBE="/sys/module/susfs_guard_lkm/parameters/probe"
                BB="$(command -v busybox || echo busybox)"

                ARM_STAGE=0
                [ -f "$STAGE_FILE" ] && ARM_STAGE=$(cat "$STAGE_FILE" 2>/dev/null | tr -dc '0-9')
                [ -z "$ARM_STAGE" ] && ARM_STAGE=0
                case "$ARM_STAGE" in 0|1|2|3|4|5) ;; *) ARM_STAGE=0 ;; esac
                STAGE_MAX=5
                [ -f "$STAGE_MAX_FILE" ] && STAGE_MAX=$(cat "$STAGE_MAX_FILE" 2>/dev/null | tr -dc '0-9')
                [ -z "$STAGE_MAX" ] && STAGE_MAX=5
                case "$STAGE_MAX" in 0|1|2|3|4|5) ;; *) STAGE_MAX=5 ;; esac
                if [ "$ARM_STAGE" -gt "$STAGE_MAX" ]; then
                        log_boot "boot-completed: arm_stage $ARM_STAGE above stage_max $STAGE_MAX - clamping for this trigger"
                        ARM_STAGE=$STAGE_MAX
                fi

                INIT_SEQ=0
                [ -f "$INIT_SEQ_FILE" ] && INIT_SEQ=$(cat "$INIT_SEQ_FILE" 2>/dev/null | tr -dc '0-9')
                [ -z "$INIT_SEQ" ] && INIT_SEQ=0
                case "$INIT_SEQ" in 0|1|2|3|4|5|6|7) ;; *) INIT_SEQ=0 ;; esac
                [ "$INIT_SEQ" -gt 7 ] && INIT_SEQ=7

                TRIGGER_MODE="sync"
                [ -f "$PERSISTENT_DIR/trigger_mode" ] && TRIGGER_MODE=$(head -n 1 "$PERSISTENT_DIR/trigger_mode" 2>/dev/null | tr -d '[:space:]')
                case "$TRIGGER_MODE" in sync|set|get|early) ;; *) TRIGGER_MODE="sync" ;; esac
                # v43 default = 'sync': force_init is written as 2, the module
                # runs susfs_init_body DIRECTLY in the .set (no workqueue at
                # all - substep 0 is pure stores). 'set' writes 1 (the v42
                # deferred/schedule_work path, kept for comparison); 'get'
                # dispatches through the probe .get; 'early' wrote force_init
                # at post-fs-data time (the v35-v37 context) - this script
                # then only runs the witness + init poll.
                [ "$TRIGGER_MODE" = "early" ] && log_boot "boot-completed: trigger_mode=early - the dispatch already happened at post-fs-data; polling only"

                CUR_BOOT="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d -)"

                MARKER=""
                [ -f "$STAGE_BOOT_FILE" ] && MARKER=$(cat "$STAGE_BOOT_FILE" 2>/dev/null)
                case "$MARKER" in
                "ok "*" $CUR_BOOT"|"nok "*" $CUR_BOOT") : ;;
                *) echo "try $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null ;;
                esac

                mkdir -p "$LOG_DIR" 2>/dev/null
                trace() {
                        echo "[$(rs_ts)] boot=$CUR_BOOT $*" >> "$INIT_TRACE" 2>/dev/null
                        sync 2>/dev/null
                        log_boot "init-trace: $*"
                }
                # v42: param reads survive a param_lock deadlock. The lock
                # sleeps TASK_KILLABLE, so SIGKILL breaks a blocked read;
                # a plain TERM would not. timeout's own 124 (or a KILL
                # 137) is receipted as "param read TIMEOUT" - the v41
                # witness hung silently on exactly this and looked like
                # "stuck at -1", proving nothing.
                tread() {
                        [ -n "$RS_TIMEOUT" ] && { $RS_TIMEOUT -s KILL 1 cat "$1" 2>/dev/null; return; }
                        cat "$1" 2>/dev/null
                }
                { echo "---- boot $CUR_BOOT begin (v42 substep ladder; trigger_mode=$TRIGGER_MODE) ----"; } >> "$INIT_TRACE" 2>/dev/null
                tail -n 400 "$INIT_TRACE" > "$INIT_TRACE.tmp" 2>/dev/null && mv "$INIT_TRACE.tmp" "$INIT_TRACE" 2>/dev/null
                trace "STEP $INIT_SEQ/7 DISPATCHING (arm_stage=$ARM_STAGE/$STAGE_MAX marker='$MARKER' mode=$TRIGGER_MODE module=$(sed -n 's/^version=//p' $MODDIR/module.prop 2>/dev/null))"

                # resolver seed (unchanged from v41)
                log_boot "boot-completed: seeding resolver (v2: kln/gsoff preferred, tables if visible)"
                SEED_STR="$(seed_kallsyms_resolver_v2)"
                if [ -n "$SEED_STR" ]; then
                        trace "seed v2 written: $SEED_STR"
                        log_boot "boot-completed: kr_seed(v2) = $SEED_STR"
                else
                        trace "seed v2 NOT written (no kln= and no tables visible) - the module will refuse at substep 2 and nok (safe)"
                        log_boot "boot-completed: kr_seed NOT written (tables hidden or param missing) - the module will refuse to init rather than scan (safe); seed_kallsyms_resolver_v2 said: $SEED_STR"
                fi

                if [ -w "$STAGE_PARAM" ]; then
                        trace "writing arm_stage=$ARM_STAGE (layer gate)"
                        echo "$ARM_STAGE" > "$STAGE_PARAM" 2>/dev/null
                fi
                if [ -w "$MAXSTEP_PARAM" ]; then
                        trace "writing init_maxstep=$INIT_SEQ (substep gate)"
                        echo "$INIT_SEQ" > "$MAXSTEP_PARAM" 2>/dev/null
                        log_boot "boot-completed: substep seq=$INIT_SEQ armed (init_maxstep=$INIT_SEQ arm_stage=$ARM_STAGE; ladder: 0=dispatch 1=+imports 2=+resolver 3=+gs_off 4=+deadman 5=+crosscheck 6=+patch 7=+layers; max=$STAGE_MAX)"
                else
                        log_boot "boot-completed: init_maxstep param not writable (fallback image, not a v40+ build)"
                fi

                # v42 BOX HEARTBEAT: pure userspace, no module access - it
                # keeps beating through a param deadlock AND survives long
                # enough to bound a real box death to a 5s window.
                (
                        h=0
                        while [ "$h" -lt 8 ]; do
                                sleep 5
                                h=$((h+1))
                                echo "[$(rs_ts)] boot=$CUR_BOOT heartbeat @${h}x5s (alive, uptime $(cut -d. -f1 /proc/uptime 2>/dev/null))" >> "$INIT_TRACE" 2>/dev/null
                                sync 2>/dev/null
                        done
                        echo "[$(rs_ts)] boot=$CUR_BOOT heartbeat window done (40s)" >> "$INIT_TRACE" 2>/dev/null
                        sync 2>/dev/null
                ) &

                # v42 WITNESS: timeout-guarded reads - a param_lock deadlock
                # shows up as TIMEOUT receipts instead of a silent hang.
                if [ -f "$LASTSTEP_PARAM" ]; then
                        (
                                n=0; last_seen=""; bg_diag=""; to_count=0
                                while [ "$n" -lt 30 ]; do
                                        cur="$(tread $LASTSTEP_PARAM)"
                                        rc=$?
                                        done_="$(tread $INIT_DONE)"
                                        if [ "$rc" = "124" ] || [ "$rc" = "137" ]; then
                                                to_count=$((to_count+1))
                                                trace "witness(bg): PARAM READ TIMEOUT x$to_count @${n}s - mod param traffic is DEADLOCKED (kernel may still be alive; heartbeats tell) - probe the box: adb shell su -c 'dmesg > /data/adb/ReSuSFS/logs/dmesg_freeze.txt; cat /sys/module/susfs_guard_lkm/parameters/diag_log > /data/adb/ReSuSFS/logs/diag_freeze.txt; cat /proc/modules > /data/adb/ReSuSFS/logs/modules_freeze.txt; sync' then reboot"
                                                [ "$to_count" -ge 2 ] && exit 0
                                                sleep 1; n=$((n+1)); continue
                                        fi
                                        combo="${cur}|${done_}"
                                        if [ "$combo" != "$last_seen" ]; then
                                                trace "witness(bg): laststep=$cur init_done=$done_ @${n}s"
                                                last_seen="$combo"
                                        fi
                                        cur_diag="$(tread $DIAG_PARAM)"
                                        if [ -n "$cur_diag" ] && [ "$cur_diag" != "$bg_diag" ]; then
                                                printf '%s' "$cur_diag" > "$DIAG_SNAP" 2>/dev/null
                                                sync 2>/dev/null
                                                bg_diag="$cur_diag"
                                                trace "witness(bg): diag_log snapshot @${n}s (len=${#cur_diag})"
                                        fi
                                        if [ "$done_" = "1" ] && [ "$n" -ge 5 ]; then
                                                trace "witness(bg): init_done=1 seen - background witness exiting @${n}s"
                                                exit 0
                                        fi
                                        sleep 1
                                        n=$((n+1))
                                done
                                trace "witness(bg): 30s window elapsed (init_done=$(tread $INIT_DONE) laststep=$(tread $LASTSTEP_PARAM))"
                        ) &
                fi

                # ---- v43 pre-trigger: console breadcrumbs ON + dmesg baseline ----
                # diag_printk=1 arms the setter's EMERG printk (XYZDIAG2: .set
                # ENTERED ...) - it goes to the ring AND the console (tty0),
                # so the LDPlayer window itself shows it if the box dies at
                # the write. Keep a second adb window running `dmesg -w` too.
                DIAG_PRINTK_PARAM="/sys/module/susfs_guard_lkm/parameters/diag_printk"
                if [ -w "$DIAG_PRINTK_PARAM" ]; then
                        echo 1 > "$DIAG_PRINTK_PARAM" 2>/dev/null
                        trace "diag_printk=1 armed (EMERG breadcrumbs: XYZDIAG2 at .set entry, XYZDIAG1 in the body)"
                fi
                trace "dmesg baseline (last 6): $(dmesg 2>/dev/null | tail -n 6 | tr '\n' '|' | head -c 300)"

                # ---- THE TRIGGER -------------------------------------------------
                if [ "$TRIGGER_MODE" = "early" ]; then
                        trace "trigger_mode=early: dispatch already happened at post-fs-data (no write here)"
                elif [ "$TRIGGER_MODE" = "get" ] && [ -w "$PROBE_ARM" ] && [ -f "$PROBE" ]; then
                        trace "trigger_mode=get: writing probe_arm=1 (pure kernel param code), then reading probe (module .get dispatches)"
                        log_boot "boot-completed: triggering via READ channel (probe .get; substep $INIT_SEQ)"
                        echo 1 > "$PROBE_ARM" 2>/dev/null
                        trace "probe_arm=1 written (kernel-only code path)"
                        trace "reading probe param - module .get executes now (laststep -60 = entered)"
                        PROBE_OUT="$(tread $PROBE)"
                        trace "probe read returned: '$PROBE_OUT' (kworker dispatched from the READ path)"
                elif [ "$TRIGGER_MODE" = "set" ] && [ -w "$FORCE_INIT" ]; then
                        trace "trigger_mode=set: writing force_init=1 (v42 deferred path: bare schedule_work; kworker sentinels -50 entered, -51 done)"
                        log_boot "boot-completed: triggering force_init=1 (DEFERRED channel; substep $INIT_SEQ; system fully booted)"
                        echo 1 > "$FORCE_INIT" 2>/dev/null
                        trace "force_init=1 write returned (kworker scheduled)"
                elif [ -w "$FORCE_INIT" ]; then
                        trace "trigger_mode=sync: writing force_init=2 (v43 SYNC path: the .set calls susfs_init_body DIRECTLY - no workqueue; sentinels -70 entered, -71 already-done)"
                        log_boot "boot-completed: triggering force_init=2 (SYNC channel, direct body call, no queueing; substep $INIT_SEQ; system fully booted)"
                        echo 2 > "$FORCE_INIT" 2>/dev/null
                        trace "force_init=2 write returned (sync body ran to completion inside the write)"
                else
                        log_boot "boot-completed: force_init param not writable (old module image?)"
                fi
                # ------------------------------------------------------------------

                # Poll init_done with timeout-guarded reads (same as v41
                # except every read is bounded; diag snapshots unchanged).
                if [ -f "$INIT_DONE" ]; then
                        mkdir -p /data/adb/ReSuSFS/logs 2>/dev/null
                        LAST_DIAG=""
                        LAST_STEP="$(tread $LASTSTEP_PARAM)"
                        n=0
                        while [ "$n" -lt 25 ] && [ "$(tread $INIT_DONE)" != "1" ]; do
                                STEP_NOW="$(tread $LASTSTEP_PARAM)"
                                if [ -n "$STEP_NOW" ] && [ "$STEP_NOW" != "$LAST_STEP" ]; then
                                        trace "witness: laststep=$STEP_NOW @${n}s"
                                        LAST_STEP="$STEP_NOW"
                                fi
                                CUR="$(tread $DIAG_PARAM)"
                                if [ -n "$CUR" ] && [ "$CUR" != "$LAST_DIAG" ]; then
                                        printf '%s' "$CUR" > "$DIAG_SNAP" 2>/dev/null
                                        sync 2>/dev/null
                                        log_boot "boot-completed: diag_log snapshot @${n}s (len=${#CUR}) last: $(printf '%s' "$CUR" | tail -n 1 | head -c 120)"
                                        trace "diag_log @${n}s changed (last line: $(printf '%s' "$CUR" | tail -n 1 | head -c 100))"
                                        LAST_DIAG="$CUR"
                                fi
                                sleep 1
                                n=$((n+1))
                        done
                        CUR="$(tread $DIAG_PARAM)"
                        if [ -n "$CUR" ] && [ "$CUR" != "$LAST_DIAG" ]; then
                                printf '%s' "$CUR" > "$DIAG_SNAP" 2>/dev/null
                                sync 2>/dev/null
                        fi
                        { echo "---- diag_log final snapshot (substep $INIT_SEQ, after ${n}s poll) ----"
                          printf '%s\n' "$CUR"
                          echo "---- end diag_log ----"; } >> "$BOOT_LOG" 2>/dev/null
                        if [ "$(tread $INIT_DONE)" = "1" ]; then
                                trace "STEP $INIT_SEQ COMPLETE (init_done=1 after ${n}s; module laststep=$(tread $LASTSTEP_PARAM))"
                                log_boot "boot-completed: substep $INIT_SEQ init COMPLETE (init_done=1 after ${n}s)"
                                already=""
                                case "$MARKER" in
                                "ok "*" $CUR_BOOT") already=1 ;;
                                esac
                                if [ -n "$already" ]; then
                                        log_boot "boot-completed: ladder already advanced this boot (marker '$MARKER') - skipping the advance"
                                elif [ "$ARM_STAGE" -ge 2 ]; then
                                        # v26.11.49: this boot just armed (or re-armed) the
                                        # sys_call_table transport.  The v48 field verdict: the
                                        # box died at the FIRST syscall(173) through the patched
                                        # entry - 2-5s AFTER init returned 0 and AFTER this
                                        # 'ok' was already written, so every wedged boot
                                        # confirmed itself and the next boot re-armed stage 3
                                        # (five consecutive wedges, 2026-11-24 11:00-11:11).
                                        # The ladder confirmation for a transport-armed boot
                                        # is therefore DEFERRED until the supercall self-test
                                        # below survives: a wedge there leaves this boot's
                                        # "try" marker stale, and post-fs-data's demotion caps
                                        # the ladder below this rung on the next boot - one
                                        # wedge boot maximum, never a loop.
                                        SC_DEFER_ADVANCE=1
                                        log_boot "boot-completed: init done at arm_stage $ARM_STAGE (transport armed) - ladder confirmation DEFERRED until the supercall self-test survives (v49)"
                                else
                                        echo "ok $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null
                                        if [ "$INIT_SEQ" -lt 6 ]; then
                                                echo $((INIT_SEQ + 1)) > "$INIT_SEQ_FILE" 2>/dev/null
                                                log_boot "boot-completed: substep $INIT_SEQ healthy - next boot runs substep $((INIT_SEQ + 1))/7"
                                        elif [ "$INIT_SEQ" -eq 6 ]; then
                                                echo 7 > "$INIT_SEQ_FILE" 2>/dev/null
                                                echo 1 > "$STAGE_FILE" 2>/dev/null
                                                log_boot "boot-completed: stage-0 substeps all healthy - next boot runs the LAYER LOOP at arm_stage 1 (seq=7)"
                                        elif [ "$ARM_STAGE" -lt "$STAGE_MAX" ]; then
                                                echo $((ARM_STAGE + 1)) > "$STAGE_FILE" 2>/dev/null
                                                log_boot "boot-completed: arm_stage $ARM_STAGE healthy (init done + boot completed) - next boot arms stage $((ARM_STAGE + 1))/$STAGE_MAX"
                                        else
                                                log_boot "boot-completed: arm_stage $ARM_STAGE healthy - at ladder max $STAGE_MAX"
                                        fi
                                fi
                        else
                                trace "STEP $INIT_SEQ did NOT complete in 25s (init_done=0; module laststep=$(tread $LASTSTEP_PARAM)) - nok, same substep retried next boot"
                                log_boot "boot-completed: init did NOT complete at substep $INIT_SEQ (stage $ARM_STAGE) after ${n}s - last breadcrumb is in $DIAG_SNAP and the diag_log block above. v43 attribution: witness stuck at -1 with heartbeats BEATING = param deadlock (see the TIMEOUT receipt + dmesg capture commands); stuck at -1 with heartbeats STOPPED = the box died before module code reached ANY sentinel (check the LDPlayer window/console for XYZDIAG2 - if the EMERG breadcrumb shows, the .set was entered and died between the print and the first store); -70/-71 = SYNC .set entered/already-done; -50 = kworker entered then froze; -60 = probe .get entered; 0..7 = froze inside that substep. sync mode holding param_lock while higher substeps run makes short PARAM READ TIMEOUT receipts EXPECTED during the run - heartbeats tell kernel-alive."
                                case "$MARKER" in
                                "nok "*" $CUR_BOOT") : ;;
                                *) echo "nok $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null ;;
                                esac
                        fi

                        # ---- v26.11.45: supercall self-test (arm_stage >= 2) ---------
                        # v26.11.49: the transport rides the LIVE sys_call_table[173]
                        # entry (this kernel's built-in KernelSU-Next dispatches
                        # every syscall through the table) WITH the original
                        # entry's kCFI type-hash preamble replicated before the
                        # thunk (the v48 verdict: a preamble-less thunk died at
                        # the first dispatch, five boots out of five).  The
                        # self-test is the transport's live-fire proof: the CLI
                        # below issues the FIRST syscall(173) through the
                        # patched entry, and (a) invokes the MODULE'S OWN
                        # 173-riding CLI first, (b) prints the sha256 of the
                        # binary it actually invoked, and (c) also runs the
                        # bundled sc_probe for a CLI-independent view of the raw
                        # syscall (rc, payload.err, counter before/after).
                        # v49: because a transport-armed boot DEFERS its ladder
                        # confirmation (see SC_DEFER_ADVANCE above), this block
                        # doubles as the survival gate - reaching its end with
                        # the box alive is what confirms the rung.
                        if [ "$INIT_SEQ" -ge 7 ] && [ "$ARM_STAGE" -ge 2 ] && [ "$(tread $INIT_DONE)" = "1" ]; then
                                SC_TEST_LOG="$LOG_DIR/sc_selftest.txt"
                                SC_CNT="/sys/module/susfs_guard_lkm/parameters/sc_entry_count"
                                SC_MODE=OBSERVE-ONLY
                                [ "$ARM_STAGE" -ge 3 ] && SC_MODE=FULL
                                SC_CLI="$MODDIR/bin/x86_64/ksu_susfs"
                                [ -x "$SC_CLI" ] || SC_CLI=/data/adb/ksu/bin/ksu_susfs
                                SC_HASH="(sha256 unavailable)"
                                command -v sha256sum >/dev/null 2>&1 && SC_HASH="$(sha256sum "$SC_CLI" 2>/dev/null | awk '{print $1}')"
                                log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v53 CLANG ACCEPT PATH + CLI WIRE ABI + THE FIRST FEATURE RUNG, nr 173; CLI: $SC_CLI)"
                                {
                                echo "---- v53 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----"
                                echo "cli: $SC_CLI"
                                echo "cli sha256: $SC_HASH (the CLI rides syscall 173; the stock reboot(169) CLI this box had during v47 is backed up at /data/adb/ReSuSFS/ksu_susfs.pre-v48.bak)"
                                echo "before: sc_entry_count=$(tread $SC_CNT)"
                                echo '-- ksu_susfs show version (timeout 3):'
                                $BB timeout 3 "$SC_CLI" show version 2>&1
                                echo '-- ksu_susfs show variant (timeout 3):'
                                $BB timeout 3 "$SC_CLI" show variant 2>&1
                                echo '-- ksu_susfs show enabled_features (timeout 3):'
                                $BB timeout 3 "$SC_CLI" show enabled_features 2>&1
                                echo "after: sc_entry_count=$(tread $SC_CNT)"
                                # ---- v26.11.53: THE FEATURE RUNG (stage >= 3 only) ---------------
                                # The first live FEATURE commands on this box, from the stock
                                # CLI's own wire ids: add_sus_path (0x55550), add_sus_path_loop
                                # (0x55553), hide_sus_mnts_for_non_su_procs (0x55561). Expect
                                # SILENT SUCCESS (exit 0, no output) for all three; the readback
                                # below (sc_probe) dumps what got stored. At stage 2 (OBSERVE)
                                # this block is skipped - feature calls there answer 126 like
                                # every other not-yet-accepted command.
                                if [ "$ARM_STAGE" -ge 3 ]; then
                                        echo "---- v53 FEATURE RUNG @ $(date '+%Y-%m-%d %H:%M:%S') ----"
                                        echo "feature before: sc_entry_count=$(tread $SC_CNT)"
                                        mkdir -p /data/local/tmp 2>/dev/null
                                        : > /data/local/tmp/.resusfs_v53_selftest 2>/dev/null
                                        : > /data/local/tmp/.resusfs_v53_selftest_loop 2>/dev/null
                                        echo '-- ksu_susfs add_sus_path /data/local/tmp/.resusfs_v53_selftest (timeout 3; EXPECT silent success, exit=0):'
                                        $BB timeout 3 "$SC_CLI" add_sus_path /data/local/tmp/.resusfs_v53_selftest 2>&1
                                        echo "   exit=$?"
                                        echo '-- ksu_susfs add_sus_path_loop /data/local/tmp/.resusfs_v53_selftest_loop (timeout 3; EXPECT silent success, exit=0):'
                                        $BB timeout 3 "$SC_CLI" add_sus_path_loop /data/local/tmp/.resusfs_v53_selftest_loop 2>&1
                                        echo "   exit=$?"
                                        echo '-- ksu_susfs hide_sus_mnts_for_non_su_procs 1 (timeout 3; EXPECT silent success, exit=0):'
                                        $BB timeout 3 "$SC_CLI" hide_sus_mnts_for_non_su_procs 1 2>&1
                                        echo "   exit=$?"
                                        echo '-- regression: ksu_susfs show version (timeout 3; MUST still answer v2.3.0):'
                                        $BB timeout 3 "$SC_CLI" show version 2>&1
                                        echo "feature after: sc_entry_count=$(tread $SC_CNT)"
                                fi
                                SC_PROBE=""
                                for p in /data/adb/ksu/bin/sc_probe "$MODDIR/bin/x86_64/sc_probe"; do
                                        [ -x "$p" ] && { SC_PROBE="$p"; break; }
                                done
                                if [ -n "$SC_PROBE" ]; then
                                        echo "---- sc_probe ($SC_PROBE, raw syscall view, independent of any CLI) ----"
                                        $BB timeout 10 "$SC_PROBE" 2>&1
                                else
                                        echo 'sc_probe: not found (expected at /data/adb/ksu/bin/sc_probe or bin/x86_64/sc_probe)'
                                fi
                                echo 'NOTE: v53 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry AND the whole accept path are clang-17; the uid gate reads the cred offset CALIBRATED at install from init_task/init_cred; the SHOW ids follow the STOCK CLI wire ABI (e1=version 20B, e2=enabled_features 8196B, e3=variant 20B); v53 adds THE FIRST FEATURE RUNG: 0x55550=add_sus_path and 0x55553=add_sus_path_loop (accepted, validated, deduped, stored in a 32-slot .data table - full -> -ENOSPC), 0x55561=hide_sus_mnts (recorded), private readback 0x55f53 via sc_probe; set_uname (0x55590) / set_cmdline (0x555b0) stay not-handled until the next rung; the stored paths are NOT yet enforced (accept+store is this rung); the v49 GCC wrapper is never called.'
                                } > "$SC_TEST_LOG" 2>&1
                                cat "$SC_TEST_LOG" >> "$BOOT_LOG" 2>/dev/null
                                log_boot "boot-completed: supercall self-test done (receipt: $SC_TEST_LOG)"
                        fi

                        # ---- v26.11.49: the DEFERRED ladder confirmation -----------------------
                        # Reached only when a transport-armed boot (ARM_STAGE >= 2)
                        # completed its init AND survived the supercall self-test
                        # above - the box is alive with the patched entry live
                        # under traffic, which is the actual claim the ladder
                        # confirms.  A boot that wedges at the self-test never
                        # reaches this block: its "try" marker stays stale and
                        # post-fs-data's demotion caps the ladder on the next
                        # boot.
                        if [ -n "$SC_DEFER_ADVANCE" ]; then
                                echo "ok $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null
                                if [ "$INIT_SEQ" -lt 6 ]; then
                                        echo $((INIT_SEQ + 1)) > "$INIT_SEQ_FILE" 2>/dev/null
                                        log_boot "boot-completed: substep $INIT_SEQ healthy (self-test survived) - next boot runs substep $((INIT_SEQ + 1))/7"
                                elif [ "$INIT_SEQ" -eq 6 ]; then
                                        echo 7 > "$INIT_SEQ_FILE" 2>/dev/null
                                        echo 1 > "$STAGE_FILE" 2>/dev/null
                                        log_boot "boot-completed: stage-0 substeps all healthy - next boot runs the LAYER LOOP at arm_stage 1 (seq=7)"
                                elif [ "$ARM_STAGE" -lt "$STAGE_MAX" ]; then
                                        echo $((ARM_STAGE + 1)) > "$STAGE_FILE" 2>/dev/null
                                        log_boot "boot-completed: arm_stage $ARM_STAGE healthy (init done + supercall self-test SURVIVED - the transport is live under traffic) - next boot arms stage $((ARM_STAGE + 1))/$STAGE_MAX"
                                else
                                        log_boot "boot-completed: arm_stage $ARM_STAGE healthy - at ladder max $STAGE_MAX (the v49 ceiling: 10 layers live + the kCFI-preamble'd LIVE sys_call_table supercall transport; runtime configuration of the susfs lists works via ksu_susfs)"
                                fi
                        fi

                        # ---- v26.11.54: THE ENFORCEMENT BRIDGE (gd64 ladder) ----------
                        # Arms the getdents64 filter (private supercall 0x55f54)
                        # ONLY after the stage-3 self-test passed and the stage
                        # 'ok' marker is complete, so a freeze inside THIS rung
                        # leaves stage='ok' + gd64='try' and the next boot
                        # disables enforcement without touching the proven
                        # stage-3 transport.  Every boot re-runs the rung:
                        # 'try' -> arm -> register test rule -> uid-drop test
                        # -> 'ok'; a stale 'try' (different boot_id) means the
                        # previous boot died inside the rung -> 'disabled'.
                        # v26.11.57 (v54.3): THE UID-READ FIX.  The v54.1 and
                        # v54.2 field runs both armed clean, the box survived,
                        # features even flashed 7 - but the uid-drop test
                        # failed 1s after the arm TWICE with the same terminal
                        # line.  Root cause (verified against vanilla 5.15.178
                        # AND android13-5.15 cred.h): the module read the uid
                        # at cred+8, which is the GID on 5.15 (atomic_t
                        # usage@+0, kuid_t uid@+4); every root:root caller
                        # passed the uid==0 gates by coincidence and the test
                        # (uid 101234, gid 0) was never filtered.  The .ko now
                        # reads uid@cred+4; the probe runs a GID CANARY first
                        # (root drops gid to 54321, uid stays 0 - show_version
                        # must STILL answer; a gid-keyed gate rejects exactly
                        # that call) so the receipt proves which word the gate
                        # reads.  The v54.2 full-directory walk and the
                        # per-step receipt archives are unchanged.
                        if [ -n "$SC_DEFER_ADVANCE" ] && [ "$ARM_STAGE" -ge 3 ] && [ "$SC_MODE" = "FULL" ]; then
                                GD64_FILE="$PERSISTENT_DIR/gd64_stage"
                                GD64_MARKER="$(cat "$GD64_FILE" 2>/dev/null)"
                                SC_PROBE=""
                                for p in /data/adb/ksu/bin/sc_probe "$MODDIR/bin/x86_64/sc_probe"; do
                                        [ -x "$p" ] && { SC_PROBE="$p"; break; }
                                done
                                if [ -z "$SC_PROBE" ]; then
                                        log_boot "boot-completed: v54 gd64 ladder SKIPPED (sc_probe not found)"
                                elif [ "$GD64_MARKER" = "disabled" ]; then
                                        log_boot "boot-completed: v54 gd64 ladder DISABLED (a previous boot died inside the enforcement rung or its test failed) - enforcement stays off, everything else unchanged"
                                else
                                        case "$GD64_MARKER" in
                                        "try "*" $CUR_BOOT") : ;;      # same boot (re-entry) ;;
                                        "try "*)                      # STALE: previous boot died in the rung
                                                echo "disabled" > "$GD64_FILE" 2>/dev/null
                                                log_boot "boot-completed: v54 gd64 ladder: stale 'try' marker from a previous boot ('$GD64_MARKER') - the enforcement rung is DISABLED for this version (stage-3 transport stays live; send the logs)"
                                                ;;
                                        *)
                                                echo "try 1 $CUR_BOOT" > "$GD64_FILE" 2>/dev/null
                                                sync
                                                log_boot "boot-completed: v54 gd64 ladder: arming the getdents64 filter (stage marker already 'ok' - a freeze from here on is THIS rung's)"
                                                # 1. THE ARM (private 0x55f54; receipts into the self-test log)
                                                {
                                                        echo "---- v54 gd64_arm @ $(date '+%Y-%m-%d %H:%M:%S') ----"
                                                        "$SC_PROBE" gd64_arm
                                                        echo "---- v54 readback (arm state) ----"
                                                        "$SC_PROBE" readback
                                                } >> "$SC_TEST_LOG" 2>>"$BOOT_LOG"
                                                sync
                                                # v54.2: PERSIST the arm receipt before anything can
                                                # overwrite it - the v54.1 field failure was
                                                # undiagnosable because the next boot's self-test
                                                # rewrote sc_selftest.txt before the failing check
                                                # could be read
                                                [ -n "$CUR_BOOT" ] || CUR_BOOT=unknown
                                                cp "$SC_TEST_LOG" "$PERSISTENT_DIR/logs/gd64_receipt_${CUR_BOOT}.txt" 2>/dev/null
                                                sync
                                                # the arm receipt spans two lines (cmd line +
                                                # payload.err line): judge the pair together
                                                if ! grep -A1 "gd64_arm cmd=" "$SC_TEST_LOG" 2>/dev/null | grep -q "payload.err=0 "; then
                                                        echo "disabled" > "$GD64_FILE" 2>/dev/null
                                                        log_boot "boot-completed: v54 gd64 arm REJECTED (err != 0 - see $SC_TEST_LOG) - enforcement disabled, everything else unchanged"
                                                else
                                                        log_boot "boot-completed: v54 gd64 arm OK (table[217] -> susfs_gd64_entry, preamble cloned; receipt archived to logs/gd64_receipt_${CUR_BOOT}.txt)"
                                                        # 2. THE UID-DROP FUNCTIONAL TEST (v54.2: FULL-directory
                                                        # walk, 32K batches until getdents64 returns 0 - the
                                                        # v54.1 test read ONE 4096-byte batch and lost the
                                                        # marker whenever /data/local/tmp was busy; root
                                                        # view vs app view, entry counts printed per view)
                                                        GDTEST_DIR=/data/local/tmp
                                                        GDTEST_MARKER=resusfs_v54_gdtest_marker
                                                        GDTEST_CONTROL=resusfs_v54_gdtest_control
                                                        rm -f "$GDTEST_DIR/$GDTEST_MARKER" "$GDTEST_DIR/$GDTEST_CONTROL" 2>/dev/null
                                                        echo x > "$GDTEST_DIR/$GDTEST_MARKER" 2>/dev/null
                                                        echo x > "$GDTEST_DIR/$GDTEST_CONTROL" 2>/dev/null
                                                        {
                                                                echo "---- v54 gd64_test @ $(date '+%Y-%m-%d %H:%M:%S') ----"
                                                                "$SC_PROBE" gd64_test "$GDTEST_DIR" "$GDTEST_MARKER" "$GDTEST_CONTROL"
                                                                echo "---- v54 readback (post-test) ----"
                                                                "$SC_PROBE" readback
                                                        } >> "$SC_TEST_LOG" 2>>"$BOOT_LOG"
                                                        sync
                                                        # v54.2: persist the post-test receipt (views +
                                                        # readback stats) - survives the next boot's
                                                        # self-test overwrite
                                                        cp "$SC_TEST_LOG" "$PERSISTENT_DIR/logs/gd64_receipt_${CUR_BOOT}.txt" 2>/dev/null
                                                        sync
                                                        if grep -q "v54_test: PASS" "$SC_TEST_LOG" 2>/dev/null; then
                                                                echo "ok 1 $CUR_BOOT" > "$GD64_FILE" 2>/dev/null
                                                                log_boot "boot-completed: v54 ENFORCEMENT VERIFIED (uid-drop test PASS: app-uid listings lose the registered entry, root keeps everything) - stage-late will register the config paths resolved; receipt archived to logs/gd64_receipt_${CUR_BOOT}.txt"
                                                        else
                                                                echo "disabled" > "$GD64_FILE" 2>/dev/null
                                                                log_boot "boot-completed: v54 gd64 uid-drop test FAILED (receipt archived to logs/gd64_receipt_${CUR_BOOT}.txt - send it with the logs) - enforcement DISABLED (a filter that fails its own test must not run), everything else unchanged"
                                                        fi
                                                fi
                                                ;;
                                        esac
                                fi
                        fi
                else
                        log_boot "boot-completed: init_done param not present (old module image?)"
                fi
        elif [ -f "$PERSISTENT_DIR/enable_lkm" ]; then
                log_boot "boot-completed: module image loaded (zombie state, proven safe) - init NOT triggered. Opt-in to the post-boot init experiment: touch /data/adb/ReSuSFS/enable_force_init"
        fi
fi
# ---- end v26.11.42 substep ladder trigger -------------------------------

# v26.11.23: stage-late + bootcompleted scripts are exactly what ran ~10s
# after the home screen appeared on the v26.11.22 install, right before the
# freeze - so both are receipt-gated now: if one of them hangs a boot, the
# next boot skips it automatically and boot.log names it.

log_boot "boot-completed: stage-late starting (gated, 120s)"
run_gated stage-late 120 sh "$MODDIR/ReSuSFS.sh" --stage-late >> "$BOOT_LOG" 2>&1
log_boot "boot-completed: stage-late rc=$?"

log_boot "boot-completed: bootcompleted user scripts starting (gated, 120s)"
run_gated bootcompleted-scripts 120 sh "$MODDIR/ReSuSFS.sh" --run-bootcompleted-scripts >> "$BOOT_LOG" 2>&1
log_boot "boot-completed: bootcompleted scripts rc=$?"

log_boot "=== boot-completed DONE ==="

# EOF
