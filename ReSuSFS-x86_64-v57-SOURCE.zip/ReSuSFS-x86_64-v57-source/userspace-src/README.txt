ksu_susfs.c is NOT shipped: the only copy in the sandbox is a broken
GitLab 404 HTML page from session 1. The wire-ABI authority is the
stock CLI BINARY at package-v56/bin/x86_64/ksu_susfs (sha256
7a30fa745a523a4e2897023086a2ef08d773899394781d131f68676227e80e9f,
not stripped - disassemble sc_main for the dispatch sites). The full
wire table is recorded in memory/FINDINGS.md and in sc_v53.c.
