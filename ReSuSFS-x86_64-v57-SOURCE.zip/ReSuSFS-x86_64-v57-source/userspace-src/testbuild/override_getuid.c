/* Test-only symbol override: pretend we are root so the CLI's root gate
 * passes on the sandbox user. The shipped NDK binary is untouched.
 * Kernel-side ops will still fail (no susfs kernel here, and reboot(2)
 * requires CAP_SYS_BOOT), which is exactly what this test wants to see.
 */
#include <sys/types.h>

uid_t getuid(void) { return 0; }
