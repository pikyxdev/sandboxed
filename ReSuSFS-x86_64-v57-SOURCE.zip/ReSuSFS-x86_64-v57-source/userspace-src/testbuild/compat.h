/* Host (glibc) test-build compat header.
 *
 * The vendored ksu_susfs source is written against bionic's struct stat
 * (st_atimensec-style legacy members) and includes <android/log.h>.
 * This header adapts both for a plain glibc static build so the tool's
 * logic can be exercised on a stock Linux x86_64 host. It is NOT used for
 * the shipped binary, which is built with the Android NDK.
 */
#include <limits.h>

#define st_atimensec  st_atim.tv_nsec
#define st_mtimensec  st_mtim.tv_nsec
#define st_ctimensec  st_ctim.tv_nsec

#define st_atime_nsec st_atim.tv_nsec
#define st_mtime_nsec st_mtim.tv_nsec
#define st_ctime_nsec st_ctim.tv_nsec
