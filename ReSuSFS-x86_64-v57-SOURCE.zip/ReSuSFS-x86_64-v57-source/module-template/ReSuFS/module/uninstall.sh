#!/bin/sh
rm -f /data/adb/ksu/bin/ksu_susfs
rm -f /data/adb/ksu/bin/susfs
rm -f /data/adb/ksu/bin/su
rm -f /data/adb/ksu/bin/ReSuSFS

# v26.11.23: also remove the module-owned LKM payload dir (the .ko never
# auto-loads on custom kernels, but do not leave it behind either).
rm -rf /data/adb/ReSuSFS_LKM

# v26.11.38: stand down the experiment flags + ladder state so an upgrade
# reflash starts from the safe defaults.
rm -f /data/adb/ReSuSFS/enable_lkm
rm -f /data/adb/ReSuSFS/enable_force_init
rm -f /data/adb/ReSuSFS/no_init_this_boot
rm -f /data/adb/ReSuSFS/lkm_candidate
rm -f /data/adb/ReSuSFS/arm_stage
rm -f /data/adb/ReSuSFS/stage_max
rm -f /data/adb/ReSuSFS/stage_boot

# EOF
