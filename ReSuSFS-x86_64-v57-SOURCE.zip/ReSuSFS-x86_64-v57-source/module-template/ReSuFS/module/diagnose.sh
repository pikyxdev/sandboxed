#!/bin/sh
# v26.11.23 - ReSuSFS safe bisector
#
# What this is: the v26.11.22 install froze LDPlayer 14 ~10s after the home
# screen appeared, and a frozen system leaves no logs. This script applies
# the module's features ONE STEP AT A TIME, each one individually:
#   - logged to /data/adb/ReSuSFS/logs/diagnose.log (synced after every line,
#     so it survives a hard instance restart)
#   - echoed to /dev/kmsg (visible in dmesg while the box is still alive)
#   - receipt-gated by the hang watchdog (utils.sh run_gated): if a step
#     freezes the system, force-restart the instance - the next run skips
#     that step automatically and never traps you in a hang loop
#
# NOTE v26.11.23: by default no LKM is loaded on custom kernels (LDPlayer's
# case), so steps 01-08 will answer rc!=0 "not supported" - that is the
# EXPECTED userspace-only result, not a failure. They become real kernel
# tests when the kernel has built-in susfs or you opted into the LKM:
#   touch /data/adb/ReSuSFS/enable_lkm   (then reboot)
#
# How to read the result after a hang: the last "STEP n START" line without
# its matching "STEP n DONE rc=" / "STEP n ALIVE" line names the exact
# feature that froze the kernel. Send boot.log + diagnose.log (+ dmesg if
# adb still answered) back for a targeted kernel-side fix.
#
# Run it either from the KernelSU manager Action button (this module's
# action.sh) or from a root shell:
#   adb shell su -c "sh /data/adb/modules/ReSuSFS/diagnose.sh"

PATH=/data/adb/ksu/bin:/system/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"
SUSFS_BIN=/data/adb/ksu/bin/ksu_susfs
DIAG_TMP=/data/local/tmp/susfs_diag

. "$MODDIR/utils.sh"

diag() { rs_run 15 "$SUSFS_BIN" "$@"; }

log_diag "================ DIAGNOSE START (module $(sed -n 's/^version=//p' $MODDIR/module.prop 2>/dev/null)) ================"

# v26.11.23: state of the kernel susfs interface up front, so the whole
# log is self-interpreting: userspace-only (expected rc!=0 below) vs
# real kernel interface (steps 01-08 are live kernel tests).
if susfs_kernel_alive; then
        log_diag "kernel susfs: ALIVE ($(rs_run 5 "$SUSFS_BIN" show version 2>/dev/null)) - steps 01-08 are LIVE kernel tests"
else
        log_diag "kernel susfs: NOT ALIVE - module is in userspace-only mode"
        log_diag "NOTE: no LKM is loaded on custom kernels unless you opted in"
        log_diag "NOTE: (touch /data/adb/ReSuSFS/enable_lkm + reboot). Steps 01-08"
        log_diag "NOTE: will answer rc!=0 'not supported' - that is expected."
        log_diag "NOTE: Steps 09-10 (userspace scripts) still run for completeness."
fi

# STEP 00 - environment snapshot (pure userspace, cannot hang)
log_diag "STEP 00 START: environment snapshot"
{
        echo "--- uname ---";          uname -a
        echo "--- /proc/version ---";  cat /proc/version 2>/dev/null
        echo "--- abi ---";            getprop ro.product.cpu.abi 2>/dev/null
        echo "--- android ---";        getprop ro.build.version.release 2>/dev/null
        echo "--- ksu_susfs ---";      ls -l "$SUSFS_BIN" 2>/dev/null
        echo "--- susfs proc nodes ---"
        ls -l /proc/susfs_path /proc/susfs_map /proc/susfs_kstat /proc/susfs_auto_mount 2>/dev/null || echo "(none of the common ones)"
        echo "--- LKM sysfs ---";      ls -d /sys/module/susfs_guard_lkm 2>/dev/null || echo "(no sysfs dir)"
        # v26.11.42: the ladder state (arm_stage / stage_max / stage_boot
        # files + the module's own params incl. the full diag_log trail and
        # the last wedged-boot snapshot) - the exact bring-up position and,
        # after a wedge, the last breadcrumb that ran.  init_laststep carries
        # the v41 sentinel codes: -1 fresh, -100 setter entered, -101 work
        # queued, 0..7 body substeps.  wd_timeout_s is gone with the v40
        # watchdog; force_init is 0200 write-only (a read is EACCES, not
        # a missing param - checked with -e now).
        echo "--- LKM module params (v42 substep-ladder state) ---"
        for p in arm_stage init_done sc_entry_count kr_scan diag_printk enable_log init_maxstep init_laststep; do
                echo "param $p = $(cat /sys/module/susfs_guard_lkm/parameters/$p 2>/dev/null || echo '(unreadable)')"
        done
        echo "param force_init = $([ -e /sys/module/susfs_guard_lkm/parameters/force_init ] && echo 'present (0200 write-only by design)' || echo '(absent - fallback image)')"
        echo "param wd_timeout_s = (removed in v41 - no kernel-side watchdog)"
        echo "param kr_seed = $(cat /sys/module/susfs_guard_lkm/parameters/kr_seed 2>/dev/null || echo '(unreadable - not seeded or old image)')"
        echo "--- ladder files + flags ---"
        for f in arm_stage stage_max stage_boot init_seq lkm_candidate; do
                echo "$f = $(cat /data/adb/ReSuSFS/$f 2>/dev/null || echo '(absent)')"
        done
        echo "--- init_trace.txt (v41 receipts + witness, last 30 lines) ---"
        tail -n 30 /data/adb/ReSuSFS/logs/init_trace.txt 2>/dev/null || echo "(absent - the v41 experiment has not dispatched yet)"
        for f in enable_lkm enable_force_init no_init_this_boot; do
                echo "$f = $([ -e /data/adb/ReSuSFS/$f ] && echo present || echo absent)"
        done
        echo "--- kernel facts (Phase-0 recon, v38) ---"
        ls -l /data/adb/ReSuSFS/logs/kernel_facts.txt /data/adb/ReSuSFS/logs/kernel_kallsyms.txt /data/adb/ReSuSFS/logs/kernel_config.txt 2>/dev/null || echo "(no recon files - post-fs-data kernel_recon has not run)"
        head -n 40 /data/adb/ReSuSFS/logs/kernel_facts.txt 2>/dev/null
        echo "--- diag_log (module param, full trail) ---"
        cat /sys/module/susfs_guard_lkm/parameters/diag_log 2>/dev/null || echo "(unreadable)"
        echo
        echo "--- diag_last.txt (last wedged-boot breadcrumbs, if any) ---"
        cat /data/adb/ReSuSFS/logs/diag_last.txt 2>/dev/null || echo "(absent - no wedge has been snapshotted yet)"
        echo "--- LSO ---"
        grep -i susfs /proc/modules 2>/dev/null || echo "(not in /proc/modules)"
        # v26.11.27: the module's own init lines (layer results, the
        # current_task %gs offset, the supercall/canary state, non-fatal
        # layer failures) live in dmesg and were never captured before.
        # Right after boot the ring still holds them; by diagnose time it
        # may have rotated - which is why post-fs-data also captures this
        # right after the load (see capture_lkm_live_evidence).
        echo "--- dmesg (susfs-related, last 40 lines) ---"
        BBd="$(command -v busybox)"
        dmd=""
        [ -n "$BBd" ] && dmd="$($BBd dmesg 2>/dev/null | grep -i susfs | tail -n 40)"
        [ -z "$dmd" ] && dmd="$(dmesg 2>/dev/null | grep -i susfs | tail -n 40)"
        echo "${dmd:-<dmesg unavailable or no susfs lines left in the ring>}"
} >> "$DIAG_LOG" 2>&1
log_diag "STEP 00 DONE"

# STEP 01 - passive supercalls, no rules yet
log_diag "STEP 01 START: passive supercalls (show version/variant/enabled_features)"
diag show version            >> "$DIAG_LOG" 2>&1; log_diag "STEP 01a show version rc=$?"
diag show variant            >> "$DIAG_LOG" 2>&1; log_diag "STEP 01b show variant rc=$?"
diag show enabled_features   >> "$DIAG_LOG" 2>&1; log_diag "STEP 01c show enabled_features rc=$?"
sleep 3
log_diag "STEP 01 ALIVE"

# STEP 02 - log + avc toggles
log_diag "STEP 02 START: enable_log 1 / enable_avc_log_spoofing 1"
diag enable_log 1            >> "$DIAG_LOG" 2>&1; log_diag "STEP 02a enable_log rc=$?"
diag enable_avc_log_spoofing 1 >> "$DIAG_LOG" 2>&1; log_diag "STEP 02b enable_avc_log_spoofing rc=$?"
sleep 3
diag enable_avc_log_spoofing 0 >> "$DIAG_LOG" 2>&1
log_diag "STEP 02 ALIVE (avc spoofing turned back off)"

# STEP 03 - set_uname with the REAL current values (exercises the uname path
# without changing anything)
log_diag "STEP 03 START: set_uname with real values"
diag set_uname "$(uname -r 2>/dev/null)" "$(uname -v 2>/dev/null)" >> "$DIAG_LOG" 2>&1
log_diag "STEP 03 set_uname rc=$?"
sleep 3
log_diag "STEP 03 ALIVE"

# STEP 04 - kstat add + update on a test file (the stat hook)
log_diag "STEP 04 START: add_sus_kstat + update_sus_kstat on test file"
mkdir -p "$DIAG_TMP" 2>/dev/null
echo susfs_diag > "$DIAG_TMP/kstat_target" 2>/dev/null
diag add_sus_kstat "$DIAG_TMP/kstat_target"        >> "$DIAG_LOG" 2>&1; log_diag "STEP 04a add_sus_kstat rc=$?"
diag update_sus_kstat "$DIAG_TMP/kstat_target"     >> "$DIAG_LOG" 2>&1; log_diag "STEP 04b update_sus_kstat rc=$?"
ls -l "$DIAG_TMP/kstat_target" >> "$DIAG_LOG" 2>&1
sleep 3
log_diag "STEP 04 ALIVE"

# STEP 05 - add_sus_path on a test entry + parent listing (the dirent filter)
log_diag "STEP 05 START: add_sus_path + real getdents (ls)"
echo hidden > "$DIAG_TMP/sus_path_entry" 2>/dev/null
diag add_sus_path "$DIAG_TMP/sus_path_entry" >> "$DIAG_LOG" 2>&1; log_diag "STEP 05a add_sus_path rc=$?"
diag add_sus_path "$DIAG_TMP"               >> "$DIAG_LOG" 2>&1; log_diag "STEP 05b add_sus_path (dir) rc=$?"
ls -la "$DIAG_TMP"          >> "$DIAG_LOG" 2>&1; log_diag "STEP 05c ls rc=$?"
ls -la /data/local/tmp      >> "$DIAG_LOG" 2>&1; log_diag "STEP 05d ls parent rc=$?"
sleep 3
log_diag "STEP 05 ALIVE"

# STEP 06 - add_sus_path_loop (this is what hides /dev/pts/* upstream)
log_diag "STEP 06 START: add_sus_path_loop on test entry + /dev/pts/0"
diag add_sus_path_loop "$DIAG_TMP/sus_path_entry" >> "$DIAG_LOG" 2>&1; log_diag "STEP 06a add_sus_path_loop rc=$?"
[ -e /dev/pts/0 ] && { diag add_sus_path_loop /dev/pts/0 >> "$DIAG_LOG" 2>&1; log_diag "STEP 06b /dev/pts/0 rc=$?"; }
ls -la /dev/pts             >> "$DIAG_LOG" 2>&1; log_diag "STEP 06c ls /dev/pts rc=$?"
sleep 3
log_diag "STEP 06 ALIVE"

# STEP 07 - add_sus_map + a real /proc/self/maps read (the maps kretprobe)
log_diag "STEP 07 START: add_sus_map + cat /proc/self/maps"
cp -f "$MODDIR/bin/x86_64/ksu_susfs" "$DIAG_TMP/dummy_lib.so" 2>/dev/null || echo x > "$DIAG_TMP/dummy_lib.so"
diag add_sus_map "$DIAG_TMP/dummy_lib.so" >> "$DIAG_LOG" 2>&1; log_diag "STEP 07a add_sus_map rc=$?"
cat /proc/self/maps > /dev/null 2>&1; log_diag "STEP 07b cat /proc/self/maps rc=$?"
cat /proc/1/maps > /dev/null 2>&1;  log_diag "STEP 07c cat /proc/1/maps rc=$?"
sleep 3
log_diag "STEP 07 ALIVE"

# STEP 08 - hide_sus_mnts_for_non_su_procs (mount hiding toggle)
log_diag "STEP 08 START: hide_sus_mnts_for_non_su_procs 1 (5s) then 0"
diag hide_sus_mnts_for_non_su_procs 1 >> "$DIAG_LOG" 2>&1; log_diag "STEP 08a enable rc=$?"
sleep 5
diag hide_sus_mnts_for_non_su_procs 0 >> "$DIAG_LOG" 2>&1; log_diag "STEP 08b disable rc=$?"
sleep 3
log_diag "STEP 08 ALIVE"

# STEP 09 - the four post-fs-data user scripts, one at a time (gated)
# These already ran on every v26.11.22 boot before the home screen appeared.
log_diag "STEP 09 START: post-fs-data user scripts, one by one"
for s in ReSuSFS_apply-cmdline-bootconfig.sh ReSuSFS_apply-kstat-add.sh ReSuSFS_apply-ksu-settings.sh ReSuSFS_apply-uname.sh; do
        if [ -f "$PERSISTENT_DIR/scripts/$s" ]; then
                log_diag "STEP 09.$s START"
                run_gated "diag-09-$s" 60 sh "$PERSISTENT_DIR/scripts/$s" >> "$DIAG_LOG" 2>&1
                log_diag "STEP 09.$s DONE rc=$?"
                sleep 3
                log_diag "STEP 09.$s ALIVE"
        else
                log_diag "STEP 09.$s missing, skipped"
        fi
done

# STEP 10 - the eight boot-completed user scripts, one at a time (gated).
# These ran ~10s after the home screen on v26.11.22 - the hang window.
log_diag "STEP 10 START: boot-completed user scripts, one by one"
for s in ReSuSFS_apply-mount-hiding.sh ReSuSFS_apply-props.sh ReSuSFS_apply-ksu-settings.sh ReSuSFS_apply-settings.sh ReSuSFS_apply-sus-maps.sh ReSuSFS_apply-sus-paths-loop.sh ReSuSFS_apply-sus-paths.sh ReSuSFS_cleanup-markers.sh; do
        if [ -f "$PERSISTENT_DIR/scripts/$s" ]; then
                if [ "$s" = "ReSuSFS_apply-settings.sh" ]; then
                        log_diag "STEP 10.$s START (note: this one disables adb_enabled in settings - if your adb console drops, that is this script, NOT a hang)"
                else
                        log_diag "STEP 10.$s START"
                fi
                run_gated "diag-10-$s" 60 sh "$PERSISTENT_DIR/scripts/$s" >> "$DIAG_LOG" 2>&1
                log_diag "STEP 10.$s DONE rc=$?"
                sleep 3
                log_diag "STEP 10.$s ALIVE"
        else
                log_diag "STEP 10.$s missing, skipped"
        fi
done

# STEP 11 - wrap up
log_diag "STEP 11 START: final state"
diag show enabled_features >> "$DIAG_LOG" 2>&1
log_diag "================ DIAGNOSE COMPLETE - ALL STEPS PASSED ================"
log_diag "If the system is still alive at this point, every feature of this port"
log_diag "works on this kernel. The v26.11.22 hang was therefore NOT a susfs"
log_diag "feature - re-enable the boot scripts in /data/adb/ReSuSFS/"
log_diag "scripts_postfs.txt and scripts_bootcompleted.txt (remove the leading"
log_diag "'#') one group at a time and reboot to confirm each."
log_diag "Evidence files: $DIAG_LOG, $BOOT_LOG, dmesg."

# EOF
