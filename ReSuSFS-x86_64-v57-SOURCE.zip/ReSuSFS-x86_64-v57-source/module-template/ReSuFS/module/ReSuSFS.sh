#!/bin/sh
PATH=/data/adb/ksu/bin:/data/data/com.termux/files/usr/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"
USER_SCRIPTS_DIR="$PERSISTENT_DIR/scripts"
POSTFS_SCRIPTS_FILE="$PERSISTENT_DIR/scripts_postfs.txt"
BOOTCOMPLETED_SCRIPTS_FILE="$PERSISTENT_DIR/scripts_bootcompleted.txt"
SUSFS_BIN=/data/adb/ksu/bin/ksu_susfs
SUSFS_MIN_VERSION="v2.2.0"

. "$MODDIR/utils.sh"

versionCode=$(grep versionCode $MODDIR/module.prop | sed 's/versionCode=//g' )

[ -n "$WEBUI_QUIET" ] && [ "${NO_BANNER:-0}" = "0" ] && banner

# v26.11.23: every supercall is timeout-bounded (10s). If ksu_susfs wedges,
# the surrounding gated stage still fires its own timeout, so the boot chain
# never blocks on a single stuck call.
susfs() { rs_run 10 "$SUSFS_BIN" "$@"; }

version_ge() {
        ver1="${1#v}"
        ver2="${2#v}"

        major1=$(echo "$ver1" | cut -d. -f1); major1=${major1:-0}
        minor1=$(echo "$ver1" | cut -d. -f2); minor1=${minor1:-0}
        patch1=$(echo "$ver1" | cut -d. -f3); patch1=${patch1:-0}

        major2=$(echo "$ver2" | cut -d. -f1); major2=${major2:-0}
        minor2=$(echo "$ver2" | cut -d. -f2); minor2=${minor2:-0}
        patch2=$(echo "$ver2" | cut -d. -f3); patch2=${patch2:-0}

        [ "$major1" -gt "$major2" ] && return 0
        [ "$major1" -lt "$major2" ] && return 1
        [ "$minor1" -gt "$minor2" ] && return 0
        [ "$minor1" -lt "$minor2" ] && return 1
        [ "$patch1" -ge "$patch2" ]
}

[ ! -d "$PERSISTENT_DIR" ] && mkdir -p "$PERSISTENT_DIR"

get_conf() {
        file="${3:-$PERSISTENT_DIR/config.txt}"
        val=$(grep "^$1=" "$file" 2>/dev/null | tail -n1 | cut -d'=' -f2-)
        [ -z "$val" ] && val="$2"
        echo "$val"
}

read_list() {
        [ -f "$1" ] || return
        sed 's/#.*//' "$1" | grep -v '^[[:space:]]*$'
}

[ ! -d "$USER_SCRIPTS_DIR" ] && mkdir -p "$USER_SCRIPTS_DIR"
[ ! -f "$POSTFS_SCRIPTS_FILE" ] && : > "$POSTFS_SCRIPTS_FILE"
[ ! -f "$BOOTCOMPLETED_SCRIPTS_FILE" ] && : > "$BOOTCOMPLETED_SCRIPTS_FILE"

CRON_SCRIPTS_FILE="$PERSISTENT_DIR/scripts_cron.txt"
[ ! -f "$CRON_SCRIPTS_FILE" ] && : > "$CRON_SCRIPTS_FILE"
CROND_DIR="$PERSISTENT_DIR/crontabs"

run_stage_scripts() {
        stage_file="$1"
        [ -f "$stage_file" ] || return
        # v26.11.23: an empty/comment-only list means "nothing to run" -
        # report success (0) instead of propagating grep's "no lines" rc 1,
        # so boot.log does not show a misleading rc=1 next to a clean pass.
        list=$(read_list "$stage_file") || return 0
        [ -z "$list" ] && return 0
        echo "$list" | while IFS= read -r name; do
                case "$name" in
                        "!"*) continue ;;
                esac
                script="$USER_SCRIPTS_DIR/$name"
                if [ -f "$script" ]; then
                        echo "[>] running $script"
                        log_boot "user-script '$name' starting (gated, 60s)"
                        run_gated "script-$name" 60 sh "$script"
                        echo "[*] user-script '$name' rc=$?"
                else
                        echo "[!] script not found, skipping: $name"
                        log_boot "user-script '$name' not found, skipping"
                fi
        done
}

sync_cron_scripts() {
        [ ! -d "$CROND_DIR" ] && mkdir -p "$CROND_DIR"

        pkill -f "busybox crond -bc $CROND_DIR" 2>/dev/null
        sleep 1

        busybox crond -bc "$CROND_DIR" -L /dev/null

        tmp="${CROND_DIR}/root.tmp.$$"
        : > "$tmp"

        list=$(read_list "$CRON_SCRIPTS_FILE") || { rm -f "$tmp"; return; }
        echo "$list" | while IFS= read -r line; do
                schedule=$(echo "$line" | cut -d' ' -f1-5)
                name=$(echo "$line" | cut -d' ' -f6-)
                [ -z "$name" ] && continue
                [ -f "$USER_SCRIPTS_DIR/$name" ] || { echo "[!] cron script not found, skipping: $name"; continue; }
                echo "$schedule { echo \"[\$(date '+%Y-%m-%d %H:%M:%S')] START $name\"; sh $MODDIR/ReSuSFS.sh --run-script $USER_SCRIPTS_DIR/$name; echo \"[\$(date '+%Y-%m-%d %H:%M:%S')] END $name exit=\$?\"; } >> $PERSISTENT_DIR/cron.log 2>&1" >> "$tmp"
        done

        busybox crontab -c "$CROND_DIR" "$tmp" 2>/dev/null
        rm -f "$tmp"

        echo "[+] cron schedule synced"
}

run_script() {
        script="$1"
        [ -z "$script" ] && { echo "[x] no script specified"; echo "[!] syntax: --run-script <path>"; exit 1; }
        case "$script" in
                *.sh) : ;;
                *) echo "[x] only .sh files allowed: $script"; exit 1 ;;
        esac
        [ -f "$script" ] || { echo "[x] script not found: $script"; exit 1; }
        [ -r "$script" ] || { echo "[x] script not readable: $script"; exit 1; }
        echo "[>] running $script"
        sh "$script"
        echo "[*] exit code: $?"
}

apply_list() {
        default="$1"; cmd="$2"; mode="$3"; file="${4:-$default}"

        if [ -f "$file" ]; then
                tmp="${file}.tmp.$$"
                busybox awk '
                        /^[[:space:]]*#/ { print; next }
                        /^[[:space:]]*$/ { next }
                        !seen[$0]++
                ' "$file" > "$tmp" && cat "$tmp" > "$file"
                rm -f "$tmp"
        fi

        list=$(read_list "$file") || return
        [ -z "$list" ] && return
        echo "$list" | while IFS= read -r p; do
                if [ "$mode" = "1" ] && [ ! -e "$p" ]; then echo "[!] skip missing path: $p"; continue; fi
                if [ "$mode" = "2" ] && [ ! -e "$p" ]; then continue; fi
                echo "[>] $cmd $p"
                susfs "$cmd" "$p"
        done
}

append_to_default() {
        default="$1"
        src="${2:-$default}"
        [ "$src" = "$default" ] && return 0
        case "$src" in
                *.txt) : ;;
                *) echo "[x] only .txt files allowed: $src"; return 1 ;;
        esac
        [ -f "$src" ] || { echo "[x] file not found: $src"; return 1; }
        [ -r "$src" ] || { echo "[x] file not readable: $src"; return 1; }
        [ -s "$src" ] || { echo "[x] file empty: $src"; return 1; }

        cat "$src" >> "$default"

        tmp="${default}.tmp.$$"
        busybox awk '
                /^[[:space:]]*#/ { print; next }
                !seen[$0]++
        ' "$default" > "$tmp" && {
                cat "$tmp" > "$default"
                rm -f "$tmp"
        }

        echo "[>] appended $src -> $default"
}

apply_sus_paths() { [ -n "$1" ] && { append_to_default "$PERSISTENT_DIR/sus_paths.txt" "$1" || return 1; }; apply_list "$PERSISTENT_DIR/sus_paths.txt" add_sus_path 1; }
apply_sus_paths_loop() { [ -n "$1" ] && { append_to_default "$PERSISTENT_DIR/sus_paths_loop.txt" "$1" || return 1; }; apply_list "$PERSISTENT_DIR/sus_paths_loop.txt" add_sus_path_loop 0; }
apply_sus_maps() { [ -n "$1" ] && { append_to_default "$PERSISTENT_DIR/sus_maps.txt" "$1" || return 1; }; apply_list "$PERSISTENT_DIR/sus_maps.txt" add_sus_map 1; }

apply_kstat() {
        mode="$1"
        [ -n "$2" ] && { append_to_default "$PERSISTENT_DIR/kstat_paths.txt" "$2" || return 1; }
        file="$PERSISTENT_DIR/kstat_paths.txt"
        list=$(read_list "$file") || return
        [ -z "$list" ] && return
        echo "$list" | while IFS= read -r line; do
                path=$(echo "$line" | awk '{print $1}')
                [ -z "$path" ] && continue
                args=$(echo "$line" | cut -d' ' -f2-)
                case "$mode" in
                        add)
                                if [ -n "$args" ]; then
                                        echo "[>] add_sus_kstat_statically $path $args"
                                        susfs add_sus_kstat_statically "$path" $args
                                else
                                        echo "[>] add_sus_kstat $path"
                                        susfs add_sus_kstat "$path"
                                fi
                                ;;
                        update)
                                echo "[>] update_sus_kstat $path"
                                susfs update_sus_kstat "$path"
                                ;;
                esac
        done
}

apply_kstat_add() { apply_kstat add "$1"; }
apply_kstat_update() { apply_kstat update "$1"; }

apply_open_redirect() {
        [ -n "$1" ] && { append_to_default "$PERSISTENT_DIR/open_redirect.txt" "$1" || return 1; }
        file="$PERSISTENT_DIR/open_redirect.txt"
        list=$(read_list "$file") || return
        [ -z "$list" ] && return
        echo "$list" | while IFS= read -r line; do
                target=$(echo "$line" | awk '{print $1}')
                redirect=$(echo "$line" | awk '{print $2}')
                scheme=$(echo "$line" | awk '{print $3}')
                [ -z "$target" ] || [ -z "$redirect" ] || [ -z "$scheme" ] && continue
                [ -e "$target" ] && [ -e "$redirect" ] || { echo "[!] skip: $target -> $redirect (missing endpoint)"; continue; }
                echo "[>] add_open_redirect $target -> $redirect (scheme $scheme)"
                susfs add_open_redirect "$target" "$redirect" "$scheme"
        done
}



apply_uname() {
        [ -n "$1" ] && {
                case "$1" in
                        *.txt) : ;;
                        *) echo "[x] only .txt files allowed: $1"; return 1 ;;
                esac
                [ -f "$1" ] || { echo "[x] file not found: $1"; return 1; }
                [ -r "$1" ] || { echo "[x] file not readable: $1"; return 1; }
                [ -s "$1" ] || { echo "[x] file empty: $1"; return 1; }

                release=$(grep "^release=" "$1" | tail -n1 | cut -d'=' -f2-)
                version=$(grep "^version=" "$1" | tail -n1 | cut -d'=' -f2-)

                [ -z "$release" ] && { echo "[x] release missing in $1"; return 1; }
                [ -z "$version" ] && { echo "[x] version missing in $1"; return 1; }

                [ -f "$PERSISTENT_DIR/uname.txt" ] && {
                        cp "$PERSISTENT_DIR/uname.txt" "${PERSISTENT_DIR}/uname.txt.bak.$$"
                        grep -v "^release=" "$PERSISTENT_DIR/uname.txt" > "${PERSISTENT_DIR}/uname.txt.tmp.$$"
                        grep -v "^version=" "${PERSISTENT_DIR}/uname.txt.tmp.$$" > "$PERSISTENT_DIR/uname.txt"
                        rm -f "${PERSISTENT_DIR}/uname.txt.tmp.$$" "${PERSISTENT_DIR}/uname.txt.bak.$$"
                }

                printf "release=%s\nversion=%s\n" "$release" "$version" >> "$PERSISTENT_DIR/uname.txt"
        }

        file="$PERSISTENT_DIR/uname.txt"
        [ -f "$file" ] || return

        release=$(grep "^release=" "$file" | tail -n1 | cut -d'=' -f2-)
        version=$(grep "^version=" "$file" | tail -n1 | cut -d'=' -f2-)

        [ -z "$release" ] && { echo "[x] release missing in $file"; return 1; }
        [ -z "$version" ] && { echo "[x] version missing in $file"; return 1; }

        echo "[>] set_uname '$release' '$version'"
        susfs set_uname "$release" "$version"
}

apply_cmdline_bootconfig() {
        [ -n "$1" ] && { append_to_default "$PERSISTENT_DIR/cmdline_or_bootconfig.txt" "$1" || return 1; }
        file="$PERSISTENT_DIR/cmdline_or_bootconfig.txt"
        # v26.11.23 fix: only hand the kernel a file that carries at least one
        # non-comment line. The stock default file is documentation-only, and
        # passing it on would have spoofed /proc/cmdline with comment text for
        # every non-su process.
        list=$(read_list "$file")
        [ -z "$list" ] && { echo "[*] cmdline/bootconfig list empty, skipping"; return 0; }
        echo "[>] set_cmdline_or_bootconfig $file"
        susfs set_cmdline_or_bootconfig "$file"
}

status_report() {
        # v26.11.23: dedupe - only rewrite module.prop when the status line
        # actually changed, so the periodic status loop does not rewrite the
        # overlay-mounted file (and feed the module-mount churn) on every pass.
        set_desc() {
                # v26.11.23 fix: NOT sed -i - the status strings now carry paths
                # ("/data/adb/ReSuSFS/enable_lkm") and break sed's /
                # delimiter. Rebuild the file safely instead; printf %s passes
                # any string through untouched, and cat > preserves the
                # inode/permissions (no overlay churn).
                cur="$(sed -n 's/^description=//p' "$MODDIR/module.prop" 2>/dev/null)"
                [ "$cur" = "$1" ] && return 0
                tmp="$MODDIR/module.prop.rs.$$"
                if grep -v '^description=' "$MODDIR/module.prop" 2>/dev/null > "$tmp"; then
                        printf 'description=%s\n' "$1" >> "$tmp"
                        cat "$tmp" > "$MODDIR/module.prop" 2>/dev/null
                fi
                rm -f "$tmp" 2>/dev/null
        }

        if [ -f $MODDIR/disable ]; then
                echo "[*] not running since module has been disabled"
                set_desc "status: disabled"
                return
        fi

        if [ ! -x "$SUSFS_BIN" ]; then
                echo "[x] ksu_susfs binary not found at $SUSFS_BIN"
                echo "[x] this kernel does not expose susfs, or susfs userspace tool is missing"
                set_desc "status: userspace-only (ksu_susfs missing) | LKM opt-in: /data/adb/ReSuSFS/enable_lkm"
                return
        fi

        # v26.11.23: no kernel susfs reachable (stock kernel and the LKM was
        # not loaded - the safe default on custom kernels). Userspace-only
        # mode is a supported, stable state: the script/cron/prop features
        # keep working, kernel-side hiding is dormant until a susfs-capable
        # kernel or an opt-in LKM provides the interface.
        if ! susfs_kernel_alive; then
                echo "[*] userspace-only mode: no kernel susfs detected (LKM not loaded or kernel without susfs)"
                set_desc "status: userspace-only (no kernel susfs) | LKM opt-in: /data/adb/ReSuSFS/enable_lkm"
                return
        fi

        susfs_version=$(susfs show version 2>/dev/null)
        if [ -z "$susfs_version" ] || ! version_ge "$susfs_version" "$SUSFS_MIN_VERSION"; then
                echo "[x] unsupported susfs version: '$susfs_version'"
                echo "[x] need $SUSFS_MIN_VERSION or higher"
                set_desc "status: unsupported susfs $susfs_version | need $SUSFS_MIN_VERSION+"
                return
        fi

        feat=$(susfs show enabled_features 2>/dev/null | wc -l)
        variant=$(susfs show variant 2>/dev/null)
        set_desc "status: active | susfs $susfs_version ($variant) | features: $feat"
        echo "[+] $susfs_version | $variant | features: $feat"
}

apply_toggles() {
        stage="$1"
        file="${2:-$PERSISTENT_DIR/config.txt}"
        [ -f "$file" ] || return
        if [ "$stage" = "early" ]; then
                hide_mnts=$(get_conf HIDE_SUS_MNTS_NON_SU "" "$file")
                enable_log=$(get_conf ENABLE_LOG "" "$file")
                avc_spoof=$(get_conf ENABLE_AVC_LOG_SPOOFING "" "$file")

                [ -n "$hide_mnts" ] && { echo "[>] hide_sus_mnts_for_non_su_procs $hide_mnts (early)"; susfs hide_sus_mnts_for_non_su_procs "$hide_mnts"; }
                [ -n "$enable_log" ] && { echo "[>] enable_log $enable_log"; susfs enable_log "$enable_log"; }
                [ -n "$avc_spoof" ] && { echo "[>] enable_avc_log_spoofing $avc_spoof"; susfs enable_avc_log_spoofing "$avc_spoof"; }
        elif [ "$stage" = "late" ]; then
                hide_mnts=$(get_conf HIDE_SUS_MNTS_NON_SU "" "$file")
                [ -n "$hide_mnts" ] && { echo "[>] hide_sus_mnts_for_non_su_procs $hide_mnts (late)"; susfs hide_sus_mnts_for_non_su_procs "$hide_mnts"; }
        fi
}

stage_early() {
        echo "[+] stage: early (post-fs-data)"

        # v26.11.23: userspace-only mode - no kernel susfs to talk to (stock
        # kernel, LKM not loaded by the safeguard). Applying susfs rules would
        # only produce dozens of failing supercalls; the userspace features
        # (user scripts, cron, props) keep running below/around this.
        if ! susfs_kernel_alive; then
                echo "[*] userspace-only mode: no kernel susfs - skipping susfs application"
                echo "[*] LKM opt-in (custom kernels): touch /data/adb/ReSuSFS/enable_lkm"
                return 0
        fi

        apply_kstat_add
        apply_uname
        apply_open_redirect
        apply_cmdline_bootconfig
        apply_toggles early
}

stage_late() {
        echo "[+] stage: late (boot-completed)"

        # v26.11.23: same userspace-only gate as stage_early. stage-late is
        # exactly what ran ~10s after the home screen appeared on the frozen
        # v26.11.22 install; with no kernel susfs there is nothing to apply
        # here and the stage stays a no-op.
        if ! susfs_kernel_alive; then
                echo "[*] userspace-only mode: no kernel susfs - skipping susfs application"
                return 0
        fi

        apply_sus_paths
        apply_sus_paths_loop
        apply_sus_maps
        apply_kstat_update
        apply_toggles late
        sync_cron_scripts
        status_report
}

run() {
        stage_early
        stage_late
}

action() { run; }

show_status() {
        echo "$susfs_version"
        susfs show variant
        susfs show enabled_features
}

show_help () {
        banner
        echo "[%] $( grep '^description=' $MODDIR/module.prop | sed 's/description=//' )"
        echo "usage:"
        printf " --action \t\t\t\tfull apply (early+late stage)\n"
        printf " --stage-early \t\t\t\tpost-fs-data stage only\n"
        printf " --stage-late \t\t\t\tboot-completed stage only\n"
        printf " --status \t\t\t\tshow susfs version / variant / enabled features\n"
        printf " --status-report \t\t\tsilently refresh module.prop's live status line\n"
        printf "\n"
        printf "if [file] is given it is appended (deduped) into the default list, then applied:\n"
        printf " --apply-sus-paths [file] \t\tadd_sus_path from list\n"
        printf " --apply-sus-paths-loop [file] \t\tadd_sus_path_loop from list\n"
        printf " --apply-sus-maps [file] \t\tadd_sus_map from list\n"
        printf " --apply-kstat-add [file] \t\tstage add_sus_kstat from list\n"
        printf " --apply-kstat-update [file] \t\tcommit update_sus_kstat from list\n"
        printf " --apply-open-redirect [file] \t\tadd_open_redirect from list\n"
        printf " --apply-uname [file] \t\t\tset_uname from config\n"
        printf " --apply-cmdline-bootconfig [file] \tset_cmdline_or_bootconfig from file\n"
        printf " --apply-toggles <early|late> [file] \tapply hide_sus_mnts/enable_log/avc_log_spoofing from config\n"
        printf " --run-script <file> \t\t\trun a user script from UserHub\n"
        printf " --run-postfs-scripts \t\t\trun all UserHub scripts flagged for post-fs-data\n"
        printf " --run-bootcompleted-scripts \t\trun all UserHub scripts flagged for boot-completed\n"
        printf " --sync-cron-scripts \t\t\trebuild the cron schedule from scripts_cron.txt\n"
        printf "\n"
        printf " --help \t\t\t\tdisplays this message\n"
}

case "$1" in
        --action) action; exit ;;
        --stage-early) stage_early; exit ;;
        --stage-late) stage_late; exit ;;
        --status) show_status; exit ;;
        --status-report) status_report; exit ;;
        --apply-sus-paths) apply_sus_paths "$2"; exit ;;
        --apply-sus-paths-loop) apply_sus_paths_loop "$2"; exit ;;
        --apply-sus-maps) apply_sus_maps "$2"; exit ;;
        --apply-kstat-add) apply_kstat_add "$2"; exit ;;
        --apply-kstat-update) apply_kstat_update "$2"; exit ;;
        --apply-open-redirect) apply_open_redirect "$2"; exit ;;
        --apply-uname) apply_uname "$2"; exit ;;
        --apply-cmdline-bootconfig) apply_cmdline_bootconfig "$2"; exit ;;
        --apply-toggles) apply_toggles "$2" "$3"; exit ;;
        --run-script) shift; run_script "$1"; exit ;;
        --run-postfs-scripts) run_stage_scripts "$POSTFS_SCRIPTS_FILE"; exit ;;
        --run-bootcompleted-scripts) run_stage_scripts "$BOOTCOMPLETED_SCRIPTS_FILE"; exit ;;
        --sync-cron-scripts) sync_cron_scripts; exit ;;
        --help|*) show_help; exit ;;
esac

# EOF
