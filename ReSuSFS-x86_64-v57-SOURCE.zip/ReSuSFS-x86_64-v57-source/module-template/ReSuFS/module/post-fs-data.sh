#!/bin/sh
PATH=/data/adb/ksu/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"

. "$MODDIR/utils.sh"

log_boot "=== post-fs-data START (kernel: $(uname -r 2>/dev/null), module: $(sed -n 's/^version=//p' $MODDIR/module.prop 2>/dev/null)) ==="

# v26.11.38 PHASE-0 RECON FIRST: capture the kernel's build facts to
# /data/adb/ReSuSFS/logs/kernel_facts.txt (+ kernel_kallsyms.txt,
# + kernel_config.txt) BEFORE any LKM action runs - even a boot that
# wedges later leaves the facts on disk for the next one, and the
# first successful boot hands us the compiler string, IKCONFIG config,
# kallsyms layout and KSU variant the port has been missing all along.
# (Implements Phase 0 of the LDPlayer port guide; bounded + gated.)
log_boot "post-fs-data: kernel_recon starting (gated, 60s)"
run_gated kernel-recon 60 sh -c ". $MODDIR/utils.sh; kernel_recon" >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: kernel_recon rc=$?"

# load the susfs LKM IMAGE. On custom (non-GKI) kernels like LDPlayer 14's
# 5.15.178+ this is a NO-OP unless the user opted in via
# /data/adb/ReSuSFS/enable_lkm (v26.11.23 safeguard - see utils.sh).
# The load is receipt-gated + timeout-bounded, so a wedged load attempt
# cannot block the boot chain AND is skipped on the next boot.
# v26.11.38: this is the PROVEN-SAFE zombie image state ONLY (v25..v37
# booted fine with the image loaded and init never running). The init
# trigger itself MOVED to boot-completed.sh: susfs_init now runs only
# AFTER the system is fully up, so a wedged init can never freeze the
# boot at 50% again - worst case the desktop freezes with all evidence
# already on disk, and the ladder below demotes the next boot.
log_boot "post-fs-data: LKM image load starting (gated, 150s; opt-in only on custom kernels)"
run_gated lkm-load 150 sh -c ". $MODDIR/utils.sh; load_susfs_lkm" >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: LKM load rc=$?"

if [ -e /proc/susfs_path ] || [ -d /sys/module/susfs_guard_lkm ]; then
        log_boot "post-fs-data: susfs LKM image is LIVE (image loaded)"
        # v26.11.38 LADDER, SPLIT ACROSS THE BOOT:
        #   post-fs-data.sh (HERE): demotion + caps - the EARLIEST reader of
        #     the stage_boot marker from the PREVIOUS boot. A "try N" marker
        #     whose boot_id is not this boot's means that boot's init
        #     (triggered at boot-completed time) never completed its witness:
        #     demote to a stage-0 evidence boot and cap stage_max below N.
        #   boot-completed.sh: seed the resolver from /proc/kallsyms, arm the
        #     stage, write the "try N" marker, trigger force_init, poll
        #     init_done while snapshotting diag_log, then witness ok/nok and
        #     raise the ladder by one rung.
        # Same-boot re-run safety is kept: markers written by THIS boot are
        # never demoted, and post-fs-data running twice in one boot is a
        # no-op (the marker check keys off the boot_id).
        STAGE_FILE="/data/adb/ReSuSFS/arm_stage"
        STAGE_MAX_FILE="/data/adb/ReSuSFS/stage_max"
        STAGE_BOOT_FILE="/data/adb/ReSuSFS/stage_boot"
        LADDER_VERSION_FILE="/data/adb/ReSuSFS/ladder_version"

        # ---- v26.11.45: ladder reset on MODULE VERSION CHANGE -----------------
        # The stage ladder's SEMANTICS are version-specific (v45 renumbered the
        # rungs: 2=supercall observe, 3=supercall accept, 4=LSM class, 5=sys_call
        # table writers; v44 had 2=supercall, 3=LSM, 4=full with max 4).  A
        # persisted stage_max/arm_stage from an older version would clamp or
        # mis-arm the new one (the v44 stage-3 wedge left stage_max capped at 2
        # on this box).  So: when module.prop's version differs from
        # ladder_version, re-base the STAGE dimension (stage file 0, stage_max
        # 5) and clear any stale stage_boot marker; the SUBSTEP dimension
        # (init_seq) is version-independent and stays where it was, so the
        # climb after an upgrade is stage 0 -> 5 at substep 7.
        MODVER=$(sed -n 's/^version=//p' $MODDIR/module.prop 2>/dev/null)
        LADDER_VER=$(cat "$LADDER_VERSION_FILE" 2>/dev/null)
        if [ -n "$MODVER" ] && [ "$MODVER" != "$LADDER_VER" ]; then
                log_boot "post-fs-data: module version changed ('$LADDER_VER' -> '$MODVER') - re-basing the stage ladder (arm_stage=0, stage_max=5, stale marker cleared); the substep ladder stays"
                echo "$MODVER" > "$LADDER_VERSION_FILE" 2>/dev/null
                echo 5 > "$STAGE_MAX_FILE" 2>/dev/null
                echo 0 > "$STAGE_FILE" 2>/dev/null
                rm -f "$STAGE_BOOT_FILE" 2>/dev/null
        fi

        ARM_STAGE=0
        [ -f "$STAGE_FILE" ] && ARM_STAGE=$(cat "$STAGE_FILE" 2>/dev/null | tr -dc '0-9')
        [ -z "$ARM_STAGE" ] && ARM_STAGE=0
        case "$ARM_STAGE" in 0|1|2|3|4|5) ;; *) ARM_STAGE=0 ;; esac

        STAGE_MAX=5
        [ -f "$STAGE_MAX_FILE" ] && STAGE_MAX=$(cat "$STAGE_MAX_FILE" 2>/dev/null | tr -dc '0-9')
        [ -z "$STAGE_MAX" ] && STAGE_MAX=5
        case "$STAGE_MAX" in 0|1|2|3|4|5) ;; *) STAGE_MAX=5 ;; esac
        if [ "$ARM_STAGE" -gt "$STAGE_MAX" ]; then
                log_boot "post-fs-data: arm_stage $ARM_STAGE above stage_max $STAGE_MAX - clamping"
                ARM_STAGE=$STAGE_MAX
        fi

        # Wedge demotion: a "try N <boot_id>" marker from a PREVIOUS boot means
        # that boot's post-boot init never completed its witness - it wedged
        # the box (or the user pulled power mid-experiment). Demote to a
        # stage-0 evidence boot and cap the ladder below the wedging rung.
        # If the wedge was at stage 0 itself, the resolver class is broken on
        # this kernel even SEEDED and printk-less: stand down completely this
        # boot (no trigger - boot-completed.sh checks no_init_this_boot), and
        # remove BOTH opt-in flags so the next boot comes up without the
        # module image init attempt at all (the zombie image stays proven
        # safe; a deliberate re-touch of the flags gets one fresh attempt).
        CUR_BOOT="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d -)"
        MARKER=""
        [ -f "$STAGE_BOOT_FILE" ] && MARKER=$(cat "$STAGE_BOOT_FILE" 2>/dev/null)
        MARKER_BOOT=""
        case "$MARKER" in
        "try "*|"ok "*|"nok "*) MARKER_BOOT=$(echo "$MARKER" | awk '{print $3}') ;;
        esac
        if [ -n "$MARKER_BOOT" ] && [ "$MARKER_BOOT" != "$CUR_BOOT" ]; then
                case "$MARKER" in
                try*)
                        # v26.11.40/v41: the wedge dossier goes INTO boot.log first,
                        # so one paste back carries everything: the init_trace
                        # receipts name the exact substep the frozen boot had
                        # dispatched, and the diag snapshot is whatever the
                        # poller salvaged before the freeze.
                        {
                                echo "---- WEDGE DOSSIER (stale marker '$MARKER' from boot $MARKER_BOOT) ----"
                                if [ -f "$LOG_DIR/init_trace.txt" ]; then
                                        echo "---- init_trace.txt (receipts; last 60 lines) ----"
                                        tail -n 60 "$LOG_DIR/init_trace.txt" 2>/dev/null
                                else
                                        echo "---- init_trace.txt: ABSENT (the frozen boot was a pre-v40 image, or the trigger never dispatched) ----"
                                fi
                                if [ -f "$LOG_DIR/diag_last.txt" ]; then
                                        echo "---- diag_last.txt ----"
                                        cat "$LOG_DIR/diag_last.txt" 2>/dev/null
                                else
                                        echo "---- diag_last.txt: ABSENT (init produced no crumbs, or the poller froze with the box) ----"
                                fi
                                echo "---- end WEDGE DOSSIER ----"
                        } >> "$BOOT_LOG" 2>/dev/null
                        if [ "$ARM_STAGE" -le 0 ]; then
                                log_boot "post-fs-data: a stage-0/substep boot itself never completed (marker '$MARKER') - see the WEDGE DOSSIER above for the exact substep. Removing enable_lkm + enable_force_init and suppressing the trigger this boot (zombie image, proven safe); evidence: $LOG_DIR/init_trace.txt + diag_last.txt + boot.log + kernel_facts.txt. Send all four back."
                                rm -f /data/adb/ReSuSFS/enable_lkm 2>/dev/null
                                rm -f /data/adb/ReSuSFS/enable_force_init 2>/dev/null
                                rm -f "$STAGE_BOOT_FILE" 2>/dev/null
                                echo 1 > /data/adb/ReSuSFS/no_init_this_boot 2>/dev/null
                        else
                                NEW_MAX=$((ARM_STAGE - 1))
                                log_boot "post-fs-data: PREVIOUS BOOT never completed at stage $ARM_STAGE (marker '$MARKER') - presumed wedge: demoting to a stage-0 evidence boot, capping stage_max at $NEW_MAX (init_trace receipts above name the substep)"
                                echo "$NEW_MAX" > "$STAGE_MAX_FILE" 2>/dev/null
                        fi
                        ARM_STAGE=0
                        echo "0" > "$STAGE_FILE" 2>/dev/null
                        ;;
                nok*)
                        # The previous boot COMPLETED and was witnessed (the
                        # box came up fully) but its init did not finish: a
                        # slow or stalled init, NOT a wedge. Retry the same
                        # rung - demoting here would false-positive on every
                        # healthy-but-slow seeded-resolver pass.
                        log_boot "post-fs-data: previous boot completed but init at stage $ARM_STAGE did not (marker '$MARKER') - NOT a wedge: retrying the same rung"
                        ;;
                esac
        fi

        # v26.11.27: capture the decisive evidence while the module's init
        # lines may still be in the dmesg ring (this is now post-LOAD only -
        # init has not even been triggered yet in v38; the poll+snapshot of
        # diag_log moved to boot-completed.sh, right next to the trigger).
        capture_lkm_live_evidence >> "$BOOT_LOG" 2>&1

        # ---- v26.11.42 trigger_mode=early ----------------------------------
        # The v35-v37 field triggers ran at post-fs-data time (system at
        # ~7s, boot quiet) and their module code verifiably EXECUTED; the
        # v39-v41 triggers ran at boot-completed and froze at the write.
        # trigger_mode=early moves the force_init write back to the v35-v37
        # context: if the early write survives where the late one froze,
        # the trigger CONTEXT (concurrency, ~20s of system state), not the
        # write itself, is the variable.  Receipts + recovery are identical
        # (a wedged early trigger leaves the stale "try" marker for the
        # next boot's stand-down; the init poll here is timeout-guarded).
        if [ -f /data/adb/ReSuSFS/enable_lkm ] && [ -f /data/adb/ReSuSFS/enable_force_init ] && [ ! -f /data/adb/ReSuSFS/no_init_this_boot ] && [ -d /sys/module/susfs_guard_lkm ]; then
                TRIGGER_MODE="set"
                [ -f /data/adb/ReSuSFS/trigger_mode ] && TRIGGER_MODE=$(head -n 1 /data/adb/ReSuSFS/trigger_mode 2>/dev/null | tr -d '[:space:]')
                if [ "$TRIGGER_MODE" = "early" ]; then
                        FORCE_INIT="/sys/module/susfs_guard_lkm/parameters/force_init"
                        LASTSTEP_PARAM="/sys/module/susfs_guard_lkm/parameters/init_laststep"
                        INIT_DONE="/sys/module/susfs_guard_lkm/parameters/init_done"
                        INIT_SEQ=0
                        [ -f /data/adb/ReSuSFS/init_seq ] && INIT_SEQ=$(cat /data/adb/ReSuSFS/init_seq 2>/dev/null | tr -dc '0-9')
                        [ -z "$INIT_SEQ" ] && INIT_SEQ=0
                        case "$INIT_SEQ" in 0|1|2|3|4|5|6|7) ;; *) INIT_SEQ=0 ;; esac
                        log_boot "post-fs-data: trigger_mode=early - writing force_init NOW (the v35-v37 trigger context; substep $INIT_SEQ)"
                        if [ -w "$FORCE_INIT" ]; then
                                echo 1 > "/sys/module/susfs_guard_lkm/parameters/diag_printk" 2>/dev/null
                                echo 1 > "$FORCE_INIT" 2>/dev/null
                                log_boot "post-fs-data: early force_init write returned (kworker scheduled; boot-completed.sh will NOT re-trigger - it skips when trigger_mode=early and init_done is set or the same boot already dispatched)"
                                echo "try $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null
                        else
                                log_boot "post-fs-data: early trigger skipped (force_init param not writable - old image?)"
                        fi
                fi
        fi
elif susfs_kernel_alive; then
        log_boot "post-fs-data: kernel susfs ALIVE (built-in or LKM) - full features enabled"
else
        log_boot "post-fs-data: no kernel susfs (stock kernel + LKM not loaded) - userspace-only mode"
fi

log_boot "post-fs-data: stage-early starting (gated, 120s)"
run_gated stage-early 120 sh "$MODDIR/ReSuSFS.sh" --stage-early >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: stage-early rc=$?"

log_boot "post-fs-data: postfs user scripts starting (gated, 90s)"
run_gated postfs-scripts 90 sh "$MODDIR/ReSuSFS.sh" --run-postfs-scripts >> "$BOOT_LOG" 2>&1
log_boot "post-fs-data: postfs scripts rc=$?"

log_boot "=== post-fs-data DONE ==="

# EOF
