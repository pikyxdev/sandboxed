# ReSuSFS x86_64 - v26.11.41

## v26.11.41: THE FREEZE NOW NAMES ITSELF (watchdog removed, codegen reverted, sentinel witness)

The v40 field result (2026-11-23 09:01:32, from your uploaded boot.log +
init_trace.txt): the box froze AT the `force_init` sysfs write.

```
[09:01:32] init-trace: writing force_init=1 (dispatching the deferred kworker)
[09:01:32] boot-completed: triggering force_init (deferred kworker; substep 0; ...)
                      <-- NOTHING AFTER THIS. No "force_init write returned",
                           no poller line, box hard-frozen, instance restart.
```

That write is the **first module code the whole boot executes**: under the
ksud zombie load `do_init_module` never ran the module's init, and the
earlier param writes (kr_seed, arm_stage, init_maxstep) are pure *kernel*
`param_ops_*` code, not this module's code. The v39 boot froze at the same
boundary with essentially the same image. The next boot's stand-down then
removed both flags, printed the WEDGE DOSSIER and suppressed the trigger -
**the recovery path is now field-proven**, and the module image itself
(loaded, zombie, init never triggered) has never taken a boot down.

What the v40 evidence could NOT do was say WHERE inside that boundary the
freeze sat: the receipts ended before the echo and the poller only starts
after it. v41 closes that gap and removes every identified suspect at once.

### What v26.11.41 changes

* **THE KERNEL-SIDE WATCHDOG IS REMOVED.** The v40 `panic`-on-stall delayed
  work (`wd_timeout_s`) never fired (the box froze *without* rebooting, so
  there was nothing for it to reboot), ran inside the very boundary it
  existed to instrument, and was the only unproven-call path in substep 0:
  `schedule_delayed_work`/`cancel_delayed_work_sync` pull
  `queue_delayed_work_on`, `cancel_delayed_work_sync`,
  `__msecs_to_jiffies` plus the brand-new `panic` import - none of them ever
  field-called before v40. Recovery is the proven userspace pair: the next
  boot's stand-down. `panic` drops out of the import set entirely.
* **THE CODEGEN IS REVERTED TO THE PROVEN PROFILE.** The v40 .ko was built
  with `RETHUNK=y`: all 446 function returns compiled as
  `cs jmp __x86_return_thunk` - i.e. every function return in the module
  jumps through a loader-absolutized import. The v26.11.26-37 vanilla image
  that ran module code live in the field (the v35 trigger ran the init body
  to ~50% of the layer loop) returned with plain `ret`. v41 builds with
  `RETPOLINE=n RETHUNK=n`: **zero return thunks**, plain `ret`s,
  `__x86_return_thunk` also drops out of the import set. The vermagic is
  unchanged (`5.15.178+ SMP preempt modversions`); the 123 remaining
  imports were all re-verified **present AND unique** against your uploaded
  field `kernel_kallsyms.txt` (99296 kernel records).
* **SENTINEL CODES + A BACKGROUND WITNESS.** `init_laststep` now carries
  boundary markers the userspace can see in real time:

  | value | meaning |
  |-------|---------|
  | `-1` | fresh module, trigger not run yet |
  | `-100` | the `force_init` setter ENTERED - the first module code |
  | `-101` | setter finished DIAG, about to `queue_work` the kworker |
  | `0` | the kworker is inside `susfs_init_body` |
  | `1..7` | inside substep N's own calls |

  `boot-completed.sh` now starts a **background witness BEFORE the
  `force_init` echo** (the v40 poller started after the echo that never
  returned) that mirrors every `init_laststep`/`init_done` change into
  `logs/init_trace.txt` with a `sync` per receipt, and snapshots
  `diag_log` to `logs/diag_last.txt`. A freeze therefore localizes itself
  ON DISK:
  witness stuck at `-1` = froze before any module code (kernel sysfs
  machinery, not the module); `-100` = in the setter's first calls;
  `-101` = at the `queue_work` dispatch; `0` = in the kworker's first
  statements; `N` = in substep N.
* **THE LADDER IS UNCHANGED.** `init_seq` 0..7 (0 = kworker dispatch proof
  only, 1 = +imports_guard, 2 = +resolver with the `kln=`/`gsoff=` seed,
  3 = +gs_off, 4 = +dead-man, 5 = +crosscheck, 6 = +patch_memory,
  7 = +layer loop with `arm_stage` 0..4), one rung per healthy boot,
  next-boot stand-down on a wedge, WEDGE DOSSIER into boot.log, payload
  stamp `v26.11.41` so a v41 flash refreshes the device image (the
  boot-time self-heal fires on stamp mismatch too).
* **THE COLLECTER'S `force_init` MISREAD IS FIXED.** `force_init` is
  deliberately `0200` (write-only): a *read* fails with EACCES, which the
  v40 collector printed as "param not exposed - fallback image". It now
  checks presence with `-e` and explains the mode. (`wd_timeout_s` is gone
  with the watchdog - reported as such.)

### Testing v26.11.41 (same two-step opt-in as v38..v40)

```
1. flash ReSuSFS-x86_64-v26.11.41.zip (KernelSU manager -> install from storage)
   - or adb:  adb push ReSuSFS-x86_64-v26.11.41.zip /data/adb/... then flash
2. adb shell "su -c 'touch /data/adb/ReSuSFS/enable_lkm'"
3. adb shell "su -c 'touch /data/adb/ReSuSFS/enable_force_init'"
4. reboot and let the boot COMPLETE (home screen visible)
5. watch:   adb shell "su -c 'tail -n 30 /data/adb/ReSuSFS/logs/init_trace.txt'"
```

Substep 0 runs on the first armed boot. Expected healthy sequence in
`init_trace.txt`:

```
STEP 0/7 DISPATCHING ...
seed v2 written: kln=... gsoff=...
writing arm_stage=0 (layer gate)
writing init_maxstep=0 (substep gate)
witness(bg): laststep=-1 init_done=0 @0s
writing force_init=1 (... sentinels: -100=setter entered, ...)
witness(bg): laststep=-100 init_done=0 @1s     <-- module code started
witness(bg): laststep=-101 init_done=0 @1s     <-- work queued
witness(bg): laststep=0 init_done=1 @2s        <-- kworker ran the body
force_init write returned (kworker scheduled)
STEP 0 COMPLETE (init_done=1 ...) - next boot runs substep 1/7
```

If the box freezes again, reboot/restart the instance - the next boot stands
down and prints the WEDGE DOSSIER, and the last `witness(bg)` receipt in
`init_trace.txt` names the exact boundary per the table above. Then send
back the four files: `logs/init_trace.txt`, `logs/diag_last.txt`,
`logs/boot.log`, `logs/kernel_facts.txt`.

---

# ReSuSFS x86_64 - v26.11.38

## v26.11.38: KERNEL-FACTS + SEEDED RESOLVER + POST-BOOT TRIGGER

The v26.11.37 result: a stage-0 evidence boot - imports guard, the kallrecon
auto-discovery SCAN and the DIAG printk, nothing else armed - STILL wedged the
box. Three conclusions drove this release:

1. The wedge lives inside that three-mechanism set. The scan is the only
   unbounded-ish, layout-guessy kernel-side work in it; the printk is the only
   thing that runs unconditionally before everything else; and the trigger
   itself ran DURING boot, which is why the boot animation froze at 50%.
2. The port has been building and debugging against a GUESSED kernel. The
   guide's Phase 0 (compiler string, IKCONFIG config, kallsyms layout, KSU
   variant) was never collected; Phase 1 (ymuuuu's prebuilt GKI
   android13-5.15 x64 ko) was never tried; Phase 2 (build against the exact
   android13-5.15-2025-03 source) was never done. v38 does all three.
3. Whatever wedges, the evidence now has to survive and the boot must not.

### What v26.11.38 changes

* **THE TRIGGER MOVED OUT OF THE BOOT.** `susfs_init` now runs in
  `boot-completed.sh` - after `sys.boot_completed`, on a fully booted,
  usable system. A wedged init can no longer freeze the boot animation at
  50%; the worst case is a frozen desktop with adb alive, evidence already
  on disk, and the ladder demotes + caps the next boot on its own.
  The trigger is additionally opt-in via a NEW second flag:
  `touch /data/adb/ReSuSFS/enable_force_init`
  (`enable_lkm` alone now keeps the module in its PROVEN-SAFE zombie image
  state, exactly the state v25..v37 booted fine with).
* **THE MEMORY SCAN IS OFF BY DEFAULT.** The resolver is SEEDED instead:
  `boot-completed.sh` greps the kernel's own kallsyms TABLE addresses out of
  `/proc/kallsyms` (they are public symbols: `kallsyms_offsets`/
  `kallsyms_addresses`, `kallsyms_relative_base`, `kallsyms_num_syms`,
  `kallsyms_names`, `kallsyms_markers`, `kallsyms_token_table`,
  `kallsyms_token_index`) and writes them into the new `kr_seed` module
  param. kallrecon then only VALIDATES the tables with bounded
  `copy_from_kernel_nofault` reads - no scanning. Without a seed and
  without an explicit `kr_scan=1` the resolver REFUSES (-ENODATA) instead
  of scanning. The v37 stage-0 wedge sat exactly in the class this removes.
* **MODULE PRINTK IS OFF BY DEFAULT.** `diag_printk` param (default 0) gates
  every DIAG/`pr_err`/raw-printk path, and `enable_log` now defaults OFF at
  load. The v35-era "printk is suppressed by KernelSU" observation was
  equally consistent with "printk wedged the kernel before dmesg could be
  read" - and printk is the ONE thing that ran unconditionally at step 1 in
  every wedged boot since v33. Crumbs now go to the `diag_log` param only,
  which the sysfs channel (proven working: every force_init write arrived)
  exposes.
* **PHASE-0 KERNEL RECON, EVERY BOOT.** post-fs-data writes
  `logs/kernel_facts.txt` (+`kernel_kallsyms.txt`, +`kernel_config.txt`):
  `/proc/version` compiler string, osrelease, taint, getenforce, key
  sysctls, ksud availability + variant hints, BTF dir, IKCONFIG config (when
  `/proc/config.gz` exists), `/proc/modules`, and the kallsyms layout
  markers (table symbols, `.cfi_jt` count, `current_task`/`fixed_percpu_data`
  ground truth). Collected BEFORE any LKM action, so even a wedged boot
  leaves the facts on disk.
* **THREE LKM CANDIDATES** switchable at runtime via
  `/data/adb/ReSuSFS/lkm_candidate` (default `android13`):

  | value | .ko | origin |
  |-------|-----|--------|
  | `android13` | `susfs_guard_lkm-x86_64-android13-5.15.ko` | **built against AOSP kernel/common `android13-5.15` at tag `ASB-2025-03-05_13-5.15`** - the March 2025 android13-5.15 release (5.15.178), the exact lineage the port guide identified for LDPlayer 14's `5.15.178+` kernel (Phase 2) |
  | `vanilla` | `susfs_guard_lkm-x86_64-vanilla-5.15.ko` | kernel.org linux-5.15.178 build - the v26.11.26..37 image, empirically config-matched (RETPOLINE/STACKPROTECTOR/HARDENED_USERCOPY/X86_5LEVEL/RANDOMIZE_MEMORY/MODULE_UNLOAD off, vermagic byte-identical) |
  | `ymuuu13` | `ymuuuu_android13-5.15_susfs_guard_lkm.ko` | ymuuuu's prebuilt GKI android13-5.15 x64 ko, live-tested on emulator GKI kernels (Phase 1 - "the cheap shot") |

  `echo vanilla > /data/adb/ReSuSFS/lkm_candidate` (or `android13`/`ymuuu13`)
  then reboot. Note: `ymuuu13` has NO `force_init`/`kr_seed` params (upstream
  image, normal init path) - it is the "does a known-good GKI x64 image even
  behave the same here" experiment, not a bring-up candidate for the ladder.

### The bring-up ladder (v37 semantics, relocated)

```
touch /data/adb/ReSuSFS/enable_lkm          # 1. load the image (zombie, safe)
touch /data/adb/ReSuSFS/enable_force_init  # 2. opt into the post-boot init
reboot                                     # 3. stage 0 runs AFTER the boot completes
# ... watch it climb one rung per healthy boot (~5 boots to full susfs):
adb shell su -c "cat /data/adb/ReSuSFS/arm_stage /data/adb/ReSuSFS/stage_max /data/adb/ReSuSFS/stage_boot"
adb shell su -c "tail -n 40 /data/adb/ReSuSFS/logs/boot.log"
```

Stage meanings (arm_stage): 0 = resolver-only evidence run (SEEDED,
printk-less); 1 = + resolve-only + `/proc` nodes; 2 = + supercall kretprobe
(the only kernel-text patch below 3); 3 = + lsm/sus_path/uname; 4 = full.

If a rung wedges the (already booted) box: power-cycle - the NEXT boot
demotes to stage 0 and caps `stage_max` below the wedging rung. If even a
stage-0 evidence run wedges, post-fs-data removes BOTH opt-in flags and
suppresses the trigger, so the box comes up clean with the evidence intact.

### Evidence to send back (from a wedged or healthy boot)

```
adb shell su -c "cat /data/adb/ReSuSFS/logs/kernel_facts.txt"   # Phase-0 facts (NEW - the big one)
adb shell su -c "cat /data/adb/ReSuSFS/logs/diag_last.txt"      # last breadcrumbs of the init
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"           # ladder transitions + seed + snapshots
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/diag_log"   # if the box is still alive
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/kr_seed"    # what was seeded
```

`kernel_facts.txt` finally answers the questions the port has been guessing
at: which compiler and config the LD kernel was built with (vanilla
kernel.org vs android13-5.15 lineage), whether BTF is available (exact
struct layouts at runtime), the kallsyms layout variant, and the KernelSU
variant - that picks the default LKM candidate for v39 and closes Phase 0.

### If a wedged init freezes the desktop (recovery)

```
adb root
adb shell rm -f /data/adb/ReSuSFS/enable_force_init   # stop the init experiment
adb shell rm -f /data/adb/ReSuSFS/enable_lkm          # also stand down the image load
adb reboot
```

Or just power-cycle: the ladder demotes + caps itself. If adb will not
connect, re-clone the LDPlayer instance - the evidence files survive under
`/data/adb/ReSuSFS/logs/` on the wedged instance's disk.

---

# ReSuSFS x86_64 - v26.11.37

## v26.11.37: EVIDENCE-FIRST STAGED BRING-UP

The v26.11.36 result: a fresh flash (no `/data/adb/ReSuSFS/arm_stage` file)
ran the stage-1 default - kallrecon resolver + `/proc` control nodes + the
supercall kretprobe on `__x64_sys_reboot` - and the boot **STILL wedged at
50%**. Two conclusions:

1. The wedge is inside the stage-1 set itself (resolver / current_task
   gs-off discovery / resolve-only layers / proc nodes / the kretprobe).
   Note the kretprobe had never been live-tested before v35: every earlier
   release loaded a zombie image whose init never ran at all.
2. Mechanism-class batching at that granularity could not attribute the
   wedge, and a default of 1 was too optimistic.

### What v26.11.37 changes

The old stage 1 is SPLIT, the kretprobe gets a rung of its own, and the
default drops to the floor that history has actually proven safe
(v25..v32: image load + params = boots fine; the resolver is read-only and
timeout-bounded):

| arm_stage | what arms | mechanism |
|-----------|-----------|-----------|
| 0 (DEFAULT) | nothing - imports guard, kallrecon resolver, current_task gs-off discovery, crosschecks | evidence mode, no layers, no kernel-text writes |
| 1 | + fp_hook (resolve only), ksu_umount_gate, ksu_allow_gate, sus_map, sus_mount, cmdline, open_redirect, prop_view, enable_log, avc_spoof | resolve-only + `/proc` nodes - no kernel text is touched |
| 2 | + supercall | **the `__x64_sys_reboot` kretprobe ALONE** - the only kernel-text patch below stage 3, on its own rung |
| 3 | + lsm_hook, sus_path (+ self-hide/relabel), uname, hide_syms | LSM hook insertion, kprobe on `kallsyms_op.s_show`, kretprobe on newuname |
| 4 | + create_gate, opath, dirent, kstat, sus_unix | full susfs - sys_call_table entry writes |

`arm_stage` defaults to **0 in the module image itself** (BSS, not `.data`),
so even a manual `insmod ... force_init=1` without the boot scripts lands on
the resolver-only floor.

### The ladder is self-managing (no more blind wedges)

* **service.sh** is the only writer of "healthy": after `sys.boot_completed`
  AND `init_done=1` it writes `ok N` to `/data/adb/ReSuSFS/stage_boot` and
  raises `arm_stage` by ONE rung (capped by `/data/adb/ReSuSFS/stage_max`).
  A wedge that manifests LATE in the boot (after init already reported done)
  can therefore never escalate past its rung.
* **post-fs-data.sh** writes `try N` before triggering `force_init`. If the
  next boot finds a leftover `try N` (the previous boot never completed),
  it demotes to a stage-0 evidence boot and caps `stage_max` at N-1 - the
  same wedge cannot recur blind, and the system regains function one proven
  rung per reboot.
* If even a stage-0 evidence boot wedges, the resolver class itself is
  broken on this kernel: post-fs-data removes `enable_lkm` automatically so
  the system boots without the module, and the evidence stays in the logs.

### Evidence survives the wedge now

While polling `init_done`, post-fs-data snapshots the module's `diag_log`
parameter to `/data/adb/ReSuSFS/logs/diag_last.txt` **every second it
changes** (and appends the final state to `boot.log`). printk from this
module is suppressed by KernelSU's hook and its `filp_open` is blocked, so
the module parameter is the only evidence channel - and it does not survive
a reboot unless copied out in time.

New breadcrumbs in v37 (all in `diag_log`):

* every init sub-step prints a crumb BEFORE running (so the last line
  always names the about-to-run function): `DIAG step 2/3/4a/4b/5/5a/6.N`
* the kallrecon resolver now drops phase crumbs: `resolver: pass 1
  starting`, `find_kallsyms_base() starting`, `pass 1 done`, `RETRY pass 2
  ...`, `resolver: ready (layout vN base=... num=...)`
* the supercall layer drops crumbs around the registration: `supercall:
  about to register_kretprobe on __x64_sys_reboot - THE ONLY text patch at
  stage 2` and `kretprobe REGISTERED (addr=...)`. If the box wedges right
  after the "about to" line, that layer is the culprit, identified.

### What to do

Flash, reboot, `touch /data/adb/ReSuSFS/enable_lkm`, then just REBOOT
REPEATEDLY. Each healthy boot raises the ladder one rung (~5 reboots to
full susfs). Watch it climb:

```
adb shell su -c "cat /data/adb/ReSuSFS/arm_stage /data/adb/ReSuSFS/stage_max /data/adb/ReSuSFS/stage_boot"
adb shell su -c "tail -n 30 /data/adb/ReSuSFS/logs/boot.log"
```

If a rung wedges: the boot stops there, `stage_boot` stays on `try N`, and
the NEXT reboot (no adb rescue needed - just reboot) comes up at stage 0
with `stage_max` capped at N-1. Then send back:

```
adb shell su -c "cat /data/adb/ReSuSFS/logs/diag_last.txt"       # last breadcrumbs of the wedged boot
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"           # stage transitions + diag_log final snapshot
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/diag_log"   # if the box is still alive
adb shell su -c "dmesg | grep -E 'XYZDIAG1|susfs_guard_lkm|ReSuSFS|DIAG step'"
```

The last breadcrumb before the wedge names the exact function that was
running when the kernel died.

### If a boot wedges (recovery)

```
adb root
adb shell rm /data/adb/ReSuSFS/enable_lkm
adb reboot
```

Keep `arm_stage` - the ladder self-manages (v37's demotion already resets it
to 0 on the boot after a wedge). If adb will not connect while stuck,
re-clone the LDPlayer instance; the evidence files survive under
`/data/adb/ReSuSFS/logs/` on the wedged instance's disk - grab
`diag_last.txt` + `boot.log` from the clone's disk image if you can, they
name the wedge point.

---

# ReSuSFS x86_64 - v26.11.36

## v26.11.36: STAGED BRING-UP (no more blind wedges)

The v26.11.35 boot was the FIRST TIME the module's init body ever ran on
this kernel (every earlier release either never ran init at all, or died
inside freed .init.text).  It ran the full layer surgery at once - LSM
hook insertion, sys_call_table entry writes, kprobes, /proc nodes - and
the boot wedged at 50%, with no evidence which step killed it.

The post-mortem ruled out every previously-known failure class:

* **Freed .init.text is ruled out.**  The deployed .ko has exactly one
  function in `.init.text`: the 17-byte `susfs_init` wrapper (and its
  `init_module` alias).  Nothing `force_init` reaches lives in freed
  memory - `susfs_init_body` is in `.text.unlikely`, and the three
  de-__init'd helpers are in `.text`.
* **NULL current->fs in the kworker is ruled out.**  5.15 creates every
  kthread with `CLONE_FS | CLONE_FILES` (`kernel/kthread.c:357`,
  `create_kthread()`), and kthreadd itself shares init's fs - so the
  kworker has a valid root and `kern_path("/proc/...")` in
  self-hide/relabel resolves normally.
* **The patching primitive is the stock stop_machine + fixmap +
  copy_to_kernel_nofault flow** (same lineage as KernelSU-Next's x86_64
  LKM), and the LSM hook insertion finds its list heads by IDENTITY
  (walking which list holds `selinux_<member>`), not by compiled
  offsets.

What remains: some step of the layer surgery on this LTO+PGO+BOLT
KernelSU-Next kernel wedges it - and it had never been live-tested,
because init never ran in any earlier release.

### What v26.11.36 changes

The layer loop is now gated by an `arm_stage` module parameter
(0644, set by post-fs-data.sh from `/data/adb/ReSuSFS/arm_stage`
BEFORE the `force_init` write).  Layers are grouped by what their init
actually DOES (audited per init function):

| arm_stage | what arms | mechanism |
|-----------|-----------|-----------|
| 0 | nothing (resolver + diagnostics only) | evidence mode |
| 1 (DEFAULT) | fp_hook (resolve only), ksu_umount_gate, ksu_allow_gate, sus_map, sus_mount, cmdline, open_redirect, prop_view, enable_log, avc_spoof, **supercall** | symbol resolution + /proc nodes + one kretprobe on `__x64_sys_reboot` (the same primitive KernelSU itself registers at boot; reboot is a cold path) |
| 2 | + lsm_hook, sus_path (+ the self-hide/relabel pass, which needs sus_path), uname, hide_syms | LSM hook insertion, kern_path-backed rule table, kprobe on `kallsyms_op.s_show`, kretprobe on newuname |
| 3 | + create_gate, opath, dirent, kstat, sus_unix | **sys_call_table entry writes** through stop_machine |

At stage 1 the supercall answers: `ksu_susfs show version` works, and
`diag_log` carries the full resolver evidence.  A stage-1 boot is the
safe default.

### The bring-up ladder

After a healthy stage-1 boot, escalate ONE mechanism class per boot:

```
adb shell su -c "echo 2 > /data/adb/ReSuSFS/arm_stage"   # + LSM/sus_path class
adb reboot
# ... check boot.log + diag_log, then:
adb shell su -c "echo 3 > /data/adb/ReSuSFS/arm_stage"   # full susfs
adb reboot
```

If a stage wedges, the mechanism class that caused it is known from
which stage you were on - and stage 1 always boots, so the module never
takes the system down blind.  Every skipped layer is named in
`diag_log`, and `init_done` polling now covers the full 2x10s kallrecon
retry path (25 seconds).

### If a boot wedges (recovery)

```
adb root
adb shell rm /data/adb/ReSuSFS/enable_lkm
adb shell rm -f /data/adb/ReSuSFS/arm_stage
adb reboot
```

If adb will not connect while stuck, re-clone the LDPlayer instance.

### Evidence to send back (especially from a wedged boot, before recovery)

```
adb shell su -c "dmesg | grep -E 'XYZDIAG1|susfs_guard_lkm|ReSuSFS|DIAG step'"
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/diag_log"
adb shell su -c "cat /sys/module/susfs_guard_lkm/parameters/init_done /sys/module/susfs_guard_lkm/parameters/arm_stage /sys/module/susfs_guard_lkm/parameters/sc_entry_count"
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"
```

The last `DIAG step N` line in dmesg/diag_log names the exact function
that wedged the kernel.

---

# ReSuSFS x86_64 - v26.11.28

## v26.11.28: supercall path fixed (kprobe+skip+canary -> kretprobe)

The v26.11.27 boot.log proved the LKM loads and is stable, but every
`ksu_susfs` supercall came back with "no supercall answer".  Root cause
analysis of the v26.11.27 dmesg evidence (which the v27 capture filtered
too narrowly to show, but the failure mode was unambiguous):

1. **The canary's delayed recheck failed.**  `susfs_supercall_init()`
   first registers a kprobe on a self-test function (`susfs_sc_canary_fn`)
   and verifies the IP-write skip mechanism works (`susfs_kp_skip_return`
   sets `regs->ip = &susfs_just_return` so the probed function returns
   immediately with a forced value).  At init time the kprobe is still
   int3-based and the IP write is honored - canary passes, `sc_canary_ok`
   is set, `register_kprobe(&reboot_kp)` proceeds, the module loads.
   But `schedule_delayed_work(&canary_dw, msecs_to_jiffies(1000))` fires
   a recheck one second later, and by then the kprobe optimizer has armed
   (or the probe rides the ftrace trampoline on LDPlayer's clang-LTO
   kernel).  An optimized/ftrace probe IGNORES the IP write - the canary
   function returns its natural value, the recheck fails, `sc_canary_ok`
   goes false, and `reboot_pre` exits at its `if (!sc_canary_ok) return 0`
   gate.  Every subsequent `ksu_susfs` supercall hits that gate, the real
   `__x64_sys_reboot` runs with our magics, returns -EINVAL (our magics
   are not LINUX_REBOOT_MAGIC1/2), and the CLI reports "no supercall
   answer".

2. **A second latent crash bug on x86_64.**  Even if the canary had
   passed, `reboot_pre` followed an arm64 syscall-wrapper quirk:
   `real_regs = (struct pt_regs *)susfs_sc_arg(regs, 0)` dereferences
   magic1 (0xDEADBEEF) as a `struct pt_regs *`.  On arm64 the wrapper's
   first argument IS a nested pt_regs*; on x86_64 the syscall args live
   DIRECTLY in `regs->di/si/dx/r10`.  This would have been a page fault
   oops on the first supercall - masked only because `sc_canary_ok` was
   always false and the deref was never reached.

### The fix: kretprobe, not kprobe+skip

`v26.11.28` replaces the entire kprobe+IP-skip+canary mechanism with a
**kretprobe** on `__x64_sys_reboot`:

- **`susfs_sc_entry` (entry_handler)**: reads `magic1/magic2/cmd/payload`
  DIRECTLY from `regs` via `susfs_sc_arg(regs, N)` - no arm64 indirection.
  Returns 0 (arm the return handler) only for root callers with matching
  magics and a `susfs_cmd_handled()` command; returns -1 (don't arm)
  otherwise, so real `reboot(2)` calls and unsupported commands pass
  through untouched.

- **`susfs_sc_ret (return_handler)**: fires from the rethook trampoline
  AFTER `__x64_sys_reboot` returned -EINVAL for our magics (harmless:
  the kernel's reboot path does NOT act on bad magics).  Queues the
  actual command via `task_work_add(TWA_RESUME)` (process context,
  before the syscall returns to userspace), then overrides `regs->ax`
  to 0 via `susfs_kp_set_ret` so userspace sees success.

The rethook trampoline is reliable on EVERY kprobe backend (int3,
jump-optimized, ftrace) - there is no IP write to ignore, so no canary
is needed.  The `susfs_sc_canary_fn`/`canary_kp`/`canary_dw`/`sc_canary_ok`
symbols are all gone from the .ko.

### Verification

```
undefined symbols: 122  (same as v26.11.27 - all runtime-resolved)
vermagic: 5.15.178+ SMP preempt modversions   (byte-identical to kernel)
register_kretprobe, susfs_sc_entry, susfs_sc_ret, reboot_krp: present
canary/sc_canary/susfs_sc_canary/reboot_pre/reboot_kp: absent
try_module_get/module_put/find_vma/current_task/saved_boot_config: still absent
```

### What to expect when you flash v26.11.28

Flash, reboot, `touch /data/adb/ReSuSFS/enable_lkm`, reboot again, then
send `boot.log` + `diagnose.log`.  If the kretprobe registered and the
path works, you should see in the LKM live evidence block:

```
---- supercall live test (ksu_susfs show version / variant / enabled_features) ----
<the actual susfs version string, not "no supercall answer">
<the actual susfs variant string>
<the actual enabled_features list>
```

And in dmesg (now captured with a WIDER filter - the v27 `grep -i susfs`
missed `pr_warn("supercall delivery uses a kprobe path...")` because
"supercall" contains no "susfs" substring):

```
susfs supercall: armed (reboot ABI kretprobe, version ...)
susfs_guard_lkm: supercall delivery uses a kretprobe on __x64_sys_reboot - ...
```

If the supercall STILL doesn't answer, the widened dmesg capture will now
show exactly which layer failed (the v27 filter was the second bug after
the kprobe+skip design).  Next suspect in that case: `ksu_init_symbol_resolver()`
or `register_kretprobe` itself returning non-zero.

---

## Historical: v26.11.27

# ReSuSFS x86_64 - v26.11.27

## The v26.11.26 result: the LKM LOADS

The v26.11.26 boot.log is the breakthrough the port has been working
toward since v26.10.23:

```
susfs_insmod: resolved 122/122; unresolved 0
susfs_insmod: init_module(582192 bytes, 122 symbols absolutized, params "")
susfs_insmod: loaded (vermagic fixup not needed); checking /sys/module/susfs_guard_lkm
susfs_insmod: OK: /sys/module/susfs_guard_lkm exists
[+] LKM loaded successfully (susfs_insmod, custom-kernel path)
post-fs-data: LKM load rc=0
post-fs-data: susfs LKM is LIVE (/proc/susfs_path present)
```

The five-symbol fix worked exactly as designed: zero unresolved
imports, the kernel accepted the module WITHOUT the vermagic patch
("vermagic fixup not needed"), `/proc/susfs_path` was created at load
time, and the module shows Live in `/proc/modules`. The whole boot
completed in ~10s on TWO consecutive boots with the module loaded -
no freeze, no watchdog skips. The load wall is over.

## The remaining issue: the supercall path does not answer

Every `ksu_susfs` command reports "no supercall answer", and
stage-early's functional probe (`ksu_susfs show version`) failed one
second after the load - the path was dead from the start, not degraded
later. That keeps the module in userspace-only mode (kernel-side
features undriven; the WebUI's "Unsupported ksu_susfs version /
Unknown / no features" is the same symptom - the "3 Sus Kstat" there
is userspace bookkeeping from the apply scripts, not the kernel).
Two more observations point the same way: the module's own control
nodes disappear from stat minutes after the load (the `-e` check
passed at load time, `ls -l /proc/susfs_path` fails in diagnose), and
the module's self-hiding from `/proc/modules` is not active (its line
shows). Stealth layers that did not arm - the same failure class as
the supercall.

The kernel-side mechanism was verified in source: the supercall layer
is fatal, so a live module proves the canary and the reboot kprobe
registration both succeeded at init; the register mappings (di/si/dx/
r10) and the magic constants (0xDEADBEEF/0xFAFAFAFA) match between
the CLI and the handler. What the evidence must now separate: the
delayed canary recheck disarming the supercall, the reboot kprobe at a
wrong address (BOLT/LTO kallsyms quirk), the `current_task` %gs offset
assumption (kallsyms printed `0` for it under kptr_restrict=2, which
may be the restricted print rather than the true offset), or non-fatal
layers that failed to arm.

## What v26.11.27 changes: automatic evidence capture

The module's init-time lines (layer results, the current_task %gs
offset it chose, the canary state, non-fatal layer failures) all went
to dmesg - which nobody captured: `susfs_insmod` seeks /dev/kmsg to
the END before init_module, and diagnose.sh never dumped dmesg.
v26.11.27 captures it automatically. Right after every successful
load, post-fs-data now appends to boot.log:

- a **live supercall test** (`ksu_susfs show version / variant /
  enabled_features`, each timeout-bounded);
- the **module's own init-time dmesg** (the susfs-related lines of the
  last 400);
- the **kallsyms ground truth** for `current_task`, `__x64_sys_reboot`,
  `__per_cpu_start`, `fixed_percpu_data`, `init_task` - with
  kptr_restrict relaxed exactly the way the loader does (restored
  right after). An 'A' (per-CPU) record prints the symbol's true
  per-CPU offset, which directly validates the offset the module
  chose at init;
- the **kprobe registration state** (best effort via
  /sys/kernel/debug/kprobes/list);
- the module's **/proc/modules visibility** (self-hiding active or
  not);
- the **control-node state**: `-e` (existence) versus `ls /proc`
  (getdents view) - hidden from listing is the module's own stealth
  working as designed, missing from stat is a bug.

`diagnose.sh` STEP 00 dumps the same susfs-related dmesg tail, so the
user-triggered diagnose carries the module state too.

The bundled LKM is unchanged (byte-identical .ko to v26.11.26): it
loads and the system is stable - the next LKM change lands only after
this evidence names the dead layer.

## Flashing v26.11.27

Flash in KernelSU manager, reboot, and (for the LKM opt-in) `touch
/data/adb/ReSuSFS/enable_lkm` then reboot once more. After the boot,
send `/data/adb/ReSuSFS/logs/boot.log` (the live-evidence block will
be at the top of the LKM section) and, if convenient, the diagnose.log
from the Action button. `adb shell su -c "dmesg | grep -i susfs"`
right after a boot is an even faster shortcut.

---

# ReSuSFS x86_64 - v26.11.26 (historical, kept for reference)

## What the v26.11.25 log revealed

v26.11.25 got the LKM through the vermagic and `__versions` gates: the
loader parsed the module (42 sections, 1413 symbols, 127 imports), relaxed
`kptr_restrict`, resolved 122 of 127 imports to real kernel addresses from
`/proc/kallsyms`, patched the vermagic in place from
`"5.15.178+ SMP preempt mod_unload modversions "` (45 bytes) to
`"5.15.178+ SMP preempt modversions "` (34 bytes, the kernel's own), and
resubmitted. The kernel answered `ENOENT` (errno 2) and printed exactly
five rejects:

```
susfs_guard_lkm: Unknown symbol try_module_get (err -2)
susfs_guard_lkm: Unknown symbol find_vma (err -2)
susfs_guard_lkm: Unknown symbol module_put (err -2)
susfs_guard_lkm: Unknown symbol saved_boot_config (err -2)
```

(and `current_task`, the fifth, was named in the loader's own diagnostic).
No vermagic complaint, no `module_layout` rejection - the gate that
v26.11.25 fixed stays passed. The five names are the leftover: every one
of them is normally reachable through the kernel's export table or
kallsyms, and LDPlayer's `clang +pgo +bolt +lto` build removed the EXPORT
for each.

## What v26.11.26 changes

Each of the five names is eliminated at the source level - the compiler
no longer emits the corresponding `SHN_UNDEF` entry, so the kernel's
symbol-resolution pass has nothing to reject.

1. **`try_module_get` and `module_put`** - LDPlayer's kernel was built
   WITHOUT `CONFIG_MODULE_UNLOAD` (its required vermagic lacks the
   `mod_unload` token that v26.11.25 carried and had to patch out). The
   `extern` declarations of `try_module_get`/`module_put` in
   `<linux/module.h>` live behind `#ifdef CONFIG_MODULE_UNLOAD`, so
   building the LKM with `MODULE_UNLOAD=y` left them as real `extern`
   calls and the compiler emitted `R_X86_64_PLT32 try_module_get` /
   `module_put` relocations. Building with `MODULE_UNLOAD=n` turns both
   into `static inline` no-ops, the relocations vanish, and the resulting
   vermagic is byte-identical to the kernel's own
   (`5.15.178+ SMP preempt modversions ` - the loader's vermagic fixup is
   no longer needed for this token, though it stays as a safety net).
2. **`find_vma`** - replaced with the file-local `sus_map_find_vma(mm, addr)`
   already defined earlier in `sus_map.c` for the `walk_page_range` hook.
   Same contract (first VMA whose `vm_end > addr`), same maple-tree /
   linked-list walk under the `mmap_read_lock` the caller already holds.
   No semantic change; the `R_X86_64_PLT32 find_vma` relocation disappears.
3. **`current_task`** - the kernel's `<asm/current.h>` defines `current`
   as `this_cpu_read_stable(current_task)`, whose inline-asm expansion is
   `movq %gs:current_task_offset, %reg` - an `R_X86_64_32S current_task`
   relocation. The displacement is normally filled from
   `EXPORT_PER_CPU_SYMBOL(current_task)`, which LDPlayer's LTO+trim build
   removed. v26.11.26 overrides `<asm/current.h>` in the kbuild-x64 tree
   (only used for out-of-tree module builds - the kernel itself was never
   compiled against this tree) so `current` reads through
   `movq %%gs:0(,%1,1), %0` (SIB-only addressing), with the displacement
   loaded from a runtime global `susfs_current_task_gs_off`. That global
   is filled once at module init from `ksu_kallsyms_lookup_name("current_task")`
   (kernel/susfs_current.c, called right after `ksu_init_symbol_resolver()`
   returns). On LDPlayer kallsyms reports `current_task` at address 0,
   which is also the correct per-CPU displacement there; on a stock 5.15
   kernel where `current_task` is at offset 4096 (after `fixed_percpu_data`
   which is `__aligned(PAGE_SIZE)`) the same resolver sets the
   displacement to 4096. Either way the compiler never emits a
   `current_task` relocation.
4. **`saved_boot_config`** - the original code declared it `extern` and
   relied on ksud / susfs_insmod to relocate it from kallsyms (the
   variable is an fs/init-main.c static, never `EXPORT_SYMBOL`'d). The
   v26.11.25 boot log confirmed LDPlayer's kallsyms does not list
   `saved_boot_config` at all, so the import was left at `SHN_UNDEF/0`.
   v26.11.26 makes `saved_boot_config` a `static char *` local to
   `spoof_cmdline.c` and removes the matching `IMP_DATA` entry from
   `imports_guard.c`. The `spoof_cmdline` feature is now INERT on LDPlayer
   (`/proc/bootconfig` is not spoofed); the file header documents how to
   re-arm it on a kernel that does list the symbol.

## Verification

- `objdump -t susfs_guard_lkm.ko | grep -E 'try_module_get|find_vma|module_put|current_task|saved_boot_config'`
  returns no `*UND*` entries for any of the five names; `saved_boot_config`
  shows up as a local `.bss` symbol (the file-static), as expected.
- Undefined symbol count: 127 (v25) -> 122 (v26). Every remaining import
  was already resolvable on LDPlayer in the v25 boot log.
- Vermagic (from `strings`): `5.15.178+ SMP preempt modversions ` -
  byte-identical to what the v25 loader had to patch in place.
- Loader host simulation parses the new .ko (42 sections, 1409 symbols)
  without complaint; the kallsyms walk cannot run on the build host
  (non-root, kptr_restrict=2) but the parse / symbol-resolution-stage
  artifacts are identical to v25's.

## What to expect on the next opt-in boot

This is the first build that the kernel should accept: the vermagic
matches byte-for-byte, the `__versions` gate stays passed (unchanged from
v25), and every name the kernel refused in v25 is gone from the symbol
table. If the load still fails, the boot.log will say which layer is next
- most likely candidates are the kallrecon layout discovery (kernel
symbol-table variant detection, runs inside `ksu_init_symbol_resolver()`)
or the first kprobe registration in the layer init plan. Either way the
diagnostic block from v25 (dmesg tail + MODVERSIONS probe + per-name
kallsyms status) still ships and will print the evidence.

## Flashing v26.11.26

Same as v25: flash in KernelSU manager, reboot, and (for the LKM opt-in)
`touch /data/adb/ReSuSFS/enable_lkm` then reboot once more. The module
ships in userspace-only mode by default; the LKM is only attempted when
the opt-in flag is present.

---

# ReSuSFS x86_64 - v26.11.25 (historical, kept for reference)

## What the v26.11.24 log revealed

With the loader fixed, the opt-in boot finally ran the real load: the loader
parsed the module (51 sections, 1429 symbols, 141 imports), relaxed
kptr_restrict, resolved 124 imports to real kernel addresses from
/proc/kallsyms, and submitted the patched image. The kernel answered
ENOEXEC (errno 8) and printed NOTHING - no "Unknown symbol", no
"version magic ... should be ...". ksud failed identically. Reading the
exact 5.15.178 kernel/module.c source explains it completely:

- load_module() calls **check_modstruct_version() BEFORE the vermagic
  check** (module.c:4029 vs :3575).
- On a CONFIG_MODVERSIONS=y kernel (an Android 14 GKI-style build, which
  exports module_layout with a CRC), a module with **no __versions
  section** hits check_version()'s "versindex == 0" path, which calls
  try_to_force_load(), whose no-force-load branch is
  `return -ENOEXEC;` - **the single unprinted failure in the whole
  module loader**. Every earlier build of this port had MODVERSIONS off,
  so this is the wall every v26.11.22..24 load attempt died on.
- The same log named the other problem: 17 of 141 imports were unresolved.
  12 of them (7 retpoline thunks, __stack_chk_fail, __check_object_size,
  pgdir_shift, page_offset_base, ptrs_per_p4d) are imports for kernel
  features LDPlayer's kernel runs WITHOUT - build-config mismatches. The
  other 5 (try_module_get, module_put, find_vma, saved_boot_config,
  current_task) resolve kernel-side (export tables / kallsyms).

## What v26.11.25 changes

1. **The bundled LKM is rebuilt to pass the gate and match the kernel:**
   - a neutral single-entry `__versions` section (kernel/modver_dummy.c +
     tools/normalize_modver.py) turns the module_layout CRC check into the
     kernel's own escape hatch - `pr_warn_once("no symbol version for
     module_layout")` + accepted;
   - CONFIG_MODVERSIONS=y build, so the vermagic carries the "modversions"
     word the target expects ("5.15.178+ SMP preempt mod_unload
     modversions");
   - the 12 phantom imports are GONE: 141 -> 127 imports, all resolvable
     on the target (verified offline against the import list).
2. **Failed loads now dump decisive evidence** into boot.log: the
   MODVERSIONS probe (grep __crc_module_layout /proc/kallsyms - on a
   MODVERSIONS kernel the CRC is the printed address), per-name kallsyms
   status for the imports that matter, a raw dmesg tail, and the
   kernel-config snapshot when /proc/config.gz exists.
3. The loader no longer runs twice per opt-in boot, and errno-8 failures
   with an empty kernel log now print an explanation of the silent gate
   (for user-supplied or older .ko images).
4. Everything else is unchanged: opt-in-only LKM on custom kernels,
   functional built-in-susfs detection, userspace-only mode, safe
   defaults, receipt/hang-watchdog boot gating, diagnose.sh bisector.

Offline verification: a gate simulator that transcribes the exact
5.15.178 load_module order shows the OLD .ko failing silently at
check_modstruct_version (the device symptom, reproduced) and the NEW one
passing; 22/22 install simulation, 41/41 safeguard/watchdog tests.

## Flashing v26.11.25

Flash `ReSuSFS-x86_64-v26.11.25.zip` in the KernelSU manager (over the old
module is fine). Your `/data/adb/ReSuSFS/enable_lkm` flag and configs
survive the upgrade. Restart the instance.

Your `enable_lkm` flag is still in place, so the next boot's post-fs-data
runs the fixed loader over the NEW image. In boot.log you should see, in
order:

1. `[*] Trying susfs_insmod (custom-kernel primary path)...`
2. the loader's verbose report (127 undefined symbols now, and
   `resolved <n>/127` - expect only a handful unresolved: the exported
   names the kernel itself resolves, e.g. try_module_get, module_put,
   find_vma)
3. `init_module(...)` - and then, if the gate analysis is right, one of:
   - `[+] LKM loaded successfully (susfs_insmod, custom-kernel path)` -
     kernel susfs is live. Verify with `dmesg | grep -i susfs`,
     `ls /proc/susfs_path`, or re-run diagnose.sh (steps 01-08 start
     answering). Expect one harmless dmesg line:
     `susfs_guard_lkm: no symbol version for module_layout`.
   - a NEW kind of failure report - the loader's own lines plus the
     evidence block (MODVERSIONS probe, kallsyms status, raw dmesg tail)
     - send boot.log + dmesg back and the next fix targets exactly what
     the kernel names.

## If the system freezes after the load

The LKM is still a generic 5.15.178 x86_64 build (LDPlayer publishes no
kernel source/config), and it hooks live kernel paths - a mismatch can
wedge the kernel. Rollback: force-restart the instance, then immediately

```
adb shell su -c "rm /data/adb/ReSuSFS/enable_lkm"
```

(you have a window of several seconds before post-fs-data fires; if adb
is dead, connect right after the boot animation starts:
`adb connect 127.0.0.1:5555`). Last resort:
`adb shell su -c "touch /data/adb/modules/ReSuSFS/disable"`.

## Running the bisector (optional)

KernelSU manager -> module page -> **Action** button, or
`adb shell su -c "sh /data/adb/modules/ReSuSFS/diagnose.sh"`. On kernels
without susfs (LKM not loaded) steps 01-08 answer "not supported" - that
is expected. If a step freezes the system: force-restart; the watchdog
skips that step on the next run automatically.

## What to send back

```
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"     > boot.log
adb shell su -c "cat /data/adb/ReSuSFS/logs/diagnose.log" > diagnose.log
adb shell su -c "dmesg"                                   > dmesg.txt
```
