#!/bin/sh

DEST_BIN_DIR=/data/adb/ksu/bin
PERSISTENT_DIR=/data/adb/ReSuSFS

. "$MODPATH/utils.sh"

export MODULE_HOT_INSTALL_REQUEST="true"
export MODULE_HOT_RUN_SCRIPT="hotinstall.sh"

banner "$MODPATH"

ui_print "[%] customize.sh "

# v26.11.23 (safe-diagnostic build): when upgrading from an older build whose
# /data/adb/ReSuSFS configs enable boot-time hiding (the v26.11.22 default
# did: 4 postfs + 8 bootcompleted scripts), force-reset to the new safe
# defaults so a stale config cannot keep triggering the post-boot freeze.
# The old directory is preserved as a timestamped backup, nothing is lost.
SAFE_CFG_MARKER="$PERSISTENT_DIR/.safe_diag_v1"
if [ -d "$PERSISTENT_DIR" ] && [ ! -f "$SAFE_CFG_MARKER" ]; then
        ui_print "[*] old ReSuSFS config found - resetting to safe defaults"
        ts_backup="$(date '+%Y%m%d-%H%M%S' 2>/dev/null)"
        if mv "$PERSISTENT_DIR" "${PERSISTENT_DIR}.bak.${ts_backup}" 2>/dev/null; then
                ui_print "[+] backup saved: ${PERSISTENT_DIR}.bak.${ts_backup}"
        else
                rm -rf "$PERSISTENT_DIR" 2>/dev/null
                ui_print "[!] could not move old config, removed it instead"
        fi
fi

detect_key_press() {
        # x86_64 port: emulators (LDPlayer and friends) have no volume keys,
        # so getevent never yields KEY_VOLUME and the original timeout path
        # aborts config updates on them. Auto-answer "VOLUME UP" (the safe
        # default: keep existing configs) on x86_64 instead of blocking.
        case "$(uname -m 2>/dev/null)" in
                x86_64)
                        ui_print "[*] x86_64 device without volume keys: auto-selecting the safe default (keep configs)"
                        return 0
                        ;;
        esac
        timeout_seconds=6
        timeout 0.5 getevent -c 0 >/dev/null 2>&1
        # v26.11.23 portability fix: the original used the bashism
        # `read -t ... < <(getevent ...)`, which several Android shells and
        # any strict POSIX shell refuse to parse ("redirection unexpected" -
        # it aborts the whole installer). Pipe through timeout instead: no
        # volume event within the window simply yields an empty line.
        line="$(timeout $timeout_seconds getevent -ql 2>/dev/null | awk '/KEY_VOLUME/ {print; exit}')"
        if [ -z "$line" ]; then
                ui_print "[!] No key pressed within $timeout_seconds seconds. Skipping installation..."
                return 1
        fi
        if echo "$line" | grep -q "KEY_VOLUMEUP"; then
                return 0
        else
                ui_print "[+] Skipping reset..."
                return 1
        fi
}

CONFIGURE=true
if [ -d "$PERSISTENT_DIR" ]; then
        ui_print "[*] Will select NO in 6s if no volume buttons pressed"
        ui_print "[*] Do you want to update the configs?"
        ui_print "[*] VOLUME UP for NO, DOWN for YES"
        if detect_key_press; then
                CONFIGURE=false
        fi

        if $CONFIGURE; then
                ui_print "[*] Have you backed up your configuration?"
                ui_print "[*] VOLUME UP for YES, DOWN for NO"
                if ! detect_key_press; then
                        ui_print "[!] Please back up your configuration first"
                        exit 1
                fi
        fi
fi

CONFIG_DIR="$MODPATH/configs"

[ ! -d "$CONFIG_DIR" ] || [ -z "$(ls -A "$CONFIG_DIR" 2>/dev/null)" ] && ui_print "[!] No config files found" && exit 0

handle_files() {
        src_dir="$1"
        dst_dir="$2"
        files="$3"
        action="$4"
        DIFFERENT=""
        for file in $files; do
                src="$src_dir/$file"
                dst="$dst_dir/$file"
                if [ ! -f "$dst" ]; then
                        mkdir -p "$dst_dir/$(dirname "$file")"
                        cp "$src" "$dst"
                        ui_print "[+] $file copied"
                elif ! cmp -s "$src" "$dst"; then
                        DIFFERENT="$DIFFERENT $file"
                fi
        done
        if [ -n "$DIFFERENT" ]; then
                ui_print "[*] Changed files:"
                for file in $DIFFERENT; do
                        ui_print "    - $file"
                done
                ui_print "[*] VOLUME UP to $action, DOWN to keep"
                if detect_key_press; then
                        for file in $DIFFERENT; do
                                mkdir -p "$dst_dir/$(dirname "$file")"
                                cp "$src_dir/$file" "$dst_dir/$file"
                                ui_print "[+] $file $action"
                        done
                else
                        ui_print "[+] Kept existing files"
                fi
        fi
}

if $CONFIGURE; then
        handle_files "$CONFIG_DIR" "$PERSISTENT_DIR" "scripts_bootcompleted.txt scripts_postfs.txt" "updated"
        if [ -d "$CONFIG_DIR/scripts" ]; then
                handle_files "$CONFIG_DIR/scripts" "$PERSISTENT_DIR/scripts" "$(get_all_files "$CONFIG_DIR/scripts")" "updated"
        fi

        CONFIG_FILES=$(get_all_files "$CONFIG_DIR" | grep -v '^scripts/')
        [ -n "$CONFIG_FILES" ] && handle_files "$CONFIG_DIR" "$PERSISTENT_DIR" "$CONFIG_FILES" "reset"
fi

rm -rf "$CONFIG_DIR"

# mark this persistent dir as safe-diagnostic so a later upgrade knows the
# configs already carry the safe defaults (and to not re-back them up)
mkdir -p "$PERSISTENT_DIR" 2>/dev/null
: > "$SAFE_CFG_MARKER" 2>/dev/null
ui_print "[+] safe defaults installed: NO kernel hiding runs at boot"
ui_print "[+] boot stages are logged to $PERSISTENT_DIR/logs/boot.log"
ui_print "[+] run the Action button (or diagnose.sh) to bisect features"

download_susfs_guard_lkm
update_susfs || exit 1

# v26.11.23: report what the module will actually do on THIS kernel, so
# the post-install expectation matches reality:
#   - built-in susfs detected (or an LKM already live) -> full features
#   - otherwise -> userspace-only mode; the bundled LKM stays UNLOADED
#     unless the user opts in via /data/adb/ReSuSFS/enable_lkm
if check_susfs_support; then
        ui_print "[+] kernel susfs detected (built-in or already live): full features enabled"
else
        ui_print "[*] no kernel susfs detected on $(uname -r 2>/dev/null)"
        ui_print "[*] SAFE DEFAULT: the susfs LKM is NOT loaded on custom kernels."
        ui_print "[*] The module runs in userspace-only mode: install and boot"
        ui_print "[*] stay stable; kernel-side hiding stays dormant until a"
        ui_print "[*] susfs-capable kernel is used or you opt in."
        ui_print "[*]"
        ui_print "[*] v26.11.44: THE RESOLVER PROBE FIX."
        ui_print "[*] The v43 field boots proved the SYNC trigger safe:"
        ui_print "[*] substeps 0 and 1 completed (init_done=1, rc=0), and"
        ui_print "[*] substep 2 refused BY DESIGN: 'kln probe lookup of"
        ui_print "[*] 'printk' returned 0x0 - refusing'. Your greps found it:"
        ui_print "[*] this GKI-style LTO kernel lists _printk and vprintk"
        ui_print "[*] but has ZERO 'printk' entries - the probe asked for a"
        ui_print "[*] name the kernel does not have. The seed kln= address"
        ui_print "[*] was exactly kallsyms_lookup_name all along. v44 probes"
        ui_print "[*] _printk FIRST, then printk, then vprintk - first hit"
        ui_print "[*] validates KLN mode; the activation breadcrumb names"
        ui_print "[*] which probe answered. Recon also stops claiming"
        ui_print "[*] kernel_config.txt when /proc/config.gz is absent."
        ui_print "[*] Next boots run substeps 2..7, then the arm_stage"
        ui_print "[*] ladder; send back the logs after each boot."
        ui_print "[*] v26.11.43: TRI-CHANNEL TRIGGER + CONSOLE BREADCRUMBS."
        ui_print "[*] The v41 field boot froze AT the force_init echo with the"
        ui_print "[*] witness blind: its param reads need mod->param_lock,"
        ui_print "[*] the same mutex the stuck write path holds. A full static"
        ui_print "[*] post-mortem found two hard defects; v42 fixes both:"
        ui_print "[*]  1. STRUCT MODULE SIZE MISMATCH: the running kernel's"
        ui_print "[*]     struct module is the ANDROID one (scmversion + 4"
        ui_print "[*]     KABI reserves, 0x340); every kernel.org-built image"
        ui_print "[*]     since v26.11.26 shipped a 0x300 section and let the"
        ui_print "[*]     kernel write 0x40 bytes past it into module .bss."
        ui_print "[*]     The android13 candidate is now built against the"
        ui_print "[*]     EXACT running lineage (AOSP android13-5.15"
        ui_print "[*]     ASB-2025-03-05, verified 5.15.178)."
        ui_print "[*]  2. TOOLCHAIN PROFILE: the ONLY images whose module"
        ui_print "[*]     code verifiably EXECUTED in the field (v34..v37)"
        ui_print "[*]     were all built with GCC (.text.unlikely/"
        ui_print "[*]     .rodata.str1.8 fingerprints) with no thunk imports;"
        ui_print "[*]     the clang-built v40/v41 froze at the first call."
        ui_print "[*]     v42 builds BOTH candidates with GCC, RETPOLINE and"
        ui_print "[*]     RETHUNK off - the field kernel's kallsyms has NO"
        ui_print "[*]     __x86_indirect_thunk_* symbols, and the verifier"
        ui_print "[*]     rejected the first v42 build exactly for importing"
        ui_print "[*]     them: 124 imports, all present in the field"
        ui_print "[*]     kallsyms, zero thunks, plain rets."
        ui_print "[*]  3. MINIMAL SETTER: force_init's .set is now BARE"
        ui_print "[*]     schedule_work + ret; all sentinels moved into the"
        ui_print "[*]     kworker (outside param_lock): laststep -50 ="
        ui_print "[*]     kworker entered (raw store first instruction),"
        ui_print "[*]     -51 = already done, -60 = probe .get entered,"
        ui_print "[*]     0..7 = body substeps."
        ui_print "[*]  4. THE WITNESS CAN NO LONGER BE BLINDED: every param"
        ui_print "[*]     read goes through `timeout -s KILL 1 cat` - a"
        ui_print "[*]     param_lock deadlock prints TIMEOUT receipts with"
        ui_print "[*]     the exact adb dmesg-capture commands to run BEFORE"
        ui_print "[*]     rebooting (the one decisive capture every previous"
        ui_print "[*]     wedge lost)."
        ui_print "[*]  5. BOX HEARTBEAT: a pure-userspace watchdog (file+sync"
        ui_print "[*]     only) beats 5s x 8 across the trigger - beats"
        ui_print "[*]     continuing = kernel alive (capture dmesg!), beats"
        ui_print "[*]     stopping = the death window bounded to 5s."
        ui_print "[*]  6. READ-PATH TRIGGER: set /data/adb/ReSuSFS/trigger_mode"
        ui_print "[*]     to 'get' to dispatch module code through the sysfs"
        ui_print "[*]     READ path (probe param) instead of the write path,"
        ui_print "[*]     or 'early' to trigger at post-fs-data (the v35-v37"
        ui_print "[*]     context that ran). Default 'set'."
        ui_print "[*] The VANILLA candidate is the default (the only image"
        ui_print "[*] that loads clean in the field); the android13 ko stays"
        ui_print "[*] bundled for re-testing, and the payload stamp v26.11.44"
        ui_print "[*] refreshes the device image"
        ui_print "[*] on upgrade (self-heal fires on stamp mismatch too)."
        ui_print "[*] v26.11.38: KERNEL-FACTS + SEEDED RESOLVER + POST-BOOT TRIGGER"
        ui_print "[*] v37 proved even a stage-0 evidence boot could wedge, and"
        ui_print "[*] the trigger ran DURING boot - which is why boots froze"
        ui_print "[*] at 50%. v38 changes all three suspects at once:"
        ui_print "[*]  1. INIT NOW RUNS ONLY AFTER BOOT COMPLETES"
        ui_print "[*]     (boot-completed.sh) - a wedged init can no longer"
        ui_print "[*]     freeze the boot animation; worst case the desktop"
        ui_print "[*]     freezes with adb alive + evidence on disk, and the"
        ui_print "[*]     next boot self-demotes the ladder."
        ui_print "[*]  2. NO MORE KERNEL-MEMORY SCANNING: the resolver is"
        ui_print "[*]     SEEDED with the kernel's own kallsyms table"
        ui_print "[*]     addresses from /proc/kallsyms (kr_seed param); the"
        ui_print "[*]     kallrecon scan is off by default (kr_scan=0) and"
        ui_print "[*]     the module REFUSES to init without a seed."
        ui_print "[*]  3. NO MORE MODULE PRINTK by default (diag_printk=0,"
        ui_print "[*]     enable_log off) - the v37 'printk suppressed'"
        ui_print "[*]     observation was equally consistent with 'printk"
        ui_print "[*]     wedged the kernel'; crumbs now go to diag_log only."
        ui_print "[*] Also: Phase-0 kernel recon every boot (compiler string,"
        ui_print "[*] IKCONFIG config, kallsyms layout -> logs/kernel_facts.txt)"
        ui_print "[*] and THREE LKM candidates, switchable at runtime via"
        ui_print "[*] /data/adb/ReSuSFS/lkm_candidate: android13 (DEFAULT: built"
        ui_print "[*] against AOSP android13-5.15 ASB-2025-03 - LDPlayer 14's"
        ui_print "[*] exact lineage), vanilla (kernel.org 5.15.178), ymuuu13"
        ui_print "[*] (ymuuuu's prebuilt GKI android13-5.15 x64 ko)."
        ui_print "[*]"
        ui_print "[*] TWO-STEP OPT-IN (each step is independently safe):"
        ui_print "[*]  touch /data/adb/ReSuSFS/enable_lkm"
        ui_print "[*]    -> loads the module IMAGE (zombie state: v25-v37 boots"
        ui_print "[*]       proved this stable; nothing runs)"
        ui_print "[*]  touch /data/adb/ReSuSFS/enable_force_init"
        ui_print "[*]    -> ALSO runs susfs_init AFTER boot completes (the"
        ui_print "[*]       staged experiment: 0=resolver-only 1=+resolve/proc"
        ui_print "[*]       2=+supercall 3=+lsm/sus_path 4=full; one rung per"
        ui_print "[*]       healthy boot; a wedge demotes + caps the next)"
        ui_print "[*] RECOVERY if a wedged init freezes the desktop:"
        ui_print "[*]   adb root && adb shell rm -f /data/adb/ReSuSFS/enable_force_init"
        ui_print "[*]   (rm enable_lkm too to stand down completely) + reboot"
        ui_print "[*]   - or just reboot: the ladder demotes itself."
        ui_print "[*] Evidence to send back: logs/kernel_facts.txt +"
        ui_print "[*] logs/diag_last.txt + logs/boot.log"
fi

chmod 755 "$MODPATH/ReSuSFS.sh"
chmod 644 "$MODPATH/post-fs-data.sh" "$MODPATH/service.sh" "$MODPATH/uninstall.sh" 2>/dev/null

if [ -d "$DEST_BIN_DIR" ]; then
        ui_print "[+] creating symlink in $DEST_BIN_DIR"
        ln -sf "/data/adb/modules/ReSuSFS/ReSuSFS.sh" "$DEST_BIN_DIR/ReSuSFS"
fi

if [ ! -d "$PERSISTENT_DIR/.webui_config" ] || [ ! -f "$PERSISTENT_DIR/.webui_config/custom.css" ]; then
        mkdir -p "$PERSISTENT_DIR/.webui_config"
        mv "$MODPATH/custom.css" "$PERSISTENT_DIR/.webui_config/custom.css"
else
        rm -f "$MODPATH/custom.css"
fi

# EOF
