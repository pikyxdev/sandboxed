#!/bin/sh
PATH=/data/adb/ksu/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"

. "$MODDIR/utils.sh"

# ---- v26.11.42 POST-BOOT SUBSTEP LADDER TRIGGER --------------------------
# The v41 field boot (2026-11-23 17:51:30) froze the box AT the force_init
# echo WITH the witness running: one receipt at @0s (laststep=-1), then
# nothing - no "write returned", no further witness poll, no 30s-elapsed
# line, manual instance restart.  The witness itself was blind: its param
# reads need mod->param_lock, the same mutex the stuck write path holds.
#
# v42 changes the instrumentation contract:
#   - every param read below goes through `busybox timeout 1`, so a
#     param_lock deadlock prints "param read TIMEOUT" receipts instead of
#     hanging the witness silently (that was the v41 blind spot);
#   - a BOX HEARTBEAT subshell (file+sync only, NO module access) beats
#     every 5s for 40s across the trigger window: beats continuing after a
#     frozen trigger = kernel alive, only module-param traffic dead -> the
#     script prints the adb dmesg capture commands to run BEFORE rebooting;
#     beats stopping = the box itself died, window bounded to 5s;
#   - trigger modes via /data/adb/ReSuSFS/trigger_mode:
#       set   (default) - write force_init (the sysfs WRITE channel; v42's
#                         setter is BARE schedule_work, 3 instructions)
#       get           - write probe_arm=1 (pure kernel code), then cat the
#                       "probe" param: module code dispatched through the
#                       sysfs READ path, which no module code has ever run
#                       through on this box.  Survives where "set" froze ->
#                       the write path is the culprit; freezes too ->
#                       module code execution itself.
#       early         - post-fs-data.sh writes force_init instead (the
#                       v35-v37 trigger context that verifiably ran)
#   - kernel-side sentinels are in the KWORKER now (outside param_lock):
#       -1 = fresh module, trigger not run
#       -50 = kworker ENTERED (raw store first instruction - module code
#             executes, before vsnprintf/any call)
#       -51 = kworker saw init_done=1 (already initialized)
#       -60 = the probe .get ENTERED (read channel equivalent of -50)
#       0..7 = susfs_init_body substeps (0 also store-first now)
#
# Ladder witness semantics (same as v37-v41, unchanged):
#   "try N <boot_id>" written before triggering; init_done=1 within the
#   window -> "ok" + advance ONE substep; init_done=0 -> "nok" (same rung
#   retried next boot); a boot that never completes its witness leaves the
#   stale "try" for post-fs-data's stand-down/demotion on the next boot.
#
# The trigger still needs BOTH opt-in flags:
#   /data/adb/ReSuSFS/enable_lkm          (loads the image in post-fs-data)
#   /data/adb/ReSuSFS/enable_force_init   (runs the post-boot init experiment)
if [ -d /sys/module/susfs_guard_lkm ]; then
        if [ -f "$PERSISTENT_DIR/no_init_this_boot" ]; then
                log_boot "boot-completed: init suppressed this boot (stage-0 wedge recovery from post-fs-data) - trigger skipped, flags already removed"
                rm -f "$PERSISTENT_DIR/no_init_this_boot" 2>/dev/null
        elif [ -f "$PERSISTENT_DIR/enable_lkm" ] && [ -f "$PERSISTENT_DIR/enable_force_init" ]; then
                STAGE_FILE="/data/adb/ReSuSFS/arm_stage"
                STAGE_MAX_FILE="/data/adb/ReSuSFS/stage_max"
                STAGE_BOOT_FILE="/data/adb/ReSuSFS/stage_boot"
                INIT_SEQ_FILE="/data/adb/ReSuSFS/init_seq"
                INIT_TRACE="$LOG_DIR/init_trace.txt"
                STAGE_PARAM="/sys/module/susfs_guard_lkm/parameters/arm_stage"
                MAXSTEP_PARAM="/sys/module/susfs_guard_lkm/parameters/init_maxstep"
                LASTSTEP_PARAM="/sys/module/susfs_guard_lkm/parameters/init_laststep"
                FORCE_INIT="/sys/module/susfs_guard_lkm/parameters/force_init"
                INIT_DONE="/sys/module/susfs_guard_lkm/parameters/init_done"
                DIAG_PARAM="/sys/module/susfs_guard_lkm/parameters/diag_log"
                DIAG_SNAP="/data/adb/ReSuSFS/logs/diag_last.txt"
                PROBE_ARM="/sys/module/susfs_guard_lkm/parameters/probe_arm"
                PROBE="/sys/module/susfs_guard_lkm/parameters/probe"
                BB="$(command -v busybox || echo busybox)"

                ARM_STAGE=0
                [ -f "$STAGE_FILE" ] && ARM_STAGE=$(cat "$STAGE_FILE" 2>/dev/null | tr -dc '0-9')
                [ -z "$ARM_STAGE" ] && ARM_STAGE=0
                case "$ARM_STAGE" in 0|1|2|3|4|5) ;; *) ARM_STAGE=0 ;; esac
                STAGE_MAX=5
                [ -f "$STAGE_MAX_FILE" ] && STAGE_MAX=$(cat "$STAGE_MAX_FILE" 2>/dev/null | tr -dc '0-9')
                [ -z "$STAGE_MAX" ] && STAGE_MAX=5
                case "$STAGE_MAX" in 0|1|2|3|4|5) ;; *) STAGE_MAX=5 ;; esac
                if [ "$ARM_STAGE" -gt "$STAGE_MAX" ]; then
                        log_boot "boot-completed: arm_stage $ARM_STAGE above stage_max $STAGE_MAX - clamping for this trigger"
                        ARM_STAGE=$STAGE_MAX
                fi

                INIT_SEQ=0
                [ -f "$INIT_SEQ_FILE" ] && INIT_SEQ=$(cat "$INIT_SEQ_FILE" 2>/dev/null | tr -dc '0-9')
                [ -z "$INIT_SEQ" ] && INIT_SEQ=0
                case "$INIT_SEQ" in 0|1|2|3|4|5|6|7) ;; *) INIT_SEQ=0 ;; esac
                [ "$INIT_SEQ" -gt 7 ] && INIT_SEQ=7

                TRIGGER_MODE="sync"
                [ -f "$PERSISTENT_DIR/trigger_mode" ] && TRIGGER_MODE=$(head -n 1 "$PERSISTENT_DIR/trigger_mode" 2>/dev/null | tr -d '[:space:]')
                case "$TRIGGER_MODE" in sync|set|get|early) ;; *) TRIGGER_MODE="sync" ;; esac
                # v43 default = 'sync': force_init is written as 2, the module
                # runs susfs_init_body DIRECTLY in the .set (no workqueue at
                # all - substep 0 is pure stores). 'set' writes 1 (the v42
                # deferred/schedule_work path, kept for comparison); 'get'
                # dispatches through the probe .get; 'early' wrote force_init
                # at post-fs-data time (the v35-v37 context) - this script
                # then only runs the witness + init poll.
                [ "$TRIGGER_MODE" = "early" ] && log_boot "boot-completed: trigger_mode=early - the dispatch already happened at post-fs-data; polling only"

                CUR_BOOT="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d -)"

                MARKER=""
                [ -f "$STAGE_BOOT_FILE" ] && MARKER=$(cat "$STAGE_BOOT_FILE" 2>/dev/null)
                case "$MARKER" in
                "ok "*" $CUR_BOOT"|"nok "*" $CUR_BOOT") : ;;
                *) echo "try $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null ;;
                esac

                mkdir -p "$LOG_DIR" 2>/dev/null
                trace() {
                        echo "[$(rs_ts)] boot=$CUR_BOOT $*" >> "$INIT_TRACE" 2>/dev/null
                        sync 2>/dev/null
                        log_boot "init-trace: $*"
                }
                # v42: param reads survive a param_lock deadlock. The lock
                # sleeps TASK_KILLABLE, so SIGKILL breaks a blocked read;
                # a plain TERM would not. timeout's own 124 (or a KILL
                # 137) is receipted as "param read TIMEOUT" - the v41
                # witness hung silently on exactly this and looked like
                # "stuck at -1", proving nothing.
                tread() {
                        [ -n "$RS_TIMEOUT" ] && { $RS_TIMEOUT -s KILL 1 cat "$1" 2>/dev/null; return; }
                        cat "$1" 2>/dev/null
                }
                { echo "---- boot $CUR_BOOT begin (v42 substep ladder; trigger_mode=$TRIGGER_MODE) ----"; } >> "$INIT_TRACE" 2>/dev/null
                tail -n 400 "$INIT_TRACE" > "$INIT_TRACE.tmp" 2>/dev/null && mv "$INIT_TRACE.tmp" "$INIT_TRACE" 2>/dev/null
                trace "STEP $INIT_SEQ/7 DISPATCHING (arm_stage=$ARM_STAGE/$STAGE_MAX marker='$MARKER' mode=$TRIGGER_MODE module=$(sed -n 's/^version=//p' $MODDIR/module.prop 2>/dev/null))"

                # resolver seed (unchanged from v41)
                log_boot "boot-completed: seeding resolver (v2: kln/gsoff preferred, tables if visible)"
                SEED_STR="$(seed_kallsyms_resolver_v2)"
                if [ -n "$SEED_STR" ]; then
                        trace "seed v2 written: $SEED_STR"
                        log_boot "boot-completed: kr_seed(v2) = $SEED_STR"
                else
                        trace "seed v2 NOT written (no kln= and no tables visible) - the module will refuse at substep 2 and nok (safe)"
                        log_boot "boot-completed: kr_seed NOT written (tables hidden or param missing) - the module will refuse to init rather than scan (safe); seed_kallsyms_resolver_v2 said: $SEED_STR"
                fi

                if [ -w "$STAGE_PARAM" ]; then
                        trace "writing arm_stage=$ARM_STAGE (layer gate)"
                        echo "$ARM_STAGE" > "$STAGE_PARAM" 2>/dev/null
                fi
                if [ -w "$MAXSTEP_PARAM" ]; then
                        trace "writing init_maxstep=$INIT_SEQ (substep gate)"
                        echo "$INIT_SEQ" > "$MAXSTEP_PARAM" 2>/dev/null
                        log_boot "boot-completed: substep seq=$INIT_SEQ armed (init_maxstep=$INIT_SEQ arm_stage=$ARM_STAGE; ladder: 0=dispatch 1=+imports 2=+resolver 3=+gs_off 4=+deadman 5=+crosscheck 6=+patch 7=+layers; max=$STAGE_MAX)"
                else
                        log_boot "boot-completed: init_maxstep param not writable (fallback image, not a v40+ build)"
                fi

                # v42 BOX HEARTBEAT: pure userspace, no module access - it
                # keeps beating through a param deadlock AND survives long
                # enough to bound a real box death to a 5s window.
                (
                        h=0
                        while [ "$h" -lt 8 ]; do
                                sleep 5
                                h=$((h+1))
                                echo "[$(rs_ts)] boot=$CUR_BOOT heartbeat @${h}x5s (alive, uptime $(cut -d. -f1 /proc/uptime 2>/dev/null))" >> "$INIT_TRACE" 2>/dev/null
                                sync 2>/dev/null
                        done
                        echo "[$(rs_ts)] boot=$CUR_BOOT heartbeat window done (40s)" >> "$INIT_TRACE" 2>/dev/null
                        sync 2>/dev/null
                ) &

                # v42 WITNESS: timeout-guarded reads - a param_lock deadlock
                # shows up as TIMEOUT receipts instead of a silent hang.
                if [ -f "$LASTSTEP_PARAM" ]; then
                        (
                                n=0; last_seen=""; bg_diag=""; to_count=0
                                while [ "$n" -lt 30 ]; do
                                        cur="$(tread $LASTSTEP_PARAM)"
                                        rc=$?
                                        done_="$(tread $INIT_DONE)"
                                        if [ "$rc" = "124" ] || [ "$rc" = "137" ]; then
                                                to_count=$((to_count+1))
                                                trace "witness(bg): PARAM READ TIMEOUT x$to_count @${n}s - mod param traffic is DEADLOCKED (kernel may still be alive; heartbeats tell) - probe the box: adb shell su -c 'dmesg > /data/adb/ReSuSFS/logs/dmesg_freeze.txt; cat /sys/module/susfs_guard_lkm/parameters/diag_log > /data/adb/ReSuSFS/logs/diag_freeze.txt; cat /proc/modules > /data/adb/ReSuSFS/logs/modules_freeze.txt; sync' then reboot"
                                                [ "$to_count" -ge 2 ] && exit 0
                                                sleep 1; n=$((n+1)); continue
                                        fi
                                        combo="${cur}|${done_}"
                                        if [ "$combo" != "$last_seen" ]; then
                                                trace "witness(bg): laststep=$cur init_done=$done_ @${n}s"
                                                last_seen="$combo"
                                        fi
                                        cur_diag="$(tread $DIAG_PARAM)"
                                        if [ -n "$cur_diag" ] && [ "$cur_diag" != "$bg_diag" ]; then
                                                printf '%s' "$cur_diag" > "$DIAG_SNAP" 2>/dev/null
                                                sync 2>/dev/null
                                                bg_diag="$cur_diag"
                                                trace "witness(bg): diag_log snapshot @${n}s (len=${#cur_diag})"
                                        fi
                                        if [ "$done_" = "1" ] && [ "$n" -ge 5 ]; then
                                                trace "witness(bg): init_done=1 seen - background witness exiting @${n}s"
                                                exit 0
                                        fi
                                        sleep 1
                                        n=$((n+1))
                                done
                                trace "witness(bg): 30s window elapsed (init_done=$(tread $INIT_DONE) laststep=$(tread $LASTSTEP_PARAM))"
                        ) &
                fi

                # ---- v43 pre-trigger: console breadcrumbs ON + dmesg baseline ----
                # diag_printk=1 arms the setter's EMERG printk (XYZDIAG2: .set
                # ENTERED ...) - it goes to the ring AND the console (tty0),
                # so the LDPlayer window itself shows it if the box dies at
                # the write. Keep a second adb window running `dmesg -w` too.
                DIAG_PRINTK_PARAM="/sys/module/susfs_guard_lkm/parameters/diag_printk"
                if [ -w "$DIAG_PRINTK_PARAM" ]; then
                        echo 1 > "$DIAG_PRINTK_PARAM" 2>/dev/null
                        trace "diag_printk=1 armed (EMERG breadcrumbs: XYZDIAG2 at .set entry, XYZDIAG1 in the body)"
                fi
                trace "dmesg baseline (last 6): $(dmesg 2>/dev/null | tail -n 6 | tr '\n' '|' | head -c 300)"

                # ---- THE TRIGGER -------------------------------------------------
                if [ "$TRIGGER_MODE" = "early" ]; then
                        trace "trigger_mode=early: dispatch already happened at post-fs-data (no write here)"
                elif [ "$TRIGGER_MODE" = "get" ] && [ -w "$PROBE_ARM" ] && [ -f "$PROBE" ]; then
                        trace "trigger_mode=get: writing probe_arm=1 (pure kernel param code), then reading probe (module .get dispatches)"
                        log_boot "boot-completed: triggering via READ channel (probe .get; substep $INIT_SEQ)"
                        echo 1 > "$PROBE_ARM" 2>/dev/null
                        trace "probe_arm=1 written (kernel-only code path)"
                        trace "reading probe param - module .get executes now (laststep -60 = entered)"
                        PROBE_OUT="$(tread $PROBE)"
                        trace "probe read returned: '$PROBE_OUT' (kworker dispatched from the READ path)"
                elif [ "$TRIGGER_MODE" = "set" ] && [ -w "$FORCE_INIT" ]; then
                        trace "trigger_mode=set: writing force_init=1 (v42 deferred path: bare schedule_work; kworker sentinels -50 entered, -51 done)"
                        log_boot "boot-completed: triggering force_init=1 (DEFERRED channel; substep $INIT_SEQ; system fully booted)"
                        echo 1 > "$FORCE_INIT" 2>/dev/null
                        trace "force_init=1 write returned (kworker scheduled)"
                elif [ -w "$FORCE_INIT" ]; then
                        trace "trigger_mode=sync: writing force_init=2 (v43 SYNC path: the .set calls susfs_init_body DIRECTLY - no workqueue; sentinels -70 entered, -71 already-done)"
                        log_boot "boot-completed: triggering force_init=2 (SYNC channel, direct body call, no queueing; substep $INIT_SEQ; system fully booted)"
                        echo 2 > "$FORCE_INIT" 2>/dev/null
                        trace "force_init=2 write returned (sync body ran to completion inside the write)"
                else
                        log_boot "boot-completed: force_init param not writable (old module image?)"
                fi
                # ------------------------------------------------------------------

                # Poll init_done with timeout-guarded reads (same as v41
                # except every read is bounded; diag snapshots unchanged).
                if [ -f "$INIT_DONE" ]; then
                        mkdir -p /data/adb/ReSuSFS/logs 2>/dev/null
                        LAST_DIAG=""
                        LAST_STEP="$(tread $LASTSTEP_PARAM)"
                        n=0
                        while [ "$n" -lt 25 ] && [ "$(tread $INIT_DONE)" != "1" ]; do
                                STEP_NOW="$(tread $LASTSTEP_PARAM)"
                                if [ -n "$STEP_NOW" ] && [ "$STEP_NOW" != "$LAST_STEP" ]; then
                                        trace "witness: laststep=$STEP_NOW @${n}s"
                                        LAST_STEP="$STEP_NOW"
                                fi
                                CUR="$(tread $DIAG_PARAM)"
                                if [ -n "$CUR" ] && [ "$CUR" != "$LAST_DIAG" ]; then
                                        printf '%s' "$CUR" > "$DIAG_SNAP" 2>/dev/null
                                        sync 2>/dev/null
                                        log_boot "boot-completed: diag_log snapshot @${n}s (len=${#CUR}) last: $(printf '%s' "$CUR" | tail -n 1 | head -c 120)"
                                        trace "diag_log @${n}s changed (last line: $(printf '%s' "$CUR" | tail -n 1 | head -c 100))"
                                        LAST_DIAG="$CUR"
                                fi
                                sleep 1
                                n=$((n+1))
                        done
                        CUR="$(tread $DIAG_PARAM)"
                        if [ -n "$CUR" ] && [ "$CUR" != "$LAST_DIAG" ]; then
                                printf '%s' "$CUR" > "$DIAG_SNAP" 2>/dev/null
                                sync 2>/dev/null
                        fi
                        { echo "---- diag_log final snapshot (substep $INIT_SEQ, after ${n}s poll) ----"
                          printf '%s\n' "$CUR"
                          echo "---- end diag_log ----"; } >> "$BOOT_LOG" 2>/dev/null
                        if [ "$(tread $INIT_DONE)" = "1" ]; then
                                trace "STEP $INIT_SEQ COMPLETE (init_done=1 after ${n}s; module laststep=$(tread $LASTSTEP_PARAM))"
                                log_boot "boot-completed: substep $INIT_SEQ init COMPLETE (init_done=1 after ${n}s)"
                                already=""
                                case "$MARKER" in
                                "ok "*" $CUR_BOOT") already=1 ;;
                                esac
                                if [ -n "$already" ]; then
                                        log_boot "boot-completed: ladder already advanced this boot (marker '$MARKER') - skipping the advance"
                                else
                                        echo "ok $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null
                                        if [ "$INIT_SEQ" -lt 6 ]; then
                                                echo $((INIT_SEQ + 1)) > "$INIT_SEQ_FILE" 2>/dev/null
                                                log_boot "boot-completed: substep $INIT_SEQ healthy - next boot runs substep $((INIT_SEQ + 1))/7"
                                        elif [ "$INIT_SEQ" -eq 6 ]; then
                                                echo 7 > "$INIT_SEQ_FILE" 2>/dev/null
                                                echo 1 > "$STAGE_FILE" 2>/dev/null
                                                log_boot "boot-completed: stage-0 substeps all healthy - next boot runs the LAYER LOOP at arm_stage 1 (seq=7)"
                                        elif [ "$ARM_STAGE" -lt "$STAGE_MAX" ]; then
                                                echo $((ARM_STAGE + 1)) > "$STAGE_FILE" 2>/dev/null
                                                log_boot "boot-completed: arm_stage $ARM_STAGE healthy (init done + boot completed) - next boot arms stage $((ARM_STAGE + 1))/$STAGE_MAX"
                                        else
                                                log_boot "boot-completed: arm_stage $ARM_STAGE healthy - at ladder max $STAGE_MAX (full susfs armed)"
                                        fi
                                fi
                        else
                                trace "STEP $INIT_SEQ did NOT complete in 25s (init_done=0; module laststep=$(tread $LASTSTEP_PARAM)) - nok, same substep retried next boot"
                                log_boot "boot-completed: init did NOT complete at substep $INIT_SEQ (stage $ARM_STAGE) after ${n}s - last breadcrumb is in $DIAG_SNAP and the diag_log block above. v43 attribution: witness stuck at -1 with heartbeats BEATING = param deadlock (see the TIMEOUT receipt + dmesg capture commands); stuck at -1 with heartbeats STOPPED = the box died before module code reached ANY sentinel (check the LDPlayer window/console for XYZDIAG2 - if the EMERG breadcrumb shows, the .set was entered and died between the print and the first store); -70/-71 = SYNC .set entered/already-done; -50 = kworker entered then froze; -60 = probe .get entered; 0..7 = froze inside that substep. sync mode holding param_lock while higher substeps run makes short PARAM READ TIMEOUT receipts EXPECTED during the run - heartbeats tell kernel-alive."
                                case "$MARKER" in
                                "nok "*" $CUR_BOOT") : ;;
                                *) echo "nok $ARM_STAGE $CUR_BOOT" > "$STAGE_BOOT_FILE" 2>/dev/null ;;
                                esac
                        fi

                        # ---- v26.11.45: supercall self-test (arm_stage >= 2) ---------
                        # One bounded live-fire supercall at a CONTROLLED moment
                        # (right after the trigger, not buried in stage-late), so
                        # every stage>=2 boot carries a supercall datapoint even
                        # if the box never reaches stage-late.  Stage 2 = observe
                        # (the kprobe logs but never answers, so 'show version'
                        # still fails with the CLI's own no-answer error); stage
                        # >= 3 = full (an answer is EXPECTED).  The receipts go to
                        # sc_selftest.txt and boot.log; sc_entry_count delta
                        # around the two calls proves the kprobe fired.
                        if [ "$INIT_SEQ" -ge 7 ] && [ "$ARM_STAGE" -ge 2 ] && [ "$(tread $INIT_DONE)" = "1" ]; then
                                SC_TEST_LOG="$LOG_DIR/sc_selftest.txt"
                                SC_CNT="/sys/module/susfs_guard_lkm/parameters/sc_entry_count"
                                SC_MODE=OBSERVE-ONLY
                                [ "$ARM_STAGE" -ge 3 ] && SC_MODE=FULL
                                log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE)"
                                {
                                echo "---- v45 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----"
                                echo "before: sc_entry_count=$(tread $SC_CNT)"
                                echo '-- ksu_susfs show version (timeout 3):'
                                $BB timeout 3 /data/adb/ksu/bin/ksu_susfs show version 2>&1
                                echo '-- ksu_susfs show variant (timeout 3):'
                                $BB timeout 3 /data/adb/ksu/bin/ksu_susfs show variant 2>&1
                                echo "after: sc_entry_count=$(tread $SC_CNT)"
                                echo 'NOTE: answers travel in payload.err (v45 contract); observe mode answers nothing BY DESIGN.'
                                } > "$SC_TEST_LOG" 2>&1
                                cat "$SC_TEST_LOG" >> "$BOOT_LOG" 2>/dev/null
                                log_boot "boot-completed: supercall self-test done (receipt: $SC_TEST_LOG)"
                        fi
                else
                        log_boot "boot-completed: init_done param not present (old module image?)"
                fi
        elif [ -f "$PERSISTENT_DIR/enable_lkm" ]; then
                log_boot "boot-completed: module image loaded (zombie state, proven safe) - init NOT triggered. Opt-in to the post-boot init experiment: touch /data/adb/ReSuSFS/enable_force_init"
        fi
fi
# ---- end v26.11.42 substep ladder trigger -------------------------------

# v26.11.23: stage-late + bootcompleted scripts are exactly what ran ~10s
# after the home screen appeared on the v26.11.22 install, right before the
# freeze - so both are receipt-gated now: if one of them hangs a boot, the
# next boot skips it automatically and boot.log names it.

log_boot "boot-completed: stage-late starting (gated, 120s)"
run_gated stage-late 120 sh "$MODDIR/ReSuSFS.sh" --stage-late >> "$BOOT_LOG" 2>&1
log_boot "boot-completed: stage-late rc=$?"

log_boot "boot-completed: bootcompleted user scripts starting (gated, 120s)"
run_gated bootcompleted-scripts 120 sh "$MODDIR/ReSuSFS.sh" --run-bootcompleted-scripts >> "$BOOT_LOG" 2>&1
log_boot "boot-completed: bootcompleted scripts rc=$?"

log_boot "=== boot-completed DONE ==="

# EOF
