#!/bin/sh
PATH=/data/adb/ksu/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"

. "$MODDIR/utils.sh"

log_boot "service: waiting for sys.boot_completed"
n=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
        n=$((n + 1))
        [ $((n % 60)) -eq 0 ] && log_boot "service: still waiting for boot after ${n}s"
done
log_boot "service: boot completed after ${n}s - starting status loop (30s cadence)"

# v26.11.38: the ladder witness/raise moved to boot-completed.sh, next to
# the trigger it belongs to (service.sh runs at class late_start - BEFORE
# sys.boot_completed, so witnessing the init state here raced the trigger
# and wrote spurious "nok" markers). This script keeps exactly two jobs:
# wait for the completed boot (above), and run the passive status canary.

# v26.11.23: the status loop is the passive canary. Every report is
# timeout-bounded; a rc != 0 means ksu_susfs could not answer (timeout /
# missing binary / wedged supercall) and is logged with its return code.
# Cadence is 30s: it is still a canary, but it no longer rewrites
# module.prop (status_report dedupes) or wakes the CPU every 5s.
i=0
while true; do
        if [ -f "$MODDIR/disable" ]; then
                log_boot "service: module disabled - stopping status loop"
                break
        fi
        rs_run 30 sh "$MODDIR/ReSuSFS.sh" --status-report > /dev/null 2>&1
        rc=$?
        if [ "$rc" -ne 0 ]; then
                log_boot "service: status-report rc=$rc (ksu_susfs timeout/failure - kernel may be wedged)"
        fi
        i=$((i + 1))
        [ $((i % 20)) -eq 0 ] && log_boot "service: alive, $i status reports so far"
        sleep 30
done

# EOF
