#!/system/bin/sh
#title=Spoof settings
#author=ahmed-alnassif
#desc=Spoofs developer options, debugging states, and SELinux status

PATH=/data/adb/ksu/bin:/data/data/com.termux/files/usr/bin:$PATH

settings put global development_settings_enabled 0

# x86_64 port (v26.11.24): adb_enabled / adb_wifi_enabled stay ON by
# default. On emulators (LDPlayer and friends) the host-side window, input
# injection and multi-instance control ride on adb - disabling guest adb at
# boot-completed leaves a guest that is alive but whose UI looks frozen
# (the v26.11.22 "hang ~10s after boot"). Uncomment ONLY on a physical
# device that really needs it:
#settings put global adb_enabled 0
#settings put global adb_wifi_enabled 0

settings put global package_verifier_enable 1
settings put global verifier_verify_adb_installs 1
settings put global usb_mass_storage_enabled 0
settings delete global hidden_api_policy

[ "$(getenforce)" != "Enforcing" ] && setenforce 1

echo "[+] settings spoofed successfully"
echo "[*] no reboot required"