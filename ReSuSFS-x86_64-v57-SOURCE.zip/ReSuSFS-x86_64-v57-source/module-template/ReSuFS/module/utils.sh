#!/bin/sh
PATH=/data/adb/ksu/bin:/data/data/com.termux/files/usr/bin:$PATH

# MODDIR must point at the module's *current* location:
#   - during customize.sh, KernelSU stages the freshly extracted module at
#     $MODPATH (/data/adb/modules_update/ReSuSFS) and exports MODPATH;
#   - at runtime (service.sh / post-fs-data.sh / action.sh / ReSuSFS.sh)
#     the installed module lives at /data/adb/modules/ReSuSFS.
# v26.11.22 fix: this used to be hard-coded to the runtime path, so during
# installation every "is the bundled payload there?" check looked at the
# old install dir instead of the staging dir and a first flash always died
# with "Failed to install module script" (no bundled LKM / ksu_susfs
# "missing"). Resolving MODPATH here fixes both aborts at once.
MODDIR="/data/adb/modules/ReSuSFS"
[ -n "$MODPATH" ] && MODDIR="$MODPATH"
export SUSFS_LKM="/data/adb/ReSuSFS_LKM"

banner() {
        local dir="${1:-$MODDIR}"
        local module_prop="$dir/module.prop"
        local banner_file="$dir/banner"
        local author=$(sed -n 's/^author=//p' "$module_prop" 2>/dev/null)
        local version=$(sed -n 's/^version=//p' "$module_prop" 2>/dev/null)

        [ -f "$banner_file" ] && cat "$banner_file"

        echo "Authors:  ${author:-Unknown}"
        echo "Version: ${version:-Unknown}"
        echo
}

get_all_files() {
    local dir="$1"
    find "$dir" -type f 2>/dev/null | sed "s|^$dir/||"
}

# Resolve the device ABI. getprop is authoritative (it survives arm-translation
# layers that make uname -m lie), uname -m is only a fallback when getprop is
# unavailable. Returns one of: arm64-v8a, x86_64, or the raw getprop value
# (which update_susfs will then reject as unsupported).
get_device_abi() {
        local abi
        abi="$(getprop ro.product.cpu.abi 2>/dev/null)"

        case "$abi" in
                arm64-v8a|x86_64) echo "$abi"; return 0 ;;
        esac

        case "$(uname -m 2>/dev/null)" in
                aarch64) echo "arm64-v8a"; return 0 ;;
                x86_64) echo "x86_64"; return 0 ;;
        esac

        [ -n "$abi" ] && { echo "$abi"; return 0; }
        return 1
}

download_file() {
        local BB url="$1" out="$2" attempt=1 max=5 timeout=30 delay=3

        BB=$(command -v busybox) || { echo "[!] No BusyBox found!"; return 1; }

        while [ "$attempt" -le "$max" ]; do
                echo "[*] Download attempt $attempt/$max..."

                $BB wget -q --no-check-certificate \
                        --timeout="$timeout" \
                        --tries=1 \
                        --continue \
                        "$url" -O "$out" && [ -s "$out" ] && {
                        echo "[+] Download successful"
                        return 0
                }

                [ -f "$out" ] && [ ! -s "$out" ] && rm -f "$out"

                echo "[-] Download failed (attempt $attempt)"
                [ "$attempt" -lt "$max" ] && {
                        echo "[*] Retrying in ${delay}s..."
                        $BB sleep "$delay"
                        delay=$((delay * 2))
                }
                attempt=$((attempt + 1))
        done

        rm -f "$out"
        echo "[!] All download attempts failed"
        return 1
}

update_susfs() {
        local BB url tmp DEST_BIN_DIR ARCH module_root
        DEST_BIN_DIR="/data/adb/ksu/bin"

        # v26.11.22 fix: install-time payload dir. During customize.sh the
        # module is staged at $MODPATH, so the bundled x86_64 CLI must be
        # read from there; at runtime fall back to the installed module.
        module_root="${MODPATH:-$MODDIR}"

        if [ ! -d "$DEST_BIN_DIR" ]; then
                echo "[!] '$DEST_BIN_DIR' not existed, installation aborted."
                return 1
        fi

        ARCH="$(get_device_abi)" || {
                echo "[!] Unable to determine device ABI!"
                return 1
        }

        BB=$(command -v busybox) || { echo "[!] No BusyBox found!"; return 1; }
        echo "[+] BusyBox found: $BB"

        case "$ARCH" in
                arm64-v8a)
                        url="https://gitlab.com/simonpunk/susfs4ksu/-/raw/gki-android14-6.1/ksu_module_susfs/tools/ksu_susfs_arm64?ref_type=heads"
                        tmp="/data/local/tmp/ksu_susfs_arm64"

                        echo "[*] Downloading SUSFS binary..."
                        download_file "$url" "$tmp" || return 1

                        echo "[+] Installing ksu_susfs binary for arm64"
                        if $BB mv -f "$tmp" "$DEST_BIN_DIR/ksu_susfs" && $BB chmod 755 "$DEST_BIN_DIR/ksu_susfs"; then
                                echo "[+] SUSFS updated successfully!"
                                return 0
                        else
                                rm -f "$tmp"
                                echo "[!] Installation failed!"
                                return 1
                        fi
                        ;;
                x86_64)
                        # x86_64 port: the CLI is bundled with the module (freestanding
                        # binary, same ksu_susfs command surface; talks the supercall
                        # ABI and the /proc/susfs_* nodes susfs_guard_lkm provides).
                        # If another susfs LKM module already provides ksu_susfs as a
                        # symlink, keep it - never overwrite what that LKM ships.
                        if [ -L "$DEST_BIN_DIR/ksu_susfs" ]; then
                                echo "[+] ksu_susfs is already provided by the x86_64 susfs LKM, keeping it"
                                return 0
                        fi

                        if [ ! -f "$module_root/bin/x86_64/ksu_susfs" ]; then
                                echo "[!] Bundled x86_64 ksu_susfs binary not found: $module_root/bin/x86_64/ksu_susfs"
                                echo "[!] Rebuild it (see README-x86_64-PORT.md) and repackage the module."
                                return 1
                        fi

                        echo "[+] Installing bundled x86_64 ksu_susfs CLI"
                        if $BB cp -f "$module_root/bin/x86_64/ksu_susfs" "$DEST_BIN_DIR/ksu_susfs" && \
                           $BB chmod 755 "$DEST_BIN_DIR/ksu_susfs"; then
                                ln -sf ksu_susfs "$DEST_BIN_DIR/susfs" 2>/dev/null
                                ln -sf ksu_susfs "$DEST_BIN_DIR/sus" 2>/dev/null
                                echo "[+] SUSFS updated successfully!"
                                return 0
                        else
                                rm -f "$DEST_BIN_DIR/ksu_susfs"
                                echo "[!] Installation failed!"
                                return 1
                        fi
                        ;;
                *)
                        echo "[!] Only arm64-v8a and x86_64 are supported! (detected: '$ARCH')"
                        return 1
                        ;;
        esac
}

# v26.11.23: FUNCTIONAL kernel-susfs probe. Asking the ksu_susfs CLI for
# the susfs version is definitive: on kernels without susfs the supercall
# (reboot(0xDEADBEEF, 0xFAFAFAFA, ...)) returns EINVAL immediately, while
# kernels with built-in susfs (or a live susfs LKM) answer with a version
# string. /proc/config.gz is unavailable on most custom kernels (IKCONFIG
# off - LDPlayer 14 included), so the old config-grep test could not tell a
# KernelSU kernel with BUILT-IN susfs from a stock one and load_susfs_lkm
# would stack the LKM on top of built-in susfs: two hooking layers on the
# same syscalls is a plausible direct cause of the v26.11.22 post-boot
# freeze on LDPlayer 14.
susfs_kernel_alive() {
        # v26.11.23: the CLI's EXIT CODE is the definitive probe. The bundled
        # x86_64 CLI answers 0 ONLY when the kernel answered the supercall
        # (built-in susfs or a live LKM returns the version), and 1 with
        # "susfs: show version failed (no supercall answer, the module is
        # not loaded)" on kernels without any susfs layer. 5s bound: a
        # healthy supercall answers in microseconds, a wedged one gets cut
        # off instead of hanging the caller.
        [ -x /data/adb/ksu/bin/ksu_susfs ] || return 1

        rs_run 5 /data/adb/ksu/bin/ksu_susfs show version >/dev/null 2>&1
}

check_susfs_support() {
        local BB

        # x86_64 port: susfs can also come from the loaded susfs_guard_lkm.
        # /proc/susfs_path (control nodes) or the module's sysfs dir prove it
        # is live; treat that exactly like built-in support so the LKM is
        # never loaded twice.
        [ -e /proc/susfs_path ] && return 0
        [ -d /sys/module/susfs_guard_lkm ] && return 0

        # v26.11.23: functional probe BEFORE falling back to config files -
        # see susfs_kernel_alive(). This is what detects built-in susfs on
        # kernels that do not expose /proc/config.gz.
        susfs_kernel_alive && return 0

        [ -f /proc/config.gz ] || return 1

        BB=$(command -v busybox) || { echo "[!] No BusyBox found!"; return 1; }

        if $BB zcat /proc/config.gz 2>/dev/null | grep -q "^CONFIG_KSU_SUSFS=y"; then
                return 0
        fi

        return 1
}

# Resolve which susfs_guard_lkm image this kernel needs:
#   - arm64 GKI kernels   -> inforcqb/susfs4ksu-lkm release names;
#   - x86_64 GKI kernels  -> ymuuu/susfs4ksu-lkm-x64 zip member names;
#   - custom non-GKI x86_64 releases (e.g. LDPlayer 14's "5.15.178+") ->
#     the x86_64 build bundled with this module for that kernel series
#     ("5.15" -> susfs_guard_lkm-x86_64-5.15.ko).
get_susfs_guard_lkm() {
        local kmi ARCH base
        kmi="$(uname -r | sed -E 's/^([0-9]+\.[0-9]+)\.[0-9]+-(android[0-9]+)-.*/\2-\1/')"
        ARCH="$(get_device_abi 2>/dev/null)" || ARCH=""

        case "$ARCH" in
                x86_64)
                        case "$kmi" in
                                android12-5.10) echo "android12-5.10_susfs_guard_lkm.ko" ;;
                                android13-5.10) echo "android13-5.10_susfs_guard_lkm.ko" ;;
                                android13-5.15) echo "android13-5.15_susfs_guard_lkm.ko" ;;
                                android14-5.15) echo "android14-5.15_susfs_guard_lkm.ko" ;;
                                android14-6.1)  echo "android14-6.1_susfs_guard_lkm.ko"  ;;
                                android15-6.6)  echo "android15-6.6_susfs_guard_lkm.ko"  ;;
                                android16-6.12) echo "android16-6.12_susfs_guard_lkm.ko" ;;
                                android17-6.18) echo "android17-6.18_susfs_guard_lkm.ko" ;;
                                *)
                                        base="$(uname -r | sed -E 's/^([0-9]+\.[0-9]+)\..*/\1/')"
                                        [ -n "$base" ] && { echo "susfs_guard_lkm-x86_64-${base}.ko"; return 0; }
                                        echo "[!] You're using a custom x86_64 kernel (KMI: ${kmi:-unknown}), no matching LKM found."
                                        return 1
                                        ;;
                        esac
                        return 0
                        ;;
                *)
                        case "$kmi" in
                                android12-5.10) echo "susfs_guard_lkm-android12-5.10.ko" ;;
                                android13-5.10) echo "susfs_guard_lkm-android13-5.10.ko" ;;
                                android13-5.15) echo "susfs_guard_lkm-android13-5.15.ko" ;;
                                android14-5.15) echo "susfs_guard_lkm-android14-5.15.ko" ;;
                                android14-6.1)  echo "susfs_guard_lkm-android14-6.1.ko"  ;;
                                android15-6.6)  echo "susfs_guard_lkm-android15-6.6.ko"  ;;
                                android16-6.12) echo "susfs_guard_lkm-android16-6.12.ko" ;;
                                android17-6.18) echo "susfs_guard_lkm-android17-6.18.ko" ;;
                                *)
                                        echo "[!] You're using a custom kernel (KMI: ${kmi:-unknown}), no matching LKM found."
                                        return 1
                                        ;;
                        esac
                        return 0
                        ;;
        esac
}

# x86_64 port: install the bundled LKMs and loader instead of downloading.
# Upstream ships arm64 GKI builds only; this port bundles THREE x86_64
# candidates (v26.11.38):
#   susfs_guard_lkm-x86_64-android13-5.15.ko  built against AOSP
#     kernel/common android13-5.15 (ASB-2025-03-05_13-5.15 tag = the exact
#     lineage of LDPlayer 14's 5.15.178+ kernel per the port guide) - DEFAULT
#   susfs_guard_lkm-x86_64-vanilla-5.15.ko   built against kernel.org
#     linux-5.15.178 (the v26.11.26-37 build, config-matched empirically)
#   ymuuu_android13-5.15_susfs_guard_lkm.ko  ymuuuu's prebuilt GKI
#     android13-5.15 x64 ko ("the cheap shot" - Phase 1 of the port guide)
# plus the freestanding susfs_insmod loader that absolutizes symbols and
# fixes vermagic in place. Selection at load time: /data/adb/ReSuSFS/lkm_candidate
# (android13 | vanilla | ymuuu13, default android13 with fallback).
install_susfs_guard_lkm_x86_64() {
        local BB kmi module_root cand f installed

        BB="$(command -v busybox)" || { echo "[!] No BusyBox found!"; return 1; }

        kmi="$(get_susfs_guard_lkm)" || {
                echo "[!] Cannot determine KMI, skipping LKM install."
                return 1
        }

        module_root="${MODPATH:-$MODDIR}"
        mkdir -p "$SUSFS_LKM" 2>/dev/null

        # v26.11.40: payload refresh stamp.  The keep-existing rule below must
        # not pin a MODULE-ISSUED image across an upgrade: a v40 flash over a
        # v39 install would otherwise keep the old android13 .ko in place and
        # silently run the new experiment on an image without the substep
        # ladder, the kln resolver or the watchdog (the v38 lesson: an upgrade
        # that leaves the old payload in place ships a dead experiment).  The
        # payload carries lkm/x86_64/.payload_stamp; when it differs from the
        # installed $SUSFS_LKM/.payload_stamp, the module-issued .kos are
        # removed so the loop below reinstalls them.  Same-version reflashes
        # and genuinely user-supplied builds (placed AFTER a stamped install)
        # still win.
        PAYLOAD_STAMP_SRC=""
        [ -f "$module_root/lkm/x86_64/.payload_stamp" ] && PAYLOAD_STAMP_SRC="$(head -n 1 "$module_root/lkm/x86_64/.payload_stamp" 2>/dev/null)"
        if [ -n "$PAYLOAD_STAMP_SRC" ] && [ "$(head -n 1 "$SUSFS_LKM/.payload_stamp" 2>/dev/null)" != "$PAYLOAD_STAMP_SRC" ]; then
                for f in susfs_guard_lkm-x86_64-android13-5.15.ko                          susfs_guard_lkm-x86_64-vanilla-5.15.ko                          ymuuu_android13-5.15_susfs_guard_lkm.ko; do
                        rm -f "$SUSFS_LKM/${f}" 2>/dev/null
                done
                echo "$PAYLOAD_STAMP_SRC" > "$SUSFS_LKM/.payload_stamp" 2>/dev/null
                echo "[+] payload stamp changed ($PAYLOAD_STAMP_SRC) - refreshing module-issued .kos"
        fi

        # v26.11.38: install every bundled x86_64 candidate that exists.
        # A user-supplied file with the same name always wins (never overwrite
        # a user build for an exact kernel).
        installed=0
        for f in susfs_guard_lkm-x86_64-android13-5.15.ko \
                 susfs_guard_lkm-x86_64-vanilla-5.15.ko \
                 ymuuu_android13-5.15_susfs_guard_lkm.ko \
                 "${kmi}"; do
                if [ -f "$SUSFS_LKM/${f}" ] && [ "${f}" != "${kmi}" ]; then
                        echo "[+] Keeping existing ${f} in $SUSFS_LKM (user-supplied wins)"
                        installed=$((installed + 1))
                        continue
                fi
                if [ -f "$module_root/lkm/x86_64/${f}" ] || [ -f "$module_root/lkm/x86_64/candidates/${f}" ]; then
                        if [ -f "$module_root/lkm/x86_64/${f}" ]; then
                                $BB cp -f "$module_root/lkm/x86_64/${f}" "$SUSFS_LKM/${f}" || continue
                        else
                                $BB cp -f "$module_root/lkm/x86_64/candidates/${f}" "$SUSFS_LKM/${f}" || continue
                        fi
                        $BB chmod 644 "$SUSFS_LKM/${f}"
                        echo "[+] Installed bundled ${f}"
                        installed=$((installed + 1))
                fi
        done
        [ "$installed" -gt 0 ] || {
                echo "[!] No bundled x86_64 LKM found for this kernel ($(uname -r))"
                echo "[!] Build one from the ported tree (see README-X86_64-PORT.md)"
                return 1
        }

        # x86_64 loader: ksud-free fallback, also survives vermagic mismatches
        if [ -f "$module_root/bin/x86_64/susfs_insmod" ]; then
                $BB cp -f "$module_root/bin/x86_64/susfs_insmod" "$SUSFS_LKM/susfs_insmod" || {
                        echo "[!] Failed to copy susfs_insmod to $SUSFS_LKM"
                        return 1
                }
                $BB chmod 755 "$SUSFS_LKM/susfs_insmod"
                echo "[+] Installing bundled susfs_insmod loader"
        fi

        printf '%s\n' "$SUSFS_LKM"
        return 0
}

# x86_64 flavor of the LKM fetcher for GKI kernels: the x64 fork
# (ymuuuu/susfs4ksu-lkm-x64) publishes a single flashable module zip that
# bundles all eight GKI KMIs plus its own CLI. We download that zip once
# and pull out the .ko matching this kernel. (Custom kernels never get
# here - the bundled LKM covers them, see download_susfs_guard_lkm.)
download_susfs_guard_lkm_x64() {
        local BB kmi base_url module_zip dest_dir dest_file tmp_dir

        kmi="$(get_susfs_guard_lkm)" || {
                echo "[!] Cannot determine KMI, skipping x86_64 LKM download."
                return 1
        }

        BB="$(command -v busybox)" || {
                echo "[!] No BusyBox found!"
                return 1
        }

        base_url="https://github.com/ymuuuu/susfs4ksu-lkm-x64/releases/latest/download"
        module_zip="susfs_lkm_x64.zip"
        dest_dir="/data/local/tmp"
        dest_file="$dest_dir/${module_zip}"

        echo "[+] Downloading ${module_zip} (all x86_64 GKI KMIs, about 4.5MB+)"
        mkdir -p "$dest_dir" "$SUSFS_LKM" 2>/dev/null

        download_file "$base_url/${module_zip}" "$dest_file" || {
                echo "[!] Failed to download ${module_zip}"
                return 1
        }

        # Extract just the .ko for this kernel. Prefer busybox unzip, then
        # whatever unzip the system provides (toybox ships one on Android).
        tmp_dir="$dest_dir/resusfs_lkm_x64.$$"
        mkdir -p "$tmp_dir"

        if ! ( cd "$tmp_dir" && $BB unzip -o "$dest_file" "$kmi" ) && \
           ! ( cd "$tmp_dir" && unzip -o "$dest_file" "$kmi" ); then
                rm -rf "$tmp_dir" "$dest_file"
                echo "[!] Failed to extract ${kmi} from ${module_zip}"
                return 1
        fi

        if [ ! -f "$tmp_dir/${kmi}" ]; then
                rm -rf "$tmp_dir" "$dest_file"
                echo "[!] ${kmi} not present in ${module_zip}"
                return 1
        fi

        $BB mv -f "$tmp_dir/${kmi}" "$SUSFS_LKM/${kmi}" || {
                rm -rf "$tmp_dir" "$dest_file"
                echo "[!] Failed to move ${kmi} to $SUSFS_LKM"
                return 1
        }
        $BB chmod 644 "$SUSFS_LKM/${kmi}"

        rm -rf "$tmp_dir" "$dest_file"

        printf '%s\n' "$SUSFS_LKM"
        return 0
}

download_susfs_guard_lkm() {
        local BB kmi base_url dest_dir dest_file ARCH module_root

        if check_susfs_support; then
                echo "[+] Built-in SuSFS support, skipping LKM download"
                return 0
        fi

        ARCH="$(get_device_abi 2>/dev/null)" || ARCH=""

        if [ "$ARCH" = "x86_64" ]; then
                kmi="$(get_susfs_guard_lkm)" || {
                        echo "[!] Cannot determine KMI, skipping x86_64 LKM download."
                        return 1
                }
                module_root="${MODPATH:-$MODDIR}"

                # v26.11.22 fix: resolved through the staging dir during
                # installation, so the bundled LKM is found on first flash.
                # A user-supplied LKM in $SUSFS_LKM always wins over it.
                #
                # v26.11.39 FIX (the v38 silent no-load bug): this gate used
                # to require a file named EXACTLY ${kmi}. On a custom kernel
                # ${kmi} resolves to the LEGACY name
                # 'susfs_guard_lkm-x86_64-5.15.ko', which v38 stopped
                # shipping (the payload was renamed to the three candidates
                # and two of them moved under lkm/x86_64/candidates/). The
                # gate therefore never fired on the field device:
                # install_susfs_guard_lkm_x86_64 never ran,
                # /data/adb/ReSuSFS_LKM stayed EMPTY, and install + every
                # boot ended in "No x86_64 LKM available for this kernel"
                # + rc=1 - the v38 two-step experiment never actually ran.
                # New gate: install whenever the exact ${kmi} exists OR any
                # bundled x86_64 candidate exists in the module payload
                # (install_susfs_guard_lkm_x86_64 itself already keeps
                # user-supplied files in $SUSFS_LKM).
                if [ -f "$SUSFS_LKM/${kmi}" ] || [ -f "$module_root/lkm/x86_64/${kmi}" ] || \
                   [ -f "$module_root/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-android13-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/susfs_guard_lkm-x86_64-vanilla-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/ymuuu_android13-5.15_susfs_guard_lkm.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko" ]; then
                        install_susfs_guard_lkm_x86_64
                        return $?
                fi

                # GKI x86_64 kernels: fetch the community multi-KMI zip
                case "$kmi" in
                        android*_susfs_guard_lkm.ko)
                                download_susfs_guard_lkm_x64
                                return $?
                                ;;
                esac

                echo "[!] No x86_64 LKM available for this kernel ($(uname -r))"
                echo "[!] Build one from the ported tree (see README-X86_64-PORT.md)"
                echo "[!] and place it at $SUSFS_LKM/${kmi}"
                return 1
        fi

        kmi="$(get_susfs_guard_lkm)" || {
                echo "[!] Cannot determine KMI, skipping LKM download."
                return 1
        }

        BB="$(command -v busybox)" || {
                echo "[!] No BusyBox found!"
                return 1
        }

        base_url="https://github.com/inforcqb/susfs4ksu-lkm/releases/latest/download"
        dest_dir="/data/local/tmp"
        echo "[+] Downloading ${kmi} its size about 5MB+"
        mkdir -p "$dest_dir" "$SUSFS_LKM" 2>/dev/null

        dest_file="$dest_dir/${kmi}"
        download_file "$base_url/${kmi}" "$dest_file" || {
                echo "[!] Failed to download ${kmi}"
                return 1
        }
        $BB mv -f "$dest_file" "$SUSFS_LKM/${kmi}" || {
                echo "[!] Failed to move ${kmi} to $SUSFS_LKM"
                return 1
        }
        $BB chmod 644 "$SUSFS_LKM/${kmi}"

        echo "[+] Downloading susfs_insmod its size about 32KB+"
        dest_file="$dest_dir/susfs_insmod"
        download_file "$base_url/susfs_insmod" "$dest_file" || {
                echo "[!] Failed to download susfs_insmod"
                return 1
        }
        $BB mv -f "$dest_file" "$SUSFS_LKM/susfs_insmod" || {
                echo "[!] Failed to move susfs_insmod to $SUSFS_LKM"
                return 1
        }
        $BB chmod 755 "$SUSFS_LKM/susfs_insmod"

        printf '%s\n' "$SUSFS_LKM"
        return 0
}

# v26.11.24: after a failed LKM load, snapshot WHY the kernel refused:
# the last module-related dmesg lines (relocation / vermagic / signature
# complaints live there), the load-relevant kernel config (when
# /proc/config.gz exists), and the sysctls that gate module loading and
# kallsyms. Written to stdout - the caller runs under run_gated with stdout
# redirected into boot.log, so this lands next to the loader's own output.
# Best effort only: a failing capture must never fail the load itself.
capture_insmod_evidence() {
        local BB dm kline nm hit

        BB="$(command -v busybox)"

        echo "---- LKM load failure evidence (v26.11.26) ----"
        echo "uname: $(uname -a 2>/dev/null)"
        echo "modules_disabled: $(cat /proc/sys/kernel/modules_disabled 2>/dev/null || echo '?')"
        echo "kptr_restrict: $(cat /proc/sys/kernel/kptr_restrict 2>/dev/null || echo '?')"

        # one real kallsyms line says whether addresses are visible at all
        # (all-zero => kptr_restrict hides them and susfs_insmod refuses to
        # absolutize, by design: it never loads zero-address symbols)
        kline="$(sed -n '2p' /proc/kallsyms 2>/dev/null)"
        echo "kallsyms sample line: ${kline:-<unavailable>}"

        # v26.11.25: the v26.11.24 load failed with ENOEXEC and the kernel
        # printing NOTHING - the silent CONFIG_MODVERSIONS gate. This line
        # proves or disproves it for THIS kernel: a MODVERSIONS kernel lists
        # __crc_module_layout (the CRC value is the printed address) and a
        # non-MODVERSIONS kernel does not list the name at all.
        echo "module_layout CRC (MODVERSIONS probe): $(grep -w __crc_module_layout /proc/kallsyms 2>/dev/null || echo 'not listed (kernel has CONFIG_MODVERSIONS=n, or the address is hidden)')"

        # per-name kallsyms status for the imports that mattered in the
        # v26.11.24 log (12 were config-mismatch imports and are gone from
        # the v26.11.25 .ko; these are the rest): absent => the kernel does
        # not carry the name at all; a dotted/mangled listing explains a
        # kallsyms-based miss on an exported name; ' [module]' means it
        # belongs to another module's image.
        for nm in try_module_get module_put find_vma saved_boot_config current_task; do
                hit="$(grep -w "$nm" /proc/kallsyms 2>/dev/null | head -n 2)"
                echo "kallsyms '$nm': ${hit:-not listed}" | head -n 2
        done

        dm=""
        [ -n "$BB" ] && dm="$($BB dmesg 2>/dev/null | tail -n 300)"
        [ -z "$dm" ] && dm="$(dmesg 2>/dev/null | tail -n 300)"
        if [ -n "$dm" ]; then
                # v26.11.25: raw tail too - the filtered grep below can hide a
                # message whose wording we did not anticipate; the raw lines
                # are the last resort when reading the log next boot
                echo "---- dmesg raw tail (last 12 lines) ----"
                echo "$dm" | tail -n 12
                echo "---- dmesg tail (module-related, last 30 lines) ----"
                echo "$dm" | grep -iE 'module|insmod|vermagic|kallsyms|symbol version|crc|sig|reloc' | tail -n 30
        else
                echo "---- dmesg unavailable (dmesg_restrict? no busybox?) ----"
        fi

        if [ -r /proc/config.gz ]; then
                mkdir -p "$PERSISTENT_DIR/logs" 2>/dev/null
                ([ -n "$BB" ] && $BB zcat /proc/config.gz > "$PERSISTENT_DIR/logs/kconfig.txt" 2>/dev/null) ||
                        zcat /proc/config.gz > "$PERSISTENT_DIR/logs/kconfig.txt" 2>/dev/null
                if [ -s "$PERSISTENT_DIR/logs/kconfig.txt" ]; then
                        echo "---- kernel config saved: $PERSISTENT_DIR/logs/kconfig.txt (relevant lines) ----"
                        grep -E '^CONFIG_(MODULES|MODVERSIONS|MODULE_SIG|MODULE_COMPRESS|MODULE_REL_CRCS|MODULE_FORCE_LOAD|KALLSYMS|STRICT_KERNEL_RWX|CFI|LTO|RETPOLINE|X86_5LEVEL|IKCONFIG|DEBUG_INFO_BTF)' \
                                "$PERSISTENT_DIR/logs/kconfig.txt" 2>/dev/null | head -n 30
                fi
        else
                echo "---- /proc/config.gz not present (CONFIG_IKCONFIG_PROC off) ----"
        fi
        echo "---- end of evidence ----"
}


# v26.11.27: the v26.11.26 boot log proved the LKM LOADS (init_module rc=0,
# /sys/module/susfs_guard_lkm exists, /proc/susfs_path present right after
# the load, module Live in /proc/modules, system stable) - but every
# supercall came back with "no supercall answer": the kprobe path the
# reboot-ABI rides did not intercept anything, and stage-early's functional
# probe (ksu_susfs show version) failed one second after the load. The
# module's OWN init messages (which layers armed, which failed non-fatally,
# the current_task %gs offset it resolved, whether the canary recheck
# degraded, whether the supercall kprobe registered) all went to dmesg,
# which nobody captured: susfs_insmod seeks /dev/kmsg to the END before
# init_module, so the kernel's init-time lines are never in boot.log.
# This capture runs right AFTER a successful load and dumps exactly that
# evidence into boot.log, plus a live supercall test, the kallsyms values
# for the names the supercall and `current` depend on (with kptr_restrict
# relaxed exactly like the loader does), and the probe/module visibility
# state. Best effort only: nothing here may fail the boot stage.
capture_lkm_live_evidence() {
        local BB dm kcur knew nm hit cli

        BB="$(command -v busybox)"

        echo "---- LKM live evidence (v26.11.28) ----"

        # 1. live supercall test: does the reboot-ABI answer NOW?
        #    v26.11.28: sleep 2s first so the kretprobe's registration has
        #    fully settled (the rethook trampoline arms synchronously on
        #    register_kretprobe, but a small grace covers any optimizer
        #    quirk) and so any pr_warn from susfs_init's tail is in dmesg.
        sleep 2
        cli=/data/adb/ksu/bin/ksu_susfs
        [ -x "$cli" ] || cli="$MODDIR/bin/x86_64/ksu_susfs"
        if [ -x "$cli" ]; then
                echo "---- supercall live test (ksu_susfs show version / variant / enabled_features) ----"
                rs_run 5 "$cli" show version 2>&1 | head -n 3
                rs_run 5 "$cli" show variant 2>&1 | head -n 3
                rs_run 5 "$cli" show enabled_features 2>&1 | head -n 6
        else
                echo "supercall live test: CLI not found ($cli)"
        fi

        # 2. the module's own init messages.
        #    v26.11.29: the v28 capture used `dmesg | tail -n 600` then grepped, but the
        #    v28 boot.log showed NONE of susfs_init's messages — not even the unconditional
        #    pr_info("loaded..."). Two possible causes: (a) the messages were never printed
        #    (susfs_init didn't reach them), or (b) `dmesg` on LDPlayer reads from
        #    /proc/kmsg (incremental) instead of the full ring, so early messages were
        #    already consumed by logd. This capture now does THREE things:
        #      (i) `dmesg` with NO tail limit, grep for the module's own prefix
        #          "susfs_guard_lkm:" — this reads the FULL ring (dmesg with no tail
        #          argument reads everything available).
        #      (ii) `dmesg | tail -n 3000` with the wider grep pattern (backwards compat
        #           with v28).
        #      (iii) a RAW dump of the last 200 dmesg lines (no grep) so we NEVER lose
        #            evidence to a too-narrow filter.
        echo "---- dmesg (susfs_guard_lkm: prefix, FULL ring) ----"
        hit=""
        [ -n "$BB" ] && hit="$($BB dmesg 2>/dev/null | grep 'susfs_guard_lkm:')"
        [ -z "$hit" ] && hit="$(dmesg 2>/dev/null | grep 'susfs_guard_lkm:')"
        echo "${hit:-<no susfs_guard_lkm: lines in the full dmesg ring - susfs_init did not print, or dmesg reads incrementally>}"
        echo ""
        echo "---- dmesg (wider pattern, last 3000) ----"
        dm=""
        [ -n "$BB" ] && dm="$($BB dmesg 2>/dev/null | tail -n 3000)"
        [ -z "$dm" ] && dm="$(dmesg 2>/dev/null | tail -n 3000)"
        if [ -n "$dm" ]; then
                hit="$(echo "$dm" | grep -iE 'susfs|ReSuSFS|loaded\.|supercall|kprobe|kretprobe|DIAG|sc_entry|sc_ret|symbol version|module_layout|fail_layer|init failed|refusing to load|ksu_init|register_kretprobe' | tail -n 120)"
                if [ -n "$hit" ]; then
                        echo "$hit"
                else
                        echo "<wider pattern matched nothing in last 3000 lines>"
                fi
                echo ""
                echo "---- dmesg (RAW last 80 lines, no filter) ----"
                echo "$dm" | tail -n 80
        else
                echo "---- dmesg unavailable ----"
        fi

        # 3. kallsyms ground truth for the names the supercall and
        # `current` depend on, with kptr_restrict relaxed for the read
        # exactly like susfs_insmod does (restored right after). An 'A'
        # (absolute/per-CPU) record prints the symbol's per-CPU OFFSET as
        # its value, so the current_task line answers whether the offset
        # the module chose at init (0) was the real one.
        # v26.11.30: also dump KernelSU symbols to find the supercall dispatch
        # function (ksu_handle_sys_reboot etc.) — the v26.11.29 boot.log
        # revealed KernelSU has its own kprobe on __x64_sys_reboot, so susfs
        # needs to hook a different point in KernelSU's dispatch path.
        kcur="$(cat /proc/sys/kernel/kptr_restrict 2>/dev/null)"
        echo 0 > /proc/sys/kernel/kptr_restrict 2>/dev/null
        echo "---- kallsyms (kptr_restrict relaxed: was '$kcur') ----"
        for nm in current_task __x64_sys_reboot __per_cpu_start fixed_percpu_data init_task \
                  ksu_handle_sys_reboot ksu_handle_prctl ksu_handle_execveat \
                  ksu_handle_syscall handle_superscall susfs_suscall \
                  ksu_try_umount ksu_handle_sigterm; do
                hit="$(grep -w "$nm" /proc/kallsyms 2>/dev/null | head -n 2)"
                echo "kallsyms '$nm': ${hit:-not listed}"
        done
        echo "---- kallsyms (KernelSU-prefixed, first 30) ----"
        hit="$(grep -iE ' (t|T) ksu_' /proc/kallsyms 2>/dev/null | head -n 30)"
        echo "${hit:-<no ksu_ function symbols in kallsyms>}"
        [ -n "$kcur" ] && echo "$kcur" > /proc/sys/kernel/kptr_restrict 2>/dev/null

        # 4. where the supercall's breakpoint actually sits (best effort:
        # needs debugfs) and whether the module self-hid from /proc/modules.
        # v26.11.30: also check if debugfs is mounted (LDPlayer may not mount it).
        echo "---- kretprobe registration state (best effort) ----"
        echo "debugfs mount: $(mount 2>/dev/null | grep debugfs | head -n 1 || echo '<debugfs NOT mounted>')"
        echo "debugfs dir exists: $([ -d /sys/kernel/debug ] && echo yes || echo no)"
        echo "kprobes/list exists: $([ -f /sys/kernel/debug/kprobes/list ] && echo yes || echo no)"
        hit="$(cat /sys/kernel/debug/kprobes/list 2>/dev/null | head -n 20)"
        echo "kprobes/list (ALL, first 20): ${hit:-<unavailable>}"
        hit="$(grep susfs /proc/modules 2>/dev/null | head -n 3)"
        echo "/proc/modules: ${hit:-<module not listed - self-hiding active>}"

        # 5. control-node visibility: -e proves the node exists; the getdents
        # view tells whether the module's own stealth (susfs_self_hide_nodes,
        # hidden-from-listing by design) answers for them.
        echo "---- /proc/susfs_* control nodes ----"
        if [ -e /proc/susfs_path ]; then
                echo "/proc/susfs_path: exists (-e)"
        else
                echo "/proc/susfs_path: ABSENT (-e) - created at load time per boot.log, then gone"
        fi
        hit="$(ls /proc 2>/dev/null | grep -i susfs | head -n 10)"
        echo "ls /proc (getdents view): ${hit:-<none visible - hidden by the module's own stealth is EXPECTED>}"

        # 6. v26.11.31: module parameter diagnostics (bypasses BOTH printk AND file I/O).
        #    The v26.11.30 boot.log proved that diag_init.log was NOT created (filp_open
        #    blocked by KernelSU's hook_manager).  v26.11.31 switches to module parameters,
        #    which are exposed via /sys/module/susfs_guard_lkm/parameters/ and are managed
        #    by the kernel's module subsystem (kernel/module.c param_sysfs) — unhookable.
        echo "---- /sys/module/susfs_guard_lkm/parameters/diag_log (module param, bypasses printk+filp) ----"
        hit="$(cat /sys/module/susfs_guard_lkm/parameters/diag_log 2>/dev/null)"
        echo "${hit:-<diag_log is empty or unreadable — susfs_init did not run, or module_param not exposed>}"

        echo "---- /sys/module/susfs_guard_lkm/parameters/sc_entry_count (supercall kprobe fire count) ----"
        # v45 note: this counter is real evidence ONLY from v45 on - the v44
        # constant "10" on every boot (even zombie modules whose probe was
        # never registered) was the android struct-module tail spilling 0x40
        # bytes past the 0x300-byte .gnu.linkonce.this_module into .bss[0..0x40)
        # where the counter lives; v45's susfs_bss_stomp_pad absorbs the spill.
        echo "sc_entry_count (v45+: real kprobe hits): $(cat /sys/module/susfs_guard_lkm/parameters/sc_entry_count 2>/dev/null || echo '<param not exposed>')"

        # 7. v26.11.42 substep-ladder state: init_laststep carries the v42
        #    sentinel codes (-1 fresh module, -50 kworker entered, -51 already
        #    done, -60 probe .get entered, 0..7 body substeps).  force_init is
        #    deliberately 0200 (write-only, root): a READ fails with EACCES,
        #    which the v40 collector misreported as "param not exposed -
        #    fallback image"; presence is checked with -e now instead.
        #    wd_timeout_s no longer exists: v41 removed the kernel-side
        #    watchdog (recovery is the next boot's stand-down).  v42 adds the
        #    probe/probe_arm pair (the READ-path trigger channel).
        echo "---- /sys/module/susfs_guard_lkm/parameters: v42 substep ladder ----"
        for prm in init_maxstep init_laststep init_done arm_stage kr_scan diag_printk probe_arm; do
                hit="$(cat /sys/module/susfs_guard_lkm/parameters/$prm 2>/dev/null)"
                echo "$prm = ${hit:-<param not exposed - fallback image, no v40+ experiment>}"
        done
        if [ -e /sys/module/susfs_guard_lkm/parameters/force_init ]; then
                echo "force_init = present (0200 write-only by design; the v40 collector's 'not exposed' line was this read's EACCES, not a missing param)"
        else
                echo "force_init = <file absent - fallback image, no v40/v41 experiment>"
        fi
        echo "wd_timeout_s = <removed in v41: no kernel-side watchdog; recovery is the next boot's stand-down>"
        hit="$(cat /sys/module/susfs_guard_lkm/parameters/kr_seed 2>/dev/null)"
        if [ -n "$hit" ]; then
                echo "kr_seed = ${hit}"
        else
                echo "kr_seed = <empty - not seeded this boot>"
        fi

        echo "---- end of live evidence ----"
}

# ---- v26.11.38: Phase-0 kernel recon + resolver seeding -----------------
#
# The port guide's Phase 0: collect the kernel's build facts BEFORE any LKM
# action, into /data/adb/ReSuSFS/logs/. Every boot refreshes them, so even a
# wedged boot leaves the facts on disk for the next one. Bounded and gated
# by the caller; nothing here can fail the boot.

kernel_recon() {
        local BB out kcur n_syms

        BB="$(command -v busybox)"
        out="$LOG_DIR/kernel_facts.txt"

        mkdir -p "$LOG_DIR" 2>/dev/null

        {
        echo "================ ReSuSFS kernel recon (v26.11.38) ================"
        echo "timestamp: $(rs_ts)"
        echo "boot_id: $(rs_boot_id)"
        echo ""
        echo "--- /proc/version (compiler + build string) ---"
        cat /proc/version 2>/dev/null
        echo "--- uname -a ---"
        uname -a 2>/dev/null
        echo "--- /proc/sys/kernel/osrelease (exact KMI string) ---"
        cat /proc/sys/kernel/osrelease 2>/dev/null
        echo "--- /proc/sys/kernel/tainted ---"
        cat /proc/sys/kernel/tainted 2>/dev/null
        echo "--- getenforce ---"
        getenforce 2>/dev/null || echo "(getenforce unavailable)"
        echo "--- /proc/cmdline ---"
        cat /proc/cmdline 2>/dev/null | head -c 1024
        echo ""
        echo "--- key sysctls ---"
        for s in kernel/kptr_restrict kernel/dmesg_restrict kernel/perf_event_paranoid; do
                echo "$s = $(cat /proc/sys/$s 2>/dev/null)"
        done
        echo "--- ksud availability ---"
        if command -v ksud >/dev/null 2>&1; then
                echo "ksud on PATH: $(command -v ksud)"
                ksud --help 2>&1 | head -n 20
        else
                echo "ksud NOT on PATH"
        fi
        [ -x /data/adb/ksu/bin/ksud ] && { echo "/data/adb/ksu/bin/ksud exists"; /data/adb/ksu/bin/ksud --help 2>&1 | head -n 20; }
        echo "--- KernelSU variant hints ---"
        for p in /data/adb/ksu/bin/ksud /data/adb/ksu/bin/su /data/adb/ksud; do
                [ -e "$p" ] && echo "$p: $(ls -l $p 2>/dev/null)"
        done
        echo "--- BTF (struct layout ground truth, if present) ---"
        ls -l /sys/kernel/btf/ 2>/dev/null | head -n 8
        echo "--- IKCONFIG (/proc/config.gz -> kernel_config.txt) ---"
        if [ -e /proc/config.gz ]; then
                if gunzip -c /proc/config.gz > "$LOG_DIR/kernel_config.txt" 2>/dev/null || \
                   $BB gunzip -c /proc/config.gz > "$LOG_DIR/kernel_config.txt" 2>/dev/null; then
                        echo "config written: $LOG_DIR/kernel_config.txt ($(wc -l < "$LOG_DIR/kernel_config.txt" 2>/dev/null) lines)"
                        echo "key options:"
                        grep -E '^CONFIG_(LOCALVERSION|LOCALVERSION_AUTO|MODULES|MODULE_UNLOAD|MODVERSIONS|KALLSYMS|KALLSYMS_ALL|RETPOLINE|STACKPROTECTOR|HARDENED_USERCOPY|X86_5LEVEL|RANDOMIZE_MEMORY|PREEMPT|SECURITY_SELINUX|KPROBES|LTO_CLANG|PGO|DEBUG_INFO_BTF|IKCONFIG_PROC|ANDROID_BINDER|KALLSYMS_BASE_RELATIVE)=' "$LOG_DIR/kernel_config.txt" 2>/dev/null | head -n 40
                else
                        echo "/proc/config.gz exists but gunzip failed"
                fi
        else
                echo "/proc/config.gz absent (CONFIG_IKCONFIG_PROC off) - kallsyms + version string are the layout hints"
        fi
        echo "--- /proc/modules (first 15) ---"
        head -n 15 /proc/modules 2>/dev/null
        echo "==================================================================="
        } >> "$out" 2>/dev/null

        # kallsyms snapshot with kptr relaxed exactly like the loader: the
        # full table (bounded to the first 8 MB of text) + the resolver-seed
        # symbols extracted. Restored right after, like capture_lkm_live_evidence.
        kcur="$(cat /proc/sys/kernel/kptr_restrict 2>/dev/null)"
        echo 0 > /proc/sys/kernel/kptr_restrict 2>/dev/null

        n_syms="$(wc -l < /proc/kallsyms 2>/dev/null)"
        if [ -n "$n_syms" ] && [ "$n_syms" != "0" ]; then
                head -c 8388608 /proc/kallsyms > "$LOG_DIR/kernel_kallsyms.txt" 2>/dev/null
                {
                echo "--- kallsyms: $n_syms lines total, snapshot bounded to 8MB ---"
                echo "--- kallsyms table symbols (the kr_seed values) ---"
                grep -wE 'kallsyms_offsets|kallsyms_addresses|kallsyms_relative_base|kallsyms_num_syms|kallsyms_names|kallsyms_markers|kallsyms_token_table|kallsyms_token_index|kallsyms_seqs_of_names' /proc/kallsyms 2>/dev/null | head -n 20
                echo "--- layout-distinguishing symbols ---"
                for nm in current_task fixed_percpu_data __per_cpu_start _stext _etext kallsyms_lookup_name kallsyms_lookup sprint_symbol; do
                        hit="$(grep -w "$nm" /proc/kallsyms 2>/dev/null | head -n 2)"
                        echo "kallsyms '$nm': ${hit:-not listed}"
                done
                echo "--- LTO/CFI/BOLT markers ---"
                grep -cE '\.cfi_jt' /proc/kallsyms 2>/dev/null | sed 's/^/cfi_jt symbols: /'
                grep -wE '__cfi_check_fail|__start___jump_table|__lto_sanity' /proc/kallsyms 2>/dev/null | head -n 5
                } >> "$out" 2>/dev/null
        else
                echo "--- kallsyms unreadable ---" >> "$out" 2>/dev/null
        fi

        [ -n "$kcur" ] && echo "$kcur" > /proc/sys/kernel/kptr_restrict 2>/dev/null
        sync 2>/dev/null
        # v26.11.44: claim kernel_config.txt ONLY when it was really written
        # (/proc/config.gz absent is normal - CONFIG_IKCONFIG_PROC off); the
        # v43 summary claimed it unconditionally and misled field greps.
        if [ -s "$LOG_DIR/kernel_config.txt" ]; then
                echo "[+] kernel recon written: $out (+kernel_kallsyms.txt +kernel_config.txt)"
        else
                echo "[+] kernel recon written: $out (+kernel_kallsyms.txt; kernel_config.txt NOT written - /proc/config.gz absent on this kernel)"
        fi
}

# v26.11.38: build the kr_seed string from /proc/kallsyms (kptr relaxed like
# the loader) and write it into the module param. Echoes the seed string on
# stdout for the boot log. Returns 1 when the tables are not visible (the
# module will then refuse to resolve without scanning - by design).
seed_kallsyms_resolver() {
        local kcur seed names offs relbase num marks toktab tokidx addrs

        kcur="$(cat /proc/sys/kernel/kptr_restrict 2>/dev/null)"
        echo 0 > /proc/sys/kernel/kptr_restrict 2>/dev/null

        names="$(grep -w 'kallsyms_names' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        offs="$(grep -w 'kallsyms_offsets' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        relbase="$(grep -w 'kallsyms_relative_base' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        num="$(grep -w 'kallsyms_num_syms' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        marks="$(grep -w 'kallsyms_markers' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        toktab="$(grep -w 'kallsyms_token_table' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        tokidx="$(grep -w 'kallsyms_token_index' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        addrs="$(grep -w 'kallsyms_addresses' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"

        [ -n "$kcur" ] && echo "$kcur" > /proc/sys/kernel/kptr_restrict 2>/dev/null

        # relative layout (CONFIG_KALLSYMS_BASE_RELATIVE=y, every 5.15
        # Android/Chrome OS kernel): offsets + relative_base.
        if [ -n "$offs" ] && [ -n "$relbase" ]; then
                seed="names=$names offsets=$offs relative_base=$relbase num_syms=$num markers=$marks token_table=$toktab token_index=$tokidx"
        elif [ -n "$addrs" ]; then
                # v1 absolute layout: kallsyms_addresses instead.
                seed="names=$names addresses=$addrs num_syms=$num markers=$marks token_table=$toktab token_index=$tokidx"
        else
                echo "seed: kallsyms tables are not visible under kptr_restrict=0 - cannot seed"
                return 1
        fi

        if [ -w /sys/module/susfs_guard_lkm/parameters/kr_seed ]; then
                echo "$seed" > /sys/module/susfs_guard_lkm/parameters/kr_seed 2>/dev/null || {
                        echo "seed: kr_seed param write FAILED" >&2
                        return 1
                }
                echo "$seed"
                return 0
        fi
        echo "seed: kr_seed param not writable (module not live or old image)" >&2
        return 1
}

# v26.11.40: seed v2 - the kln= (direct function-pointer) form.  The v39
# field evidence settled it: the LDPlayer kernel's /proc/kallsyms lists NONE
# of the kallsyms TABLE variables (kallsyms_offsets/_names/_token_table/...
# - the clang-LTO+trim build dropped them), so the v1 table seed can never be
# built there.  It DOES list the functions the resolver actually needs:
#   kallsyms_lookup_name  -> kr_seed "kln=0x<addr>" (validated in-module via
#                            the imported sprint_symbol before first use)
#   current_task ('A')   -> kr_seed "gsoff=0x<offset>" (the measured device
#                            value is 0x1bc40 - v39's "0" default was wrong)
# The v1 table fields are still emitted when the tables ARE visible, so a
# kernel that lists them can use either form.  Returns the seed string on
# stdout (rc 0) when something was written; rc 1 otherwise.
seed_kallsyms_resolver_v2() {
        local kcur kln gsoff names offs relbase num marks toktab tokidx addrs seed

        kcur="$(cat /proc/sys/kernel/kptr_restrict 2>/dev/null)"
        echo 0 > /proc/sys/kernel/kptr_restrict 2>/dev/null

        kln="$(grep -w 'kallsyms_lookup_name' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        gsoff="$(grep -w 'current_task' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        offs="$(grep -w 'kallsyms_offsets' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        relbase="$(grep -w 'kallsyms_relative_base' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        addrs="$(grep -w 'kallsyms_addresses' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"

        # table fields (only meaningful on kernels that list the tables)
        names="$(grep -w 'kallsyms_names' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        num="$(grep -w 'kallsyms_num_syms' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        marks="$(grep -w 'kallsyms_markers' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        toktab="$(grep -w 'kallsyms_token_table' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"
        tokidx="$(grep -w 'kallsyms_token_index' /proc/kallsyms 2>/dev/null | head -n 1 | awk '{print $1}')"

        [ -n "$kcur" ] && echo "$kcur" > /proc/sys/kernel/kptr_restrict 2>/dev/null

        seed=""
        if [ -n "$kln" ]; then
                seed="kln=$kln"
                [ -n "$gsoff" ] && seed="$seed gsoff=$gsoff"
        fi
        # relative layout (CONFIG_KALLSYMS_BASE_RELATIVE=y)
        if [ -n "$offs" ] && [ -n "$relbase" ]; then
                seed="$seed names=$names offsets=$offs relative_base=$relbase num_syms=$num markers=$marks token_table=$toktab token_index=$tokidx"
        elif [ -n "$addrs" ]; then
                seed="$seed names=$names addresses=$addrs num_syms=$num markers=$marks token_table=$toktab token_index=$tokidx"
        fi

        if [ -z "$seed" ]; then
                echo "seed: neither kln= (kallsyms_lookup_name) nor the kallsyms tables are visible in /proc/kallsyms - cannot seed (the module will refuse to init)" >&2
                return 1
        fi

        if [ -w /sys/module/susfs_guard_lkm/parameters/kr_seed ]; then
                echo "$seed" > /sys/module/susfs_guard_lkm/parameters/kr_seed 2>/dev/null || {
                        echo "seed: kr_seed param write FAILED"
                        return 1
                }
                echo "$seed"
                return 0
        fi
        echo "seed: kr_seed param not writable (module not live or old image)"
        return 1
}

load_susfs_lkm() {
        local BB kmi lkm_file module_name insmod_bin loaded ARCH cand try_list KSUD_BIN

        module_name="susfs_guard_lkm"

        if check_susfs_support; then
                echo "[+] Built-in SuSFS support detected, skipping LKM load"
                return 0
        fi

        BB="$(command -v busybox)" || {
                echo "[!] No BusyBox found!"
                return 1
        }

        ARCH="$(get_device_abi 2>/dev/null)" || ARCH=""

        # The x64 LKM exposes /proc/susfs_path when it is live, which also
        # covers the case where its own flashable loader module beat us to it.
        if [ "$ARCH" = "x86_64" ] && [ -e /proc/susfs_path ]; then
                echo "[+] SuSFS already active, skipping LKM load"
                return 0
        fi

        kmi="$(get_susfs_guard_lkm)" || {
                echo "[!] Cannot determine KMI."
                return 1
        }

        # v26.11.23 SAFEGUARD, v26.11.24 corrected rationale: the bundled LKM
        # was built against a generic x86_64 5.15.178 config, NOT against this
        # kernel's exact build (no source or config is published for it), and
        # it hooks live kernel paths at runtime - a bad match can wedge the
        # kernel a few seconds after boot and no userspace watchdog recovers
        # that. (The earlier "this LKM froze v26.11.22" theory was wrong: the
        # device logs show this exact .ko was always rejected with ENOEXEC and
        # never loaded - v26.11.22 and v26.11.23 shipped it byte-identical, and
        # both loaders failed on it. That freeze was userspace; see the
        # CHANGELOG and the adb_enabled note in apply-settings.sh.)
        # Loading on a custom kernel therefore stays strictly opt-in:
        #   touch /data/adb/ReSuSFS/enable_lkm
        # GKI/KMI kernels keep the automatic load: those images are the
        # upstream prebuilts verified for that exact KMI.
        case "$kmi" in
                susfs_guard_lkm-x86_64-*.ko|ymuuu_*.ko)
                        if [ ! -f "$PERSISTENT_DIR/enable_lkm" ]; then
                                log_boot "SAFEGUARD: custom-kernel LKM '$kmi' NOT loaded (opt-in only) - kernel '$(uname -r 2>/dev/null)' is not a KMI build the LKM was verified for; create /data/adb/ReSuSFS/enable_lkm to load the IMAGE at your own risk (v26.11.38: the image load is the PROVEN-SAFE zombie state; the init experiment needs enable_force_init too)"
                                echo "[!] SAFEGUARD: the custom-kernel LKM is opt-in only and stays unloaded."
                                echo "[!] Kernel: $(uname -r 2>/dev/null) | LKM: $kmi"
                                echo "[!] v26.11.38 two-step opt-in:"
                                echo "[!]   touch /data/adb/ReSuSFS/enable_lkm          # load the module image (zombie, proven safe)"
                                echo "[!]   touch /data/adb/ReSuSFS/enable_force_init     # ALSO run susfs_init AFTER boot completes"
                                echo "[!] Roll back after a bad load: rm -f /data/adb/ReSuSFS/enable_lkm /data/adb/ReSuSFS/enable_force_init"
                                return 1
                        fi
                        log_boot "SAFEGUARD: /data/adb/ReSuSFS/enable_lkm present - loading custom-kernel LKM '$kmi' (user opt-in; v26.11.38: image load only - init runs post-boot only with enable_force_init)"
                        echo "[*] enable_lkm flag present: loading custom-kernel LKM image (user opt-in)"
                        ;;
        esac

        # v26.11.38: LKM CANDIDATE selection for custom x86_64 kernels.
        #   v26.11.43: DEFAULT is now VANILLA - the only candidate that loads
        #   CLEAN in the field (all relocations applied, zero kernel
        #   warnings; the v26.11.26-37 profile whose module code verifiably
        #   EXECUTED). The v42 android13 image fails init_module with ENOEXEC
        #   on the box every attempt ("no symbol version for module_layout" +
        #   an x86 "Skipping invalid relocation target" warning each boot
        #   before the fallthrough) - select it explicitly to re-test it.
        #   /data/adb/ReSuSFS/lkm_candidate: vanilla (DEFAULT) | android13 | ymuuu13
        #   vanilla   -> susfs_guard_lkm-x86_64-vanilla-5.15.ko     (kernel.org
        #                5.15.178 GCC build - empirically config-matched,
        #                loads with byte-identical vermagic)
        #   android13 -> susfs_guard_lkm-x86_64-android13-5.15.ko  (AOSP
        #                android13-5.15 ASB-2025-03 build - struct module
        #                0x340 build; currently ENOEXEC on this box)
        #   ymuuu13   -> ymuuu_android13-5.15_susfs_guard_lkm.ko    (ymuuuu's
        #                prebuilt GKI android13-5.15 x64 ko - Phase 1 cheap shot)
        # Fallback chain: chosen -> vanilla -> android13 -> legacy ${kmi}.
        case "$kmi" in
                susfs_guard_lkm-x86_64-*.ko)
                        CAND="$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)"
                        CAND_FILE=""
                        case "$CAND" in
                                vanilla|"")  CAND_FILE="susfs_guard_lkm-x86_64-vanilla-5.15.ko" ;;
                                android13)    CAND_FILE="susfs_guard_lkm-x86_64-android13-5.15.ko" ;;
                                ymuuu13)      CAND_FILE="ymuuu_android13-5.15_susfs_guard_lkm.ko" ;;
                                *)            log_boot "LKM: unknown lkm_candidate '$CAND' - using default vanilla"
                                                CAND_FILE="susfs_guard_lkm-x86_64-vanilla-5.15.ko" ;;
                        esac
                        if [ -f "$SUSFS_LKM/$CAND_FILE" ]; then
                                log_boot "LKM candidate: ${CAND:-vanilla} -> $CAND_FILE"
                                kmi="$CAND_FILE"
                        elif [ -f "$SUSFS_LKM/susfs_guard_lkm-x86_64-vanilla-5.15.ko" ]; then
                                log_boot "LKM candidate '$CAND_FILE' missing - falling back to vanilla build"
                                kmi="susfs_guard_lkm-x86_64-vanilla-5.15.ko"
                        elif [ -f "$SUSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" ]; then
                                log_boot "LKM candidate '$CAND_FILE' missing - falling back to android13 build"
                                kmi="susfs_guard_lkm-x86_64-android13-5.15.ko"
                        else
                                log_boot "LKM candidates missing - using legacy $kmi"
                        fi
                        ;;
        esac

        lkm_file="$SUSFS_LKM/${kmi}"
        insmod_bin="$SUSFS_LKM/susfs_insmod"

        # v26.11.39 self-heal: if the selected .ko is absent from $SUSFS_LKM
        # but bundled candidates exist in the module dir, (re)install them
        # right here and re-select - covers a persistent dir that stayed
        # empty since a v38 install (the install gate above never fired)
        # WITHOUT a reflash, and any later manual wipe of
        # /data/adb/ReSuSFS_LKM.
        # v26.11.40: the self-heal also fires on a PAYLOAD STAMP MISMATCH
        # (install_susfs_guard_lkm_x86_64 refreshes the module-issued .kos),
        # so a v40 module whose customize-time install was skipped for any
        # reason still swaps the v39 image out on the next boot.
        stamp_refresh=0
        pstamp="$(head -n 1 "${MODPATH:-$MODDIR}/lkm/x86_64/.payload_stamp" 2>/dev/null)"
        istamp="$(head -n 1 "$SUSFS_LKM/.payload_stamp" 2>/dev/null)"
        [ -n "$pstamp" ] && [ "$pstamp" != "$istamp" ] && stamp_refresh=1
        if [ "$ARCH" = "x86_64" ] && { [ ! -f "$lkm_file" ] || [ "$stamp_refresh" = "1" ]; }; then
                module_root="${MODPATH:-$MODDIR}"
                if [ -f "$module_root/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-android13-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/susfs_guard_lkm-x86_64-vanilla-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/ymuuu_android13-5.15_susfs_guard_lkm.ko" ] || \
                   [ -f "$module_root/lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko" ]; then
                        log_boot "LKM: '$kmi' not in $SUSFS_LKM but bundled candidates exist in the module dir - self-healing (re)install"
                        install_susfs_guard_lkm_x86_64 >/dev/null 2>&1
                        case "$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)" in
                                vanilla)
                                        [ -f "$SUSFS_LKM/susfs_guard_lkm-x86_64-vanilla-5.15.ko" ] && kmi="susfs_guard_lkm-x86_64-vanilla-5.15.ko"
                                        ;;
                                ymuuu13)
                                        [ -f "$SUSFS_LKM/ymuuu_android13-5.15_susfs_guard_lkm.ko" ] && kmi="ymuuu_android13-5.15_susfs_guard_lkm.ko"
                                        ;;
                                *)
                                        [ -f "$SUSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" ] && kmi="susfs_guard_lkm-x86_64-android13-5.15.ko"
                                        ;;
                        esac
                        lkm_file="$SUSFS_LKM/${kmi}"
                        log_boot "LKM: self-heal resolved kmi -> ${kmi}"
                fi
        fi

        # arm64 needs the susfs_insmod loader next to the .ko; x86_64 loads
        # through ksud first, so only the .ko itself is required there.
        if [ ! -f "$lkm_file" ] || { [ "$ARCH" != "x86_64" ] && [ ! -x "$insmod_bin" ]; }; then
                echo "[*] LKM or susfs_insmod missing, downloading..."
                download_susfs_guard_lkm || {
                        echo "[!] Failed to download LKM"
                        return 1
                }
        fi

        if [ ! -f "$lkm_file" ]; then
                echo "[!] LKM not found: $lkm_file"
                return 1
        fi

        # v26.11.23: every exec here is timeout-bounded, so a wedged insmod
        # cannot block the post-fs-data boot chain
        rs_run 10 $BB rmmod "$module_name" 2>/dev/null

        echo "[*] Loading ${kmi}..."
        loaded=0

        # v26.11.34 loader order — REVERSED from v26.11.24's, based on hard evidence:
        # the v26.11.26-32 boot logs proved that OUR custom susfs_insmod loader
        # calling init_module(2) DIRECTLY produces a ZOMBIE LOAD on kernels with
        # KernelSU-Next built in (LDPlayer 14): the kernel accepts the module
        # IMAGE (/sys/module/susfs_guard_lkm exists, Live in /proc/modules, module
        # params registered) but do_init_module() never effectively runs our init
        # - diag_log stays empty, sc_entry_count stays 0, no layer arms. The
        # same upstream project (inforcqb/susfs4ksu-for-lkm, and its x86_64 port
        # ymuuuu/susfs4ksu-lkm-x64, live-tested on emulator GKI kernels) states
        # plainly: "plain insmod cannot work ... Use `ksud insmod <path-to-.ko>`"
        # - the module must be loaded THROUGH KernelSU's own daemon (ksud).
        # v26.11.35 FINDING: ksud insmod ALSO produces a zombie load on LDPlayer
        # 14 - the image loads but susfs_init() is NEVER called (verified in
        # boot.log: no XYZDIAG1 printk, init_done stays 0). So ksud is necessary
        # (it gets the image in cleanly) but NOT sufficient. post-fs-data.sh
        # now ALSO triggers force_init (safe deferred-init via schedule_work)
        # to actually run susfs_init_body in a kworker. ksud FIRST for every
        # kernel, our absolutizing susfs_insmod only as fallback, and the
        # force_init trigger as the universal init-runner.
        custom_lkm=0
        case "$kmi" in
                susfs_guard_lkm-x86_64-*.ko) custom_lkm=1 ;;
        esac

        # v26.11.39: x86_64 candidate fallback chain. v38 tried ONE .ko and
        # gave up when the kernel refused it (ENOEXEC from a vermagic/import
        # mismatch is a real possibility across the three candidate builds).
        # Now a failed candidate falls through to the next one in the SAME
        # boot: android13 (default) -> vanilla (the v26.11.26-37 image,
        # proven image-load on this kernel family) -> ymuuu13 -> legacy
        # ${kmi}. Every attempt is bounded (20s); the whole stage stays well
        # inside the post-fs-data lkm-load gate (150s). arm64 keeps the
        # original single-file flow.
        if [ "$ARCH" = "x86_64" ] && [ "$custom_lkm" = "1" ]; then
                try_list="susfs_guard_lkm-x86_64-android13-5.15.ko susfs_guard_lkm-x86_64-vanilla-5.15.ko ymuuu_android13-5.15_susfs_guard_lkm.ko"
                # append the legacy/resolved ${kmi} only if it is not already
                # one of the candidates (self-heal may have re-selected
                # android13 into kmi - appending it again would retry it)
                case "$kmi" in
                        susfs_guard_lkm-x86_64-android13-5.15.ko|susfs_guard_lkm-x86_64-vanilla-5.15.ko|ymuuu_android13-5.15_susfs_guard_lkm.ko) : ;;
                        *) try_list="$try_list ${kmi}" ;;
                esac
                case "$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)" in
                        android13|"") : ;;
                        vanilla)      try_list="susfs_guard_lkm-x86_64-vanilla-5.15.ko" ;;
                        ymuuu13)      try_list="ymuuu_android13-5.15_susfs_guard_lkm.ko" ;;
                        *)            log_boot "LKM: unknown lkm_candidate '$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)' - using default chain" ;;
                esac

                KSUD_BIN=""
                if command -v ksud >/dev/null 2>&1; then
                        KSUD_BIN="$(command -v ksud)"
                elif [ -x /data/adb/ksu/bin/ksud ]; then
                        KSUD_BIN="/data/adb/ksu/bin/ksud"
                elif [ -x /data/adb/ksud ]; then
                        KSUD_BIN="/data/adb/ksud"
                fi

                for cand in $try_list; do
                        [ -f "$SUSFS_LKM/$cand" ] || continue
                        [ "$cand" = "$kmi" ] || echo "[*] Falling through to candidate: $cand"
                        if [ -n "$KSUD_BIN" ]; then
                                echo "[*] Loading $cand (ksud: $KSUD_BIN)..."
                                if rs_run 20 "$KSUD_BIN" insmod "$SUSFS_LKM/$cand"; then
                                        echo "[+] LKM loaded successfully (ksud: $cand)"
                                        kmi="$cand"
                                        loaded=1
                                        break
                                else
                                        echo "[-] ksud insmod failed for $cand - trying next candidate"
                                        log_boot "LKM: ksud insmod FAILED for '$cand' - trying next candidate"
                                fi
                        fi
                done

                # last resort: our absolutizing loader on the first existing
                # candidate. WARNING (v26.11.31-33 evidence): on kernels with
                # KernelSU-Next built in this can produce a ZOMBIE LOAD (image
                # loaded, init neutered) - which for the v38+ design is still
                # the acceptable step-1 state (init runs post-boot via sysfs).
                if [ "$loaded" -eq 0 ] && [ -x "$insmod_bin" ]; then
                        for cand in $try_list; do
                                [ -f "$SUSFS_LKM/$cand" ] || continue
                                echo "[*] Trying susfs_insmod fallback on $cand (may zombie-load on KernelSU-Next kernels)..."
                                if rs_run 20 "$insmod_bin" -v "$SUSFS_LKM/$cand"; then
                                        echo "[+] LKM loaded successfully (susfs_insmod: $cand)"
                                        kmi="$cand"
                                        loaded=1
                                fi
                                break
                        done
                fi
        else
                if command -v ksud >/dev/null 2>&1; then
                        echo "[*] Trying ksud insmod (trusted KernelSU loader, primary path)..."
                        if rs_run 60 ksud insmod "$lkm_file"; then
                                echo "[+] LKM loaded successfully (ksud)"
                                loaded=1
                        else
                                echo "[-] ksud insmod failed"
                        fi
                fi

                if [ "$loaded" -eq 0 ] && [ -x /data/adb/ksu/bin/ksud ]; then
                        echo "[*] Trying /data/adb/ksu/bin/ksud insmod..."
                        if rs_run 60 /data/adb/ksu/bin/ksud insmod "$lkm_file"; then
                                echo "[+] LKM loaded successfully (/data/adb/ksu/bin/ksud)"
                                loaded=1
                        else
                                echo "[-] /data/adb/ksu/bin/ksud insmod failed"
                        fi
                fi

                if [ "$loaded" -eq 0 ] && [ -x /data/adb/ksud ]; then
                        echo "[*] Trying /data/adb/ksud insmod..."
                        if rs_run 60 /data/adb/ksud insmod "$lkm_file"; then
                                echo "[+] LKM loaded successfully (/data/adb/ksud)"
                                loaded=1
                        else
                                echo "[-] /data/adb/ksud insmod failed"
                        fi
                fi

                # Fallback: our absolutizing loader. WARNING (v26.11.31-33 evidence):
                # on kernels with KernelSU-Next built in this can produce a ZOMBIE LOAD
                # (image loaded, init neutered). Kept only for kernels WITHOUT KernelSU
                # (a hypothetical future device), and to surface kernel complaints.
                if [ "$loaded" -eq 0 ] && [ -x "$insmod_bin" ]; then
                        echo "[*] Trying susfs_insmod fallback (may zombie-load on KernelSU-Next kernels)..."
                        if rs_run 90 "$insmod_bin" -v "$lkm_file"; then
                                echo "[+] LKM loaded successfully (susfs_insmod fallback)"
                                loaded=1
                        else
                                echo "[-] susfs_insmod failed"
                        fi
                fi
        fi

        if [ "$loaded" -eq 0 ]; then
                echo "[!] Failed to load LKM"
                capture_insmod_evidence
                return 1
        fi

        return 0
}

# ---- v26.11.23 safe-diagnostic layer ---------------------------------
#
# Persistent boot logging + hang watchdog. Everything below is additive:
# nothing upstream is changed by it.
#
# Rationale: on the first LDPlayer 14 install (v26.11.22) the system fully
# booted and then froze ~10s after the home screen appeared - exactly when
# boot-completed.sh runs stage-late plus the 8 user scripts, and when the
# media scanner starts walking paths the kernel just had flagged as sus.
# A frozen UI gives no logs, so this build records every stage to
# /data/adb/ReSuSFS/logs/boot.log (synced after every line, so it survives
# a hard instance restart) and gates every stage with a receipt: if a stage
# never finishes, the NEXT boot automatically skips it, which both breaks
# any boot-hang loop and names the culprit in the log.

PERSISTENT_DIR="/data/adb/ReSuSFS"
LOG_DIR="$PERSISTENT_DIR/logs"
BOOT_LOG="$LOG_DIR/boot.log"
DIAG_LOG="$LOG_DIR/diagnose.log"
RECEIPT_DIR="$LOG_DIR/receipts"

rs_ts() { date '+%Y-%m-%d %H:%M:%S' 2>/dev/null; }
rs_boot_id() { cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d '-'; }

# log to the persistent boot log AND /dev/kmsg (dmesg), then sync so the
# line survives a hard power cut of the emulator instance
log_boot() {
        mkdir -p "$LOG_DIR" 2>/dev/null
        echo "[$(rs_ts)] $*" >> "$BOOT_LOG" 2>/dev/null
        sync 2>/dev/null
        # /dev/kmsg may be absent or unwritable (emulators, restricted
        # containers): the dmesg mirror is best-effort and must never turn
        # the function's return code nonzero (it is the last command in the
        # boot scripts, so its rc becomes the script's rc).
        ( echo "ReSuSFS: $*" > /dev/kmsg ) 2>/dev/null || :
}

# same, but for the step-by-step diagnostic log
log_diag() {
        mkdir -p "$LOG_DIR" 2>/dev/null
        echo "[$(rs_ts)] $*" >> "$DIAG_LOG" 2>/dev/null
        sync 2>/dev/null
        ( echo "ReSuSFS-diag: $*" > /dev/kmsg ) 2>/dev/null || :
}

# resolve a timeout runner once: toybox timeout, busybox timeout, or none
RS_TIMEOUT=""
command -v timeout >/dev/null 2>&1 && RS_TIMEOUT="timeout"
[ -z "$RS_TIMEOUT" ] && command -v busybox >/dev/null 2>&1 && RS_TIMEOUT="busybox timeout"

# run a command with a timeout when one is available
rs_run() {
        secs="$1"; shift
        if [ -n "$RS_TIMEOUT" ]; then
                $RS_TIMEOUT "$secs" "$@"
        else
                "$@"
        fi
}

# Hang watchdog: run an external command under a receipt.
#   - a receipt file records "started at <ts> boot=<boot_id>" before the run
#     and is removed after it finishes
#   - if a previous boot left an open receipt, that command is skipped on
#     this boot (hang recovery); after it has hung twice it is quarantined
#     until $RECEIPT_DIR/<tag>.skips is removed manually
# Only pass simple commands (scripts / binaries): timeout cannot run shell
# functions, so function bodies call rs_run around their own exec calls.
run_gated() {
        tag="$1"; tmo="$2"; shift 2
        cur_skips=0

        mkdir -p "$RECEIPT_DIR" 2>/dev/null
        if [ -f "$RECEIPT_DIR/$tag.skips" ]; then
                cur_skips=$(cat "$RECEIPT_DIR/$tag.skips" 2>/dev/null)
                case "$cur_skips" in ''|*[!0-9]*) cur_skips=0 ;; esac
        fi

        if [ "$cur_skips" -ge 2 ]; then
                log_boot "WATCHDOG: '$tag' is quarantined (hung on two earlier boots); remove $RECEIPT_DIR/$tag.skips to re-enable"
                return 0
        fi

        cur="$(rs_boot_id)"
        if [ -f "$RECEIPT_DIR/$tag.open" ]; then
                prev="$(sed 's/.*boot=//' "$RECEIPT_DIR/$tag.open" 2>/dev/null)"
                if [ -n "$prev" ] && [ "$prev" != "$cur" ]; then
                        cur_skips=$(( cur_skips + 1 ))
                        echo "$cur_skips" > "$RECEIPT_DIR/$tag.skips" 2>/dev/null
                        log_boot "WATCHDOG: '$tag' never finished on a previous boot (receipt: $(cat "$RECEIPT_DIR/$tag.open" 2>/dev/null)); skipping it this boot (skip $cur_skips/2)"
                        rm -f "$RECEIPT_DIR/$tag.open" 2>/dev/null
                        return 0
                fi
                # same boot id -> the stage simply ran twice within one boot
                rm -f "$RECEIPT_DIR/$tag.open" 2>/dev/null
        fi

        echo "$(rs_ts) boot=$cur" > "$RECEIPT_DIR/$tag.open" 2>/dev/null
        sync 2>/dev/null
        rs_run "$tmo" "$@"
        rc=$?
        rm -f "$RECEIPT_DIR/$tag.open" "$RECEIPT_DIR/$tag.skips" 2>/dev/null
        sync 2>/dev/null
        return $rc
}

# EOF
