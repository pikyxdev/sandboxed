#!/bin/sh
PATH=/data/adb/ksu/bin:$PATH
MODDIR="/data/adb/modules/ReSuSFS"
PERSISTENT_DIR="/data/adb/ReSuSFS"

. "$MODDIR/utils.sh"

banner

echo "[*] ensuring susfs LKM + ksu_susfs CLI are installed..."
download_susfs_guard_lkm
update_susfs || exit 1

export NO_BANNER=1
sh $MODDIR/ReSuSFS.sh --status

echo
echo "[*] starting the safe step-by-step diagnostic (diagnose.sh)"
echo "[*] each feature is applied one at a time, logged to"
echo "[*] $DIAG_LOG and gated by the hang watchdog:"
echo "[*] if a step freezes the system, force-restart the instance -"
echo "[*] the next run skips that step automatically, and the last logged"
echo "[*] step names the feature that froze the kernel."
echo

sh $MODDIR/diagnose.sh

# EOF
