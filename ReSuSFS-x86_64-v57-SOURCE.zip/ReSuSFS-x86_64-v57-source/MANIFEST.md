# ReSuSFS x86_64 v57 (v54.3) source export

Everything needed to reproduce ReSuSFS-x86_64-v26.11.57.zip from scratch
(sources, build scripts, verified outputs, field evidence), plus the
full lineage back to v50.

## v54.3 = THE UID-READ FIX (first kernel-side change since v54.1)

The v26.11.55/.56 field runs: arm OK, box survived, features flashed 7,
uid-drop test failed 1s after the arm TWICE (v54.1 single-batch probe AND
v54.2 full-walk probe).  Root cause, header-verified against torvalds
v5.15 AND aosp android13-5.15 (docs/kernel-headers/): struct cred is
{ atomic_t usage@+0, kuid_t uid@+4, kgid_t gid@+8 }; the module read
the uid at cred+8 = the GID.  Every root:root field caller passed both
uid==0 gates by coincidence; the test (setresuid 101234, gid stays 0)
was never filtered.

Fix: uid@cred+4 (both gates), honest calibrate window (u32 usage, ids
+4..+0x2c), and the probe's GID CANARY (root drops gid to 54321;
show_version must still answer - a gid-keyed gate rejects exactly that
call) so the receipt proves which word the gate reads.  Change set
proven by reference-diff disassembly (build_v57_ko.sh): the ONLY code
deltas vs the field-run object are the two gate reads and the calibrate
window; imports still 15, zero ud2, wire ids unchanged.

Offline chain: 45+9 host checks (real 5.15 cred layout; three cases fail
against the old graft), 293 binary-verifier checks, 21 ladder checks,
walk regression (entry counts identical to v54.2, canary gates on a
module-less host).

## Layout

| dir | files | bytes |
| --- | --- | --- |
| lkm-source | 44 | 1250919 |
| userspace-src | 7 | 47926 |
| module-template | 47 | 2157073 |
| package-v57 | 46 | 2232305 |
| build-scripts | 102 | 1004999 |
| binaries | 6 | 3981392 |
| kernel-fragments | 7 | 145297 |
| upstream-refs | 28 | 5505582 |
| docs | 25 | 227090 |
| field-logs | 59 | 10822643 |
| flashable | 1 | 588867 |

Key checksums in SHA256SUMS.key.  The flashable zip is
flashable/ReSuSFS-x86_64-v26.11.57.zip.  Field evidence for this run:
field-logs/v56-field + v56-field-2 (the run that convicted the gid
read).  The sandbox note: the original ReSuFS-x86_64-port tree was lost
to an overlay failure and rebuilt under build-scripts/../port-v57; this
export is the authoritative copy.
