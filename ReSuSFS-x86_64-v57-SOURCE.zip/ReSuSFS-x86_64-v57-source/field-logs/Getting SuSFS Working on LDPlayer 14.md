# Getting SuSFS Working on LDPlayer 14 (x86_64, Custom Kernel)

LDPlayer 14 runs **5.15.178+**, kernel-level KernelSU built in (not GKI-stock), not Google's AVD image. Every public SuSFS LKM project (sidex15's module, inforcqb's LKM, ymuuuu's x64 port, ReSuSFS) assumes either a GKI-certified kernel whose exact source Google publishes, or a kernel someone has already source-patched. LDPlayer is neither — but the gap is traceable, not unknowable.

## The one fact that changes everything

`5.15.178` is not a generic version number — it's the exact pinned version of a real, named branch: **`android13-5.15-2025-03`** on `android.googlesource.com/kernel/common`, part of the Android‑13 GKI (`android13-5.15`) lineage. That branch was later marked deprecated once newer monthly branches superseded it (`2025-05` → 5.15.180, up through `2026-09` → 5.15.211), which lines up with LD freezing their base around early‑to‑mid 2025 and never rebasing — exactly what you'd expect from a vendor who's layered custom patches (KernelSU, their own drivers) on top and doesn't want to redo that work every month. The `+` suffix is the standard local-version marker meaning "this isn't the stock tag, something's been added."

That lineage is also *why* this is plausible at all. A developer's build log for an older LDPlayer release shows its kernel was compiled straight from `android.googlesource.com/kernel/goldfish`, using the `x86_64_ranchu_defconfig` — the same Android-emulator kernel family Google itself ships. For the 5.15 generation, that lineage continues as the `kernel/common` `android13-5.15` branch plus its x86_64 "virtual device" config, not the old standalone goldfish repo. LDPlayer isn't a bespoke, undocumented kernel — it's AOSP's emulator/common kernel tree with KernelSU and other changes grafted in, never re-certified as GKI, and never rebased since.

## Three things have to line up for an LKM, and GKI is what normally guarantees them

1. **Architecture** — x86_64 vs arm64. All the hook C-logic (sus_path, kstat spoofing, uname spoof, open_redirect) is architecture-neutral, but the actual inline-hooking/symbol-resolution layer (`patch_memory`, `lsm_hook`, `symbol_resolver`, borrowed from SukiSU‑Ultra) patches machine code and reads kernel memory layouts, which differ completely between ISAs. This is exactly the work ymuuuu did to make `susfs4ksu-lkm-x64`, and it's reusable — it doesn't care *which* x86_64 kernel it's loaded into, only that it's x86_64.
2. **KMI / struct layout** — same kernel version and config family, so the offsets the hooks assume (inside `task_struct`, `cred`, path-lookup internals, etc.) are actually right. Upstream ships `susfs_guard_lkm-android13-5.15.ko` as one of eight distinct per‑KMI builds — the C logic is shared, but each KMI gets its own compiled artifact. ymuuuu's x64 port runs a CI matrix job explicitly described as covering "the other KMIs the KernelSU-Next CI covers, android12-5.10 up to android17-6.18," producing a per‑KMI `x86_64-<kmi>-susfs_guard_lkm.ko` set — so an `android13-5.15` x86_64 build should already exist in their releases.
3. **Exact build identity (vermagic/MODVERSIONS)** — the literal thing `insmod` checks isn't "is this the right kernel version," it's a CRC over every exported symbol signature the module touches, baked in as a magic string plus per-symbol hashes. This is the layer GKI exists to freeze, and it's the layer a non-certified custom build like LD's isn't guaranteed to preserve, even with an identical version number. There's direct proof this bites people on LDPlayer specifically: someone built a module from the matching public goldfish source and matching toolchain, and still got `hello: disagrees about version of symbol module_layout` on-device — meaning their recompile wasn't byte-identical to LD's actual build, despite doing everything "by the book." Expect this exact error as the first wall.

The AVD case ymuuuu solved is easier on exactly axis 3: Android Studio's emulator runs Google's literal, published, byte-identical GKI kernel (confirmed by KernelSU‑Next‑AVD's own description — Android 12+ emulators run Google's actual Generic Kernel Image, loaded via `ksud boot-patch --ramdisk`). LDPlayer doesn't come with that guarantee; it has to be reconstructed.

## The KernelSU version wrinkle

LDPlayer's own guide has you install **tiann/KernelSU v3.3.1** — the original project, not KernelSU‑Next — and explicitly disable the emulator's separate "Root permission" toggle. The SuSFS LKM tooling is written primarily around KernelSU‑Next's `ksud insmod`/`ksud module install` flow. The good news: `ksud insmod`-style module loading does exist in mainline tiann/KernelSU too (their release history ships per-KMI `.ko` files and a `late-load` ksud command), so it'll probably work — but if the subcommand set differs on v3.3.1, inforcqb's releases already ship a manager-agnostic fallback binary (`susfs_insmod`) for exactly this situation, and a bare `insmod` as root always works regardless of what `ksud` supports.

## A concrete, phased plan

### Phase 0 — Recon (do this first, costs nothing)

```
adb shell
su
cat /proc/version                 # exact compiler + build string
cat /proc/sys/kernel/osrelease    # exact KMI string the auto-loader matches against
zcat /proc/config.gz > /sdcard/running.config   # LD's real .config, if CONFIG_IKCONFIG_PROC is on
cat /proc/sys/kernel/tainted
getenforce                        # enforcing vs permissive matters for module_load denials
ksud --help                       # see if `insmod`/`module install` exist in v3.3.1's ksud
```

`/proc/config.gz`, if it works, is the single biggest shortcut available — it hands you LD's actual build config instead of guessing menuconfig options.

### Phase 1 — Cheap shot first

Grab the `android13-5.15` x86_64 artifact from ymuuuu's `susfs4ksu-lkm-x64` releases (or the bundled module zip, which self-selects by `osrelease` — though LD's non-standard release string may not pattern-match, so be ready to push and `insmod`/`susfs_insmod` it manually). If it loads clean: done, go straight to configuring rules. If you get `disagrees about version of symbol module_layout` or a crash: expected, move to Phase 2.

### Phase 2 — The actual custom build

Clone the exact matching source instead of guessing:

```
git clone https://android.googlesource.com/kernel/common -b android13-5.15-2025-03 --depth 1 ldp-kernel
```

Check that branch's `build.config.common`/`build.config.x86_64` (or `tools/bazel` if it's on the Bazel/kleaf system) for the pinned Clang revision, and cross-check against the compiler string from `/proc/version` — match it as closely as you can. Build the kernel with `running.config` applied via `KCONFIG_ALLCONFIG` (or copy it to `.config` + `make olddefconfig`) so your tree reflects LD's actual feature set instead of an AOSP-default one. Then build the SuSFS guard LKM out-of-tree against *that* tree: take inforcqb's hook C sources plus ymuuuu's already-ported x86_64 `patch_memory`/`symbol_resolver` layer, point the Makefile's `KDIR` at your freshly built tree, and compile. This is the genuinely novel part — nobody's published this exact combination.

### Phase 3 — Fallback if Phase 2's vermagic still won't line up

Force-load (`insmod -f`), accepting real crash risk, since struct offsets could still differ even with matching config/compiler — or go further and skip the LKM model entirely: there's a maintained raw source patch for this exact KMI (`0001-Implement-SUSFS-v2.1.0-for-Android-13-Kernel-5.15.patch`, targeting the `android13-5.15` line), which you'd apply directly into the kernel source and compile SuSFS *into* the kernel image itself, the way LD did with KernelSU. That means replacing LDPlayer's actual kernel binary in its VM rather than inserting a module beside it — architecturally cleaner, but you'd be giving up whatever undocumented driver patches LD added for their virtual GPU/input/sensors unless you can identify and re-add them, so treat it as the last resort, not the first move.

Nothing here risks the host machine — worst case is a crashed/rebooted emulator instance, which is cheap to iterate on.

## References

- LDPlayer's official KernelSU guide: [https://www.ldplayer.net/support/how-to-use-kernelsu-in-ldplayer.html](https://www.ldplayer.net/support/how-to-use-kernelsu-in-ldplayer.html)
- x86_64 SuSFS guard LKM port (AVD-targeted, has a multi-KMI build matrix): [https://github.com/ymuuuu/susfs4ksu-lkm-x64](https://github.com/ymuuuu/susfs4ksu-lkm-x64)
- Upstream arm64 SuSFS LKM (hook source, per-KMI `.ko`s, `susfs_insmod` fallback loader): [https://github.com/inforcqb/susfs4ksu-for-lkm](https://github.com/inforcqb/susfs4ksu-for-lkm)
- KernelSU-Next-AVD (how Google's AVD gets rooted via GKI LKM — the pattern that doesn't directly transfer): [https://github.com/ymuuuu/KernelSU-Next-AVD](https://github.com/ymuuuu/KernelSU-Next-AVD)
- Real-world LDPlayer/NOX kernel module build log, including the `module_layout` version-mismatch failure: [https://gist.github.com/ericdennisforever/34f32cb2a1b4fc90353e1a08e3d439a0](https://gist.github.com/ericdennisforever/34f32cb2a1b4fc90353e1a08e3d439a0)
- ReSuSFS (userspace config/WebUI layer — assumes SuSFS already works at the kernel level, arm64 only): [https://github.com/ahmed-alnassif/ReSuSFS](https://github.com/ahmed-alnassif/ReSuSFS)
- sidex15's SuSFS module (same userspace-layer caveat): [https://github.com/sidex15/susfs4ksu-module](https://github.com/sidex15/susfs4ksu-module)
- Android Common Kernels / GKI branch model: [https://source.android.com/docs/core/architecture/kernel/android-common](https://source.android.com/docs/core/architecture/kernel/android-common)
- `android13-5.15-2025-03` branch history confirming the 5.15.178 version match: [https://source.android.com/docs/core/architecture/kernel/gki-android13-5_15-deprecated-builds](https://source.android.com/docs/core/architecture/kernel/gki-android13-5_15-deprecated-builds)