/* SPDX-License-Identifier: GPL-2.0 */
/*
 * susfs x86_64 port override - DO NOT UPSTREAM.
 *
 * The LDPlayer 14 kernel's clang-LTO+trim build removed
 * EXPORT_PER_CPU_SYMBOL(current_task), so the stock
 * DECLARE_PER_CPU + this_cpu_read_stable(current_task) pattern leaves an
 * unresolved external `current_task` relocation that init_module rejects.
 *
 * This override reads current_task through %gs with a displacement that is
 * resolved ONCE at module init (kernel/susfs_current.c, called from
 * susfs_init right after ksu_init_symbol_resolver): the global
 * susfs_current_task_gs_off holds the per-CPU section offset of
 * current_task.  On LDPlayer kallsyms reports current_task at address 0
 * (per-CPU start), so the displacement is 0; on a stock 5.15 kernel where
 * current_task is at offset 4096 (after fixed_percpu_data which is
 * __aligned(PAGE_SIZE)) the resolver sets it to 4096.  Either way the
 * compiler never emits a current_task relocation.
 *
 * The addressing mode 0(,%1,1) is the scaled-index form (base=0,
 * index=%1, scale=1) - equivalent to (%1) but explicit that %1 is the
 * displacement, not a pointer to dereference.  %gs base is the per-CPU
 * section base for the current CPU, set by the kernel's percpu_setup
 * during boot.
 */
#ifndef _ASM_X86_CURRENT_H
#define _ASM_X86_CURRENT_H

#include <linux/compiler.h>
#include <asm/percpu.h>

#ifndef __ASSEMBLY__
struct task_struct;

/* Defined in kernel/susfs_current.c; zero on LDPlayer (correct), or the
 * per-CPU offset of current_task on kernels that list it. */
extern unsigned long susfs_current_task_gs_off;

static __always_inline struct task_struct *get_current(void)
{
	struct task_struct *p;
	unsigned long off = susfs_current_task_gs_off;
	/* %gs:off reads current_task for THIS cpu.  The "memory" clobber
	 * blocks reordering across the read, matching the kernel's
	 * this_cpu_read_stable semantics. */
	asm volatile("movq %%gs:0(,%1,1), %0"
		     : "=r" (p)
		     : "r" (off)
		     : "memory");
	return p;
}

#define current get_current()

#endif /* __ASSEMBLY__ */

#endif /* _ASM_X86_CURRENT_H */
