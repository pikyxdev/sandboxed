/* sc_v53.c - v26.11.53 THE FIRST FEATURE RUNG (x86_64, freestanding).
 *
 * WHAT THIS FILE IS: the v52 accept path (itself the v51 all-clang graft,
 * field-proven twice end-to-end by the v51+v52 clean-room 10-boot runs:
 * transport live, SHOW channel answering) extended with the first FEATURE
 * commands.  Everything below the "v53 additions" banner is the v52 graft
 * code, byte-for-byte in spirit (receipts renamed v52->v53 so the field
 * diag_log self-identifies the rung); the additions are marked and are the
 * ONLY behavioral change.
 *
 * THE v53 RUNG (one rung at a time, per the campaign contract):
 *   0x55550  add_sus_path                wire: { char path[256]; s32 err@256 } 260B
 *   0x55553  add_sus_path_loop           same 260B shape
 *   0x55561  hide_sus_mnts_for_non_su_procs wire: { u8 on; u8 r; u16 r; s32 err@4 } 8B
 *   0x55f53  (private) v53 state readback   wire: { char dump[8192]; s32 err@8192 } 8196B
 * The first three are the stock ksu_susfs CLI's own dispatch sites (decoded
 * from the shipped binary, sha256 7a30fa74...; the CLI checks ONLY
 * payload.err - err==0 is a silent exit 0, anything else prints
 * "susfs: <cmd> failed (kernel err N)").  The fourth is private to this
 * port (chosen to collide with no CLI and no base constant) so sc_probe -
 * the raw-syscall view, independent of any CLI - can dump the stored state
 * as the field receipt.
 *
 * DESIGN RULES (all inherited from field-proven v50/v51/v52 constraints;
 * each one exists because a boot died without it):
 *   - the entry AND every handler it reaches are clang-17 code.  The v49
 *     GCC wrapper is never called (v50 stage-3 boot died at its first
 *     execution); NO base-module function is called from the accept path
 *     at all - the only extern calls are the kernel's own
 *     _copy_from_user/_copy_to_user (kernel text, already exercised under
 *     fire by the SHOW answers).  susfs_diag_logf stays init-only.
 *   - storage rides in .data ONLY.  The graft contributes ZERO .bss: the
 *     graft object is FIRST in the ld -r merge, so graft .bss would land
 *     at merged .bss+0 - inside the 0x40-byte android struct-module spill
 *     window that susfs_bss_stomp_pad exists to absorb (v44 field
 *     evidence).  The v52 field run proved .data+0/+8 (cred offset + uid
 *     gate flag) safe; v53 adds ~16.6KB of .data and no .bss.
 *   - no new undefined symbols: the v51 13-symbol set is unchanged (the
 *     build script asserts it).  Zeroing/copying is open-coded loops only
 *     (-fno-builtin keeps clang from sneaking memset/memcpy in).
 *   - stack discipline: the add handler's frame is one 260-byte local
 *     (the features answer already used 256-byte stack chunks); the
 *     readback builds into a static .data buffer and copies in 256-byte
 *     chunks, exactly like the features answer.
 *   - no locks are taken, nothing is allocated, nothing is printed from
 *     the accept path.  Slot allocation is one lock-prefixed xadd, capped.
 *
 * SEMANTICS (mirroring the CLI contract, honest about what is NOT done):
 *   add_sus_path / add_sus_path_loop: copy the 260-byte payload, validate
 *   the path (NUL-terminated, leading '/', 1..255 bytes; overlong ->
 *   err=-36/-ENAMETOOLONG, bad shape -> err=-22/-EINVAL), dedupe against
 *   stored entries (exact match -> err=0, no store, dups counter++), store
 *   into the next free slot (32 slots; full -> err=-28/-ENOSPC), write
 *   err=0 at +256, return 0.  The entry is STORED, not yet ENFORCED: the
 *   layers that would consume sus_path rules are stage-4+ machinery that
 *   stays retired (the v49 ceiling); wiring storage into enforcement is a
 *   later rung.  The two flavors share one table; a path added by either
 *   flavor is a duplicate of the other.
 *   hide_sus_mnts_for_non_su_procs: record the on/off byte, err=0 at +4.
 *   The sus_mount layer IS armed at stage 3, but the base's enforcement
 *   state is not written this rung (no verified symbol contract for it in
 *   the tree - sus_mount_view.c is not in the export); the recorded value
 *   is receipt-grade until that bridge is designed.
 *   readback 0x55f53: a plain-text dump (slots used, per-slot path +
 *   flavor, counters, toggle state) - the sc_probe receipt.
 */

/* ---- SC_V51_HOSTTEST: the sandbox unit-test surface ---------------------
 * The ONLY kernel-only primitive is the %gs current read; the host test
 * provides same-named definitions for every extern below.  Everything
 * else (calibration scan, sanity check, answer builders, storage, dump)
 * runs unmodified on the host.  (Build with -DSC_V51_HOSTTEST.) */
#ifdef SC_V51_HOSTTEST
#include <stdio.h>
#include <string.h>
#include <stdint.h>
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
typedef int32_t  s32;
#define NULL ((void *)0)
/* host shims, defined in the test driver */
extern void susfs_diag_logf(const char *fmt, ...);
extern int  susfs_current_arm_stage(void);
extern u64  ksu_kallsyms_lookup_name(const char *name);
extern u64  susfs_fp_syscall_table(void);
extern int  ksu_patch_text(void *dst, void *src, u64 len, int flags);
extern u64  _copy_from_user(void *to, const void *from, u64 n);
extern u64  _copy_to_user(void *to, const void *from, u64 n);
extern volatile int susfs_sc_entry_count;
extern u8   sc_full_mode, sc_installed;
extern u64  sc_orig;
extern unsigned long susfs_current_task_gs_off;
extern unsigned long susfs_armed_features;
extern unsigned char *sc_v51_host_current;   /* the host stand-in for %gs:off */
#else
typedef unsigned long       u64;
typedef unsigned int        u32;
typedef unsigned char       u8;
typedef int                 s32;
#define NULL ((void *)0)
#endif

struct pt_regs;                     /* incomplete: the kCFI typeid is computed
                                     * from the prototype spelling
                                     * long (const struct pt_regs *) - it must
                                     * stay EXACTLY this (same as v50). */

/* ---- the v49 base symbols this graft binds to -------------------------- */
#ifndef SC_V51_HOSTTEST
extern void susfs_diag_logf(const char *fmt, ...);
extern int  susfs_current_arm_stage(void);
extern u64  ksu_kallsyms_lookup_name(const char *name);
extern u64  susfs_fp_syscall_table(void);
extern int  ksu_patch_text(void *dst, void *src, u64 len, int flags);
extern u64  _copy_from_user(void *to, const void *from, u64 n);
extern u64  _copy_to_user(void *to, const void *from, u64 n);
extern volatile int  susfs_sc_entry_count;   /* the sc_entry_count param    */
extern u8            sc_full_mode;           /* stage >= 3: accept + answer */
extern u8            sc_installed;           /* transport armed             */
extern u64           sc_orig;                /* saved __x64_sys_ioperm      */
extern unsigned long susfs_current_task_gs_off;  /* seeded per-CPU offset   */
extern unsigned long susfs_armed_features;       /* armed-layer feature bits */
#endif

/* ---- v51 constants (inherited) ------------------------------------------ */
#define SC_V51_NR            173          /* __NR_ioperm - matches the CLI  */
#define SC_V51_HANDLER       "__x64_sys_ioperm"
#define SC_V51_SCAN_ENTRIES  512          /* liveness window (v49 value)    */
#define SC_V51_WINDOW        16           /* cloned preamble window bytes   */
#define SC_V51_PATCH_FLAGS   3            /* icache|dcache bits (x86 no-ops)*/

/* The CLI wire ABI (ksu_susfs, v45+v48 builds): syscall(173, magic1, magic2,
 * cmd, &payload).  Only the low 32 bits of each register are defined. */
#define SC_V51_MAGIC1        0xDEADBEEFu
#define SC_V51_MAGIC2        0xFAFAFAFAu

/* The susfs SHOW command ids ON THE WIRE - the stock ksu_susfs binary this
 * box runs is the ABI authority (v52, field-verified at stage 3 on this
 * box: all three answered):
 *   0x555e1  show version           20-byte answer   (str[16] + err@16)
 *   0x555e2  show enabled_features  8196-byte answer (str[8192] + err@8192)
 *   0x555e3  show variant           20-byte answer   (str[16] + err@16) */
#define CMD_SUSFS_SHOW_VERSION          0x555e1u
#define CMD_SUSFS_SHOW_ENABLED_FEATURES 0x555e2u
#define CMD_SUSFS_SHOW_VARIANT          0x555e3u

/* ---- v53: the FEATURE command ids ON THE WIRE --------------------------- *
 * Same authority, same method: the stock CLI's own dispatch sites (each
 * tied to its payload shape and fail string, decoded from the shipped
 * binary).  These three plus the three SHOW ids above are the complete
 * supercall surface of the stock CLI; everything else it does rides
 * /proc/susfs_* writes. */
#define CMD_SUSFS_ADD_SUS_PATH              0x55550u  /* 260B, err@256 */
#define CMD_SUSFS_ADD_SUS_PATH_LOOP         0x55553u  /* 260B, err@256 */
#define CMD_SUSFS_HIDE_SUS_MNTS_FOR_NON_SU_PROCS 0x55561u /* 8B, err@4 */
/* Private readback (NOT a stock CLI id; chosen to collide with no constant
 * in the CLI (8 ids) or the base .ko (adds 0x5556f/70/71/72, 0x555a0,
 * 0x555c0)).  Payload shape = the enabled_features shape (8196B). */
#define CMD_SUSFS_V53_DEBUG_LIST            0x55f53u

/* x86_64 pt_regs field offsets (hardware-specified, config-independent;
 * the same offsets the v49 wrapper's disassembly uses: r10=0x38, dx=0x60,
 * si=0x68, di=0x70).  A mirror struct so the reads stay typed; the layout
 * is the user_regs_struct order and cannot move. */
struct sc_v51_regs {
        u64 r15, r14, r13, r12;     /* 0x00 .. 0x18 */
        u64 rbp, rbx, r11, r10;     /* 0x20 .. 0x38 */
        u64 r9,  r8,  ax,  cx;      /* 0x40 .. 0x58 */
        u64 dx,  si,  di,  orig_ax; /* 0x60 .. 0x78 */
        u64 ip,  cs,  flags, sp;    /* 0x80 .. 0x90 */
        u64 ss;                      /* 0x98 */
};

/* ---- the ABI answers (byte layouts are the userspace contract) --------- */
#define SC_V51_VER_SIZE      20     /* char susfs_version[16]; int err @16  */
#define SC_V51_VER_STR_MAX   16
#define SC_V51_FEATS_SIZE    8196   /* char enabled_features[8192]; err @8192 */
#define SC_V51_FEATS_STR_MAX 8192
#define SC_V51_CHUNK         256    /* copy granularity (stack buffer)      */

/* The strings the v49 base answers (extracted from its .rodata.str1.1 at
 * +0x11b4 / +0x11bb - the ABI the CLI prints and version_ge() checks
 * against SUSFS_MIN_VERSION="v2.2.0"). */
static const char sc_v51_version[] = "v2.3.0";
static const char sc_v51_variant[] = "GKI-LKM";

/* The base's feature table, byte-for-byte (enabled_features[] in
 * susfs_supercall.c; the enum order is SUSFS_FEAT_*).  Index 0 is always
 * present; every other entry is gated on its feature bit. */
struct sc_v51_feat {
        const char *name;
        int         bit;    /* -1 = always present */
};
static const struct sc_v51_feat sc_v51_feats[] = {
        { "SUSFS_LKM_MODULES\n",                         -1 },
        { "CONFIG_KSU_SUSFS_SUS_PATH\n",                  0 },
        { "CONFIG_KSU_SUSFS_SUS_MOUNT\n",                 1 },
        { "CONFIG_KSU_SUSFS_SUS_KSTAT\n",                 2 },
        { "CONFIG_KSU_SUSFS_SPOOF_UNAME\n",               3 },
        { "CONFIG_KSU_SUSFS_ENABLE_LOG\n",                4 },
        { "CONFIG_KSU_SUSFS_HIDE_KSU_SUSFS_SYMBOLS\n",    5 },
        { "CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG\n", 6 },
        { "CONFIG_KSU_SUSFS_OPEN_REDIRECT\n",             7 },
        { "CONFIG_KSU_SUSFS_SUS_MAP\n",                   8 },
};

/* ---- v51 calibrated uid gate -------------------------------------------- */
/* v26.11.51 CRITICAL LAYOUT NOTE: these two live in .data, NOT .bss.  The
 * graft object is FIRST in the ld -r merge, so any .bss content of ours
 * would land at merged .bss+0 - inside the 0x40-byte android struct-module
 * spill window the base's susfs_bss_stomp_pad exists to absorb (see the
 * base's stomp_pad.c: LDPlayer's 0x340-byte struct module spills 0x40
 * bytes past the module's 0x300-byte this_module into whatever follows,
 * which is .bss[0..0x40) - deterministic garbage on EVERY load, the v44
 * field evidence).  A calibration offset stomped to garbage is exactly
 * the wrong-pointer-dereference class this version exists to eliminate,
 * so the graft contributes ZERO .bss: the merged .bss stays byte-identical
 * to the field-proven v50 image (base pad first, base control vars past
 * +0x40), and these two variables ride in .data at +0/+8 instead - a
 * region no spill has ever touched on this box.  v53 adds its storage to
 * .data for the same reason (see the v53 banner below). */
__attribute__((section(".data"), used))
static u64 sc_v51_cred_off;   /* task_struct.cred offset, from init_task   */
__attribute__((section(".data"), used))
static u8  sc_v51_uid_ok;     /* calibration verified; 0 = refuse to answer */

/* The task_struct scan window.  Vanilla 5.15 has cred at 0x788; the scan
 * covers 0x1000 so a vendor layout a few hundred bytes larger still fits,
 * while staying far inside the mapped .data page init_task lives on. */
#define SC_V51_TASK_SCAN      0x1000
/* struct cred sanity window (usage at +0, uid..fsgid at +8..+0x28). */
#define SC_V51_CRED_CHECK_END 0x2cu

static u32 sc_v51_current_uid(void)
{
        u64 t, cred;
#ifdef SC_V51_HOSTTEST
        t = (u64)(unsigned long)sc_v51_host_current;
#else
        u64 off = susfs_current_task_gs_off;

        /* %gs:off is current_task for THIS cpu - the same per-CPU slot the
         * kernel itself reads; the offset is seeded and validated every
         * boot by susfs_current_init (field-proven value 0x1bc40 here). */
        __asm__ volatile("movq %%gs:0(,%1,1), %0"
                         : "=r" (t)
                         : "r" (off)
                         : "memory");
#endif
        if (t < 0x1000)
                return 0xffffffffu;         /* no plausible task: not root */
        cred = *(volatile u64 *)(t + sc_v51_cred_off);
        if (cred < 0x1000)
                return 0xffffffffu;         /* NULL/error-ish: not root    */
        /* uid sits right after the atomic_long_t usage counter (5.15
         * switched usage to atomic_long_t, so uid is at +8; verified at
         * install against init_cred's all-zero root fields). */
        return *(volatile u32 *)(cred + 8);
}

/* ======================================================================= */
/* THE ANSWER BUILDERS - all-clang, uaccess through the kernel's own       */
/* out-of-line _copy_from_user/_copy_to_user (SMAP handling and fault      */
/* recovery live in kernel text; this module carries no __ex_table).       */
/* ======================================================================= */

/* 20-byte version/variant answer: str[16] zero-padded + err=0 at +16. */
static long sc_v51_answer_str(u64 payload, const char *s)
{
        char v[SC_V51_VER_SIZE];
        u32 i;

        if (payload < 0x1000)
                return -22;
        if (_copy_from_user(v, (const void *)(unsigned long)payload, sizeof(v)))
                return -14;                 /* -EFAULT, pointer unusable */
        for (i = 0; i < SC_V51_VER_STR_MAX; i++)
                v[i] = 0;
        for (i = 0; i + 1 < SC_V51_VER_STR_MAX && s[i]; i++)
                v[i] = s[i];
        /* int err at offset 16: answer 0 (success) */
        v[SC_V51_VER_STR_MAX] = 0;
        v[SC_V51_VER_STR_MAX + 1] = 0;
        v[SC_V51_VER_STR_MAX + 2] = 0;
        v[SC_V51_VER_STR_MAX + 3] = 0;
        if (_copy_to_user((void *)(unsigned long)payload, v, sizeof(v)))
                return -14;
        return 0;
}

/* 8196-byte enabled_features answer, copied in 256-byte chunks so the
 * syscall-path stack frame stays tiny (the base's out-of-line handler
 * kzallocs 8196 bytes; a freestanding graft with no kmalloc machinery
 * chunks instead).  Names may straddle chunk boundaries - the builder
 * tracks (name index, byte position) across chunks. */
static long sc_v51_answer_features(u64 payload)
{
        char buf[SC_V51_CHUNK];
        u64 feats;
        u32 name_i = 0, name_off = 0;   /* current name cursor */
        u32 done = 0;                   /* string bytes emitted */
        int chunk;

        if (payload < 0x1000)
                return -22;
        /* pointer check first, same shape as the version answer */
        if (_copy_from_user(buf, (const void *)(unsigned long)payload, 16))
                return -14;

        feats = *(volatile u64 *)(unsigned long)&susfs_armed_features;

        for (chunk = 0; chunk < SC_V51_FEATS_STR_MAX / SC_V51_CHUNK; chunk++) {
                u32 fill = 0;

                /* zero the chunk */
                for (u32 z = 0; z < SC_V51_CHUNK; z++)
                        buf[z] = 0;

                /* drain names into the chunk */
                while (fill < SC_V51_CHUNK && name_i < (sizeof(sc_v51_feats) / sizeof(sc_v51_feats[0]))) {
                        const char *n = sc_v51_feats[name_i].name;
                        int bit = sc_v51_feats[name_i].bit;
                        u32 nlen = 0;

                        while (n[nlen])
                                nlen++;

                        if (bit >= 0 && !((feats >> bit) & 1)) {
                                /* feature not armed: skip the name whole */
                                name_i++;
                                name_off = 0;
                                continue;
                        }
                        while (name_off < nlen && fill < SC_V51_CHUNK)
                                buf[fill++] = n[name_off++];
                        if (name_off >= nlen) {
                                name_i++;
                                name_off = 0;
                        }
                        /* chunk full with a name half-done: keep cursor */
                }
                done += fill;
                if (done > SC_V51_FEATS_STR_MAX)
                        return -22;     /* cannot happen; belt */
                if (_copy_to_user((void *)(unsigned long)(payload + (u64)chunk * SC_V51_CHUNK),
                                  buf, SC_V51_CHUNK))
                        return -14;
        }
        /* err = 0 at offset 8192 */
        {
                char e[4];

                e[0] = e[1] = e[2] = e[3] = 0;
                if (_copy_to_user((void *)(unsigned long)(payload + SC_V51_FEATS_STR_MAX),
                                  e, sizeof(e)))
                        return -14;
        }
        return 0;
}

/* ======================================================================= */
/* ====  v53 ADDITIONS BEGIN - everything above is the v52 graft  ========= */
/* ======================================================================= */

/* ---- v53 storage: .data ONLY (see the v51 layout note above) ----------- *
 * 32 slots x 258 bytes: path[256] (NUL-terminated), used flag at +256,
 * loop flag at +257.  Counters are receipt-grade (lock-prefixed
 * increments - no lock is ever taken/held).  sc_v53_dump is the readback
 * staging buffer: filled open-coded, copied to user in 256-byte chunks
 * exactly like the features answer.  Total new .data: 8256 + 16 + 4 +
 * 8196 = ~16.5KB; new .bss: ZERO. */
#define SC_V53_PATH_MAX       256
#define SC_V53_PATH_SLOTS     32
#define SC_V53_USED_OFF       SC_V53_PATH_MAX        /* +256: used flag    */
#define SC_V53_LOOP_OFF       (SC_V53_PATH_MAX + 1)  /* +257: loop flavor  */
#define SC_V53_PATH_WIRE      (SC_V53_PATH_MAX + 4)  /* 260: wire payload  */

__attribute__((section(".data"), used))
static u8  sc_v53_paths[SC_V53_PATH_SLOTS][SC_V53_PATH_MAX + 2];
__attribute__((section(".data"), used))
static u32 sc_v53_next_slot;      /* monotonic slot allocator (xadd)       */
__attribute__((section(".data"), used))
static u32 sc_v53_add_calls;      /* every accepted add_sus_path* call     */
__attribute__((section(".data"), used))
static u32 sc_v53_dups_skipped;   /* exact-duplicate calls (err=0, no store) */
__attribute__((section(".data"), used))
static u32 sc_v53_toggle_calls;   /* hide_sus_mnts calls                   */
__attribute__((section(".data"), used))
static u8  sc_v53_hide_mnts_on;  /* last hide_sus_mnts value (0/1)       */
__attribute__((section(".data"), used))
static char sc_v53_dump[SC_V51_FEATS_SIZE];   /* 8196: readback staging    */

/* one locked u32 increment - the entry-counter shape (no lock held) */
static void sc_v53_bump(volatile u32 *p)
{
        __asm__ volatile("lock incl %0"
                         : "+m" (*p)
                         :
                         : "memory");
}

/* write one s32 answer at payload+off; rc 0 (the stock CLI reads ONLY
 * payload.err for feature commands - a nonzero rc would just leave its
 * 126 seed in place, which is the not-answered look we do NOT want) */
static long sc_v53_answer_err(u64 payload, u32 off, s32 err)
{
        char e[4];

        e[0] = (char)((unsigned)err & 0xff);
        e[1] = (char)(((unsigned)err >> 8) & 0xff);
        e[2] = (char)(((unsigned)err >> 16) & 0xff);
        e[3] = (char)(((unsigned)err >> 24) & 0xff);
        if (_copy_to_user((void *)(unsigned long)(payload + off), e, sizeof(e)))
                return -14;
        return 0;
}

/* ---- v53: add_sus_path / add_sus_path_loop ------------------------------ *
 * Wire: { char path[256]; s32 err@256 }.  Accept-and-store is the whole
 * rung: validation -> dedupe -> store -> err=0.  Enforcement (the stage-4
 * sus_path layer) stays retired; the readback is the receipt. */
static long sc_v53_add_sus_path(u64 payload, int is_loop)
{
        char p[SC_V53_PATH_WIRE];
        u32 len, i, slot;

        if (payload < 0x1000)
                return -22;
        if (_copy_from_user(p, (const void *)(unsigned long)payload, sizeof(p)))
                return -14;             /* -EFAULT: cannot even answer */

        sc_v53_bump(&sc_v53_add_calls);

        /* path shape: NUL-terminated within path[256], leading '/', 1..255 */
        len = 0;
        while (len < SC_V53_PATH_MAX && p[len])
                len++;
        if (len == SC_V53_PATH_MAX) {
                /* no NUL inside path[256]: the CLI caps at 255 + NUL, so
                 * this is a malformed/hostile payload */
                return sc_v53_answer_err(payload, SC_V53_PATH_MAX, -36);
        }
        if (len == 0 || p[0] != '/')
                return sc_v53_answer_err(payload, SC_V53_PATH_MAX, -22);

        /* dedupe: exact match against any stored entry (either flavor) */
        for (slot = 0; slot < SC_V53_PATH_SLOTS; slot++) {
                if (!sc_v53_paths[slot][SC_V53_USED_OFF])
                        continue;
                for (i = 0; i < len && sc_v53_paths[slot][i] == p[i]; i++)
                        ;
                if (i == len && sc_v53_paths[slot][len] == 0) {
                        sc_v53_bump(&sc_v53_dups_skipped);
                        return sc_v53_answer_err(payload, SC_V53_PATH_MAX, 0);
                }
        }

        /* store: allocate the slot index atomically (capped) */
        {
                u32 idx;

                __asm__ volatile("lock xaddl %0, %1"
                                 : "=r" (idx), "+m" (sc_v53_next_slot)
                                 : "0" (1u)
                                 : "memory");
                if (idx >= SC_V53_PATH_SLOTS)
                        return sc_v53_answer_err(payload, SC_V53_PATH_MAX, -28);
                for (i = 0; i < len; i++)
                        sc_v53_paths[idx][i] = p[i];
                sc_v53_paths[idx][len] = 0;
                sc_v53_paths[idx][SC_V53_LOOP_OFF] = (u8)(is_loop ? 1 : 0);
                __asm__ volatile("" ::: "memory");   /* used flag LAST */
                sc_v53_paths[idx][SC_V53_USED_OFF] = 1;
        }
        return sc_v53_answer_err(payload, SC_V53_PATH_MAX, 0);
}

/* ---- v53: hide_sus_mnts_for_non_su_procs -------------------------------- *
 * Wire: { u8 on; u8 rsv; u16 rsv2; s32 err@4 }.  The stock CLI converts
 * its '0'/'1' argument to the numeric byte before the call.  The value is
 * recorded for the receipt; the base's enforcement state is not written
 * this rung (no verified symbol contract for it in the exported tree). */
static long sc_v53_hide_mnts(u64 payload)
{
        char p[8];

        if (payload < 0x1000)
                return -22;
        if (_copy_from_user(p, (const void *)(unsigned long)payload, sizeof(p)))
                return -14;
        sc_v53_bump(&sc_v53_toggle_calls);
        sc_v53_hide_mnts_on = (p[0] != 0);
        return sc_v53_answer_err(payload, 4, 0);
}

/* ---- v53: the readback builder (private cmd 0x55f53) -------------------- *
 * Plain text into sc_v53_dump (zeroed first), then chunked copy_to_user in
 * the features-answer shape { char dump[8192]; s32 err@8192 }.  Bounds are
 * open-coded; the table is scanned (used flags), so counters and content
 * cannot disagree about what is stored. */
static u32 sc_v53_put_u32(char *dst, u32 off, u32 cap, u32 v)
{
        char tmp[10];
        u32 n = 0, i;

        if (v == 0)
                tmp[n++] = '0';
        while (v && n < 10) {
                tmp[n++] = (char)('0' + (v % 10));
                v /= 10;
        }
        if (off >= cap)
                return off;
        if (off + n > cap)
                return cap;              /* truncated: caller stops */
        for (i = 0; i < n; i++)
                dst[off + i] = tmp[n - 1 - i];
        return off + n;
}

static u32 sc_v53_puts(char *dst, u32 off, u32 cap, const char *s)
{
        u32 i = 0;

        while (s[i] && off < cap) {
                dst[off] = s[i];
                off++;
                i++;
        }
        return off;
}

static long sc_v53_answer_debug_list(u64 payload)
{
        u32 off = 0, used = 0, loops = 0, slot, i, more = 0;
        int chunk;

        if (payload < 0x1000)
                return -22;
        /* pointer check first, same shape as the other answers */
        {
                char probe[16];

                if (_copy_from_user(probe, (const void *)(unsigned long)payload, sizeof(probe)))
                        return -14;
        }

        /* zero the staging buffer (open-coded: no memset import) */
        for (i = 0; i < SC_V51_FEATS_SIZE; i++)
                sc_v53_dump[i] = 0;

        /* header line: counters first - they prove calls happened even
         * when everything deduped */
        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX,
                          "v53-feature-rung add_calls=");
        off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, sc_v53_add_calls);
        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, " dups=");
        off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, sc_v53_dups_skipped);
        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, " toggle_calls=");
        off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, sc_v53_toggle_calls);
        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, " hide_mnts=");
        off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, sc_v53_hide_mnts_on);

        /* slot lines: emit until the buffer nearly fills (300-byte margin
         * covers the longest possible line: 255-byte path + decor) */
        for (slot = 0; slot < SC_V53_PATH_SLOTS; slot++) {
                if (!sc_v53_paths[slot][SC_V53_USED_OFF])
                        continue;
                used++;
                if (sc_v53_paths[slot][SC_V53_LOOP_OFF])
                        loops++;
                if (off > SC_V51_FEATS_STR_MAX - 300) {
                        more++;
                        continue;
                }
                off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, "\n[");
                off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, slot);
                off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, "] ");
                for (i = 0; i < SC_V53_PATH_MAX && sc_v53_paths[slot][i]; i++) {
                        if (off >= SC_V51_FEATS_STR_MAX)
                                break;
                        sc_v53_dump[off++] = sc_v53_paths[slot][i];
                }
                if (sc_v53_paths[slot][SC_V53_LOOP_OFF])
                        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, " (loop)");
        }
        /* summary line (always fits: 300-byte margin held back) */
        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, "\nslots_used=");
        off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, used);
        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, "/");
        off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, SC_V53_PATH_SLOTS);
        off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, " loops=");
        off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, loops);
        if (more) {
                off = sc_v53_puts(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, " truncated=");
                off = sc_v53_put_u32(sc_v53_dump, off, SC_V51_FEATS_STR_MAX, more);
        }

        /* chunked copy, features-answer shape */
        for (chunk = 0; chunk < SC_V51_FEATS_SIZE / SC_V51_CHUNK; chunk++) {
                if (_copy_to_user((void *)(unsigned long)(payload + (u64)chunk * SC_V51_CHUNK),
                                  sc_v53_dump + (u32)chunk * SC_V51_CHUNK,
                                  SC_V51_CHUNK))
                        return -14;
        }
        return sc_v53_answer_err(payload, SC_V51_FEATS_STR_MAX, 0);
}

/* ====  v53 ADDITIONS END ================================================= */

/* ======================================================================= */
/* THE ENTRY - the function sys_call_table[173] will point at.             */
/* clang-17 compiles this with the genuine kCFI preamble block            */
/* ([entry-16..entry-1): nop pad + movl $typeid,%eax); the installer then  */
/* clones the ORIGINAL entry's window over it (v50 mechanics, field-proven */
/* at stage 2 on this box).                                                */
/*                                                                         */
/* OBSERVE (stage 2): counter++ and -EINVAL.  Nothing else.  The rung that */
/* SURVIVED live fire in the field (boot 440a678a).                        */
/* FULL    (stage 3): the all-clang accept path - magic check,             */
/*                    calibrated-uid gate, SHOW answers, and (v53) the     */
/*                    first FEATURE commands.  The v49 GCC wrapper is      */
/*                    NEVER called.                                        */
/* ======================================================================= */
__attribute__((used, noinline))
long susfs_sc_entry(const struct pt_regs *regs)
{
        const struct sc_v51_regs *r;
        u32 magic1, magic2, cmd;
        u64 payload;

        /* One locked increment: the userspace-visible counter the self-test
         * reads before/after (the sc_entry_count module parameter). */
        __asm__ volatile("lock incl %0"
                         : "+m" (susfs_sc_entry_count)
                         :
                         : "memory");

        if (!sc_full_mode)
                return -22;             /* -EINVAL: observe mode, by design */

        r = (const struct sc_v51_regs *)regs;
        magic1 = (u32)r->di;
        magic2 = (u32)r->si;
        cmd    = (u32)r->dx;
        payload = r->r10;

        /* Not a susfs supercall: answer exactly like the original ioperm(2)
         * answers magic-shaped arguments.  No forwarding to the saved
         * handler, no indirect calls, nothing unexercised. */
        if (magic1 != SC_V51_MAGIC1)
                return -22;
        if (magic2 != SC_V51_MAGIC2)
                return -22;

        /* uid gate, calibrated (see sc_v51_calibrate).  A failed calibration
         * answers nothing - the box stays alive and the receipts say why. */
        if (!sc_v51_uid_ok)
                return -22;
        if (sc_v51_current_uid() != 0)
                return -22;

        /* The v52 rung: the three SHOW commands (field-proven at stage 3,
         * two consecutive clean-room runs). */
        if (cmd == CMD_SUSFS_SHOW_VERSION)
                return sc_v51_answer_str(payload, sc_v51_version);
        if (cmd == CMD_SUSFS_SHOW_VARIANT)
                return sc_v51_answer_str(payload, sc_v51_variant);
        if (cmd == CMD_SUSFS_SHOW_ENABLED_FEATURES)
                return sc_v51_answer_features(payload);

        /* The v53 rung: the first FEATURE commands - accept, validate,
         * store, answer err=0.  One rung at a time: set_uname (0x55590)
         * and set_cmdline_or_bootconfig (0x555b0) stay not-handled until
         * this rung survives the field. */
        if (cmd == CMD_SUSFS_ADD_SUS_PATH)
                return sc_v53_add_sus_path(payload, 0);
        if (cmd == CMD_SUSFS_ADD_SUS_PATH_LOOP)
                return sc_v53_add_sus_path(payload, 1);
        if (cmd == CMD_SUSFS_HIDE_SUS_MNTS_FOR_NON_SU_PROCS)
                return sc_v53_hide_mnts(payload);
        if (cmd == CMD_SUSFS_V53_DEBUG_LIST)
                return sc_v53_answer_debug_list(payload);
        return -22;
}

/* ---- window helpers (open-coded: no memcpy/memcmp imports) ------------- */
static void sc_v51_read_window(u64 fn, volatile u32 *w)
{
        volatile u32 *p = (volatile u32 *)(fn - SC_V51_WINDOW);
        int i;

        for (i = 0; i < SC_V51_WINDOW / 4; i++)
                w[i] = p[i];
}

static int sc_v51_window_equal(volatile const u32 *a, volatile const u32 *b)
{
        int i;

        for (i = 0; i < SC_V51_WINDOW / 4; i++)
                if (a[i] != b[i])
                        return 0;
        return 1;
}

/* ---- v51: the cred-offset calibration ---------------------------------- */
static void sc_v51_calibrate(void)
{
        u64 it, ic;
        u32 i, hits = 0, hit_off = 0;

        sc_v51_uid_ok = 0;
        sc_v51_cred_off = 0;

        it = ksu_kallsyms_lookup_name("init_task");
        ic = ksu_kallsyms_lookup_name("init_cred");
        if (!it || !ic) {
                susfs_diag_logf("supercall: v53 calibrate: init_task=0x%lx init_cred=0x%lx - %s missing from kallsyms; uid gate stays uncalibrated (answering nothing, box safe)\n",
                                it, ic, it ? "init_cred" : "init_task");
                return;
        }

        /* Find the ONE adjacent (real_cred, cred) pair both equal to
         * &init_cred inside init_task.  The idle task's creds never change,
         * so the pair is stable for the whole boot; cred is the SECOND
         * slot (struct task_struct lists real_cred first). */
        for (i = 0; (i + 1) * 8 <= SC_V51_TASK_SCAN; i++) {
                u64 a = *(volatile u64 *)(it + (u64)i * 8);
                u64 b = *(volatile u64 *)(it + (u64)i * 8 + 8);

                if (a == ic && b == ic) {
                        hits++;
                        hit_off = i * 8 + 8;
                }
        }
        if (hits != 1 || !hit_off) {
                susfs_diag_logf("supercall: v53 calibrate: init_task pair scan found %u adjacent (real_cred,cred) pairs (want exactly 1) - refusing the hardcoded-0x788 read too; uid gate stays uncalibrated (answering nothing, box safe)\n",
                                hits);
                return;
        }
        sc_v51_cred_off = hit_off;

        /* Verify struct cred's uid offset against init_cred's own bytes:
         * usage (atomic_long, +0) must be a small positive refcount, and
         * the root credential's uid/gid/suid/sgid/euid/egid/fsuid/fsgid
         * words (+8..+0x28) must ALL be zero.  A wrong uid offset here
         * fails this check and the gate stays off. */
        {
                u64 usage = *(volatile u64 *)ic;
                u32 nonzero = 0;

                for (i = 8; i <= SC_V51_CRED_CHECK_END; i += 4)
                        if (*(volatile u32 *)(ic + i) != 0)
                                nonzero++;
                if (usage == 0 || usage > 0x10000 || nonzero) {
                        susfs_diag_logf("supercall: v53 calibrate: init_cred sanity failed (usage=%lu, nonzero uid-window words=%u) - uid gate stays uncalibrated (answering nothing, box safe)\n",
                                        usage, nonzero);
                        sc_v51_cred_off = 0;
                        return;
                }
        }

        sc_v51_uid_ok = 1;
        susfs_diag_logf("supercall: v53 calibrate: task_struct.cred at +0x%lx (the v49 wrapper's hardcoded header offset was 0x788%s); uid at cred+8 verified against init_cred - the uid gate is calibrated\n",
                        (u64)hit_off,
                        hit_off == 0x788 ? " - identical here, the wedge lived elsewhere in the GCC wrapper"
                                         : " - DIFFERENT, the hardcoded read was the wedge");
}

/* ======================================================================= */
/* THE INSTALLER - replaces v49/v50's susfs_supercall_init (weakened).     */
/* The transport mechanics are the field-proven v50 shape verbatim; the    */
/* only additions are the calibration call and the receipts.               */
/* ======================================================================= */
int susfs_supercall_init(void)
{
        u64 table, entry, handler, dispatcher, me;
        volatile u32 want[SC_V51_WINDOW / 4];   /* original's preamble window */
        volatile u32 have[SC_V51_WINDOW / 4];   /* our window after the clone */
        int stage, i, live = 0, disp_idx = -1, err;

        stage = susfs_current_arm_stage();
        sc_full_mode = (stage >= 3) ? 1 : 0;

        susfs_diag_logf("supercall: v53 clang accept-path init (CLI wire ABI: e1=version e2=enabled_features e3=variant; FEATURE RUNG: 55550=add_sus_path 55553=add_sus_path_loop 55561=hide_sus_mnts, readback 55f53) (stage %d, mode=%s; entry AND accept path compiled by clang-17; the v49 GCC wrapper is never called - the v50 field verdict convicted its first execution)\n",
                        stage, sc_full_mode ? "FULL" : "OBSERVE-ONLY");

        /* 0. v51: calibrate the uid gate BEFORE anything can answer. */
        sc_v51_calibrate();

        /* 0b. v53: the feature-rung storage receipt (init context only -
         * the accept path never logs). */
        susfs_diag_logf("supercall: v53 feature rung: add_sus_path/add_sus_path_loop accepted into a %d-slot .data table (accept + store this rung; enforcement wiring is the next rung), hide_sus_mnts toggle recorded, readback cmd 0x55f53 via sc_probe\n",
                        SC_V53_PATH_SLOTS);

        /* 1. the live table (fp layer cache first, resolver fallback -
         *    the exact v49/v50 order). */
        table = susfs_fp_syscall_table();
        if (!table)
                table = ksu_kallsyms_lookup_name("sys_call_table");
        if (!table) {
                susfs_diag_logf("supercall: v53: sys_call_table not resolved - transport unavailable (loaded, not installed)\n");
                return 0;
        }

        /* 2. liveness proof, v49 shape: KernelSU-Next patched its own
         *    dispatcher INTO this table; finding it proves the table is
         *    what the live dispatch executes through. */
        dispatcher = ksu_kallsyms_lookup_name("ksu_syscall_dispatcher");
        if (dispatcher) {
                for (i = 0; i < SC_V51_SCAN_ENTRIES; i++) {
                        if (((u64 *)table)[i] == dispatcher) {
                                live++;
                                if (disp_idx < 0)
                                        disp_idx = i;
                        }
                }
        }

        entry   = ((u64 *)table)[SC_V51_NR];
        handler = ksu_kallsyms_lookup_name(SC_V51_HANDLER);
        me      = (u64)(unsigned long)&susfs_sc_entry;

        susfs_diag_logf("supercall: v53: table=0x%lx table[%d]=0x%lx handler(%s)=0x%lx dispatcher=0x%lx in %d entr%s (idx %d)\n",
                        table, SC_V51_NR, entry, SC_V51_HANDLER, handler,
                        dispatcher, live, live == 1 ? "y" : "ies", disp_idx);

        /* 3. idempotent re-init (same boot, second trigger). */
        if (entry == me) {
                susfs_diag_logf("supercall: v53: table[%d] already points at our entry (re-init) - transport LIVE\n",
                                SC_V51_NR);
                sc_orig = handler;
                sc_installed = 1;
                return 0;
        }

        /* 4. sanity gates (v49/v50 conditions; refuse = loaded, not installed). */
        if (handler && entry != handler) {
                susfs_diag_logf("supercall: v53: table[%d]=0x%lx is not %s=0x%lx - refusing (loaded, not installed)\n",
                                SC_V51_NR, entry, SC_V51_HANDLER, handler);
                return 0;
        }
        if (!live) {
                susfs_diag_logf("supercall: v53: ksu_syscall_dispatcher not found in the table - refusing (loaded, not installed)\n");
                return 0;
        }

        /* 5. our own landing pad must be intact (clang emitted endbr64). */
        if (*(volatile u32 *)&susfs_sc_entry != 0xfa1e0ff3u) {
                susfs_diag_logf("supercall: v53: our entry lost its endbr64 landing pad (0x%08x) - refusing (loaded, not installed)\n",
                                *(volatile u32 *)&susfs_sc_entry);
                return 0;
        }

        /* 6. THE PREAMBLE CLONE (v50, field-proven at stage 2): copy the
         *    ORIGINAL entry's ENTIRE 16-byte preamble window into ours,
         *    byte for byte, before the table write. */
        sc_v51_read_window(entry, want);
        sc_v51_read_window(me, have);
        susfs_diag_logf("supercall: v53 orig window [-16..-1): %08x %08x %08x %08x\n",
                        want[0], want[1], want[2], want[3]);
        susfs_diag_logf("supercall: v53 own window (clang preamble) : %08x %08x %08x %08x\n",
                        have[0], have[1], have[2], have[3]);

        err = ksu_patch_text((void *)(me - SC_V51_WINDOW),
                             (void *)want, SC_V51_WINDOW,
                             SC_V51_PATCH_FLAGS);
        if (err) {
                susfs_diag_logf("supercall: v53: preamble clone write FAILED rc=%d - refusing (loaded, not installed)\n",
                                err);
                return 0;
        }
        sc_v51_read_window(me, have);
        if (!sc_v51_window_equal(want, have)) {
                susfs_diag_logf("supercall: v53: preamble clone did not stick (%08x %08x %08x %08x vs %08x %08x %08x %08x) - refusing (loaded, not installed)\n",
                                have[0], have[1], have[2], have[3],
                                want[0], want[1], want[2], want[3]);
                return 0;
        }
        susfs_diag_logf("supercall: v53: preamble window cloned + verified (16 bytes, byte-exact)\n");

        /* 7. THE TABLE WRITE: table[173] = our entry, then read back. */
        err = ksu_patch_text((void *)&((u64 *)table)[SC_V51_NR],
                             &me, sizeof(me), SC_V51_PATCH_FLAGS);
        if (err) {
                susfs_diag_logf("supercall: v53: table entry write FAILED rc=%d - refusing (loaded, not installed)\n",
                                err);
                return 0;
        }
        if (((u64 *)table)[SC_V51_NR] != me) {
                susfs_diag_logf("supercall: v53: table entry write did not stick (0x%lx vs 0x%lx) - refusing (loaded, not installed)\n",
                                ((u64 *)table)[SC_V51_NR], me);
                return 0;
        }

        sc_orig = handler;
        sc_installed = 1;
        susfs_diag_logf("supercall: v53 transport LIVE - table[%d] -> susfs_sc_entry (clang-17 entry + ALL-CLANG accept path; observe = counter + -EINVAL; full = magic + calibrated-uid gate + SHOW answers + the v53 FEATURE RUNG: add_sus_path/add_sus_path_loop stored (32 slots, dedup, ENOSPC-capped), hide_sus_mnts recorded, readback 0x55f53; set_uname/set_cmdline stay not-handled until the next rung; uid gate %s)\n",
                        SC_V51_NR,
                        sc_v51_uid_ok ? "CALIBRATED" : "UNCALIBRATED (answering nothing)");
        return 0;
}

/* Replaces v49/v50's susfs_supercall_exit (weakened in the base).  Only
 * reached from the layer teardown path; this kernel is built without
 * MODULE_UNLOAD so it is effectively a no-op - kept correct anyway. */
void susfs_supercall_exit(void)
{
        u64 table;

        if (!sc_installed)
                return;
        table = susfs_fp_syscall_table();
        if (!table)
                table = ksu_kallsyms_lookup_name("sys_call_table");
        if (table) {
                int err = ksu_patch_text((void *)&((u64 *)table)[SC_V51_NR],
                                         &sc_orig, sizeof(sc_orig),
                                         SC_V51_PATCH_FLAGS);
                susfs_diag_logf("supercall: v53 exit: table[%d] %s (0x%lx)\n",
                                SC_V51_NR,
                                err ? "restore FAILED" : "restored",
                                sc_orig);
        }
        sc_installed = 0;
}
