// SPDX-License-Identifier: GPL-2.0
/*
 * stomp_pad.c - v26.11.45 .bss guard for the android struct-module spill.
 *
 * The running kernel is an ANDROID-common one: its struct module is 0x340
 * bytes (scmversion + KABI reserves), while a kernel.org-tree build ships a
 * 0x300-byte .gnu.linkonce.this_module.  At insmod the kernel initializes
 * ITS struct inside that section and writes 0x40 bytes past it - into
 * whatever the module core layout places after this_module, which on this
 * image is the START OF .bss.  The v44 field evidence caught the spill in
 * the act: the evidence collector read sc_entry_count=10 on EVERY boot,
 * including fresh zombie modules whose kprobe was never registered (the
 * counter's only writer is the kprobe entry path), and readelf on the
 * shipped v44 vanilla image shows .bss[0..0x40) covering susfs_diag_printk,
 * susfs_probe_arm, susfs_probe_val, susfs_force_init_val, susfs_init_done,
 * init_laststep, init_maxstep, fail_layer and susfs_sc_entry_count - the
 * module's control plane, stomped with deterministic garbage at every load.
 *
 * This object exists to make .bss[0..0x40) sacrificial.  It is the FIRST
 * object in the Makefile's link order, holds the ONLY .bss content of its
 * translation unit, and the symbol is a GLOBAL (external linkage) so the
 * compiler can never garbage-collect it out of the image - GCC reorders
 * .bss within one translation unit (a static pad in susfs_main.c landed at
 * +0x1040 behind the ints and the 4KB diag buffer, which is why this is a
 * separate object at all).
 *
 * The android13 candidate (correct 0x340 struct) wastes 64 harmless bytes.
 * Verified post-build by scripts/build_v45_verify.py: the pad must sit at
 * .bss+0 with every named control variable past +0x40.
 */
#include <linux/types.h>

/* GLOBAL and unreferenced: still emitted, still first in .bss.  Aligned(64)
 * so the .bss section alignment matches this_module's and the pad starts
 * exactly at the spill point (this_module is 0x300 bytes on a 64 boundary). */
unsigned char susfs_bss_stomp_pad[64] __aligned(64);
