// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_current.c - runtime resolver for the x86_64 current_task per-CPU
 * offset used by the overridden <asm/current.h>.
 *
 * The LDPlayer 14 kernel's clang-LTO+trim build removed
 * EXPORT_PER_CPU_SYMBOL(current_task), so the module's <asm/current.h>
 * (see kbuild-x64/source/arch/x86/include/asm/current.h) was rewritten to
 * read current_task through a register-indirect %gs access whose
 * displacement is the runtime-resolved value of susfs_current_task_gs_off.
 *
 * This file owns that global and the __init that fills it in, called from
 * susfs_init() right after ksu_init_symbol_resolver() returns and before any
 * layer that uses `current` runs.
 *
 * The default value 0 is the correct displacement on the LDPlayer 14
 * kernel (kallsyms reports current_task at address 0 there, i.e. the
 * per-CPU variable sits at the very start of the per-CPU section). On any
 * kernel where current_task lives at a non-zero per-CPU offset (stock
 * x86_64 5.15 has it at 4096, after fixed_percpu_data which is
 * __aligned(PAGE_SIZE)), the resolver below corrects the global before any
 * layer runs.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>

#include "symbol_resolver.h"
#include "susfs_log.h"
#include "susfs.h"      /* susfs_diag_logf: the init path must not printk */

unsigned long susfs_current_task_gs_off;

/* v26.11.34: __init REMOVED - the v26.11.33 force_init sysfs write called this
 * after the kernel freed .init.text, executing freed pages: boot wedged at 50%.
 * This function is also reachable from susfs_init_body (called via the force_init
 * parameter path after load), so it must live in .text and survive init freeing. */
int susfs_current_init(void)
{
        unsigned long addr;

        /* ksu_kallsyms_lookup_name() walks the live kallsyms table via the
         * kallrecon resolver (v26.11.40 kln mode: the kernel's own
         * kallsyms_lookup_name), so it sees per-CPU variables too (the loader's
         * /proc/kallsyms walker skips type 'A' records as section markers;
         * this path does not). The value it returns is the per-CPU section
         * offset of the symbol, exactly what the %gs displacement wants. */
        addr = ksu_kallsyms_lookup_name("current_task");

        /* v26.11.40: the kr_seed's gsoff= field (from /proc/kallsyms's
         * 'A current_task' line) is authoritative when present.  The field
         * evidence disproved the old "0 is correct on LDPlayer" assumption
         * (the device listing says 0x1bc40).  In kln mode the lookup above
         * already routes through the kernel's own kallsyms_lookup_name, so
         * the two agree; a disagreement is logged and the seed wins. */
        {
                unsigned long seed = ksu_kr_gsoff_seed();

                if (seed && seed != addr)
                        susfs_diag_logf("current_task: kallsyms says 0x%lx but kr_seed gsoff=0x%lx - the SEED wins\n",
                                       addr, seed);
                if (seed)
                        addr = seed;
        }

        if (!addr) {
                /* v26.11.40: the v39 code kept the 0 default here on the
                 * theory that current_task sits at per-CPU offset 0 on
                 * LDPlayer.  The device's own /proc/kallsyms (field evidence)
                 * says otherwise (0x1bc40), so 0 now means "unresolved":
                 * either the symbol is hidden or the resolver is not up.
                 * Every later reader of `current` in this module would
                 * dereference %gs:0 - fixed_percpu_data - as a task_struct,
                 * so refuse instead: the ladder retries this rung, and the
                 * operator can seed gsoff= explicitly.  (x86_64 5.15 always
                 * starts the per-CPU section with fixed_percpu_data, so a
                 * genuine offset of 0 does not exist there.) */
                susfs_diag_logf("current_task: could not resolve the per-CPU offset (lookup returned 0, no gsoff= seed) - refusing: a wrong gs displacement would make every `current` read in this module point into fixed_percpu_data. Seed kr_seed with gsoff=0x<offset> from /proc/kallsyms.\n");
                return -ENODATA;
        }

        susfs_current_task_gs_off = addr;
        susfs_diag_logf("current_task: per-CPU gs offset = 0x%lx\n", addr);
        return 0;
}
