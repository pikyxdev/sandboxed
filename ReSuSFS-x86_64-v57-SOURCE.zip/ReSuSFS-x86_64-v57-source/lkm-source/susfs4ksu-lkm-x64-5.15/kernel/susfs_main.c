// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_main.c - SUSFS LKM entry point: the layer table plus this module's control nodes.
 * Loaded via `ksud insmod`, with unexported symbols relocated via kallsyms.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/version.h>      /* LINUX_VERSION_CODE: the MODULE_IMPORT_NS spelling below */
#include <linux/fs.h>           /* d_inode() for the control-node labels; filp_open/kernel_write */
#include <linux/namei.h>        /* kern_path() */
#include <linux/path.h>         /* path_put() */
#include <linux/security.h>     /* security_secctx_to_secid(): the nodes' SELinux label */
#include <linux/uaccess.h>      /* kernel_write is declared here on 5.15 */
#include <linux/workqueue.h>    /* v26.11.34+: the deferred-init work item */

#include "susfs_kprobe.h"       /* susfs_kp_noopt_post lives here */
#include "symbol_resolver.h"
#include "ksu_allow_gate.h"     /* susfs_ksu_allow_kind: whether ksu_file applies at all */
#include "patch_memory.h"       /* ksu_patch_memory_init(): the flush helper's name differs per kernel */
#include "susfs_log.h"
#include "ksu_umount_gate.h"
#include "ksu_allow_gate.h"     /* KernelSU's allow predicate: the control-node gate */
#include "btf_layout.h"         /* the SELinux inode_security_struct.sid offset, by BTF */
#include "lsm_hook.h"
#include "susfs.h"
#include "susfs_opath.h"        /* SUSFS_OPATH_NODE + the layer's init/exit */
#include "susfs_fp_hook.h"      /* susfs_fp_init: the sys_call_table cache every fp layer installs through */

/* kernel/susfs_current.c - fills in susfs_current_task_gs_off (used by the
 * overridden <asm/current.h>) before any layer that reads `current` runs. */
int susfs_current_init(void);
extern unsigned long susfs_current_task_gs_off;

/* ---- v26.11.45: .bss stomp pad ----
 *
 * The running kernel is an ANDROID-common one: its struct module is 0x340
 * bytes (scmversion + KABI reserves), while a kernel.org-tree build ships a
 * 0x300-byte .gnu.linkonce.this_module.  At insmod the kernel initializes ITS
 * struct inside that section and writes 0x40 bytes past it - into whatever the
 * module core layout places after this_module, which on this image is the
 * START OF .bss.  v44's field evidence caught the spill in the act: the
 * evidence collector read sc_entry_count=10 on EVERY boot, including fresh
 * zombie modules whose kprobe was never registered (the counter's only
 * writer is the kprobe entry path), and readelf on the shipped vanilla image
 * shows .bss[0..0x40) covering susfs_diag_printk, susfs_probe_arm,
 * susfs_probe_val, susfs_force_init_val, susfs_init_done, init_laststep,
 * init_maxstep, fail_layer and susfs_sc_entry_count - the module's control
 * plane, stomped with deterministic garbage at every load.
 *
 * This pad is the first object in the first-linked translation unit's .bss:
 * it absorbs the spill so those variables start every load at their coded
 * values again.  The android13 candidate (correct 0x340 struct) wastes 64
 * harmless bytes.  The pad is verified post-build by readelf: it must sit at
 * .bss+0 with every named variable past +0x40.
 *
 * It is 64 bytes because 0x340-0x300 is exactly 0x40.  The pad lives in
 * stomp_pad.c as the first-linked object's ONLY .bss symbol (a GLOBAL, so it
 * can never be garbage-collected): GCC reorders .bss within a translation
 * unit, so a static pad here landed at +0x1040 - the separate object is what
 * pins it to .bss+0. */

/* ---- v26.11.31: module parameter diagnostics ----
 *
 * v26.11.30 proved that BOTH printk AND filp_open are blocked for susfs_guard_lkm:
 *  - pr_err DIAG messages don't appear in dmesg (KernelSU hook suppresses them)
 *  - diag_init.log was NOT created (filp_open blocked, despite kernel_write/filp_close
 *    resolving successfully in kallsyms)
 *
 * This is because KernelSU is BUILT INTO the kernel (ksu_* symbols at 0xffffffff8170b...
 * in vmlinux .text) with an active hook_manager that intercepts both printk and file
 * operations from modules it doesn't recognize.
 *
 * The ONLY communication channel that bypasses both printk and file I/O is the kernel's
 * own module parameter sysfs interface: /sys/module/susfs_guard_lkm/parameters/<param>.
 * This is managed by kernel/module.c's param_sysfs and cannot be hooked by KernelSU without
 * patching the module subsystem itself.
 *
 * v26.11.31 exposes TWO module parameters:
 *  - diag_log: a 4096-byte string buffer that susfs_init appends DIAG messages to.
 *    Read via: cat /sys/module/susfs_guard_lkm/parameters/diag_log
 *  - sc_entry_count: a counter incremented each time the supercall kprobe's
 *    pre_handler fires.  If this stays 0 after `ksu_susfs show version`, the
 *    kprobe is NOT firing (KernelSU's hook blocks it).
 *    Read via: cat /sys/module/susfs_guard_lkm/parameters/sc_entry_count
 *
 * Also adds ONE raw printk(KERN_ERR "XYZDIAG1: ...") call that bypasses pr_fmt
 * (no "susfs_guard_lkm: " prefix) to test whether KernelSU filters by prefix string
 * or by caller address.
 */
static char susfs_diag_log[4096];
static int susfs_diag_log_pos;
module_param_string(diag_log, susfs_diag_log, sizeof(susfs_diag_log), 0444);

/* v26.11.38: printk GATE.  The v26.11.37 result - a wedge at stage 0, where
 * the armed kernel-side work was only imports_guard, the kallrecon scan and
 * this macro's pr_err() - leaves printk from module code as a live suspect:
 * every DIAG crumb since v26.11.31 printed unconditionally, and the observed
 * "printk suppressed by KernelSU" is equally consistent with "printk wedged
 * the kernel before dmesg could be read".  Default 0: DIAG writes only the
 * diag_log buffer, which survives in the module param; the sysfs param channel
 * is proven to work on this kernel (force_init writes arrive).  Set to 1 only
 * to re-test printk itself. */
int susfs_diag_printk;
module_param_named(diag_printk, susfs_diag_printk, int, 0644);
/* (no export needed: extern int susfs_diag_printk in susfs.h reaches the
 * other translation units of this module directly.) */

static int susfs_sc_entry_count;
module_param_named(sc_entry_count, susfs_sc_entry_count, int, 0444);

/* Exported so susfs_supercall.c's sc_entry can increment it.  Non-atomic increment
 * is fine for a diagnostic counter — worst case is a lost count under concurrent
 * reboot(2) calls, which is acceptable. */
void susfs_diag_sc_entry_hit(void)
{
    susfs_sc_entry_count++;
}

static void susfs_diag_append(const char *fmt, ...)
{
    va_list args;
    int len, remaining;

    remaining = sizeof(susfs_diag_log) - susfs_diag_log_pos - 1;
    if (remaining <= 0)
        return;

    va_start(args, fmt);
    len = vsnprintf(susfs_diag_log + susfs_diag_log_pos, remaining, fmt, args);
    va_end(args);

    if (len > 0)
        susfs_diag_log_pos += (len < remaining) ? len : remaining;
}

/* v26.11.37: cross-file breadcrumb channel (prototype in susfs.h).  Identical
 * body to susfs_diag_append, but callable from other translation units: the
 * kallrecon resolver and the supercall layer's registration now drop their
 * phase crumbs into the same buffer, because printk from this module is
 * suppressed by KernelSU's hook and filp_open is blocked - diag_log is the only
 * evidence channel a wedged boot leaves behind.  Single-writer by construction
 * (only the deferred-init kworker calls into it). */
void susfs_diag_logf(const char *fmt, ...)
{
    va_list args;
    int len, remaining;

    remaining = sizeof(susfs_diag_log) - susfs_diag_log_pos - 1;
    if (remaining <= 0)
        return;

    va_start(args, fmt);
    len = vsnprintf(susfs_diag_log + susfs_diag_log_pos, remaining, fmt, args);
    va_end(args);

    if (len > 0)
        susfs_diag_log_pos += (len < remaining) ? len : remaining;
}

/* Macro: write to the module param buffer AND pr_err - but as of v26.11.38
 * the printk side is gated by diag_printk (default 0, see above).  The raw
 * XYZDIAG1 probe below is gated by the same param. */
#define DIAG(fmt, ...) do { \
    susfs_diag_append(fmt, ##__VA_ARGS__); \
    if (susfs_diag_printk) \
        pr_err("susfs_guard_lkm: " fmt, ##__VA_ARGS__); \
} while (0)


/* See susfs_kprobe.h.  Empty on purpose: it exists only so the kprobe
 * optimizer refuses these probes, its presence is the whole point. */
void susfs_kp_noopt_post(struct kprobe *kp, struct pt_regs *regs,
                         unsigned long flags)
{
}
NOKPROBE_SYMBOL(susfs_kp_noopt_post);

/* The module's own name lives in susfs.h (SUSFS_LKM_MODULE_NAME / SUSFS_LKM_SYSFS_DIR):
 * /sys/module's directory and the rules that hide it (susfs_hide_syms.c) must agree, and the
 * version lives there as well (SUSFS_LKM_VERSION) because the load-time guard can refuse the
 * module before this file's banner runs. */

/* The /proc/susfs_* control nodes are created by default and are 0777 on purpose.
 * Measured on device, 0600 plus sus_path hiding does not work: `ls -l /proc/susfs_kstat`
 * -> ENOENT (the inode_getattr hook fired) but `cat` -> Permission denied (it did not), with
 * sus_path's perm counter stuck at 0 - inode_permission() runs the DAC check BEFORE
 * security_inode_permission(), so a 0600 root-owned node fails DAC first, the LSM hook is
 * never reached, and EACCES advertises that the node exists.  General to sus_path's path
 * layer: it can only turn an ENOENT-shaped answer out of files DAC would have ALLOWED.
 * Hence 0777: DAC passes, the LSM layer is the only thing that answers (ENOENT for every
 * non-root caller).
 * The nodes exist only when the layer that hides them is installed
 * (susfs_control_node_allowed()), so an unprotected world-writable node cannot happen, and
 * root-only access is enforced by the handlers' uid checks, not by the mode.  expose_proc=0
 * removes the nodes entirely. */
bool susfs_expose_proc = true;
module_param_named(expose_proc, susfs_expose_proc, bool, 0600);

static const char *const susfs_self_hide_paths[] = {
    "/proc/susfs_kstat",
    "/proc/susfs_open_redirect",
    "/proc/susfs_enable_log",
    "/proc/susfs_avc_spoof",
    SUSFS_HIDE_MODULES_NODE,
    SUSFS_HIDE_MOUNTS_NODE,
    /* sus_path's own interface (the rule listing): it goes through the same table it
     * prints, so a broken rule table is visible in the very view that reports it. */
    SUSFS_PATH_NODE,
    /* The uname machine spoof node: it decides "translated process" from the marker VMA. */
    SUSFS_UNAME_MACHINE_NODE,
    /* The prop_view node: add/clear the property area copy pairs. */
    SUSFS_PROP_VIEW_NODE,
    /* The O_PATH layer's node: it reports the four sys_call_table/compat_sys_call_table
     * entries and the counters that say whether a wrapper ever ran. */
    SUSFS_OPATH_NODE,
    SUSFS_MAP_NODE,
    SUSFS_UNIX_NODE,
    /* The module's own sysfs directory is NOT here: it belongs to hide_module
     * (susfs_hide_syms.c), which adds and drops that rule at runtime. */
};

/* Register our control nodes in sus_path's hidden set: probing them must answer ENOENT,
 * not EACCES.  Runs after every feature init (the nodes must exist for kern_path() to
 * resolve them) and after sus_path_init(), so the hooks are already patched. */
void susfs_self_hide_nodes(void)
{
    int i;

    if (!susfs_expose_proc)
        return;

    for (i = 0; i < ARRAY_SIZE(susfs_self_hide_paths); i++) {
        int rc = sus_path_add_self_hidden(susfs_self_hide_paths[i]);

        if (rc)
            DIAG("self-hide %s failed %d\n",
                    susfs_self_hide_paths[i], rc);
    }
}

/* The control nodes are born with procfs's default label, u:object_r:proc:s0, whose policy refuses
 * even an adb shell that this module's gate accepted (measured: `cat /proc/susfs_open_redirect`
 * from u:r:shell:s0 is EACCES, while the same read from u:r:ksu:s0 works).  ksu_file is the type
 * the KernelSU policy already grants to the processes that may use su - exactly the set these
 * nodes exist for - so they are moved under it.
 *
 * There is no LSM interface for this: security_inode_setsecurity() has no inode_setsecurity hook
 * registered on this kernel (it answers the framework default, -EOPNOTSUPP, for either spelling of
 * the attribute name), and procfs has no xattr handler to go through the VFS.  What is left is the
 * field SELinux itself reads: inode->i_security points at its private inode_security_struct (until
 * the per-LSM blob split in 6.4), and the `sid` member is what every check uses.  The offset comes
 * from BTF and the member's type is verified, so a kernel whose layout moved it is refused instead
 * of being written at a guess.
 *
 * This runs once at load, on inodes nobody has opened yet; a plain 32-bit store needs no lock. */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 4, 0)
static const char susfs_control_selinux_ctx[] = "u:object_r:ksu_file:s0";
static const char susfs_proc_selinux_ctx[] = "u:object_r:proc:s0";
static size_t susfs_isec_base_offset;   /* SELinux's slot inside inode->i_security */
static size_t susfs_isec_sid_offset;
static u32 susfs_control_sid;
static u32 susfs_proc_sid;

static bool susfs_prepare_control_sid(void)
{
    unsigned long blob_sizes;
    size_t lbs_inode_off;
    int sel_off;
    int rc;

    if (security_secctx_to_secid(susfs_control_selinux_ctx,
                                 strlen(susfs_control_selinux_ctx),
                                 &susfs_control_sid) ||
        !susfs_control_sid)
        return false;
    if (security_secctx_to_secid(susfs_proc_selinux_ctx,
                                 strlen(susfs_proc_selinux_ctx),
                                 &susfs_proc_sid) ||
        !susfs_proc_sid)
        return false;
    /* Idempotent: the fsnotify layer has usually called this already. */
    if (susfs_btf_layout_init())
        return false;
    /* Every Android 5.15 here carries the per-LSM blob allocation even though the split landed
     * upstream later: inode->i_security is then a blob whose SELinux slot starts at
     * selinux_blob_sizes.lbs_inode.  A kernel without that symbol is the older shape, where
     * inode->i_security IS the struct and the base stays 0. */
    blob_sizes = find_kernel_symbol_exact("selinux_blob_sizes");
    if (blob_sizes) {
        if (susfs_btf_member_offset("lsm_blob_sizes", "lbs_inode", "int",
                                    &lbs_inode_off))
            return false;
        sel_off = READ_ONCE(*(int *)((char *)blob_sizes + lbs_inode_off));
        if (sel_off < 0 || sel_off > 4096)
            return false;
        susfs_isec_base_offset = (size_t)sel_off;
    }
    rc = susfs_btf_member_offset("inode_security_struct", "sid", "uint",
                                 &susfs_isec_sid_offset);
    return !rc;
}

/* The write is only made where the field already holds the proc label: that is what proves the
 * base, the offset and the blob ownership are all right on the kernel actually running.  Anything
 * else is left alone - a wrong guess here would corrupt a live struct. */
static void susfs_set_inode_sid(struct inode *inode, u32 sid)
{
    u32 *field;

    if (!inode->i_security)
        return;
    field = (u32 *)((char *)inode->i_security + susfs_isec_base_offset +
                    susfs_isec_sid_offset);
    if (READ_ONCE(*field) != susfs_proc_sid)
        return;
    WRITE_ONCE(*field, sid);
}
#endif

static void susfs_relabel_control_nodes(void)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0)
    /* The split is upstream here and the blob walk above is untested there, so the nodes keep their
     * default (proc) label.  That is exactly why the gate must NOT widen here: susfs_control_visible()
     * stays root-only until susfs_control_relabelled is set, because proc's policy answers EACCES to
     * the shell and to su-granted apps - the gate letting them in would turn the nodes' ENOENT into
     * an EACCES that proves they exist (susfs4ksu-lkm#108). */
    return;
#else
    int i, found = 0, changed = 0;

    if (!susfs_expose_proc)
        return;
    /* No KernelSU, no ksu_file label.  That label exists so the KernelSU predicate's set
     * (shell, the manager, su-granted apps) may read the nodes; without the predicate there is
     * nobody to widen to, so the nodes keep proc's own label and the gate stays the original
     * root-only one.  susfs_prepare_control_sid() would otherwise succeed here on BTF alone -
     * a Magisk device has no KernelSU predicate but does have SELinux - and stamp a label this
     * build has no use for. */
    if (READ_ONCE(susfs_ksu_allow_kind) != 1) {
        susfs_diag_logf("susfs: no KernelSU predicate - control nodes keep proc's label, gate stays root-only\n");
        return;
    }
    if (!susfs_prepare_control_sid()) {
        susfs_diag_logf("susfs: no ksu_file label applied (context or BTF layout unavailable)\n");
        return;
    }
    for (i = 0; i < ARRAY_SIZE(susfs_self_hide_paths); i++) {
        struct path p;
        struct inode *inode;

        if (kern_path(susfs_self_hide_paths[i], 0, &p))
            continue;
        found++;
        inode = d_inode(p.dentry);
        if (inode && inode->i_security) {
            u32 *field = (u32 *)((char *)inode->i_security +
                                 susfs_isec_base_offset +
                                 susfs_isec_sid_offset);

            if (READ_ONCE(*field) == susfs_proc_sid) {
                susfs_set_inode_sid(inode, susfs_control_sid);
                changed++;
            }
        }
        path_put(&p);
    }
    susfs_diag_logf("susfs: %d of %d control node(s) relabelled to %s\n",
               changed, found, susfs_control_selinux_ctx);
    /* Only a node that is actually relabelled may be widened to the KernelSU set: a node left under
     * proc's label answers EACCES to exactly the callers the wider gate just admitted, and EACCES
     * says "it is here" where ENOENT says "nothing here".  All-or-nothing on purpose - a partial
     * relabel means the set is not usable, and root-only is what those labels say anyway. */
    WRITE_ONCE(susfs_control_relabelled, found > 0 && changed == found);
#endif
}

/* ---- layer table: arming order IS the teardown order, reversed --------------
 * A failed load must leave NOTHING armed: when module_init() returns an error the kernel
 * frees this module's memory, so anything still installed - a patched security_hook_heads
 * slot above all - becomes a function pointer into freed memory that the next syscall goes
 * through.  Hence the exits of the already-armed layers run before failing.
 * Teardown runs in the exact reverse of arming, in one place, and the order matters:
 * sus_path's LSM layer is what answers ENOENT for this module's own 0777 control nodes (see
 * the expose_proc note), so unhooking it before the nodes are removed would expose them to
 * every process during the unload - here the nodes go first and the LSM layer last.
 * The load plan marks four layers as fatal: fp_hook, lsm_hook, sus_path and supercall; the
 * rest log their own failure and degrade to "off".  The exits are idempotent, which lets one
 * path serve rollback and unload alike. */
static int layer_lsm_hook_init(void)
{
    ksu_lsm_hook_init();
    if (!ksu_lsm_hook_ready()) {
        if (susfs_diag_printk)
            pr_err("lsm_hook: the table hook insertion walks is not resolvable on this kernel - refusing to load\n");
        susfs_diag_logf("lsm_hook: the table hook insertion walks is not resolvable on this kernel - refusing to load\n");
        return -ENOENT;
    }
    return 0;
}

/* Layer ids: the load order indexes susfs_layers[] through these, and susfs_load_plan[] below
 * carries the per-layer FATAL bool passed to susfs_load_layer().  Keep the enum and the table in
 * the same order. */
enum susfs_layer_id {
    SUSFS_L_FP_HOOK = 0,
    SUSFS_L_KSU_UMOUNT_GATE,
    SUSFS_L_KSU_ALLOW_GATE,
    SUSFS_L_LSM_HOOK,
    SUSFS_L_SUS_PATH,
    SUSFS_L_CREATE_GATE,
    SUSFS_L_OPATH,
    SUSFS_L_DIRENT,
    SUSFS_L_UNAME,
    SUSFS_L_KSTAT,
    SUSFS_L_SUS_MAP,
    SUSFS_L_SUS_MOUNT,
    SUSFS_L_CMDLINE,
    SUSFS_L_OPEN_REDIRECT,
    SUSFS_L_PROP_VIEW,
    SUSFS_L_ENABLE_LOG,
    SUSFS_L_AVC_SPOOF,
    SUSFS_L_SUPERCALL,
    SUSFS_L_HIDE_SYMS,
    SUSFS_L_SUS_UNIX,
    SUSFS_L_COUNT,
};

/* Not const: the `armed` flags live here (the pointers must outlive __init too). */
static struct susfs_layer {
    const char *name;
    int (*init)(void);
    void (*exit)(void);
    bool armed;                 /* exit is run for every layer that was attempted */
    int feature;                        /* enum susfs_feature armed on a successful init, or -1 */
} susfs_layers[] = {
    /* First, and FATAL: every fp-hook layer below (create_gate, opath, dirent, kstat, ...)
     * installs its entries through this cache.  A module that loaded without it would accept
     * rules that no fp-hook layer can ever apply - the "loaded but inert" shape this table
     * exists to avoid - so a missing sys_call_table refuses the load.  The init is idempotent
     * (the later layers' own susfs_fp_init() calls are no-ops once the cache is set), and
     * there is no exit: only the pointer is cached, the entries are restored by their owner. */
    { "fp_hook",        susfs_fp_init,                  NULL,                   false, -1 },
    /* NOT fatal: this layer only decides whether KernelSU's predicate was found at load.
     * When it was not, the gates answer the pre-#34 way and every other layer still works - so a
     * failure here is a degradation, not a reason to refuse the module.  Skipping this init entirely
     * (fail_layer=2) is safe for the same reason: the flag it sets defaults to the pre-#34 answer. */
    { "ksu_umount_gate", susfs_ksu_umount_gate_init,    NULL,                   false, -1 },
    { "ksu_allow_gate", susfs_ksu_allow_gate_init,      NULL,                   false, -1 },
    /* FATAL: every LSM layer below (sus_path first) inserts through this file's table hooks.
     * A module that loads without it would accept rules no LSM layer can apply - the same
     * "loaded but inert" shape fp_hook is fatal for.  ksu_lsm_hook_init() itself only
     * reports; the refusal lives here, where a failure can fail the load. */
    { "lsm_hook",       layer_lsm_hook_init,            ksu_lsm_hook_exit,      false, -1 },
    { "sus_path",       sus_path_init,                  sus_path_exit,          false, SUSFS_FEAT_SUS_PATH },
    /* After sus_path, whose rule table and per-caller gate it asks.  NOT fatal: when it
     * cannot arm, the create family keeps answering the kernel's own way (EEXIST for a
     * hidden name) - the read paths are unaffected. */
    { "create_gate",    susfs_create_gate_init,         susfs_create_gate_exit, false, SUSFS_FEAT_SUS_PATH },
    /* After sus_path, because this layer asks sus_path's rule table for every open it
     * post-checks - arming it first would install table entries that answer from a table
     * nobody has filled in yet.  NOT fatal: a failure here only means open(..., O_PATH) keeps
     * answering the pre-layer way (which is what the layer exists to fix, not what makes the
     * module useful), and every entry carries its own reason in the log. */
    { "opath",          susfs_opath_init,               susfs_opath_exit,       false, SUSFS_FEAT_SUS_PATH },
    /* After sus_path, whose rule table it asks.  NOT fatal: when it does not arm the
     * post-hoc filter still hides, it is only detectable while doing so. */
    { "dirent",         susfs_sus_dirent_init,          susfs_sus_dirent_exit,  false, SUSFS_FEAT_SUS_PATH },
    { "uname",          susfs_uname_init,               susfs_uname_exit,       false, SUSFS_FEAT_SPOOF_UNAME },
    { "kstat",          susfs_kstat_init,               susfs_kstat_exit,       false, SUSFS_FEAT_SUS_KSTAT },
    { "sus_map",        susfs_sus_map_init,             susfs_sus_map_exit,     false, SUSFS_FEAT_SUS_MAP },
    { "sus_mount",      susfs_sus_mount_init,           susfs_sus_mount_exit,   false, SUSFS_FEAT_SUS_MOUNT },
    { "cmdline",        susfs_spoof_cmdline_init,       susfs_spoof_cmdline_exit, false, SUSFS_FEAT_SPOOF_CMDLINE },
    { "open_redirect",  susfs_open_redirect_init,       susfs_open_redirect_exit, false, SUSFS_FEAT_OPEN_REDIRECT },
    /* After open_redirect: its app_process helper is what tells this layer's work callback
     * that the caller is an app process.  NOT fatal: it is a test feature. */
    { "prop_view",      susfs_prop_view_init,           susfs_prop_view_exit,   false, -1 },
    { "enable_log",     susfs_enable_log_init,          susfs_enable_log_exit,  false, SUSFS_FEAT_ENABLE_LOG },
    { "avc_spoof",      susfs_avc_spoof_init,           susfs_avc_spoof_exit,   false, SUSFS_FEAT_AVC_SPOOF },
    { "supercall",      susfs_supercall_init,           susfs_supercall_exit,   false, -1 },
    { "hide_syms",      susfs_hide_syms_init,           susfs_hide_syms_exit,   false, SUSFS_FEAT_HIDE_SYMS },
    /* Last, so the fail_layer numbering of every layer above stays as it was.  NOT fatal: without
     * it abstract unix listeners stay reachable, nothing else depends on it. */
    { "sus_unix",       susfs_sus_unix_init,            susfs_sus_unix_exit,    false, -1 },
};

/* Diagnostic: make one layer's init fail, by 1-based index, to exercise the rollback path
 * on the device - a `fatal` layer failing must leave the load with nothing armed.
 * `fail_layer=2` skips the ksu_umount_gate init WITHOUT failing the load (that layer is not fatal),
 * which is safe only because its flag defaults to the pre-#34 answer - see ksu_umount_gate.c.
 *
 * Index map (keep this list and the fail_layer= references in tools/verify-gki.sh and the layer
 * comments in sync whenever a layer is inserted):
 *   1 fp_hook   2 ksu_umount_gate  3 ksu_allow_gate  4 lsm_hook   5 sus_path
 *   6 create_gate  7 opath  8 dirent  9 uname  10 kstat  11 sus_map  12 sus_mount
 *   13 cmdline  14 open_redirect  15 prop_view  16 enable_log  17 avc_spoof  18 supercall
 *   19 hide_syms  20 sus_unix
 */
static int fail_layer;
module_param_named(fail_layer, fail_layer, int, 0644);

/* ---- v26.11.37: evidence-first staged bring-up ---------------------------------------
 *
 * History: v26.11.33 wedged the boot running init synchronously under sysfs
 * locks (kernfs_rwsem vs kprobe/text_mutex) with three __init callees in
 * .init.text that the kernel freed after the neutered do_init_module (v26.11.34
 * de-__init'd them).  v26.11.34 then deferred init to a kworker via force_init
 * but never triggered it (zombie: image live, init never runs).  v26.11.35
 * re-enabled the trigger: the init body ran for the FIRST TIME EVER on this
 * kernel - straight to full surgery - and the boot wedged at 50%.
 *
 * v26.11.36 therefore armed the layers in stages and made stage 1 the default
 * ("safe set": symbol resolution, /proc nodes, the supercall kprobe).  THE
 * V26.11.36 RESULT: a fresh flash with no arm_stage file ran that stage-1 default
 * AND THE BOOT STILL WEDGED AT 50%.  Two conclusions follow:
 *   1. the wedge is inside the stage-1 set itself - i.e. in kallrecon resolver /
 *      current_task gs-off discovery / resolve-only layers / proc nodes / the
 *      supercall probe (the only kernel-text patch in that set, registered
 *      BY NAME through the ftrace-backed kprobe path on this LTO/PGO/BOLT
 *      kernel - never live-tested before v35);
 *   2. "mechanism-class batching" is still too coarse to attribute the wedge, and
 *      a default of 1 was too optimistic.
 *
 * v26.11.37 therefore SPLITS THE RUNG THAT WEDGED and drops the default to the
 * rung that history has actually proven safe (v25..v32: image load + params +
 * zombie = boots fine; the resolver is read-only and timeout-bounded):
 *   stage 0 (DEFAULT): evidence-only - imports guard, kallrecon resolver,
 *     current_task gs-off discovery, crosschecks.  NO layers at all.
 *   stage 1: + the read-only / proc-node layers (sus_map, sus_mount, cmdline,
 *     open_redirect, prop_view, enable_log, avc_spoof) and the resolve-only
 *     layers (fp_hook, ksu_umount_gate, ksu_allow_gate).  No kernel text is
 *     touched at this rung.
 *   stage 2: + supercall in OBSERVE-ONLY mode - the plain __x64_sys_reboot
 *     kprobe registers and logs susfs traffic, but never accepts.  This rung
 *     proves the kprobe slot under live traffic alongside KernelSU's own
 *     reboot kprobe (the v44 kretprobe on the same slot wedged the box at
 *     first traffic; v45 replaced it with the SukiSU-proven plain-kprobe
 *     shape).
 *   stage 3: + supercall ACCEPTS (the task_work answer path goes live - this
 *     rung alone separates "the slot" from "the answer path" for the field
 *     bisect).
 *   stage 4: + the LSM-insertion class (lsm_hook, sus_path + self-hide/relabel,
 *     hide_syms, uname).
 *   stage 5: full - the sys_call_table entry writers (create_gate, opath,
 *     dirent, kstat, sus_unix).
 *
 * The stage is a module param (0644, root-writable) so post-fs-data.sh sets it
 * from /data/adb/ReSuSFS/arm_stage BEFORE writing force_init.  The boot scripts
 * run a self-managing ladder: service.sh marks a stage healthy only after
 * sys.boot_completed AND init_done=1 and raises the file by one rung; a boot
 * that never completes leaves the in-flight marker untouched and the NEXT boot
 * demotes to stage 0 and caps the ladder below the wedging rung - so the module
 * can never take the same system down twice blind.  A skipped layer logs the
 * skip into diag_log.  arm_stage is read ONCE, at the start of the layer loop;
 * writing it after init has no effect (by design). */
static int susfs_arm_stage;
module_param_named(arm_stage, susfs_arm_stage, int, 0644);

/* Read by susfs_supercall_init() to pick observe (stage 2) vs full (stage 3+)
 * mode for the kprobe.  Direct extern call, not an indirect one: the CFI gate
 * that limits this module's indirect-call surface does not constrain it. */
int susfs_current_arm_stage(void)
{
    return susfs_arm_stage;
}

/* Minimum arm_stage at which each layer runs.  Indexed by enum susfs_layer_id;
 * keep in sync with the enum above.  0 would mean "stage 0 arms it" - nothing
 * is below stage 1, so entries are 1..5.  v26.11.37: supercall moved to its own
 * rung (2) - it is the only kernel-text patch of the old stage-1 batch, and the
 * v26.11.36 stage-1 default wedged the boot.  v26.11.45: the LSM class moved
 * 3->4 and the sys_call_table writers 4->5, because stage 3 is now the
 * supercall's ACCEPT rung (observe=2, full=3) - the bisect granularity the
 * v44 stage-2/3 wedges demanded. */
static const u8 susfs_layer_stage[SUSFS_L_COUNT] = {
    [SUSFS_L_FP_HOOK]            = 1,   /* resolves sys_call_table only (writes happen in stage-5 layers) */
    [SUSFS_L_KSU_UMOUNT_GATE]    = 1,   /* resolves KernelSU symbols */
    [SUSFS_L_KSU_ALLOW_GATE]     = 1,   /* resolves KernelSU symbols */
    [SUSFS_L_LSM_HOOK]           = 4,   /* inserts into security_hook_heads lists */
    [SUSFS_L_SUS_PATH]           = 4,   /* LSM hooks + fsnotify group + kern_path-backed rule table */
    [SUSFS_L_CREATE_GATE]        = 5,   /* susfs_fp_install: sys_call_table entry write */
    [SUSFS_L_OPATH]              = 5,   /* susfs_fp_install x4: sys_call_table entry writes */
    [SUSFS_L_DIRENT]             = 5,   /* rides the stat layer's table entries */
    [SUSFS_L_UNAME]              = 4,   /* kretprobe on newuname + proc node */
    [SUSFS_L_KSTAT]               = 5,   /* susfs_fp_install: stat-family entry writes */
    [SUSFS_L_SUS_MAP]            = 1,   /* proc node only (show-slot patches happen at rule time) */
    [SUSFS_L_SUS_MOUNT]          = 1,   /* proc node only */
    [SUSFS_L_CMDLINE]            = 1,   /* reads boot_command_line, no hooks at init */
    [SUSFS_L_OPEN_REDIRECT]      = 1,   /* proc node + symbol resolution */
    [SUSFS_L_PROP_VIEW]          = 1,   /* proc node only */
    [SUSFS_L_ENABLE_LOG]         = 1,   /* proc node only */
    [SUSFS_L_AVC_SPOOF]          = 1,   /* proc node only */
    /* v26.11.49: the transport is the LIVE sys_call_table entry for the COLD
     * ioperm(2) (nr 173), WITH a replicated kCFI type-hash preamble.  The
     * v47 premise ("the table is inert, dispatch is x64_sys_call's
     * direct-call switch") was inverted by the field logs: this kernel's
     * BUILT-IN KernelSU-Next patches do_syscall_64/x64_sys_call at boot so
     * every syscall dispatches through ksu_syscall_table[nr] - the table IS
     * the live path.  The v48 field verdict then convicted the missing
     * preamble: this clang-17 LTO kernel enforces kCFI at the (non-__nocfi)
     * my_x64_sys_call dispatch, and v48's raw-asm thunk without the 4-byte
     * type hash before its entry killed the box at the FIRST syscall(173)
     * through it - five boots out of five, each dying 2-5s after init at
     * the boot-completed self-test.  v49 replicates the original entry's
     * preamble into susfs_sc_kcfi_preamble (susfs_supercall.c) before the
     * table write, with a pre-patch liveness proof (ksu_syscall_dispatcher
     * found IN the table) and the v47 arm scan kept as fallback.  No
     * kprobe is registered anywhere; the reboot slot KernelSU's own
     * kprobe rides is not on this path at all. */
    [SUSFS_L_SUPERCALL]          = 2,   /* dispatcher cold-arm redirect - ALONE on its rung; observe at stage 2, full (accepts) from stage 3 */
    [SUSFS_L_HIDE_SYMS]          = 4,   /* kprobe on kallsyms_op.s_show */
    [SUSFS_L_SUS_UNIX]           = 5,   /* susfs_fp_install: sys_call_table entry write */
};

/* Not __init/__exit: it is called from both, and an __exit callee in __init code is a
 * modpost section mismatch. */
/* noinline: its indirect calls through susfs_layers[] belong to this allow-listed function;
 * inlined into module_exit they would land in cleanup_module, which the CFI gate does not allow. */
static noinline void susfs_layers_down(int upto)
{
    int i;

    for (i = upto; i >= 0; i--) {
        if (!susfs_layers[i].armed)
            continue;
        susfs_layers[i].armed = false;
        if (susfs_layers[i].exit)
            susfs_layers[i].exit();
    }
}

/* The load order and the fatal decision live here, not in the table: susfs_load_layer()
 * receives the bool and owns the rollback-or-warn policy. */
static const struct {
    int id;
    bool fatal;
} susfs_load_plan[] = {
    { SUSFS_L_FP_HOOK, true },
    { SUSFS_L_KSU_UMOUNT_GATE, false },
    { SUSFS_L_KSU_ALLOW_GATE, false },
    { SUSFS_L_LSM_HOOK, true },
    { SUSFS_L_SUS_PATH, true },
    { SUSFS_L_CREATE_GATE, false },
    { SUSFS_L_OPATH, false },
    { SUSFS_L_DIRENT, false },
    { SUSFS_L_UNAME, false },
    { SUSFS_L_KSTAT, false },
    { SUSFS_L_SUS_MAP, false },
    { SUSFS_L_SUS_MOUNT, false },
    { SUSFS_L_CMDLINE, false },
    { SUSFS_L_OPEN_REDIRECT, false },
    { SUSFS_L_PROP_VIEW, false },
    { SUSFS_L_ENABLE_LOG, false },
    { SUSFS_L_AVC_SPOOF, false },
    { SUSFS_L_SUPERCALL, true },
    { SUSFS_L_HIDE_SYMS, false },
    { SUSFS_L_SUS_UNIX, false },
};

static int susfs_load_layer(int id, bool fatal)
{
    struct susfs_layer *l;
    int ret;

    if (id < 0 || id >= SUSFS_L_COUNT) {
        susfs_layers_down(SUSFS_L_COUNT - 1);
        return -EINVAL;
    }
    l = &susfs_layers[id];

    /* Marked before the call: a layer that half-ran still has to be taken down. */
    l->armed = true;
    if (fail_layer == id + 1) {
        DIAG("fail_layer=%d - forcing %s's init to fail (diagnostic)\n",
                fail_layer, l->name);
        ret = -EIO;
    } else {
        ret = l->init ? l->init() : 0;
    }
    if (!ret) {
        if (l->feature >= 0)
            susfs_supercall_arm_feature(l->feature);
        return 0;
    }
    if (fatal) {
        DIAG("%s init failed %d, refusing to load\n", l->name, ret);
        /* The kernel is about to free this module; a hook left behind points into it. */
        susfs_layers_down(SUSFS_L_COUNT - 1);
        return ret;
    }
    DIAG("%s init failed %d - that feature stays off\n", l->name, ret);
    return 0;
}


/* ---- v26.11.42: minimal-setter + kworker sentinels + KABI pad ----------------
 *
 * The v41 field boot (2026-11-23 17:51:30) repeated the v39/v40 signature
 * with the witness live: "writing force_init=1" receipt on disk, ONE witness
 * poll at @0s reading init_laststep=-1, then NOTHING - no "write returned"
 * receipt, no further witness poll, no 30s-elapsed line, box dead, manual
 * instance restart.  Static post-mortem of the v39/v40/v41 images found every
 * checkable thing CLEAN: the setter's machine code (no canary, plain stores,
 * direct in-module calls, one external queue_work-family call, plain ret),
 * all 123 imports present in the field kernel's kallsyms, params.c and
 * moduleparam.h byte-identical between kernel.org 5.15.178 and the running
 * kernel's android13-5.15-2025-03 lineage, .bss head (the only zone a struct
 * module overflow could touch) holding nothing the setter dereferences.
 *
 * What the post-mortem DID find, and v42 therefore fixes outright:
 *
 * 1. THE STRUCT MODULE SIZE MISMATCH.  The running kernel's struct module is
 *    the ANDROID one (scmversion + 4 ANDROID_KABI_RESERVEs): 0x340 bytes.
 *    The kernel.org-built images (v26.11.26-41, ALL of them, including the
 *    "working" v35-v37 ones!) carry a 0x300-byte .gnu.linkonce.this_module
 *    section - the kernel initializes its OWN (larger) struct module INSIDE
 *    that section at load time, writing 0x40 bytes past it into the module's
 *    .bss.  On the v35-v37 gcc layouts that overflow landed on benign ints;
 *    the a13 build (v38/39, struct module 0x340 = no overflow) and the
 *    clang rebuilds (v40/41) still froze at the first module-code call, so
 *    the overflow alone cannot be the whole story - but it is a REAL ABI
 *    violation either way: an Android-built kernel writing an Android
 *    struct module into a vanilla-sized section.  v42 builds the "android13"
 *    candidate against the EXACT running lineage (a13 ASB-2025-03) AND pads
 *    .gnu.linkonce.this_module to 0x380 on every build, so the kernel's
 *    writes (including any LD-specific extras) land on reserved padding
 *    instead of module data.
 *
 * 2. THE TOOLCHAIN PROFILE.  The ONLY images whose module code verifiably
 *    EXECUTED in the field (v26.11.34/35's 2a93454a062a, v36, v37) were all
 *    built with GCC against the kernel.org tree (.text.unlikely +
 *    .rodata.str1.8 fingerprints).  Every image since v38 was built with
 *    clang (NDK r28c) or against the a13 tree with a different section
 *    order - and every one of those froze at the first module-code call.
 *    v42 restores the proven profile for the "vanilla" candidate: the
 *    kernel.org tree with HOST GCC.  Both candidates ship in the zip; the
 *    loader picks via /data/adb/ReSuSFS/lkm_candidate (default android13).
 *
 * 3. THE ATTRIBUTION BLIND SPOTS.  The v41 witness read init_laststep
 *    through the module param sysfs files - the same files whose store path
 *    holds mod->param_lock.  If the freeze happens while that mutex is held,
 *    the witness's reads BLOCK and it looks exactly like "stuck at -1",
 *    which proves nothing.  v42 therefore:
 *      - reduces the setter to BARE schedule_work (no DIAG, no stores, no
 *        reads: the least module code that has to execute for a dispatch);
 *        all sentinels move into the kworker, which runs OUTSIDE param_lock;
 *      - adds -50 (kworker entered), -51 (already done) BELOW the v41 codes,
 *        with the FIRST kworker statement a raw store - before vsnprintf,
 *        before any call, the cheapest possible "module code runs" proof;
 *      - gives init_body the same store-first discipline (laststep=0 as the
 *        first statement);
 *      - the userspace witness reads every param through `busybox timeout 1`,
 *        so a param_lock deadlock is REPORTED instead of hanging the
 *        witness silently;
 *      - a pure-userspace box heartbeat (file+sync only, no module access)
 *        keeps writing receipts for 40s: heartbeats continuing after the
 *        trigger means the KERNEL is alive and only module-param traffic is
 *        dead (then dmesg is capturable via adb - the script prints how),
 *        heartbeats stopping names the death window to the second.
 *      - a new "probe" parameter with a custom .get: the deferred work can
 *        now be dispatched from the sysfs READ path (cat), a channel whose
 *        module code has never executed on this box.  Writing probe_arm=1
 *        (a STANDARD int param - pure kernel code) arms it; the next read of
 *        "probe" dispatches.  trigger_mode=get in the boot scripts uses it,
 *        which splits "the sysfs write path" from "module code execution"
 *        as the two remaining suspects.
 */
static int susfs_init_maxstep;
module_param_named(init_maxstep, susfs_init_maxstep, int, 0644);

static int susfs_init_laststep = -1;
module_param_named(init_laststep, susfs_init_laststep, int, 0444);

static int susfs_init_done;

/* v26.11.33: susfs_init_body is in .text (NOT __init) so it survives the
 * .init.text freeing that happens after do_init_module() runs (or is skipped
 * by KernelSU's hook).  This lets it be called from the force_init parameter
 * setter after the module is loaded. */
static int susfs_init_body(void)
{
    int i;
    int rc = 0;

    /* v26.11.42: STORE FIRST, log later.  laststep=0 on disk (a plain store
     * as the function's first executed instruction) is the cheapest proof
     * that module code runs this far; the printk probe and the DIAG crumb
     * come after it, so a freeze in THEM leaves laststep=0 behind. */
    WRITE_ONCE(susfs_init_laststep, 0);

    /* v26.11.31: raw printk WITHOUT pr_fmt prefix - if THIS appears in dmesg but
     * "susfs_guard_lkm:" prefixed messages don't, KernelSU filters by prefix string.
     * If this ALSO doesn't appear, KernelSU filters by caller address (or susfs_init
     * didn't run).  This is OUTSIDE pr_fmt so it prints as "XYZDIAG1: ..." not
     * "susfs_guard_lkm: XYZDIAG1: ...". */
    if (susfs_diag_printk)
        printk(KERN_ERR "XYZDIAG1: susfs_init ENTERED (raw printk, no pr_fmt prefix)\n");

    DIAG("DIAG step 1: susfs_init ENTERED (maxstep=%d arm_stage=%d)\n",
         susfs_init_maxstep, susfs_arm_stage);

    /* STEP 0 (dispatch proof) ends HERE: the kworker entered the body, the
     * sentinel store executed, the diag channel got its first crumb.  With
     * maxstep=0 nothing else runs - a wedge at this boundary localizes to
     * the sysfs/workqueue plumbing or the kworker entry, not to any init
     * code. */
    if (susfs_init_maxstep < 1)
        goto out_ok;

    /* First, before any layer runs and while nothing is armed: an import that was not filled in
     * is an address this module would jump to on its first call through it.  See
     * imports_guard.c - a loader that continues after an unresolved name leaves it zero, which
     * the kernel accepts without a word. */
    WRITE_ONCE(susfs_init_laststep, 1);
    DIAG("DIAG step 2: calling imports_guard\n");
    rc = susfs_imports_guard();
    if (rc) {
        DIAG("DIAG step 2 FAILED: imports_guard returned %d\n", rc);
        goto out_fail;
    }
    DIAG("init v%s (substep ladder: maxstep=%d)\n", SUSFS_LKM_VERSION, susfs_init_maxstep);

    if (susfs_init_maxstep < 2)
        goto out_ok;

    /* v26.11.38 SEEDED resolver + v26.11.40 kln= mode: the seed now prefers the
     * kernel's OWN kallsyms_lookup_name address (kr_seed "kln=0x...") over the
     * kallsyms TABLE addresses, because the target kernel does not even list
     * the table variables in /proc/kallsyms.  Validated in-module via the
     * imported sprint_symbol before use; without a seed the module REFUSES
     * (kr_scan=0) instead of scanning. */
    WRITE_ONCE(susfs_init_laststep, 2);
    DIAG("DIAG step 3: calling ksu_init_symbol_resolver (kln=/table seed; scan stays off)\n");
    rc = ksu_init_symbol_resolver();
    if (rc) {
        DIAG("DIAG step 3 FAILED: ksu_init_symbol_resolver returned %d\n", rc);
        goto out_fail;
    }

    if (susfs_init_maxstep < 3)
        goto out_ok;

    /* Resolve the per-CPU offset of current_task before any layer that uses
     * `current` runs - see kernel/susfs_current.c and the overridden
     * <asm/current.h>.  v26.11.40: the old "0 is correct on LDPlayer"
     * default was disproved by the field kallsyms (0x1bc40); the offset now
     * comes from the kln lookup or the gsoff= seed, and a 0 result refuses
     * instead of arming a %gs:0 displacement into fixed_percpu_data. */
    WRITE_ONCE(susfs_init_laststep, 3);
    DIAG("DIAG step 4a: calling susfs_current_init\n");
    rc = susfs_current_init();
    if (rc) {
        DIAG("DIAG step 4a FAILED: susfs_current_init returned %d\n", rc);
        goto out_fail;
    }
    DIAG("DIAG step 4: susfs_current_init done (gs_off=0x%lx)\n", susfs_current_task_gs_off);

    if (susfs_init_maxstep < 4)
        goto out_ok;

    /* Dead man's switch: refuse loading if in-built SuSFS is present */
    WRITE_ONCE(susfs_init_laststep, 4);
    DIAG("DIAG step 4b: dead-man check for built-in susfs (2 lookups)\n");
    if (find_kernel_symbol_exact("susfs_is_inode_sus_path") ||
        find_kernel_symbol_exact("susfs_sus_kstat_spoof_generic_fillattr")) {
        DIAG("DIAG step 4b FAILED: in-built SuSFS is already active in kernel; refusing to load\n");
        rc = -EEXIST;
        goto out_fail;
    }

    if (susfs_init_maxstep < 5)
        goto out_ok;

    /* Now that kallsyms lookups work, check the addresses themselves: see imports_guard.c. */
    WRITE_ONCE(susfs_init_laststep, 5);
    DIAG("DIAG step 5: calling imports_crosscheck\n");
    rc = susfs_imports_crosscheck();
    if (rc) {
        DIAG("DIAG step 5 FAILED: imports_crosscheck returned %d\n", rc);
        goto out_fail;
    }

    if (susfs_init_maxstep < 6)
        goto out_ok;

    /* Text/data patching needs a cache-flush helper whose name differs between kernels; resolve it
     * here, before any layer can patch.  Not fatal by itself, but below 6.12 sus_path is a fatal
     * layer and it installs its hooks by patching text, so a kernel carrying neither spelling ends
     * up refusing to load the module - with the reason in the log right here.  On 6.12+ that path
     * goes through static calls and this only costs the layers that do patch. */
    WRITE_ONCE(susfs_init_laststep, 6);
    DIAG("DIAG step 5a: calling ksu_patch_memory_init\n");
    if (ksu_patch_memory_init())
        DIAG("DIAG step 5a: patching unavailable on this kernel (see patch_memory.c)\n");

    if (susfs_init_maxstep < 7)
        goto out_ok;

    BUILD_BUG_ON(ARRAY_SIZE(susfs_layers) != SUSFS_L_COUNT);
    BUILD_BUG_ON(ARRAY_SIZE(susfs_load_plan) != SUSFS_L_COUNT);
    for (i = 0; i < (int)ARRAY_SIZE(susfs_load_plan); i++) {
        int ret;
        bool fatal = susfs_load_plan[i].fatal;

        if (susfs_load_plan[i].id != i) {
            DIAG("DIAG step 6.0: load plan entry %d names layer %d - refusing to load\n",
                   i, susfs_load_plan[i].id);
            rc = -EINVAL;
            goto out_fail;
        }

        /* v26.11.36 stage gate: skip any layer whose mechanism class is above
         * the armed stage.  Logged, so diag_log names every skip. */
        if (susfs_layer_stage[susfs_load_plan[i].id] > susfs_arm_stage) {
            DIAG("DIAG step 6.%d: layer %d (%s) SKIPPED (needs stage %d > arm_stage %d)\n",
                   i + 1, susfs_load_plan[i].id, susfs_layers[susfs_load_plan[i].id].name,
                   (int)susfs_layer_stage[susfs_load_plan[i].id], susfs_arm_stage);
            continue;
        }
        /* At stages below 4 nothing consumes the fp cache, so a missing
         * sys_call_table degrades instead of refusing the whole load. */
        if (susfs_arm_stage < 4 && susfs_load_plan[i].id == SUSFS_L_FP_HOOK)
            fatal = false;

        DIAG("DIAG step 6.%d: loading layer %d (%s, fatal=%d)\n",
               i + 1, susfs_load_plan[i].id, susfs_layers[susfs_load_plan[i].id].name,
               fatal);
        ret = susfs_load_layer(susfs_load_plan[i].id, fatal);
        if (ret) {
            DIAG("DIAG step 6.%d FAILED: layer returned %d\n", i + 1, ret);
            susfs_layers_down(SUSFS_L_COUNT - 1);
            rc = ret;
            goto out_fail;
        }
    }
    DIAG("DIAG step 7: layer loop done; self-hide/relabel %s\n",
         susfs_layers[SUSFS_L_SUS_PATH].armed ? "armed (sus_path is up)" : "SKIPPED (sus_path not armed at this stage)");

    /* v26.11.36: self-hide/relabel depend on sus_path's rule table (the nodes
     * must exist and the LSM layer must answer ENOENT for them).  Only run
     * them when sus_path actually armed; the armed flag is cleared by
     * susfs_layers_down() when its init failed, so armed == init succeeded. */
    if (susfs_layers[SUSFS_L_SUS_PATH].armed) {
        /* Registered last and undone implicitly: these are entries in sus_path's table, which
         * sus_path_exit() empties while its LSM layer still answers ENOENT for the nodes. */
        susfs_self_hide_nodes();
        susfs_relabel_control_nodes();
        DIAG("DIAG step 8: self-hide/relabel done, about to print loaded\n");
    }

    /* Operator note.  The module hides its own traces from EVERY caller, root included (a
     * built-in SUSFS has no module entry, so hiding it only from non-root would leave a
     * trace upstream does not have): `lsmod | grep susfs` stays empty and a second `insmod`
     * fails with -EEXIST, which reads like a broken module.
     * THE ONE LINE THAT IGNORES THE LOG SWITCH: everything else follows enable_log
     * (susfs_log.h), but this is the only evidence the module came up and the one thing an
     * operator greps for, so it stays unconditional even for a silent load - otherwise
     * "loaded but logging off" is indistinguishable from "not loaded".  The prefix comes
     * from pr_fmt (susfs_log.h), so the message must not repeat it. */
    /* v26.11.29: changed from pr_info to pr_err so it survives any loglevel filtering. */
    DIAG("loaded. This module is filtered out of /proc/modules for every caller including root, so `lsmod | grep susfs` stays empty - check /sys/module/%s instead (a second insmod fails with -EEXIST while it is loaded).\n",
            SUSFS_LKM_MODULE_NAME);

    /* v26.11.49: the transport note. */
    if (susfs_supercall_transport_active())
        DIAG("supercall delivery patches the LIVE sys_call_table[173] entry (the table this kernel's built-in KernelSU-Next dispatches every syscall through) to susfs_sc_entry, with the original entry's kCFI type-hash preamble replicated before the thunk - no kprobe is registered anywhere, KernelSU's reboot slot is untouched; answers are written into payload.err by the wrapper in the caller's own syscall context\n");

    WRITE_ONCE(susfs_init_laststep, 7);

out_ok:
    DIAG("DIAG step 9: susfs_init_body RETURNING 0 (maxstep=%d laststep=%d init_done=1)\n",
         susfs_init_maxstep, READ_ONCE(susfs_init_laststep));
    susfs_init_done = 1;
    return 0;

out_fail:
    DIAG("DIAG step 9: susfs_init_body FAILED at substep %d rc=%d (maxstep=%d)\n",
         READ_ONCE(susfs_init_laststep), rc, susfs_init_maxstep);
    return rc;
}

/* v26.11.33: the __init wrapper — called by do_init_module() if KernelSU
 * doesn't intercept it.  If KernelSU DOES intercept (skips do_init_module),
 * this is never called and .init.text is freed — but susfs_init_body in
 * .text survives and can be called from the force_init parameter setter. */
static int __init susfs_init(void)
{
    if (susfs_init_done)
        return 0;
    return susfs_init_body();
}

/* v26.11.43: parameter setter — called when userspace writes to
 * /sys/module/susfs_guard_lkm/parameters/force_init.
 *
 * THE v42 FIELD RESULT (boot 18d64d21a9894b69bf76f81f3d5b00fa,
 * 2026-11-23 18:59:37): with the setter reduced to BARE schedule_work,
 * a PROVEN-CLEAN image load (vanilla, all relocations applied, zero
 * kernel warnings), substep 0 armed, and the v42 attribution contract
 * live, the box still died INSIDE the force_init write: the
 * "force_init write returned" receipt never landed, the first 5s box
 * heartbeat never landed (death bounded to <5s), the witness's @0s
 * read succeeded (params alive at trigger+0s), no PARAM READ TIMEOUT
 * receipts (NOT a param_lock deadlock), no -50 sentinel (the kworker
 * never executed the fn's first store).  v39/v40/v41 showed the same
 * signature with different images; the ONLY context in which the
 * dispatch verifiably RAN (v34-v37, gcc/kernel.org images) was the
 * POST-FS-DATA trigger ("early"), never the boot-completed trigger.
 * The .set is also the FIRST module FUNCTION CALL of the whole boot
 * (every other param read/write rides kernel param_ops code, and the
 * kretprobe handler is the only other module code that runs).
 *
 * v43 therefore splits the dispatch channel from the queueing path:
 *
 *   echo 2 > force_init  -> SYNC dispatch: susfs_init_body() called
 *                           DIRECTLY from this .set, maxstep-gated.
 *                           With init_maxstep=0 the body is stores +
 *                           vsnprintf only - NO workqueue, NO wake-up,
 *                           NO scheduling machinery at all.  If even
 *                           THIS freezes the box, the sysfs write path
 *                           itself (kernfs/param_lock) is guilty; if
 *                           it survives where the deferred path froze,
 *                           the queue_work path is guilty.
 *   echo 1 > force_init  -> deferred dispatch: BARE schedule_work +
 *                           ret (the v42 path, byte-for-byte when
 *                           diag_printk=0 - kept for comparison).
 *
 * BOTH paths first hit a diag_printk-gated raw printk at KERN_EMERG.
 * printk takes NO param_lock, goes straight to the ring buffer AND to
 * the console (cmdline: console=tty0 ignore_loglevel), so it is the
 * one breadcrumb that survives BOTH a param deadlock AND a dead box:
 * the LDPlayer window itself shows it at freeze time.  Raw literal
 * "XYZDIAG2:" prefix - outside pr_fmt, cannot be prefix-filtered.
 * 0200 = root-writable, not world-visible. */
static int susfs_force_init_val;

static void susfs_deferred_init_fn(struct work_struct *w)
{
    int rc;

    /* v26.11.42: STORE FIRST - before any call, before vsnprintf, before
     * anything that can wedge: a raw store as the kworker's first executed
     * instruction.  laststep=-50 on disk (visible through the 0444 param
     * while param traffic is alive) means "module code executed this far".
     * A box that freezes with the witness stuck at -1 and heartbeats still
     * beating never got module code running at all. */
    WRITE_ONCE(susfs_init_laststep, -50);

    if (susfs_init_done) {
        WRITE_ONCE(susfs_init_laststep, -51);
        return;
    }
    DIAG("force_init(deferred): running susfs_init_body in kworker context\n");
    rc = susfs_init_body();
    DIAG("force_init(deferred): susfs_init_body returned %d\n", rc);
}

static DECLARE_WORK(susfs_init_work, susfs_deferred_init_fn);

/* The v43 setter.  "2" = SYNC dispatch (body called directly from here -
 * no workqueue at all); anything else (including "1") = the v42 deferred
 * path, BARE schedule_work + ret.  Both paths leave the diag_printk-gated
 * EMERG breadcrumb FIRST: it proves ".set entered" on the console (tty0)
 * even if the very next instruction wedges the box. */
static int susfs_param_set_force_init(const char *val, const struct kernel_param *kp)
{
    bool sync;

    while (*val == ' ' || *val == '\t')
        val++;
    sync = (*val == '2');

    if (susfs_diag_printk)
        printk(KERN_EMERG "XYZDIAG2: force_init .set ENTERED (mode=%s, maxstep=%d, laststep=%d)\n",
               sync ? "SYNC-direct-body" : "DEFERRED-schedule_work",
               susfs_init_maxstep, READ_ONCE(susfs_init_laststep));

    if (sync) {
        /* v43 SYNC channel: -70 = sync setter entered the body call.
         * Runs under mod->param_lock (fine: maxstep=0 body is stores +
         * vsnprintf only; higher substeps only read kernel functions). */
        WRITE_ONCE(susfs_init_laststep, -70);
        if (susfs_init_done) {
            WRITE_ONCE(susfs_init_laststep, -71);
            return 0;
        }
        (void)susfs_init_body();
        return 0;
    }

    /* v42 deferred channel: BARE schedule_work + ret. */
    schedule_work(&susfs_init_work);
    return 0;
}

module_param_call(force_init, susfs_param_set_force_init, NULL, &susfs_force_init_val, 0200);

/* v26.11.42: the READ-path dispatch channel ("probe").  susfs_param_get_probe
 * is module code invoked from param_attr_show - the sysfs READ path - which
 * no module code has ever executed through on this box.  Writing probe_arm=1
 * (a STANDARD int param: pure kernel param_ops_int code) arms the dispatch;
 * the next `cat .../parameters/probe` then schedules the deferred kworker
 * and returns its value.  boot-completed.sh uses this when
 * /data/adb/ReSuSFS/trigger_mode contains "get" - splitting "the sysfs
 * WRITE path" from "module code execution" as suspects: if the get-channel
 * dispatch survives a boot that the set-channel froze, the write path
 * itself is implicated; if both freeze identically, it is module code
 * execution or the machinery common to both. */
static int susfs_probe_arm;
module_param_named(probe_arm, susfs_probe_arm, int, 0644);

static int susfs_probe_val;

static int susfs_param_get_probe(char *buffer, const struct kernel_param *kp)
{
    /* Store first, dispatch second: the -60 receipt distinguishes "probe .get
     * entered" from "dispatch attempted" for the read channel exactly like
     * -50 does for the kworker. */
    WRITE_ONCE(susfs_init_laststep, -60);
    if (susfs_probe_arm && !susfs_init_done)
        schedule_work(&susfs_init_work);
    return scnprintf(buffer, PAGE_SIZE, "%d\n", susfs_probe_val);
}

module_param_call(probe, NULL, susfs_param_get_probe, &susfs_probe_val, 0444);

/* v26.11.42 note on .gnu.linkonce.this_module ABI: no in-source padding -
 * the compiler's emission order inside a linkonce section is not guaranteed
 * enough to safely append bytes after __this_module.  ABI correctness comes
 * from the BUILD TREE instead: the "android13" candidate is built against
 * the a13 ASB-2025-03 tree whose struct module IS the running kernel's
 * (0x340, scmversion + KABI reserves), and the "vanilla" candidate keeps
 * the kernel.org 0x300 section of the v35-v37 images whose 0x40-byte
 * overflow into .bss was field-proven benign on the gcc layout.  The build
 * scripts verify the section size of every shipped image. */

/* v26.11.34: init_done — readable proof that susfs_init_body completed.
 * post-fs-data.sh polls this after the load; 1 = init ran to the end. */
module_param_named(init_done, susfs_init_done, int, 0444);

static void __exit susfs_exit(void)
{
    susfs_layers_down((int)ARRAY_SIZE(susfs_layers) - 1);
    SUSFS_LOGI("susfs_guard_lkm: exit\n");
}

module_init(susfs_init);
module_exit(susfs_exit);
MODULE_LICENSE("GPL");

/* The VFS symbol namespace of this kernel's GKI builds.
 *
 * Four symbols this module imports - kern_path and ihold (fs/), override_creds and
 * revert_creds (kernel/cred.c) - are exported as
 * EXPORT_SYMBOL_NS(sym, ANDROID_GKI_VFS_EXPORT_ONLY), and the Android build maps that
 * name to the long string below with a per-directory ccflag before the compiler
 * stringifies it (fs/Makefile: subdir-ccflags-y += -DANDROID_GKI_VFS_EXPORT_ONLY=...,
 * plus kernel/Makefile for cred.o on some releases).  A module that does not import the
 * RESULTING string is refused by the kernel's module loader with
 *   "module uses symbol (kern_path) from namespace VFS_internal_... but does not import
 *    it"  ->  "Unknown symbol kern_path (err -22)"
 * which is why plain insmod failed on the phone before this line existed.
 *
 * The long form must be written out literally: MODULE_IMPORT_NS(ns) stringifies its
 * argument, so passing the macro name ANDROID_GKI_VFS_EXPORT_ONLY would import a
 * namespace that no kernel ever creates.  (Measured on the built .ko: .modinfo carried
 * no import_ns entry at all.)
 *
 * v6.13 turned that upside down: "module: Convert symbol namespace to string literal"
 * (upstream cdd30ebb1b9f, also in the Android common trees) made the macro's argument a
 * STRING LITERAL, so the old token form now stringifies into "\"VFS_...\"" and the import
 * is refused.  Both spellings are kept below and chosen by version, so the same source
 * builds from 5.10 through 6.18.
 *
 * Note this is necessary but NOT sufficient for plain insmod: further symbols we
 * reference are not in the kernel's export table in any of the six supported GKI
 * variants (kallsyms_lookup_name and friends, saved_boot_config, task_work_add, init_mm,
 * __set_fixmap, copy_to_kernel_nofault), so loading without a
 * helper still needs those to be resolved at runtime.  The userspace loader
 * (tools/susfs_insmod.c) sidesteps the whole question by rewriting undefined symbols to
 * absolute addresses, exactly as KernelSU's ksud does - see README. */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
MODULE_IMPORT_NS("VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver");
#else
MODULE_IMPORT_NS(VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver);
#endif
MODULE_DESCRIPTION("SUSFS guard LKM (susfs_guard_lkm) v2.3.1-gki");
