// SPDX-License-Identifier: GPL-2.0
/* v26.11.25: neutralize the CONFIG_MODVERSIONS "module_layout" gate - the wall
 * v26.11.24 hit on LDPlayer 14 (5.15.178+, Android 14).
 *
 * What happened there: init_module(2) returned ENOEXEC (8) with the kernel
 * printing NOTHING - no "Unknown symbol", no "version magic ... should be".
 * Walking every -ENOEXEC path in 5.15's kernel/module.c leaves exactly one
 * silent one: check_modstruct_version() -> check_version() with a module that
 * has no __versions section at all (this port's build used CONFIG_MODVERSIONS=n
 * while the target kernel - an Android 14 GKI-style build - has it =y and
 * exports module_layout with a CRC). check_version() then does:
 *
 *	if (versindex == 0)                       <- our module: no __versions
 *		return try_to_force_load(mod, symname) == 0;
 *
 * and try_to_force_load() ends in `#else return -ENOEXEC; #endif` when
 * CONFIG_MODULE_FORCE_LOAD is off - the single unprinted failure in the whole
 * loader. That is exactly "init_module failed without vermagic mismatch /
 * Exec format error (os error 8)", and it fires BEFORE simplify_symbols(), so
 * not even "Unknown symbol" lines appear.
 *
 * The kernel's own escape hatch is two paragraphs below in check_version():
 * a module whose __versions section EXISTS but contains no entry for the
 * looked-up name only earns
 *	pr_warn_once("%s: no symbol version for %s\n", ...)
 * and then `return 1` - ACCEPTED. (Same for every imported name: CRC checks
 * degrade to a warn-once + accept, and resolution falls back to the export
 * table by name - which is precisely what this port wants, since its imports
 * are absolutized from /proc/kallsyms or resolved by name anyway.)
 *
 * So this object pins exactly ONE entry whose name never matches any import,
 * and the gate passes on every kernel - MODVERSIONS or not (on a
 * CONFIG_MODVERSIONS=n kernel check_version() is a `return 1` stub and the
 * section is inert). The post-build normalizer (tools/normalize_modver.py)
 * then rewrites the section to contain ONLY this entry, so a build against a
 * tree with a full Module.symvers (which would add a real module_layout CRC
 * computed against THIS tree's struct module - a value that only matches the
 * exact kernel it was built against) can never smuggle a disagreeing CRC back
 * in.
 *
 * Side effects, on purpose: the __versions section makes
 * same_magic(..., has_crcs=true) skip the kernel-release word of vermagic,
 * so the 5.15.178+ part stops mattering - and this build also enables
 * CONFIG_MODVERSIONS so the vermagic carries the "modversions" word that the
 * target (a MODVERSIONS kernel, per the diagnosis above) expects after it.
 */

#include <linux/module.h>
#include <linux/init.h>

static const struct modversion_info ____resusfs_modversions[] __used __section("__versions") = {
	{ .crc = 0, .name = "__resusfs_neutral" },
};
