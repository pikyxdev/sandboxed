// SPDX-License-Identifier: GPL-2.0
/*
 * susfs_supercall.c - SUSFS supercall dispatcher
 * (v49: live sys_call_table entry with a replicated kCFI type-hash preamble).
 *
 * THE v49 FIELD VERDICT (the five v48 boots, 2026-11-24 11:00-11:11):
 * v48's table transport installed cleanly, init returned 0, and EVERY boot
 * died 2-5s later - the last boot.log line each time was "supercall
 * self-test starting", i.e. the box died at the FIRST syscall(173) ever
 * dispatched through sys_call_table[173] = susfs_sc_entry (the v47 boots
 * x9/x10 prove the same call site is safe with the ORIGINAL entry: the
 * 173-riding CLI ran there and returned -EINVAL three times per boot).
 * The discriminator between "original entry survives" and "our entry
 * dies on first call" is the TARGET of the indirect call
 * ksu_syscall_table[nr](regs): this clang-17 LTO kernel enforces kCFI
 * (kallsyms carries is_cfi_preamble_symbol and cfi_suffix, the kCFI
 * kallsyms machinery), and KernelSU-Next's LIVE dispatch wrapper
 * my_x64_sys_call (kernel/hook/x86_64/syscall_hook.c) is NOT __nocfi -
 * its table dispatch is type-checked, and every legitimate entry carries
 * the 4-byte type hash immediately BEFORE its address.  v48 installed a
 * GCC raw-asm thunk with NO preamble: the first dispatch read
 * [susfs_sc_entry - 4] (arbitrary module text), the compare failed, the
 * kernel died - five out of five boots, exactly at the self-test, and
 * nowhere else.  (my_do_syscall_64, the alternative KSU patch target,
 * IS __nocfi - but the field proves the checked my_x64_sys_call path is
 * the live one on this box; the v49 entry satisfies BOTH shapes.)
 *
 * THE v49 FIX: susfs_sc_entry now has a 4-byte kCFI preamble slot
 * immediately before it (susfs_sc_kcfi_preamble, in module .text).  At
 * install time the module reads the 4 bytes at [original table entry - 4]
 * - by construction the exact type hash this call site checks against -
 * cross-samples sibling entries for the receipt, replicates the hash
 * into its own preamble through ksu_patch_text (fixmap write; module
 * .text is RO after load), verifies the readback, and only then patches
 * the table entry.  On a kernel WITHOUT kCFI the replicated word is
 * inert dead bytes before the entry (never executed), so the transport
 * is safe under both CFI regimes.
 *
 * Everything else is the v48 transport, whose premise the field upheld:
 * the table IS the live dispatch path on this kernel (KernelSU-Next
 * BUILT IN with CONFIG_KSU_X86_PATCH_SYSCALL_DISPATCHER; ksu_syscall_
 * dispatcher found IN the table), the v47 dispatcher-arm redirect sat in
 * dead code, and x64_sys_call's own body is bypassed by KSU's entry
 * patch - which is exactly why patching its arms (v47) or trusting
 * __nocfi annotations on do_syscall_64 (v48's assumption) both missed.
 * The fp_hook layer's field-proven entry patcher (publish-orig, write,
 * verify, restore) does the write; a pre-patch liveness check proves the
 * table is the live path by finding ksu_syscall_dispatcher IN it.  The
 * wrapper itself is UNCHANGED and now runs in real syscall process context
 * as the direct callee of my_do_syscall_x64 - same signature the table
 * entries have (long (*)(const struct pt_regs *)), answer in payload.err and
 * the return value, passthrough to the saved original entry.  The v47 arm
 * scan stays compiled in as a FALLBACK for a hypothetical kernel where the
 * table turns out inert (both KSU dispatcher patches failed); on this box
 * the table path arms first.
 *
 * The wire ABI is UNCHANGED from upstream: a root process issues
 *   syscall(NR, KSU_INSTALL_MAGIC1, SUSFS_MAGIC, cmd_id, &payload)
 * and the kernel writes payload.err back (0 = ok, else errno-style).
 * Upstream SUSFS patches kernel/reboot.c's SYSCALL_DEFINE4 to branch into
 * ksu_handle_sys_reboot(); v45's LKM substitute for that was a plain kprobe
 * on __x64_sys_reboot, and the v45 field verdict convicted it: on this box
 * KernelSU itself keeps a kprobe on that same wrapper (dmesg "KernelSU: reboot
 * kprobe registered successfully"), and a second probe on the same slot - even
 * a SukiSU-shaped plain one, even observe-only - froze the box ~1-2s after the
 * first live fire, twice, at two different stages, with the LDPlayer host
 * raising its uCountStall dialog.  v46 parked the ladder at stage 1 and defused
 * the self-test; v47 replaces the transport outright.
 *
 * THE v47 TRANSPORT - WHY THE OLD ONES ARE DEAD HERE, AND WHAT THIS ONE IS:
 *
 *   (1) sys_call_table[] entry replacement (the arm64 SUSFS/KernelSU
 *       technique, and this module's own fp_hook layer) is INERT on this
 *       kernel: since the Retbleed-era hardening (present in 5.15),
 *       arch/x86/entry/common.c does
 *           regs->ax = x64_sys_call(regs, nr);
 *       where x64_sys_call() is a direct-call switch over the syscall number
 *       (arch/x86/entry/syscall_64.c: "The sys_call_table[] is no longer used
 *       for system calls").  Writing sys_call_table[169] changes what a
 *       tracer reports, not what the CPU executes.  KernelSU's own answer to
 *       this on x86_64 is KSU_X86_PATCH_SYSCALL_DISPATCHER: "dynamically
 *       patches the hardened syscall dispatcher at runtime so the syscall hook
 *       can work" - and that is exactly the class of hook v47 ships.
 *
 *   (2) An inline hook ON __x64_sys_reboot itself would clobber the bytes
 *       KernelSU's JUMP-OPTIMIZED reboot kprobe has already rewritten
 *       ("kprobes: kprobe jump-optimization is enabled" at boot) - strictly
 *       worse than the shared slot we are retiring.
 *
 *   (3) A kprobe on any OTHER syscall is still a probe-class mechanism with a
 *       kprobe-context pre_handler: no sleeping, no copy_to_user, no way to
 *       answer in the syscall return - the whole task_work detour v45 needed.
 *
 * So v47 redirects ONE arm of the hardened dispatcher:
 *
 *   - The supercall's syscall number MOVES from reboot(2) (169, the slot
 *     KernelSU's own supercall rides, hot with its fd-install traffic) to
 *     ioperm(2) (173) - an x86-only legacy port-I/O syscall that NOTHING in
 *     Android userspace issues, whose arm in x64_sys_call() is therefore
 *     COLD: the arm is executed only when someone deliberately calls
 *     syscall(173, ...), i.e. only our own CLI.  __x64_sys_ioperm is a real
 *     standalone handler on this kernel (kallsyms 0xffffffff81027650, its own
 *     ksys_ioperm callee at 0xffffffff810274a0), not a __do_sys_ni_syscall
 *     alias.
 *   - At init the module scans kernel text [_stext, _etext] for every
 *     E8/E9 rel32 branch whose target is __x64_sys_ioperm - i.e. exactly the
 *     dispatcher's arm(s), wherever clang-LTO/BOLT laid them out (the scan is
 *     layout-independent, and covers every inlined/LTO-duplicated dispatcher
 *     copy at once; LTO's my_x64_sys_call / do_syscall_64 fragments included).
 *   - Each site's 4-byte rel32 is rewritten - through the SAME
 *     ksu_patch_text() primitive the fp_hook layer would use (phys_from_virt
 *     -> FIX_BTMAP fixmap -> copy_to_kernel_nofault under stop_machine) - to
 *     tail-jump into this module's wrapper instead of __x64_sys_ioperm.  The
 *     opcode byte (E8/E9) is not touched; the write is one 4-byte rel32.
 *   - The wrapper runs in REAL SYSCALL PROCESS CONTEXT (it IS the callee the
 *     dispatcher tail-jumps to): current is the caller, sleeping is allowed,
 *     copy_to_user works, and the wrapper's return value lands in regs->ax
 *     exactly as the original callee's would.  Magic mismatch (or non-root,
 *     or an unarmed command, or observe mode) -> tail-call the saved original
 *     handler: a genuine ioperm(2) behaves exactly as the kernel built it,
 *     and KernelSU's reboot kprobe is never touched because reboot(2) is not
 *     on this path AT ALL.  NO kprobe is registered anywhere in v47.
 *
 *   The CLI contract moves with the syscall number: ksu_susfs's nine
 *   syscall sites are patched 169 -> 173 (mov eax,0xa9 -> 0xad, same length).
 *   The payload.err answer contract is unchanged (v45 already taught the CLI
 *   to read payload.err and ignore the syscall return; v47 additionally
 *   returns 0 there, so both conventions hold).
 *
 * Bisect granularity is kept: arm_stage 2 installs the redirect in
 * OBSERVE-ONLY mode (logs susfs traffic, passes everything through - the rung
 * proves the patch + first live supercall fire); arm_stage >= 3 turns
 * acceptance on.  A wedge at stage 3 convicts the accept path alone; a clean
 * stage-2 boot proves the transport.  The shell ladder (v47 post-fs-data.sh)
 * re-opens rungs 2/3 with this transport and keeps 4/5 retired: stage 4/5
 * froze the box on their OWN layers (lsm_hook/sus_path/uname/hide_syms and
 * the (inert-on-this-kernel) sys_call_table writers), with no supercall
 * involved at all.
 *
 * The handlers keep upstream's signature `void xxx(void __user **arg)`, *arg pointing at
 * the userspace payload struct; v47 calls them directly from the wrapper
 * (process context) - the task_work answer machinery is GONE with the kprobe.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kprobes.h>         /* NOKPROBE_SYMBOL only; register/unregister_kprobe imports stay pinned by imports_guard.c */
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/cred.h>
#include <linux/syscalls.h>
#include <linux/string.h>
#include <linux/bitmap.h>
#include "susfs_abi.h"
#include "susfs_fp_hook.h"         /* susfs_syscall_fn_t; susfs_fp_init cache */
#include "patch_memory.h"          /* ksu_patch_text */
#include "symbol_resolver.h"
#include "susfs_log.h"
#include "susfs.h"

/* ---- v47 transport constants -------------------------------------------- */
#define SC_SYSCALL_NR           173 /* __NR_ioperm on x86_64 - matches the CLI patch */
#define SC_HANDLER_SYMBOL       "__x64_sys_ioperm"
/* Rel32 must fit: the module text and the kernel dispatcher are both in the
 * top canonical half, and the module region starts at MODULES_VADDR
 * (0xffffffffa0000000) - ~500MB above kernel text, well inside rel32.  The
 * check is kept so a pathological module placement refuses cleanly instead of
 * writing a wrapped displacement. */
#define SC_MAX_SITES            8   /* dispatcher arms; more than that means the scan
                                     * is matching something unexpected - refuse */

struct sc_site {
        unsigned long addr;        /* address of the E8/E9 opcode byte */
        u32 saved_rel;             /* original rel32 (restore path) */
};

static struct sc_site sc_sites[SC_MAX_SITES];
static int sc_site_count;          /* sites redirected (incl. already-ours) */
static susfs_syscall_fn_t sc_orig;  /* __x64_sys_ioperm, recovered from the arm */
static bool sc_installed;
static bool sc_full_mode;           /* arm_stage >= 3: accept + answer.  arm_stage 2: observe only. */

/* ------------------------------------------------------------------ */
/* payload handlers - UNCHANGED from v45 (upstream ABI shapes)          */
/* ------------------------------------------------------------------ */

static void susfs_show_version(void __user **arg)
{
        struct st_susfs_version info = {0};

        if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
                info.err = -EFAULT;
                goto out;
        }
        strscpy(info.susfs_version, SUSFS_VERSION_STR, SUSFS_MAX_VERSION_BUFSIZE);
        info.err = 0;
out:
        if (copy_to_user((void __user *)*arg, &info, sizeof(info)))
                pr_warn("susfs show_version copy_to_user failed\n");
}

static void susfs_show_variant(void __user **arg)
{
        struct st_susfs_variant info = {0};

        if (copy_from_user(&info, (void __user *)*arg, sizeof(info))) {
                info.err = -EFAULT;
                goto out;
        }
        strscpy(info.susfs_variant, SUSFS_VARIANT_STR, SUSFS_MAX_VARIANT_BUFSIZE);
        info.err = 0;
out:
        if (copy_to_user((void __user *)*arg, &info, sizeof(info)))
                pr_warn("susfs show_variant copy_to_user failed\n");
}

/* List every feature this LKM implements: the first line marks the source (an LKM, not a built-in
 * SUSFS) and the rest use upstream CONFIG macro names.  An entry is reported only while its layer
 * armed it (susfs_supercall_arm_feature(), called by susfs_main.c after that layer's init returned
 * 0): advertising a feature whose registration failed is the exact inconsistency a detector probes
 * for, and the same bit is what lets the command through - one registry, so the list and the
 * command table cannot disagree. */
struct feature_entry {
        const char *name;
        int feature;            /* enum susfs_feature, or -1 = always present */
};

static DECLARE_BITMAP(susfs_armed_features, SUSFS_FEAT_COUNT);

void susfs_supercall_arm_feature(enum susfs_feature feature)
{
        if ((int)feature >= 0 && feature < SUSFS_FEAT_COUNT)
                set_bit(feature, susfs_armed_features);
}

bool susfs_supercall_feature_armed(enum susfs_feature feature)
{
        return (int)feature >= 0 && feature < SUSFS_FEAT_COUNT &&
               test_bit(feature, susfs_armed_features);
}

static const struct feature_entry enabled_features[] = {
        /* First line, and deliberately not a CONFIG_* name: the caller has to be able to tell this
         * list apart from a built-in SUSFS's, whose features live in the kernel image and have a
         * different lifecycle (no load/unload, no /sys/module entry, no module parameters). */
        { "SUSFS_LKM_MODULES\n",                -1 },
        { "CONFIG_KSU_SUSFS_SUS_PATH\n",        SUSFS_FEAT_SUS_PATH },
        { "CONFIG_KSU_SUSFS_SUS_MOUNT\n",       SUSFS_FEAT_SUS_MOUNT },
        { "CONFIG_KSU_SUSFS_SUS_KSTAT\n",       SUSFS_FEAT_SUS_KSTAT },
        { "CONFIG_KSU_SUSFS_SPOOF_UNAME\n",     SUSFS_FEAT_SPOOF_UNAME },
        { "CONFIG_KSU_SUSFS_ENABLE_LOG\n",      SUSFS_FEAT_ENABLE_LOG },
        { "CONFIG_KSU_SUSFS_HIDE_KSU_SUSFS_SYMBOLS\n",  SUSFS_FEAT_HIDE_SYMS },
        { "CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG\n",     SUSFS_FEAT_SPOOF_CMDLINE },
        { "CONFIG_KSU_SUSFS_OPEN_REDIRECT\n",   SUSFS_FEAT_OPEN_REDIRECT },
        { "CONFIG_KSU_SUSFS_SUS_MAP\n",         SUSFS_FEAT_SUS_MAP },
        /* hide_modules is not upstream's, so it is not listed here - the feature itself is unchanged. */
};

/* The -ENOMEM answer for CMD_SUSFS_SHOW_ENABLED_FEATURES is the whole ABI struct (8192-byte
 * string + err), copied in one piece.  As a local it broke the 6.1/6.6 builds: "stack frame
 * size (8320) exceeds limit (2048) in 'susfs_tw_func' [-Wframe-larger-than]", an error
 * there.  As a static it is harmless - BSS-zeroed, err = -ENOMEM, same for every caller. */
static struct st_susfs_enabled_features susfs_enabled_features_nomem;

static void susfs_show_enabled_features(void __user **arg)
{
        struct st_susfs_enabled_features *info;
        size_t off = 0;
        int i;

        info = kzalloc(sizeof(*info), GFP_KERNEL);
        if (!info) {
                /* Answering nothing would leave the caller unable to tell "no memory" from
                 * "the kernel said nothing": report it in the ABI's err field. */
                susfs_enabled_features_nomem.err = -ENOMEM;
                if (copy_to_user((void __user *)*arg, &susfs_enabled_features_nomem,
                                 sizeof(susfs_enabled_features_nomem)))
                        pr_warn("susfs show_enabled_features copy_to_user failed\n");
                pr_warn_ratelimited("susfs: show_enabled_features kzalloc failed, reported -ENOMEM\n");
                return;
        }

        for (i = 0; i < ARRAY_SIZE(enabled_features); i++) {
                const char *name = enabled_features[i].name;
                size_t len = strlen(name);

                if (enabled_features[i].feature >= 0 &&
                    !susfs_supercall_feature_armed(enabled_features[i].feature))
                        continue;
                if (off + len >= SUSFS_ENABLED_FEATURES_SIZE)
                        break;
                memcpy(info->enabled_features + off, name, len);
                off += len;
        }
        info->err = 0;

        if (copy_to_user((void __user *)*arg, info, sizeof(*info)))
                pr_warn("susfs show_enabled_features copy_to_user failed\n");
        kfree(info);
}

/* The v47 equivalent of v45's susfs_tw_func(): dispatch one accepted command.
 * It runs in the WRAPPER'S process context (the caller's syscall), so the
 * handlers may kzalloc/copy_to_user directly - the task_work worker, the
 * try_module_get pin and the GFP_ATOMIC allocation are gone with the kprobe. */
static void susfs_dispatch_cmd(unsigned int cmd, void __user *payload)
{
        void __user *arg = payload;

        switch (cmd) {
        case CMD_SUSFS_SHOW_VERSION:
                susfs_show_version(&arg);
                break;
        case CMD_SUSFS_SHOW_VARIANT:
                susfs_show_variant(&arg);
                break;
        case CMD_SUSFS_SHOW_ENABLED_FEATURES:
                susfs_show_enabled_features(&arg);
                break;
        case CMD_SUSFS_ADD_SUS_PATH:
        case CMD_SUSFS_ADD_SUS_PATH_LOOP:
                /* The two commands answer a missing path differently upstream. */
                sus_path_supercall(cmd, &arg);
                break;
        case CMD_SUSFS_ADD_SUS_MAP:
                susfs_sus_map_supercall(&arg);
                break;
        case CMD_SUSFS_ADD_SUS_KSTAT:
        case CMD_SUSFS_UPDATE_SUS_KSTAT:
        case CMD_SUSFS_ADD_SUS_KSTAT_STATICALLY:
                susfs_kstat_supercall(cmd, &arg);
                break;
        case CMD_SUSFS_SET_UNAME:
                susfs_uname_supercall(&arg);
                break;
        case CMD_SUSFS_ENABLE_LOG:
                susfs_enable_log_supercall(&arg);
                break;
        case CMD_SUSFS_ENABLE_AVC_LOG_SPOOFING:
                susfs_avc_spoof_supercall(&arg);
                break;
        case CMD_SUSFS_SET_CMDLINE_OR_BOOTCONFIG:
                susfs_spoof_cmdline_supercall(&arg);
                break;
        case CMD_SUSFS_ADD_OPEN_REDIRECT:
                susfs_open_redirect_supercall(&arg);
                break;
        case CMD_SUSFS_HIDE_SUS_MNTS_FOR_NON_SU_PROCS:
                susfs_sus_mount_supercall(&arg);
                break;
        default:
                /* Unreachable: the wrapper only calls this for a command
                 * susfs_cmd_handled() accepted.  Kept as a net in case the
                 * two lists drift apart. */
                pr_warn("susfs_guard_lkm: supercall: unsupported cmd 0x%x reached the dispatcher (susfs_cmd_handled() and the switch disagree)\n",
                        cmd);
                break;
        }
}

/* Commands susfs_dispatch_cmd() above actually dispatches - keep the two in sync.
 *
 * The wrapper consults this BEFORE accepting the command: upstream answers an
 * unrecognised command with `return -EINVAL` from ksu_handle_sys_reboot()
 * (KernelSU/10_enable_susfs_for_ksu.patch:2925-2926), and reboot.c's `if (ret) goto
 * orig_flow;` falls through to the real reboot path, whose magic check rejects
 * 0xDEADBEEF/0xFAFAFAFA with -EINVAL.  Upstream writes NOTHING to payload.err then, and 126
 * (ERR_CMD_NOT_SUPPORTED) is a USERSPACE sentinel the ksu_susfs C tool pre-seeds and reads
 * back as "the kernel never handled this command" (ksu_susfs/jni/features/sus_map.c:51-53,
 * ksu_susfs/jni/includes/susfs_defs.h:16-18).  So an unknown command must NOT be hijacked:
 * answer nothing and leave payload.err at its pre-seeded value, while every command listed
 * here gets its answer written into the payload by the dispatcher.  v47 mirrors that exactly:
 * an unhandled command falls back to the original ioperm handler (which returns -EINVAL for
 * the magic-shaped arguments without touching anything), and the CLI keeps its 126.
 *
 * A command is handled only while its feature is armed, so a command for a failed non-fatal
 * layer falls through exactly like an unknown one - the same registry SHOW_ENABLED_FEATURES
 * reads, so the advertised list and the accepted commands cannot disagree. */
static int susfs_cmd_feature(unsigned int cmd)
{
        switch (cmd) {
        case CMD_SUSFS_ADD_SUS_PATH:
        case CMD_SUSFS_ADD_SUS_PATH_LOOP:
                return SUSFS_FEAT_SUS_PATH;
        case CMD_SUSFS_ADD_SUS_MAP:
                return SUSFS_FEAT_SUS_MAP;
        case CMD_SUSFS_ADD_SUS_KSTAT:
        case CMD_SUSFS_UPDATE_SUS_KSTAT:
        case CMD_SUSFS_ADD_SUS_KSTAT_STATICALLY:
                return SUSFS_FEAT_SUS_KSTAT;
        case CMD_SUSFS_SET_UNAME:
                return SUSFS_FEAT_SPOOF_UNAME;
        case CMD_SUSFS_ENABLE_LOG:
                return SUSFS_FEAT_ENABLE_LOG;
        case CMD_SUSFS_ENABLE_AVC_LOG_SPOOFING:
                return SUSFS_FEAT_AVC_SPOOF;
        case CMD_SUSFS_SET_CMDLINE_OR_BOOTCONFIG:
                return SUSFS_FEAT_SPOOF_CMDLINE;
        case CMD_SUSFS_ADD_OPEN_REDIRECT:
                return SUSFS_FEAT_OPEN_REDIRECT;
        case CMD_SUSFS_HIDE_SUS_MNTS_FOR_NON_SU_PROCS:
                return SUSFS_FEAT_SUS_MOUNT;
        default:
                return -1;
        }
}

static bool susfs_cmd_handled(unsigned int cmd)
{
        int feature;

        switch (cmd) {
        case CMD_SUSFS_SHOW_VERSION:
        case CMD_SUSFS_SHOW_VARIANT:
        case CMD_SUSFS_SHOW_ENABLED_FEATURES:
                return true;
        default:
                break;
        }

        feature = susfs_cmd_feature(cmd);
        return feature >= 0 && susfs_supercall_feature_armed(feature);
}

/* ------------------------------------------------------------------ */
/* the wrapper - the dispatcher's cold arm tail-jumps here             */
/* ------------------------------------------------------------------ */

/* The one indirect call on this path: through the recovered handler
 * address.  __nocfi noinline, the module-wide convention (tools/cfi_sites.py):
 * ksu_umount_gate.c's susfs_ksu_umount_ask() is the reference shape. */
static __nocfi noinline long sc_call_orig(const struct pt_regs *regs)
{
        return sc_orig(regs);
}
NOKPROBE_SYMBOL(sc_call_orig);

/* Runs as the tail callee of x64_sys_call's ioperm arm: REAL syscall process
 * context, current == the calling task, regs == the caller's full pt_regs
 * (di/si/dx/r10 are the four syscall(173, magic1, magic2, cmd, payload)
 * arguments), and the return value lands in regs->ax exactly as
 * __x64_sys_ioperm's would.  notrace keeps ftrace out of the entry; the
 * function is reached by a DIRECT branch from kernel text, so no landing pad
 * (endbr64) is required on this 5.15 kernel (IBT is 5.18+); the NOKPROBE
 * marker keeps a later kprobe registration on it out of the running system.
 *
 * Argument mapping (x86_64 pt_regs in syscall context):
 *   di = magic1 (0xDEADBEEF), si = magic2 (0xFAFAFAFA), dx = cmd, r10 = payload.
 * The magic values are 32-bit immediates in the CLI's variadic syscall() call:
 * only the low 32 bits of each register are defined, so the comparison is
 * 32-bit exactly like v45's `(int)real->di` was. */
asmlinkage notrace long susfs_sc_wrapper(const struct pt_regs *regs)
{
        unsigned int magic1, magic2, cmd;
        void __user *payload;

        /* v26.11.31 DIAGNOSTIC, kept: incremented per wrapper entry (= per
         * ioperm(2) syscall reaching the dispatcher) so userspace can see
         * the arm is live.  Atomic-safe, process context. */
        susfs_diag_sc_entry_hit();

        magic1 = (unsigned int)regs->di;
        magic2 = (unsigned int)regs->si;
        cmd = (unsigned int)regs->dx;
        payload = (void __user *)regs->r10;

        /* Not a susfs supercall: a genuine ioperm(2) call (nothing on this
         * box issues one, but correctness first), a KernelSU supercall on
         * its own numbers, or a non-root caller.  Tail-call the original
         * handler - identical behaviour to the unpatched arm. */
        if (magic1 != KSU_INSTALL_MAGIC1)
                return sc_call_orig(regs);
        if (magic2 != SUSFS_MAGIC)
                return sc_call_orig(regs);
        if (current_uid().val != 0)
                return sc_call_orig(regs);

        if (!sc_full_mode) {
                /* Stage 2 (observe): the rung proves the transport under
                 * live traffic without accepting anything.  The receipt is
                 * rate-limited because a busy CLI retries; one line per
                 * burst is enough. */
                pr_err_ratelimited("susfs_guard_lkm: sc OBSERVE: susfs supercall seen (cmd=0x%x uid=%u) - stage 2 observes only, not answering\n",
                                   cmd, current_uid().val);
                return sc_call_orig(regs);
        }

        /* Our magics but an unsupported/unarmed command: fall back to the
         * original handler - upstream's "not handled" shape (payload.err
         * keeps the CLI's pre-seeded 126). */
        if (!susfs_cmd_handled(cmd)) {
                pr_err_ratelimited("susfs_guard_lkm: sc: cmd 0x%x not handled (feature not armed?)\n", cmd);
                return sc_call_orig(regs);
        }

        /* Accept: answer IN the caller's syscall, in process context.  The
         * handlers write payload.err (the ABI the v45-patched CLI reads);
         * 0 here additionally makes the syscall return meaningful. */
        susfs_dispatch_cmd(cmd, payload);
        return 0;
}
NOKPROBE_SYMBOL(susfs_sc_wrapper);

/* ------------------------------------------------------------------ */
/* v48 primary transport: the LIVE sys_call_table entry                 */
/* ------------------------------------------------------------------ */

/* The table entry is an INDIRECT call target (my_do_syscall_x64 does
 * ksu_syscall_table[nr](regs)), so the wrapper needs the landing pad
 * susfs_fp_install() demands: endbr64.  On this non-IBT 5.15 it decodes as
 * a 4-byte no-op; if IBT ever lights up it is the required entry marker.
 * Emitted as raw bytes so any assembler takes it; the thunk is 2 instructions
 * and jmp's straight into the (unchanged) C wrapper above.
 *
 * v49: the 4 bytes IMMEDIATELY BEFORE the entry are the kCFI type-hash
 * preamble slot.  kCFI call sites compare the expected type id against
 * [target - 4] before every indirect call; a raw-asm thunk without that
 * word trips the check on the first dispatch (the five v48 deaths).  The
 * slot is patched at install time with the hash read from the ORIGINAL
 * table entry's own preamble - the value this call site already accepts
 * - via ksu_patch_text (module .text is RO after load).  On a non-kCFI
 * kernel the word is dead bytes and the layout is harmless. */
asmlinkage notrace long susfs_sc_wrapper(const struct pt_regs *regs);
extern asmlinkage notrace long susfs_sc_entry(const struct pt_regs *regs);   /* the asm thunk above */
extern unsigned int susfs_sc_kcfi_preamble;                                 /* the 4 bytes at susfs_sc_entry - 4 */
static int sc_install_arm_scan(void);        /* the v47 fallback, defined below */

__asm__(".pushsection .text, \"ax\"\n"
        ".balign 8\n"
        ".globl susfs_sc_kcfi_preamble\n"
        ".type susfs_sc_kcfi_preamble, @object\n"
        "susfs_sc_kcfi_preamble:\n"
        "\t.long 0\n"
        ".size susfs_sc_kcfi_preamble, . - susfs_sc_kcfi_preamble\n"
        ".globl susfs_sc_entry\n"
        ".type susfs_sc_entry, @function\n"
        "susfs_sc_entry:\n"
        "\t.byte 0xf3, 0x0f, 0x1e, 0xfa\n"     /* endbr64 */
        "\tjmp susfs_sc_wrapper\n"
        ".size susfs_sc_entry, .-susfs_sc_entry\n"
        ".popsection\n");

static struct susfs_fp_hook sc_table_hook = {
        .name           = "supercall",
        .sym            = SC_HANDLER_SYMBOL,
        .nr             = SC_SYSCALL_NR,     /* 173, matches the CLI patch */
        .nr_compat      = 0,                 /* no 32-bit entry: no compat task
                                               * issues ioperm(2), and the CLI
                                               * is native-only by design */
        .wrapper        = susfs_sc_entry,
        .orig_slot      = &sc_orig,          /* passthrough reads this */
};
static bool sc_table_installed;

/* How many table entries the liveness scan reads.  The module is built
 * against vanilla 5.15.178 headers whose __NR_syscalls is the vanilla count;
 * the target table is at least that large (same KMI), and the scan is a pure
 * read, so a small over-read past the table end stays in .rodata and is
 * harmless.  512 covers every 5.15 x86_64 shape comfortably. */
#define SC_TABLE_SCAN_ENTRIES   512

static int sc_install_table(void)
{
        unsigned long table, dispatcher, entry, handler;
        unsigned long kcfi_sym;
        u32 want, have;
        int i, live = 0, disp_idx = -1, same = 0, diff = 0, err;

        table = susfs_fp_syscall_table();
        if (!table) {
                susfs_diag_logf("supercall: sys_call_table not resolved (fp layer) - table transport unavailable, falling back to the arm scan\n");
                return -ENOENT;
        }

        /* Liveness proof, in the direction that matters: KernelSU-Next's
         * ksu_syscall_hook_init() patched an __x64_sys_ni_syscall slot of
         * THIS table to ksu_syscall_dispatcher.  Finding it proves the table
         * is what the live dispatch calls through on this kernel - i.e.
         * an entry we patch is an entry the CPU executes. */
        dispatcher = ksu_kallsyms_lookup_name("ksu_syscall_dispatcher");
        if (dispatcher) {
                for (i = 0; i < SC_TABLE_SCAN_ENTRIES; i++) {
                        if (((unsigned long *)table)[i] == dispatcher) {
                                live++;
                                if (disp_idx < 0)
                                        disp_idx = i;
                        }
                }
        }

        entry = ((unsigned long *)table)[SC_SYSCALL_NR];
        handler = ksu_kallsyms_lookup_name(SC_HANDLER_SYMBOL);
        susfs_diag_logf("supercall: v49 table transport: sys_call_table at 0x%lx, table[%d]=0x%lx, kallsyms %s=0x%lx, ksu_syscall_dispatcher at 0x%lx in %d entr%s (idx %d)\n",
                        table, SC_SYSCALL_NR, entry,
                        SC_HANDLER_SYMBOL, handler, dispatcher,
                        live, live == 1 ? "y" : "ies", disp_idx);

        if (entry == (unsigned long)&susfs_sc_entry) {
                susfs_diag_logf("supercall: table[%d] already points at our entry (re-init) - transport LIVE\n",
                                SC_SYSCALL_NR);
                sc_orig = (susfs_syscall_fn_t)handler;
                sc_table_hook.installed = true;
                sc_table_installed = true;
                return 0;
        }

        if (handler && entry != handler) {
                susfs_diag_logf("supercall: table[%d] does not hold %s (0x%lx vs 0x%lx) - refusing the table transport, falling back to the arm scan\n",
                                SC_SYSCALL_NR, SC_HANDLER_SYMBOL, entry, handler);
                return -ENOENT;
        }
        if (!live) {
                susfs_diag_logf("supercall: ksu_syscall_dispatcher not found in the table - the table may be inert on this kernel, falling back to the arm scan\n");
                return -ENOENT;
        }

        /* ---- v49: replicate the kCFI type-hash preamble ----------------- */
        /* The dispatch's indirect call is type-checked on this kernel
         * (my_x64_sys_call is not __nocfi); every real entry carries the
         * 4-byte type id at [entry - 4].  The ORIGINAL entry value is,
         * by construction, a target this exact call site already accepts -
         * so its preamble IS the hash to replicate. */
        kcfi_sym = ksu_kallsyms_lookup_name("is_cfi_preamble_symbol");
        want = READ_ONCE(*(const u32 *)((const u8 *)entry - 4));
        for (i = 0; i < 6; i++) {
                unsigned long e = ((unsigned long *)table)[i];

                if (!e || e == (unsigned long)&susfs_sc_entry)
                        continue;
                if (READ_ONCE(*(const u32 *)((const u8 *)e - 4)) == want)
                        same++;
                else
                        diff++;
        }
        susfs_diag_logf("supercall: kcfi %s (is_cfi_preamble_symbol at 0x%lx); entry preamble 0x%08x (siblings same=%d diff=%d)\n",
                        kcfi_sym ? "PRESENT" : "not listed",
                        kcfi_sym, want, same, diff);

        if ((unsigned long)&susfs_sc_entry - (unsigned long)&susfs_sc_kcfi_preamble != 4) {
                susfs_diag_logf("supercall: thunk layout broken (preamble at 0x%lx, entry at 0x%lx - not adjacent) - refusing the table transport\n",
                                (unsigned long)&susfs_sc_kcfi_preamble,
                                (unsigned long)&susfs_sc_entry);
                return -EIO;
        }
        err = ksu_patch_text(&susfs_sc_kcfi_preamble, &want, sizeof(want),
                             KSU_PATCH_TEXT_FLUSH_DCACHE);
        if (err) {
                susfs_diag_logf("supercall: kcfi preamble write FAILED rc=%d - refusing the table transport\n", err);
                return err;
        }
        have = READ_ONCE(susfs_sc_kcfi_preamble);
        if (have != want) {
                susfs_diag_logf("supercall: kcfi preamble write did not stick (read 0x%08x wrote 0x%08x) - refusing the table transport\n",
                                have, want);
                return -EIO;
        }
        susfs_diag_logf("supercall: kcfi preamble replicated into the thunk (0x%08x at 0x%lx)\n",
                        want, (unsigned long)&susfs_sc_kcfi_preamble);

        err = susfs_fp_install(&sc_table_hook);
        if (err) {
                susfs_diag_logf("supercall: susfs_fp_install failed rc=%d - falling back to the arm scan\n", err);
                return err;
        }
        sc_table_installed = true;
        susfs_diag_logf("supercall: table[%d] redirected -> susfs_sc_entry (orig %s, kcfi 0x%08x, mode=%s) - the LIVE dispatch entry on this KernelSU-Next kernel\n",
                        SC_SYSCALL_NR, SC_HANDLER_SYMBOL, want,
                        sc_full_mode ? "FULL" : "OBSERVE-ONLY");
        return 0;
}

/* ------------------------------------------------------------------ */
/* the installer: find the dispatcher's ioperm arm(s), redirect them    */
/* ------------------------------------------------------------------ */

/* A branch-site candidate: an E8 (call rel32) or E9 (jmp rel32) whose
 * computed target is the handler.  Vanilla 5.15's x64_sys_call() arms compile
 * to `jmp __x64_sys_X` tail-jumps (E9); clang may emit call+jmp or E8 - both
 * are handled; a direct branch is a direct branch. */
static int sc_branch_target(unsigned long site, unsigned long *target)
{
        const u8 *b = (const u8 *)site;
        s32 rel;

        if (READ_ONCE(b[0]) != 0xE8 && READ_ONCE(b[0]) != 0xE9)
                return 0;
        memcpy(&rel, b + 1, sizeof(rel));
        *target = site + 5 + rel;
        return 1;
}

/* Scan [lo, lo+len) for E8/E9 branches targeting `handler'.  Returns the
 * number of hits, writes their addresses into out[] (at most max).  Also
 * counts every E8/E9 seen (receipts: proves the scan ran and how dense the
 * region was). */
static int sc_scan_region(unsigned long lo, unsigned long len,
                          unsigned long handler, unsigned long *out, int max,
                          unsigned long *branches_seen)
{
        unsigned long end = lo + len;
        unsigned long seen = 0, found = 0;
        const u8 *b;

        for (b = (const u8 *)lo; (unsigned long)b + 5 <= end; b++) {
                unsigned long t;

                if (READ_ONCE(b[0]) != 0xE8 && READ_ONCE(b[0]) != 0xE9)
                        continue;
                seen++;
                if (!sc_branch_target((unsigned long)b, &t))
                        continue;
                if (t != handler)
                        continue;
                if (found < (unsigned long)max)
                        out[found] = (unsigned long)b;
                found++;
        }
        *branches_seen = seen;
        return (int)found;
}

/* Rewrite one site's rel32 so the branch lands on `to' instead of its
 * original target.  The opcode byte is left alone; the 4-byte displacement
 * goes through ksu_patch_text (fixmap + copy_to_kernel_nofault under
 * stop_machine), and the write is verified by reading it back - the same
 * contract fp_patch_entry() enforces for table entries. */
static int sc_patch_site(unsigned long site, unsigned long to)
{
        u32 new_rel;
        s32 rel_check;
        int err;

        rel_check = (s32)(to - (site + 5));
        if ((unsigned long)(site + 5 + (long)rel_check) != to) {
                susfs_diag_logf("supercall: site 0x%lx -> 0x%lx does not fit a rel32 - refusing this site\n",
                                site, to);
                return -ERANGE;
        }

        new_rel = (u32)rel_check;
        err = ksu_patch_text((void *)(site + 1), &new_rel, sizeof(new_rel),
                             KSU_PATCH_TEXT_FLUSH_DCACHE);
        if (err) {
                susfs_diag_logf("supercall: ksu_patch_text FAILED for site 0x%lx rc=%d\n", site, err);
                return err;
        }

        {
                u32 readback;

                memcpy(&readback, (const void *)(site + 1), sizeof(readback));
                if (readback != new_rel) {
                        /* Nothing to roll back: a write that did not stick
                         * left the original displacement in place. */
                        susfs_diag_logf("supercall: site 0x%lx write did not stick (read 0x%x wrote 0x%x) - refusing\n",
                                        site, readback, new_rel);
                        return -EIO;
                }
        }
        return 0;
}

static int sc_restore_site(const struct sc_site *s)
{
        int err;

        err = ksu_patch_text((void *)(s->addr + 1), (void *)&s->saved_rel,
                             sizeof(s->saved_rel), KSU_PATCH_TEXT_FLUSH_DCACHE);
        if (err)
                susfs_diag_logf("supercall: restore of site 0x%lx FAILED rc=%d\n", s->addr, err);
        return err;
}

/* ---- ABI layout assertions ----
 * These sizes and `err` offsets ARE the userspace contract (ksu_susfs, ksud and
 * tools/susfs_sc compile against these numbers); a drift shows up as "the command returned
 * 0 and userspace printed garbage", not as a build error, and the repository's own
 * abi_layout_check/ harness is not wired into any build step - hence the trip wire here.
 * Values are aarch64 LP64, the only ABI shipped clients use, and match upstream's structs
 * (kernel_patches/include/linux/susfs.h). */
/* v26.11.34: __init REMOVED (was: static void __init susfs_abi_layout_check) -
 * reachable from susfs_init_body via the force_init parameter path after
 * .init.text freeing; must live in .text (BUILD_BUG_ONs evaluate at build time
 * anyway, the runtime calls are harmless plain checks). */
static void susfs_abi_layout_check(void)
{
        BUILD_BUG_ON(sizeof(struct st_susfs_sus_path) != 260);
        BUILD_BUG_ON(offsetof(struct st_susfs_sus_path, err) != 256);

        BUILD_BUG_ON(sizeof(struct st_susfs_sus_map) != 260);
        BUILD_BUG_ON(offsetof(struct st_susfs_sus_map, err) != 256);

        BUILD_BUG_ON(sizeof(struct st_susfs_sus_kstat) != 376);
        BUILD_BUG_ON(offsetof(struct st_susfs_sus_kstat, err) != 372);

        BUILD_BUG_ON(sizeof(struct st_susfs_uname) != 136);
        BUILD_BUG_ON(offsetof(struct st_susfs_uname, err) != 132);

        BUILD_BUG_ON(sizeof(struct st_susfs_log) != 8);
        BUILD_BUG_ON(offsetof(struct st_susfs_log, err) != 4);

        BUILD_BUG_ON(sizeof(struct st_susfs_avc_log_spoofing) != 8);
        BUILD_BUG_ON(offsetof(struct st_susfs_avc_log_spoofing, err) != 4);

        BUILD_BUG_ON(sizeof(struct st_susfs_hide_sus_mnts_for_non_su_procs) != 8);
        BUILD_BUG_ON(offsetof(struct st_susfs_hide_sus_mnts_for_non_su_procs, err) != 4);

        BUILD_BUG_ON(sizeof(struct st_susfs_open_redirect) != 520);
        BUILD_BUG_ON(offsetof(struct st_susfs_open_redirect, err) != 516);

        BUILD_BUG_ON(sizeof(struct st_susfs_spoof_cmdline_or_bootconfig) != 8196);
        BUILD_BUG_ON(offsetof(struct st_susfs_spoof_cmdline_or_bootconfig, err) != 8192);

        BUILD_BUG_ON(sizeof(struct st_susfs_version) != 20);
        BUILD_BUG_ON(offsetof(struct st_susfs_version, err) != 16);

        BUILD_BUG_ON(sizeof(struct st_susfs_variant) != 20);
        BUILD_BUG_ON(offsetof(struct st_susfs_variant, err) != 16);

        BUILD_BUG_ON(sizeof(struct st_susfs_enabled_features) != 8196);
        BUILD_BUG_ON(offsetof(struct st_susfs_enabled_features, err) != 8192);
}

int susfs_supercall_init(void)
{
        int err;

        susfs_diag_logf("supercall: init entered, abi_layout_check next\n");
        susfs_abi_layout_check();

        /* v45 stage split, kept verbatim: arm_stage 2 = observe (redirect
         * installed + logging, no accepts); arm_stage >= 3 = full (accept +
         * answer).  A wedge at stage 3 convicts the accept path alone; a
         * clean stage-2 boot proves the transport itself. */
        sc_full_mode = susfs_current_arm_stage() >= 3;

        /* v48: the LIVE sys_call_table entry first (this kernel dispatches
         * through the table - KernelSU-Next's own do_syscall_64 patch), the
         * v47 dispatcher-arm scan as fallback. */
        err = sc_install_table();
        if (!err) {
                sc_installed = true;
                susfs_diag_logf("supercall: transport LIVE - sys_call_table[%d] entry, mode=%s; no kprobe registered anywhere; KernelSU's reboot slot untouched\n",
                                SC_SYSCALL_NR, sc_full_mode ? "FULL" : "OBSERVE-ONLY");
                return 0;
        }
        susfs_diag_logf("supercall: table transport did not arm (rc=%d) - trying the v47 dispatcher-arm scan as fallback\n", err);
        return sc_install_arm_scan();
}

/* The v47 transport, kept as the fallback path: scan kernel text for the
 * dispatcher's direct E8/E9 arm(s) to __x64_sys_ioperm and redirect them.
 * On the v47 field box these arms were dead code (the table is the live
 * dispatch), which is exactly why this is no longer the primary. */
static int sc_install_arm_scan(void)
{
        unsigned long handler, lo, len, branches = 0;
        unsigned long hits[SC_MAX_SITES];
        unsigned long stext, etext;
        int nhits, i, err, patched;

        /* 1. the cold handler.  __x64_sys_ioperm must be a REAL standalone
         * handler (not a __do_sys_ni_syscall alias) and the CLI patch pins
         * the same syscall number, so there is deliberately no fallback
         * list: a missing ioperm refuses cleanly with receipts instead of
         * silently using a syscall the CLI does not send. */
        handler = ksu_kallsyms_lookup_name(SC_HANDLER_SYMBOL);
        if (!handler) {
                susfs_diag_logf("supercall: %s not in kallsyms - refusing (the v47 transport needs the real cold handler; the CLI patch sends syscall %d)\n",
                                SC_HANDLER_SYMBOL, SC_SYSCALL_NR);
                return -ENOENT;
        }
        sc_orig = (susfs_syscall_fn_t)handler;
        susfs_diag_logf("supercall: cold handler %s at 0x%lx (nr %d; reboot's hot slot is NOT on this path)\n",
                        SC_HANDLER_SYMBOL, handler, SC_SYSCALL_NR);

        /* 2. find the dispatcher's arm(s).  Preferred region: the whole
         * kernel text [_stext, _etext] - layout-independent under
         * clang-LTO/BOLT and it covers EVERY dispatcher copy (an LTO
         * duplicate arm in my_x64_sys_call/do_syscall_64 fragments included)
         * in one pass; every E8/E9 to the handler is by construction a
         * syscall-dispatch arm, because the wrapper is only ever called from
         * dispatch.  Fallback windows if the boundary symbols are missing. */
        stext = ksu_kallsyms_lookup_name("_stext");
        etext = ksu_kallsyms_lookup_name("_etext");
        if (stext && etext && etext > stext && etext - stext <= 0x4000000UL) {
                lo = stext;
                len = etext - stext;
                susfs_diag_logf("supercall: scanning kernel text [_stext 0x%lx, _etext 0x%lx) for E8/E9 -> %s\n",
                                stext, etext, SC_HANDLER_SYMBOL);
        } else {
                lo = ksu_kallsyms_lookup_name("x64_sys_call");
                if (!lo)
                        lo = ksu_kallsyms_lookup_name("do_syscall_64");
                if (!lo) {
                        susfs_diag_logf("supercall: no _stext/_etext and no x64_sys_call/do_syscall_64 to scan around - refusing\n");
                        return -ENOENT;
                }
                len = 0x4000;
                susfs_diag_logf("supercall: no text bounds (_stext/_etext), scanning 0x4000 window at 0x%lx\n", lo);
        }

        nhits = sc_scan_region(lo, len, handler, hits, SC_MAX_SITES, &branches);
        susfs_diag_logf("supercall: scan found %d arm(s) to %s among %lu branches\n",
                        nhits, SC_HANDLER_SYMBOL, branches);
        if (nhits <= 0) {
                /* No direct branch anywhere in kernel text: the dispatcher
                 * on this kernel would have to be a pure function-pointer
                 * table (shape the 5.15 hardening explicitly moved AWAY from,
                 * and shape the kallsyms span of x64_sys_call argues against)
                 * - refuse with the receipt that names it, v48 would patch
                 * the table entry instead. */
                susfs_diag_logf("supercall: NO direct arm to %s found - refusing (dispatcher not direct-call shaped on this kernel; send the logs)\n",
                                SC_HANDLER_SYMBOL);
                return -ENOENT;
        }
        if (nhits > SC_MAX_SITES) {
                susfs_diag_logf("supercall: %d arms found exceeds the %d-site cap - refusing (unexpected shape; send the logs)\n",
                                nhits, SC_MAX_SITES);
                return -E2BIG;
        }

        /* 3. redirect every arm.  Sites that already point at our wrapper
         * (a re-init after a partial run) are counted as live, not patched
         * twice; every other site keeps its original rel32 for the restore
         * path. */
        patched = 0;
        for (i = 0; i < nhits; i++) {
                unsigned long t;

                sc_branch_target(hits[i], &t);
                if (t == (unsigned long)&susfs_sc_wrapper) {
                        susfs_diag_logf("supercall: site 0x%lx already points at our wrapper (re-init)\n",
                                        hits[i]);
                        sc_sites[sc_site_count].addr = hits[i];
                        memcpy(&sc_sites[sc_site_count].saved_rel,
                               (const void *)(hits[i] + 1), sizeof(u32));
                        sc_site_count++;
                        continue;
                }
                if (t != handler) {
                        /* the scan guarantees this; kept as a belt for the
                         * (site, target) pair drifting between scan and patch */
                        susfs_diag_logf("supercall: site 0x%lx target 0x%lx != handler 0x%lx - skipping\n",
                                        hits[i], t, handler);
                        continue;
                }
                err = sc_patch_site(hits[i], (unsigned long)&susfs_sc_wrapper);
                if (err) {
                        /* roll back everything this init already patched */
                        while (sc_site_count > 0 && patched > 0) {
                                sc_site_count--;
                                sc_restore_site(&sc_sites[sc_site_count]);
                                patched--;
                        }
                        return err;
                }
                sc_sites[sc_site_count].addr = hits[i];
                memcpy(&sc_sites[sc_site_count].saved_rel,
                       (const void *)(hits[i] + 1), sizeof(u32));
                sc_site_count++;
                patched++;
                susfs_diag_logf("supercall: arm at 0x%lx redirected -> susfs_sc_wrapper (orig %s, mode=%s)\n",
                                hits[i], SC_HANDLER_SYMBOL,
                                sc_full_mode ? "FULL" : "OBSERVE-ONLY");
        }

        sc_installed = true;
        susfs_diag_logf("supercall: transport LIVE - %d arm(s) redirected (patched %d), mode=%s; no kprobe registered anywhere; KernelSU's reboot slot untouched\n",
                        sc_site_count, patched, sc_full_mode ? "FULL" : "OBSERVE-ONLY");
        return 0;
}

/* True whenever the transport is armed - susfs_main.c's post-load note keys
 * off this.  The v45 name said 'kprobe'; v47 has none, so the name says what
 * it now means. */
bool susfs_supercall_transport_active(void)
{
        return sc_installed;
}

void susfs_supercall_exit(void)
{
        int i, err;

        if (!sc_installed)
                return;
        if (sc_table_installed) {
                susfs_fp_remove(&sc_table_hook);
                susfs_diag_logf("supercall: sys_call_table[%d] entry restored\n",
                                SC_SYSCALL_NR);
                sc_table_installed = false;
        }
        for (i = 0; i < sc_site_count; i++) {
                err = sc_restore_site(&sc_sites[i]);
                if (err)
                        continue;       /* logged; keep restoring the rest */
                susfs_diag_logf("supercall: arm at 0x%lx restored\n", sc_sites[i].addr);
        }
        sc_site_count = 0;
        sc_installed = false;
}
