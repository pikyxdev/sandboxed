/* SPDX-License-Identifier: GPL-2.0 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kallsyms.h>
#include <linux/string.h>
#include <linux/version.h>

#include "symbol_resolver.h"
#include "susfs_log.h"
#include "susfs.h"              /* v26.11.37: susfs_diag_logf - resolver phase crumbs into diag_log */

#include "kallrecon/lib/core.h"
#include "kallrecon/lib/hint.h"
#include "kallrecon/lib/slide.h"
#include "kallrecon/lib/symbol.h"
#include "kallrecon/lib/variant.h"

#define KR_SCAN_BACK    0x400000UL
#define KR_SCAN_FWD     0x200000UL
#define KR_TIMEOUT_MS   10000

#define KR_NAME_MAX     256
#define KR_ALL_MAX      8

static bool kr_ready;

/* ---- v26.11.40 kln (direct function-pointer) mode ---------------------
 *
 * The v39 field result: the LDPlayer kernel's kallsyms listing carries NONE
 * of the kallsyms TABLE variables (kallsyms_offsets / _names /
 * _token_table / ... - the clang-LTO+trim build removed them from the
 * symbol table), so the table seed can never be built there and a seeded
 * resolver could only ever refuse.  But the listing DOES carry the
 * functions this module actually needs:
 *   kallsyms_lookup_name  (name -> address;  NOT an EXPORT, cannot be an import)
 *   sprint_symbol         (address -> "name+off/size"; already a resolved import)
 * so the seed now also accepts
 *   kln=0x<addr>   kallsyms_lookup_name's address (validated below)
 *   gsoff=0x<off>  current_task's per-CPU offset (consumed by susfs_current_init)
 * and in kln mode every lookup routes through the kernel's own
 * kallsyms_lookup_name - the same function the kernel itself uses.  No
 * table walk, no memory scan, no kallrecon involvement at all.
 *
 * Single-writer by construction: only the deferred-init kworker reaches
 * this (init_maxstep >= 2). */
static bool kr_kln_mode;
static unsigned long kr_kln_fn;
static unsigned long kr_gsoff_seed_val;

unsigned long ksu_kr_gsoff_seed(void)
{
        return kr_gsoff_seed_val;
}

/* __nocfi noinline: an indirect call into kernel text through a seed-supplied
 * pointer, exactly like the kr_klp wrapper it replaces. */
static __nocfi noinline unsigned long kr_kln_call(const char *name)
{
        unsigned long (*fn)(const char *) = (void *)kr_kln_fn;

        if (!kr_kln_fn)
                return 0;
        return fn(name);
}

/* Does sprint_symbol(buf, addr) name the symbol `name' (at any offset)?  Used
 * by the kln-mode variants of ksu_symbol_is_start / ksu_addr_is_named /
 * ksu_symbol_name_of; the imported sprint_symbol is used, so no new import
 * appears.  Tolerant of the same suffix forms the table walk accepted:
 * `name' followed by end-of-string, '.', or '$', excluding ".cfi_jt". */
static int kr_spr_names(unsigned long addr, const char *name,
                         char *buf, size_t bufsz)
{
        char *plus;
        size_t len;

        if (!sprint_symbol(buf, addr))
                return 0;
        plus = strchr(buf, '+');
        if (plus)
                *plus = '\0';
        len = strlen(name);
        if (strlen(buf) < len)
                return 0;
        if (strncmp(buf, name, len))
                return 0;
        if (buf[len] && buf[len] != '.' && buf[len] != '$')
                return 0;
        if (strstr(buf + len, ".cfi_jt"))
                return 0;
        return 1;
}

static bool kr_layout_ready(void)
{
        return klnum_val && kloffs_addr && klnames_addr;
}

static __nocfi noinline unsigned long kr_klp(const char *name)
{
        return kallrecon_klp(name);
}

static const char *(*kr_lookup_fn)(unsigned long addr, unsigned long *symbolsize,
                                   unsigned long *offset, char **modname, char *namebuf);

static __nocfi noinline const char *kr_lookup(unsigned long addr, char **modname, char *buf)
{
        return kr_lookup_fn(addr, NULL, NULL, modname, buf);
}

unsigned long find_kernel_symbol_exact_any(const char *symbol_name)
{
        if (!symbol_name || !symbol_name[0])
                return 0;

        /* v26.11.40 kln mode: the kernel's own lookup function, seeded. */
        if (kr_kln_mode)
                return kr_kln_call(symbol_name);

        if (!kr_ready || !kallrecon_klp)
                return 0;

        return kr_klp(symbol_name);
}

unsigned long ksu_kallsyms_lookup_name(const char *name)
{
        return find_kernel_symbol_exact_any(name);
}

unsigned long find_kernel_symbol_exact(const char *symbol_name)
{
        unsigned long addr;
        char buf[KSYM_SYMBOL_LEN];
        char *mod = NULL;

        addr = find_kernel_symbol_exact_any(symbol_name);
        if (!addr)
                return 0;

        /* kln mode: the kernel's kallsyms_lookup_name only answers for core
         * kernel symbols, so the module check below is unnecessary; the
         * imported sprint_symbol still validates the name matches. */
        if (kr_kln_mode) {
                if (!kr_spr_names(addr, symbol_name, buf, sizeof(buf)))
                        return 0;
                return addr;
        }
        if (!kr_lookup_fn)
                return 0;

        if (!kr_lookup(addr, &mod, buf))
                return 0;

        if (mod) {
                susfs_diag_logf("ignore symbol %s of module %s\n", symbol_name, mod);
                return 0;
        }

        return addr;
}

void *ksu_resolve_symbol_for_functable_hook(const char *symbol_name)
{
        unsigned long addr;

        if (!kr_ready || !symbol_name || !symbol_name[0])
                return NULL;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
        addr = find_kernel_symbol_exact(symbol_name);
        if (!addr)
                addr = kallrecon_find_variant(symbol_name, 0);
#else
        {
                char cfi_name[KSYM_NAME_LEN];

                snprintf(cfi_name, sizeof(cfi_name), "%s.cfi_jt", symbol_name);
                addr = find_kernel_symbol_exact(cfi_name);
                if (!addr)
                        addr = kallrecon_find_variant(symbol_name, 1);
                if (!addr)
                        addr = find_kernel_symbol_exact(symbol_name);
        }
#endif

        return addr ? (void *)addr : NULL;
}

struct kr_collect {
        unsigned long *addrs;
        int max;
        int n;
};

static void kr_collect_add(struct kr_collect *c, unsigned long addr)
{
        int i;

        if (!addr)
                return;
        for (i = 0; i < c->n; i++)
                if (c->addrs[i] == addr)
                        return;
        if (c->n < c->max)
                c->addrs[c->n++] = addr;
}

int ksu_find_symbol_all(const char *name, unsigned long *addrs, int max)
{
        struct slide_win w;
        struct kr_collect c = { .addrs = addrs, .max = max };
        char nbuf[KR_NAME_MAX];
        unsigned int idx = 0;
        int retried = 0;

        if (!kr_ready || !name || !name[0] || !addrs || max <= 0)
                return 0;

        mutex_lock(&ks_linear_lock);
        if (safe_read(ti_buf, (void *)klindex_addr, sizeof(ti_buf)) ||
            safe_read(tt_buf, (void *)kltable_addr, sizeof(tt_buf)) ||
            slide_init(&w, klnames_addr, KS_WIN_SIZE, KS_WIN_MARGIN))
                goto out;

        while (idx < klnum_val) {
                const unsigned char *enc = slide_ptr(&w, slide_buf);
                unsigned int len = enc[0];
                unsigned int hdr = 1;

                if (len & 0x80) {
                        len = (len & 0x7f) | (enc[1] << 7);
                        hdr = 2;
                }

                if (len > KR_NAME_MAX || w.off + hdr + len > w.valid) {
                        if (retried || slide_advance(&w, (w.valid - w.off) + 4))
                                break;
                        retried = 1;
                        continue;
                }
                retried = 0;

                if (ks_expand_raw(enc, ti_buf, tt_buf, nbuf, sizeof(nbuf)) &&
                    !strcmp(nbuf, name))
                        kr_collect_add(&c, sym_addr((int)idx));

                if (slide_advance(&w, hdr + len))
                        break;
                idx++;
        }

out:
        mutex_unlock(&ks_linear_lock);
        return c.n;
}

int ksu_symbol_name_of(unsigned long addr, char *buf, char **module_out)
{
        char *mod = NULL;

        if (module_out)
                *module_out = NULL;
        if (!buf)
                return -EINVAL;
        buf[0] = '\0';
        if (!kr_ready)
                return -ENOSYS;
        if (!addr)
                return -EINVAL;

        if (kr_lookup_fn) {
                if (!kr_lookup(addr, &mod, buf))
                        return -ENOENT;
                if (module_out)
                        *module_out = mod;
                return (int)strlen(buf);
        }

        /* v26.11.40 kln mode: the imported sprint_symbol is the name source
         * (no table walk exists in this mode). */
        if (kr_kln_mode) {
                if (!sprint_symbol(buf, addr))
                        return -ENOENT;
                return (int)strlen(buf);
        }

        if (sym_name_at(addr, buf, KSYM_SYMBOL_LEN) < 0)
                return -ENOENT;

        return (int)strlen(buf);
}

/* v26.11.40: kln-mode name-at-address check - start means offset 0. */
static int kr_kln_is_start(unsigned long addr, const char *name)
{
        char buf[KSYM_SYMBOL_LEN];
        char *plus;
        int off;

        if (!sprint_symbol(buf, addr))
                return 0;
        plus = strchr(buf, '+');
        if (!plus)
                return 0;
        *plus = '\0';
        off = 0;
        /* the offset after '+' is always "0x..." - start means it is 0x0 */
        if (strncmp(plus + 1, "0x0", 3) == 0 &&
            (plus[4] == '/' || plus[4] == '\0' || plus[4] == '\n'))
                off = 1;
        if (!off)
                return 0;
        return kr_spr_names(addr, name, buf, sizeof(buf));
}

int ksu_symbol_is_start(unsigned long addr, const char *name)
{
        char buf[KSYM_SYMBOL_LEN];
        size_t len, nlen;
        int idx;

        if (!kr_ready || !addr || !name || !name[0])
                return 0;

        /* v26.11.40 kln mode: name-at-address via the imported sprint_symbol
         * (the table walk does not exist in this mode). */
        if (kr_kln_mode)
                return kr_kln_is_start(addr, name);

        len = strlen(name);
        if (len >= sizeof(buf))
                return 0;

        idx = sym_name_at(addr, buf, sizeof(buf));
        nlen = strlen(buf);
        if (idx >= 0 && sym_addr(idx) == addr && nlen >= len &&
            !strncmp(buf, name, len) &&
            (!buf[len] || buf[len] == '.' || buf[len] == '$') &&
            !strstr(buf + len, ".cfi_jt"))
                return 1;

        return ksu_addr_is_named(addr, name);
}

int ksu_addr_is_named(unsigned long addr, const char *name)
{
        unsigned long addrs[KR_ALL_MAX];
        int n, i;

        if (!kr_ready || !addr || !name || !name[0])
                return 0;

        if (kr_kln_mode) {
                /* first-match only: the kernel's kallsyms_lookup_name returns
                 * one address; the duplicate/variant names the table walk
                 * enumerates (".llvm.<hash>", ".cfi_jt") are not distinguishable
                 * here.  For the import crosscheck this is sufficient: a name
                 * kallsyms resolves is the one the loader used. */
                char buf[KSYM_SYMBOL_LEN];

                return kr_spr_names(addr, name, buf, sizeof(buf));
        }

        n = ksu_find_symbol_all(name, addrs, (int)ARRAY_SIZE(addrs));
        for (i = 0; i < n; i++)
                if (addrs[i] == addr)
                        return 1;

        return 0;
}

/* v26.11.34: __init REMOVED (was: int __init ksu_init_symbol_resolver) - this is
 * reachable from susfs_init_body via the force_init parameter path AFTER the
 * kernel freed .init.text; calling it there executed freed pages (v26.11.33
 * boot hang at 50%). It must live in .text. */
/* v26.11.38: SEEDED resolver.  The v26.11.37 result - a wedge at stage 0,
 * where the armed kernel-side work was imports_guard, this resolver's
 * auto-discovery SCAN, and the DIAG printk - leaves the scan itself as a
 * live suspect: it is the only unbounded-ish, layout-guessy kernel-side work
 * at that stage, never live-tested on this LTO/PGO/BOLT kernel.
 *
 * The kernel's own kallsyms TABLE ADDRESSES are public in /proc/kallsyms
 * (kallsyms_offsets / kallsyms_addresses, kallsyms_relative_base,
 * kallsyms_num_syms, kallsyms_names, kallsyms_markers,
 * kallsyms_token_table, kallsyms_token_index), so userspace greps them out
 * and seeds them here BEFORE writing force_init:
 *   echo "names=0x... offsets=0x... relative_base=0x... num_syms=0x... \
 *         markers=0x... token_table=0x... token_index=0x..." \
 *        > /sys/module/susfs_guard_lkm/parameters/kr_seed
 * With a complete seed kallrecon only VALIDATES each table with bounded
 * safe_read calls (the hint fields are consumed by
 * hint_commit_offsets / resolve_layout_v2 etc.); it never scans.
 *
 * Without a seed the resolver now REFUSES (-ENODATA) instead of scanning.
 * The old 2x10s auto-discovery is kept behind kr_scan=1 for manual use
 * only - it is the thing v26.11.37 was still arming blind. */

static char susfs_kr_seed[1024];
module_param_string(kr_seed, susfs_kr_seed, sizeof(susfs_kr_seed), 0644);

static int susfs_kr_scan;
module_param_named(kr_scan, susfs_kr_scan, int, 0644);

/* hand-rolled hex parser: sscanf is not exported on every kernel this
 * module targets, and strsep is avoided to keep the import list unchanged */
static int kr_parse_hex(const char *s, unsigned long *out)
{
        unsigned long v = 0;
        int n = 0;

        if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
                s += 2;
                if (!s[0])
                        return 0;
        }
        while (*s) {
                char c = *s++;
                unsigned long d;

                if (c >= '0' && c <= '9')
                        d = c - '0';
                else if (c >= 'a' && c <= 'f')
                        d = c - 'a' + 10;
                else if (c >= 'A' && c <= 'F')
                        d = c - 'A' + 10;
                else
                        return 0;
                v = (v << 4) | d;
                if (++n > 16)
                        return 0;
        }
        if (!n)
                return 0;
        *out = v;
        return 1;
}

/* parse "key=0xVAL key=0xVAL ..." out of the kr_seed param buffer into a
 * kallrecon hint.  Single writer by construction (only the deferred-init
 * kworker reaches the resolver).  Returns the number of recognized fields.
 * v26.11.40: kln= (kallsyms_lookup_name address) and gsoff= (current_task
 * per-CPU offset) are parsed first; they are not kallrecon hint fields. */
static int kr_seed_parse(struct kallrecon_hint *h)
{
        static char buf[1024];
        char *tok, *p;
        int got = 0;

        kr_kln_fn = 0;
        kr_gsoff_seed_val = 0;

        if (!susfs_kr_seed[0])
                return 0;
        strncpy(buf, susfs_kr_seed, sizeof(buf) - 1);
        buf[sizeof(buf) - 1] = '\0';

        p = buf;
        for (;;) {
                char *eq;

                while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r' || *p == ',')
                        p++;
                if (!*p)
                        break;
                tok = p;
                while (*p && *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r' && *p != ',')
                        p++;
                if (*p)
                        *p++ = '\0';

                eq = strchr(tok, '=');
                if (!eq) {
                        susfs_diag_logf("resolver: kr_seed token '%s' has no '=' - ignored\n", tok);
                        continue;
                }
                *eq = '\0';
                {
                        unsigned long v;

                        if (!kr_parse_hex(eq + 1, &v)) {
                                susfs_diag_logf("resolver: kr_seed field '%s' is not hex - ignored\n", tok);
                                continue;
                        }
                        if (!strcmp(tok, "names"))
                                { h->names = v; got++; }
                        else if (!strcmp(tok, "offsets"))
                                { h->offsets = v; got++; }
                        else if (!strcmp(tok, "addresses"))
                                { h->offsets = v; got++; } /* v1 absolute layout */
                        else if (!strcmp(tok, "relative_base"))
                                { h->relative_base = v; got++; }
                        else if (!strcmp(tok, "num_syms"))
                                { h->num_syms = v; got++; }
                        else if (!strcmp(tok, "markers"))
                                { h->markers = v; got++; }
                        else if (!strcmp(tok, "token_table"))
                                { h->token_table = v; got++; }
                        else if (!strcmp(tok, "token_index"))
                                { h->token_index = v; got++; }
                        else if (!strcmp(tok, "seqs"))
                                { h->seqs = v; got++; }
                        /* v26.11.40 kln seed fields */
                        else if (!strcmp(tok, "kln"))
                                { if (v) kr_kln_fn = v; }
                        else if (!strcmp(tok, "gsoff"))
                                { if (v) kr_gsoff_seed_val = v; }
                        else
                                susfs_diag_logf("resolver: unknown kr_seed field '%s' - ignored\n", tok);
                }
        }
        return got;
}

/* v26.11.40 kln mode floor: same as imports_guard's SUSFS_IMPORT_ADDR_MIN
 * (kernel text/data on x86_64 sits above 0xff00000000000000; user addresses
 * and zeros sit below) - kept local so this translation unit does not depend
 * on imports_guard.c's macro. */
#define KR_ADDR_FLOOR 0xff00000000000000UL

/* v26.11.44: the probe candidates.  The v26.11.43 field result (LDPlayer 14,
 * GKI-style 5.15.178+ clang-17 LTO build): this kernel's /proc/kallsyms lists
 * _printk at ffffffff810b6d00 and vprintk at ffffffff810b9de0 but has ZERO
 * "printk" lines - the old probe asked for a name this kernel does not have,
 * kln correctly answered 0x0, and the resolver refused a WORKING kln (the
 * seed kln=ffffffff810fd360 had already passed sprint_symbol validation as
 * kallsyms_lookup_name itself).  Probe _printk first (the GKI 5.15 reality),
 * then printk (vanilla kernels), then vprintk; the first hit proves the
 * function answers.  The crosscheck tolerates names kallsyms does not list
 * (it skips them), so no other site needs this. */
static const char * const kr_kln_probe_names[] = {
        "_printk", "printk", "vprintk", NULL
};

/* v26.11.40: activate and validate kln mode.  The seed's kln= address is
 * checked by asking the IMPORTED sprint_symbol what lives at that address:
 * it must be kallsyms_lookup_name itself ("name+0x0/...").  A wrong or
 * stale kallsyms snapshot fails this and the resolver refuses - never a
 * silent wrong-function pointer.  Then one probe lookup (a printk-family
 * text symbol every kernel has under SOME name) proves the function
 * answers.  Returns 0 on success. */
static int kr_kln_activate(void)
{
        char buf[KSYM_SYMBOL_LEN];
        unsigned long probe = 0;
        const char *hit = NULL;
        int pi;

        if (!kr_kln_fn) {
                susfs_diag_logf("resolver: kr_seed has no kln= - no kln mode\n");
                return -ENODATA;
        }
        if (kr_kln_fn < KR_ADDR_FLOOR) {
                susfs_diag_logf("resolver: kln=0x%lx is not a kernel address - refusing (bad seed)\n", kr_kln_fn);
                return -ENODATA;
        }
        if (!sprint_symbol(buf, kr_kln_fn)) {
                susfs_diag_logf("resolver: kln validation: sprint_symbol failed - refusing\n");
                return -ENODATA;
        }
        if (strncmp(buf, "kallsyms_lookup_name", strlen("kallsyms_lookup_name"))) {
                susfs_diag_logf("resolver: kln validation FAILED: address 0x%lx is '%.64s', not kallsyms_lookup_name - refusing (stale or wrong seed)\n",
                               kr_kln_fn, buf);
                return -ENODATA;
        }
        for (pi = 0; kr_kln_probe_names[pi]; pi++) {
                probe = kr_kln_call(kr_kln_probe_names[pi]);
                if (probe && probe >= KR_ADDR_FLOOR) {
                        hit = kr_kln_probe_names[pi];
                        break;
                }
                susfs_diag_logf("resolver: kln probe lookup of '%s' returned 0x%lx - trying next candidate\n",
                               kr_kln_probe_names[pi], probe);
                probe = 0;
        }
        if (!hit) {
                susfs_diag_logf("resolver: kln probe lookups all failed (_printk/printk/vprintk; last returned 0x%lx) - refusing\n",
                               probe);
                return -ENODATA;
        }
        kr_kln_mode = true;
        kr_ready = true;
        susfs_diag_logf("resolver: KLN mode ACTIVE (kallsyms_lookup_name@0x%lx validated via sprint_symbol + probe '%s'=0x%lx; no table walk, no scan)\n",
                       kr_kln_fn, hit, probe);
        return 0;
}

int ksu_init_symbol_resolver(void)
{
        struct kallrecon_hint hint;
        int seeded;

        memset(&hint, 0, sizeof(hint));
        seeded = kr_seed_parse(&hint);

        /* v26.11.40: kln= is authoritative when present - it does not need
         * the tables at all (they are not even listed on the target kernel).
         * The gsoff= field rides along in the same seed. */
        if (kr_kln_fn) {
                int rc = kr_kln_activate();

                if (rc)
                        return rc;
                goto resolver_ready;
        }

        if (seeded) {
                susfs_diag_logf("resolver: kr_seed parsed (%d fields: names=0x%lx offsets=0x%lx relbase=0x%lx num=0x%lx markers=0x%lx toktab=0x%lx tokidx=0x%lx)\n",
                               seeded, hint.names, hint.offsets, hint.relative_base,
                               hint.num_syms, hint.markers, hint.token_table, hint.token_index);
                hint.timeout_ms = KR_TIMEOUT_MS;
                kallrecon_supply(&hint);

                susfs_diag_logf("resolver: find_kallsyms_base() starting (SEEDED - validation only, no scan)\n");
                find_kallsyms_base();
                susfs_diag_logf("resolver: seeded pass done (layout_ready=%d klp=%d fail_reason=%d)\n",
                               kr_layout_ready(), !!kallrecon_klp, kallrecon_fail_reason());

                if (!kr_layout_ready() || !kallrecon_klp) {
                        susfs_diag_logf("resolver: seed INVALID - refusing to load (fix the kr_seed values; scanning stays off)\n");
                        if (susfs_diag_printk)
                                pr_err("symbol_resolver: kr_seed invalid (%d), refusing to load\n",
                                       kallrecon_fail_reason());
                        return -ENODATA;
                }
                kr_ready = true;
                susfs_diag_logf("resolver: SEEDED ready (layout v%d base=0x%lx num=%u klp=%d)\n",
                               (int)kl_layout, kernel_base, klnum_val, !!kallrecon_klp);
                goto resolver_ready;
        }

        if (!susfs_kr_scan) {
                susfs_diag_logf("resolver: NO kr_seed and kr_scan=0 - refusing to load WITHOUT scanning (v26.11.38 safe default: the v26.11.37 stage-0 wedge sat in this class; write kr_seed from /proc/kallsyms, or set kr_scan=1 for the old auto-discovery)\n");
                return -ENODATA;
        }

        /* kr_scan=1: the v26.11.36/37 auto-discovery path, manual opt-in only */
        susfs_diag_logf("resolver: kr_scan=1 - auto-discovery pass 1 starting (timeout=%ums)\n", KR_TIMEOUT_MS);
        memset(&hint, 0, sizeof(hint));
        hint.timeout_ms = KR_TIMEOUT_MS;
        kallrecon_supply(&hint);

        susfs_diag_logf("resolver: find_kallsyms_base() starting\n");
        find_kallsyms_base();
        susfs_diag_logf("resolver: pass 1 done (layout_ready=%d klp=%d)\n",
                       kr_layout_ready(), !!kallrecon_klp);

        if (!kr_layout_ready() || !kallrecon_klp) {
                susfs_diag_logf("resolver: RETRY pass 2 starting (2x scan window, timeout=%ums)\n",
                               KR_TIMEOUT_MS);
                memset(&hint, 0, sizeof(hint));
                hint.scan_back = KR_SCAN_BACK * 2;
                hint.scan_fwd = KR_SCAN_FWD * 2;
                hint.timeout_ms = KR_TIMEOUT_MS;
                kallrecon_supply(&hint);
                kallrecon_retry();
                susfs_diag_logf("resolver: retry pass 2 done (layout_ready=%d klp=%d)\n",
                               kr_layout_ready(), !!kallrecon_klp);
        }

        if (!kr_layout_ready() || !kallrecon_klp) {
                susfs_diag_logf("resolver: FAILED (fail_reason=%d klp=%d) - refusing to load\n",
                               kallrecon_fail_reason(), !!kallrecon_klp);
                if (susfs_diag_printk)
                        pr_err("symbol_resolver: kallrecon discovery failed (%d, klp=%d), refusing to load\n",
                               kallrecon_fail_reason(), !!kallrecon_klp);
                return -ENODATA;
        }

        kr_ready = true;
        susfs_diag_logf("resolver: ready (layout v%d base=0x%lx num=%u klp=%d)\n",
                       (int)kl_layout, kernel_base, klnum_val, !!kallrecon_klp);

resolver_ready:
        /* v26.11.40: kln mode has no kallrecon tables and no kallsyms_lookup
         * walker (kr_klp would deref a NULL kallrecon_klp here); name-at-address
         * goes through the imported sprint_symbol instead.  The activation
         * banner is already in diag_log. */
        if (kr_kln_mode)
                return 0;

        kr_lookup_fn = (void *)kr_klp("kallsyms_lookup");
        if (!kr_lookup_fn) {
                susfs_diag_logf("resolver: kallsyms_lookup not resolved, module names unavailable\n");
                if (susfs_diag_printk)
                        pr_warn("symbol_resolver: kallsyms_lookup not resolved, module names unavailable\n");
        }

        /* v26.11.40: was SUSFS_LOGI - a printk the init path no longer makes
         * (zero-printk init); the same line now lives in diag_log only. */
        susfs_diag_logf("symbol_resolver: kallrecon layout v%d base=0x%lx num=%u klp=%d\n",
                   (int)kl_layout, kernel_base, klnum_val, !!kallrecon_klp);

        return 0;
}
