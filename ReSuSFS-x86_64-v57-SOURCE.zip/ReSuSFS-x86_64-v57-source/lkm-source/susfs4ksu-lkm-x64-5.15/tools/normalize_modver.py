#!/usr/bin/env python3
"""normalize_modver.py - pin a module .ko's __versions section to exactly one
neutral entry (v26.11.25).

Why: on a CONFIG_MODVERSIONS=y kernel (LDPlayer 14's Android-14 GKI-style
5.15.178+ is one), load_module() calls check_modstruct_version() BEFORE any
symbol is resolved, and a module with NO __versions section at all dies there
SILENTLY with -ENOEXEC:

    check_version(): if (versindex == 0)
                         return try_to_force_load(...) == 0;   /* #else: -ENOEXEC, no print */

while a module whose __versions section exists but has NO entry for
"module_layout" only earns pr_warn_once("no symbol version for module_layout")
and is ACCEPTED. kernel/modver_dummy.c plants the neutral entry; this script
then makes it the ONLY entry, so that a build against a tree with a full
Module.symvers (real CRCs computed against that tree's struct module) can never
smuggle a module_layout CRC back in - a CRC that would only match the exact
kernel it was built against and fail with "disagrees about version of symbol".

Entry layout (include/linux/module.h):
    struct modversion_info { unsigned long crc; char name[56]; }   /* 64 bytes */

Usage: normalize_modver.py <module.ko>   (edits the file in place; prints a diff)
"""
import struct
import sys

DUMMY_NAME = b"__resusfs_neutral"
ENTRY_SIZE = 64           # sizeof(unsigned long) + MODULE_NAME_LEN(56)
NAME_OFF = 8
NAME_LEN = 56


def die(msg):
    print("normalize_modver: %s" % msg)
    sys.exit(1)


def main(path):
    with open(path, "rb") as f:
        img = bytearray(f.read())

    if len(img) < 64:
        die("file too small to be an ELF")

    if img[:4] != b"\x7fELF" or img[4] != 2 or img[5] != 1:
        die("not an ELF64 little-endian object")
    e_shoff, = struct.unpack_from("<Q", img, 0x28)
    e_shentsize, = struct.unpack_from("<H", img, 0x3A)
    e_shnum, = struct.unpack_from("<H", img, 0x3C)
    e_shstrndx, = struct.unpack_from("<H", img, 0x3E)

    if e_shentsize != 64 or e_shoff == 0 or e_shnum == 0:
        die("no usable section table")

    shdrs = [(e_shoff + i * 64) for i in range(e_shnum)]

    # section-name string table (sh_name is a u32 at offset 0 of each Elf64_Shdr)
    st = shdrs[e_shstrndx]
    st_off, = struct.unpack_from("<Q", img, st + 0x18)
    st_size, = struct.unpack_from("<Q", img, st + 0x20)
    names = bytes(img[st_off:st_off + st_size])

    def secname(i):
        o, = struct.unpack_from("<I", img, shdrs[i])
        if o >= st_size:
            return None
        end = names.find(b"\0", o)
        end = st_size if end < 0 else end
        return names[o:end].decode("latin1")

    idx = None
    for i in range(e_shnum):
        if secname(i) == "__versions":
            idx = i
            break
    if idx is None:
        die("no __versions section: build the module with kernel/modver_dummy.c")

    data_off, = struct.unpack_from("<Q", img, shdrs[idx] + 0x18)
    data_size, = struct.unpack_from("<Q", img, shdrs[idx] + 0x20)

    n_entries = data_size // ENTRY_SIZE
    if data_size % ENTRY_SIZE != 0:
        die("__versions size %d is not a multiple of %d" % (data_size, ENTRY_SIZE))

    before = []
    for j in range(n_entries):
        o = data_off + j * ENTRY_SIZE
        crc, = struct.unpack_from("<Q", img, o)
        nm = bytes(img[o + NAME_OFF:o + NAME_OFF + NAME_LEN])
        nm = nm[:nm.find(b"\0") if b"\0" in nm else NAME_LEN]
        before.append((crc, nm.decode("latin1")))

    # rewrite entry[0] as the neutral entry, then shrink the section to it
    o = data_off
    struct.pack_into("<Q", img, o, 0)
    img[o + NAME_OFF:o + NAME_OFF + NAME_LEN] = DUMMY_NAME.ljust(NAME_LEN, b"\0")
    struct.pack_into("<Q", img, shdrs[idx] + 0x20, ENTRY_SIZE)

    with open(path, "wb") as f:
        f.write(img)

    dropped = [nm for crc, nm in before if nm != DUMMY_NAME.decode("latin1")]
    print("normalize_modver: %s" % path)
    print("  __versions: %d entries -> 1 (crc=0, name=%r)" % (n_entries, DUMMY_NAME.decode()))
    if dropped:
        print("  dropped entries (CRCs computed against the BUILD tree, meaningless elsewhere):")
        for nm in dropped:
            print("    - %s" % nm)
    else:
        print("  no other entries were present (dummy-only already)")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: normalize_modver.py <module.ko>")
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
