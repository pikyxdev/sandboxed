/* sc_v50.c - v26.11.50 CLANG ENTRY GRAFT (x86_64, freestanding).
 *
 * WHAT THIS FILE IS: the v50 supercall transport, compiled with clang-17
 * (the SAME compiler family that built the target kernel) and grafted onto
 * the field-proven v49 module object (ld -r; the v49 definitions of the
 * three overridden symbols are weakened in the base and dropped by the
 * linker - see scripts/build_v50_ko.sh).  Everything else in the module -
 * the wrapper body, the layer ladder, the substep ladder, the witness,
 * the CLI - is the v49 field code, byte for byte.
 *
 * WHY v50 EXISTS - THE TWO SURVIVING v48/v49 DEATH THEORIES, AND HOW THIS
 * FILE KILLS BOTH:
 *
 *   FACTS (field, 2026-11-24): v48 (raw-asm thunk, no preamble) froze the
 *   box at the FIRST syscall(173) dispatched through table[173], 5/5 boots.
 *   v49 (thunk with the ORIGINAL entry's [entry-4] word - 0xebebffff -
 *   replicated into its own [entry-4] slot, readback-verified) froze the
 *   SAME way, 1/1 boot (the stage-2 wedge that demoted this box's ladder).
 *   The ORIGINAL entry boots fine.  Measured on this kernel: the [-4] words
 *   of the first six table entries are ALL DIFFERENT (v49's own receipt:
 *   "siblings same=0 diff=6"), which is impossible if a kCFI call site
 *   checked [target-4] against one expected type hash for those entries -
 *   so either the live dispatch checks a DIFFERENT offset (a non-default
 *   kcfi layout in LDPlayer's clang build; the first-6 entries are also
 *   plausibly PGO/BOLT-rewritten so their preamble bytes are scrambled),
 *   or the dispatch is not kCFI-checked at all and the freeze lives in the
 *   entry mechanics elsewhere.  v49 proved byte-copying [-4] ALONE is not
 *   sufficient either way.
 *
 *   FIX 1 (preamble theory): the installer CLONES THE ORIGINAL ENTRY'S
 *   ENTIRE 16-BYTE PREAMBLE WINDOW ([orig-16 .. orig-1]) into our entry's
 *   window, byte for byte, through the same proven ksu_patch_text primitive
 *   v49 used, with byte-exact readback verification BEFORE the table entry
 *   is touched.  Whatever bytes the dispatch inspects in [-16..-1) - the
 *   hash at -4, a movl opcode at -5, a wider custom-offset pattern - our
 *   entry then presents EXACTLY the bytes the original entry presents, and
 *   the original entry demonstrably passes.  No guessing, no offset
 *   assumptions, no hash computation.  As belt-and-braces the entry is a
 *   REAL clang-17 function carrying a GENUINE kCFI preamble for the exact
 *   syscall-table prototype long (const struct pt_regs *) (clang emits the
 *   5-byte "movl $hash,%eax" block at [entry-5..entry-1], hash at [entry-4],
 *   exactly like the kernel's own entries) - if the clone window were ever
 *   wrong, the genuine preamble is still the best possible guess.
 *
 *   FIX 2 (entry-mechanics theory): stage-2 OBSERVE mode - the first
 *   live-fire rung - is now MINIMAL: one locked 32-bit increment of the
 *   userspace-visible counter and return -EINVAL.  No printk, no current
 *   read, no credential walk, no forwarding to the original handler, no
 *   dispatch.  The v49 observe path did all of those on the raw syscall
 *   path; v50's first fire through the new entry is the shortest possible
 *   instruction sequence that still leaves evidence (the counter) and
 *   answers the caller (-EINVAL, the same errno the original ioperm(2)
 *   returns for the magic-shaped arguments - the CLI contract is
 *   unchanged).  The full wrapper (v45-proven logic) runs only from
 *   stage 3, after stage 2 has proven the entry mechanics under fire.
 *
 * INSTALL GATE: the table write happens ONLY after (a) the table is the
 * proven-live one (ksu_syscall_dispatcher found inside it, as every boot
 * since v47 shows), (b) table[173] still holds the real __x64_sys_ioperm,
 * (c) our entry's endbr64 landing pad is intact, (d) the 16-byte clone
 * write verified byte-exact.  ANY refusal logs a full receipt and returns
 * 0 (layer 17 is FATAL - an error return would refuse the whole module
 * load and un-arm every other working layer; the honest state is "loaded,
 * transport not installed", visible via susfs_supercall_transport_active()
 * and the diag receipts).  No path in this file can freeze the box: the
 * only kernel writes are the two verified patch_text calls, and the only
 * new executable code on the syscall path is the minimal entry above.
 *
 * Symbol contract with the v49 base object (all verified by
 * scripts/build_v50_verify.py after the merge):
 *   susfs_sc_wrapper      T  (v49)  - called directly by the entry, stage 3
 *   susfs_diag_logf       T  (v49)  - variadic receipt logger
 *   susfs_current_arm_stage T(v49)  - the ladder rung
 *   ksu_kallsyms_lookup_name T(v49) - resolver
 *   susfs_fp_syscall_table T (v49)  - the fp layer's cached live table
 *   ksu_patch_text        T  (v49)  - fixmap + stop_machine write primitive
 *   sc_orig / sc_installed / sc_full_mode / susfs_sc_entry_count
 *                         b  (v49, globalized by build_v50_ko.sh)
 *   susfs_supercall_init / susfs_supercall_exit / susfs_sc_entry
 *                         T  (v49, WEAKENED; the strong definitions here win)
 *
 * Compile flags (build_v50_ko.sh): clang-17, -O2 -fsanitize=kcfi
 * -fcf-protection=branch -fno-stack-protector -fno-pic -mno-red-zone
 * -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 -ffreestanding -nostdinc
 * -fno-builtin.  No includes, no libcalls: every loop is open-coded so the
 * object adds ZERO new undefined symbols to the merged module.
 */

/* ---- minimal freestanding vocabulary (no includes at all) ------------- */
typedef unsigned long       u64;
typedef unsigned int        u32;
typedef unsigned char       u8;
typedef int                 s32;

#define NULL ((void *)0)

struct pt_regs;                     /* incomplete: the entry only passes the
                                     * pointer through, and the prototype
                                     * spelling long (const struct pt_regs *)
                                     * is what the kCFI typeid is computed
                                     * from - it must stay EXACTLY this. */

/* ---- the v49 base symbols this graft binds to -------------------------- */
extern long susfs_sc_wrapper(const struct pt_regs *regs);
extern void susfs_diag_logf(const char *fmt, ...);
extern int  susfs_current_arm_stage(void);
extern u64  ksu_kallsyms_lookup_name(const char *name);
extern u64  susfs_fp_syscall_table(void);
extern int  ksu_patch_text(void *dst, void *src, u64 len, int flags);

/* v49 .bss state (globalized in the base by build_v50_ko.sh; same storage
 * the v49 wrapper and the module_param machinery already use) */
extern volatile int  susfs_sc_entry_count;   /* the sc_entry_count param    */
extern u8            sc_full_mode;           /* stage >= 3: accept + answer */
extern u8            sc_installed;           /* transport armed             */
extern u64           sc_orig;                /* saved __x64_sys_ioperm      */

/* ---- v50 constants ------------------------------------------------------ */
#define SC_V50_NR            173          /* __NR_ioperm - matches the CLI  */
#define SC_V50_HANDLER       "__x64_sys_ioperm"
#define SC_V50_SCAN_ENTRIES  512          /* liveness window (v49 value)    */
#define SC_V50_WINDOW        16           /* cloned preamble window bytes   */
#define SC_V50_PATCH_FLAGS   3            /* icache|dcache bits (x86 no-ops)*/

/* ======================================================================= */
/* THE ENTRY - the function sys_call_table[173] will point at.             */
/*                                                                         */
/* clang-17 compiles this with:                                            */
/*   __cfi_susfs_sc_entry: [nop pad] movl $<typeid>,%eax   <- 16-byte      */
/*   susfs_sc_entry:      endbr64; ...                     <- kCFI block   */
/*   (the genuine preamble; the installer then clones the ORIGINAL's       */
/*   16-byte window over it, so the dispatched bytes are identical to      */
/*   what the kernel already accepts for the original entry).              */
/*                                                                         */
/* OBSERVE (stage 2): counter++ and -EINVAL.  Nothing else.                */
/* FULL    (stage 3): the v45-proven v49 wrapper (magic check, uid gate,   */
/*                    command dispatch, payload.err answers).              */
/* ======================================================================= */
__attribute__((used, noinline))
long susfs_sc_entry(const struct pt_regs *regs)
{
        /* One locked increment: safe in any context, no locks, no printk.
         * This is the same susfs_sc_entry_count the userspace self-test
         * reads before/after (the sc_entry_count module parameter). */
        __asm__ volatile("lock incl %0"
                         : "+m" (susfs_sc_entry_count)
                         :
                         : "memory");

        if (!sc_full_mode)
                return -22;             /* -EINVAL: observe mode, by design */

        /* Stage 3: full accept path.  Everything below this line is the
         * v49 wrapper - unchanged, and its non-susfs passthrough still
         * goes through sc_orig (the saved real ioperm handler). */
        return susfs_sc_wrapper(regs);
}

/* ---- window helpers (open-coded: no memcpy/memcmp imports) ------------- */
static void sc_v50_read_window(u64 fn, volatile u32 *w)
{
        /* Read the 16 bytes BEFORE a function entry, 4 bytes at a time.
         * Kernel text is plain readable memory here (v49 read the same
         * region with READ_ONCE). */
        volatile u32 *p = (volatile u32 *)(fn - SC_V50_WINDOW);
        int i;

        for (i = 0; i < SC_V50_WINDOW / 4; i++)
                w[i] = p[i];
}

static int sc_v50_window_equal(volatile const u32 *a, volatile const u32 *b)
{
        int i;

        for (i = 0; i < SC_V50_WINDOW / 4; i++)
                if (a[i] != b[i])
                        return 0;
        return 1;
}

/* ======================================================================= */
/* THE INSTALLER - replaces v49's susfs_supercall_init (weakened in base). */
/* ======================================================================= */
int susfs_supercall_init(void)
{
        u64 table, entry, handler, dispatcher, me;
        volatile u32 want[SC_V50_WINDOW / 4];   /* original's preamble window */
        volatile u32 have[SC_V50_WINDOW / 4];   /* our window after the clone */
        int stage, i, live = 0, disp_idx = -1, err;

        stage = susfs_current_arm_stage();
        sc_full_mode = (stage >= 3) ? 1 : 0;

        susfs_diag_logf("supercall: v50 clang transport init (stage %d, mode=%s; entry compiled by clang-17 with a genuine kCFI preamble)\n",
                        stage, sc_full_mode ? "FULL" : "OBSERVE-ONLY");

        /* 1. the live table (fp layer cache first, resolver fallback -
         *    the exact v49 order). */
        table = susfs_fp_syscall_table();
        if (!table)
                table = ksu_kallsyms_lookup_name("sys_call_table");
        if (!table) {
                susfs_diag_logf("supercall: v50: sys_call_table not resolved - transport unavailable (loaded, not installed)\n");
                return 0;
        }

        /* 2. liveness proof, v49 shape: KernelSU-Next patched its own
         *    dispatcher INTO this table; finding it proves the table is
         *    what the live dispatch executes through. */
        dispatcher = ksu_kallsyms_lookup_name("ksu_syscall_dispatcher");
        if (dispatcher) {
                for (i = 0; i < SC_V50_SCAN_ENTRIES; i++) {
                        if (((u64 *)table)[i] == dispatcher) {
                                live++;
                                if (disp_idx < 0)
                                        disp_idx = i;
                        }
                }
        }

        entry   = ((u64 *)table)[SC_V50_NR];
        handler = ksu_kallsyms_lookup_name(SC_V50_HANDLER);
        me      = (u64)&susfs_sc_entry;

        susfs_diag_logf("supercall: v50: table=0x%lx table[%d]=0x%lx handler(%s)=0x%lx dispatcher=0x%lx in %d entr%s (idx %d)\n",
                        table, SC_V50_NR, entry, SC_V50_HANDLER, handler,
                        dispatcher, live, live == 1 ? "y" : "ies", disp_idx);

        /* 3. idempotent re-init (same boot, second trigger). */
        if (entry == me) {
                susfs_diag_logf("supercall: v50: table[%d] already points at our entry (re-init) - transport LIVE\n",
                                SC_V50_NR);
                sc_orig = handler;
                sc_installed = 1;
                return 0;
        }

        /* 4. sanity gates (v49 conditions; refuse = loaded, not installed). */
        if (handler && entry != handler) {
                susfs_diag_logf("supercall: v50: table[%d]=0x%lx is not %s=0x%lx - refusing (loaded, not installed)\n",
                                SC_V50_NR, entry, SC_V50_HANDLER, handler);
                return 0;
        }
        if (!live) {
                susfs_diag_logf("supercall: v50: ksu_syscall_dispatcher not found in the table - refusing (loaded, not installed)\n");
                return 0;
        }

        /* 5. our own landing pad must be intact (clang emitted endbr64;
         *    the fp_install discipline, checked by the installer itself). */
        if (*(volatile u32 *)&susfs_sc_entry != 0xfa1e0ff3u) {
                susfs_diag_logf("supercall: v50: our entry lost its endbr64 landing pad (0x%08x) - refusing (loaded, not installed)\n",
                                *(volatile u32 *)&susfs_sc_entry);
                return 0;
        }

        /* 6. THE V50 PREAMBLE CLONE: copy the ORIGINAL entry's ENTIRE
         *    16-byte preamble window ([orig-16 .. orig-1]) into ours,
         *    byte for byte, before the table write.  v49 copied only the
         *    4 bytes at [entry-4] and the box still froze; v50 makes our
         *    window byte-identical to the original's at EVERY offset the
         *    dispatch could plausibly inspect, so whatever check the
         *    original passes, ours passes the same one.  Both windows go
         *    into the receipt so a refusal or a later wedge is diagnosable
         *    from the logs alone. */
        sc_v50_read_window(entry, want);
        sc_v50_read_window(me, have);
        susfs_diag_logf("supercall: v50 orig window [-16..-1): %08x %08x %08x %08x\n",
                        want[0], want[1], want[2], want[3]);
        susfs_diag_logf("supercall: v50 own window (clang preamble) : %08x %08x %08x %08x\n",
                        have[0], have[1], have[2], have[3]);

        err = ksu_patch_text((void *)(me - SC_V50_WINDOW),
                             (void *)want, SC_V50_WINDOW,
                             SC_V50_PATCH_FLAGS);
        if (err) {
                susfs_diag_logf("supercall: v50: preamble clone write FAILED rc=%d - refusing (loaded, not installed)\n",
                                err);
                return 0;
        }
        sc_v50_read_window(me, have);
        if (!sc_v50_window_equal(want, have)) {
                susfs_diag_logf("supercall: v50: preamble clone did not stick (%08x %08x %08x %08x vs %08x %08x %08x %08x) - refusing (loaded, not installed)\n",
                                have[0], have[1], have[2], have[3],
                                want[0], want[1], want[2], want[3]);
                return 0;
        }
        susfs_diag_logf("supercall: v50: preamble window cloned + verified (16 bytes, byte-exact)\n");

        /* 7. THE TABLE WRITE: table[173] = our entry, through the same
         *    primitive every fp-layer patch uses, then read back. */
        err = ksu_patch_text((void *)&((u64 *)table)[SC_V50_NR],
                             &me, sizeof(me), SC_V50_PATCH_FLAGS);
        if (err) {
                susfs_diag_logf("supercall: v50: table entry write FAILED rc=%d - refusing (loaded, not installed)\n",
                                err);
                return 0;
        }
        if (((u64 *)table)[SC_V50_NR] != me) {
                susfs_diag_logf("supercall: v50: table entry write did not stick (0x%lx vs 0x%lx) - refusing (loaded, not installed)\n",
                                ((u64 *)table)[SC_V50_NR], me);
                return 0;
        }

        sc_orig = handler;
        sc_installed = 1;
        susfs_diag_logf("supercall: v50 transport LIVE - table[%d] -> susfs_sc_entry (clang-17 entry, 16-byte cloned preamble, mode=%s; observe = counter + -EINVAL only, full = the v49 wrapper)\n",
                        SC_V50_NR, sc_full_mode ? "FULL" : "OBSERVE-ONLY");
        return 0;
}

/* Replaces v49's susfs_supercall_exit (weakened in the base).  Only ever
 * reached from the layer teardown path; this kernel is built without
 * MODULE_UNLOAD so it is effectively a no-op - kept correct anyway. */
void susfs_supercall_exit(void)
{
        u64 table;

        if (!sc_installed)
                return;
        table = susfs_fp_syscall_table();
        if (!table)
                table = ksu_kallsyms_lookup_name("sys_call_table");
        if (table) {
                int err = ksu_patch_text((void *)&((u64 *)table)[SC_V50_NR],
                                         &sc_orig, sizeof(sc_orig),
                                         SC_V50_PATCH_FLAGS);
                susfs_diag_logf("supercall: v50 exit: table[%d] %s (0x%lx)\n",
                                SC_V50_NR,
                                err ? "restore FAILED" : "restored",
                                sc_orig);
        }
        sc_installed = 0;
}
