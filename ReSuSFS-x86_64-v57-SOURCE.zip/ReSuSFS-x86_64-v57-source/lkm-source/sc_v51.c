/* sc_v51.c - v26.11.51 THE CLANG ACCEPT PATH (x86_64, freestanding).
 *
 * WHAT THIS FILE IS: the v51 supercall transport AND accept path, compiled
 * with clang-17 (the compiler family that built the target kernel) and
 * grafted onto the field-proven v49 module object (ld -r; the v49/v50
 * definitions of the three overridden symbols are weakened in the base and
 * dropped by the linker - see scripts/build_v51_ko.sh).  Everything else in
 * the module - the wrapper body, the layer ladder, the substep ladder, the
 * witness, the CLI - is the v49 field code, byte for byte.
 *
 * THE v50 FIELD VERDICT THIS FILE ANSWERS (2026-11-25, boot 777e7068):
 * the v50 clang ENTRY is proven under fire - the stage-2 boot (440a678a)
 * ran the patched table[173] entry live (counter increments, -EINVAL
 * answers, full 40s heartbeat window, clean shutdown into the next boot).
 * The stage-3 boot (777e7068) armed the SAME entry with sc_full_mode=1 and
 * the box died at the first `ksu_susfs show version` of the self-test -
 * i.e. at the FIRST EXECUTION of the v49 GCC-compiled susfs_sc_wrapper,
 * the one component that had never run live before (v47's arm redirect sat
 * in dead code; v48/v49 died at their first dispatched syscall(173) too,
 * which was also the wrapper's first execution - 3 transport generations,
 * 7 wedge boots, one common factor).
 *
 * WHY THE WRAPPER DIES - WHAT v51 REMOVES INSTEAD OF GUESSING:
 *   1. The wrapper is GCC-14 module code reached through the live syscall
 *      table; no OTHER module code had ever been reached that way when it
 *      first ran (the stage-1/2 "gate" layers only cache function pointers
 *      - susfs_ksu_umount_gate_init stores ksu_uid_should_umount and
 *      returns; no table entry ever pointed at module code before the
 *      supercall transport).  v51's syscall path is 100% CLANG, same
 *      flags as the proven entry.
 *   2. The wrapper reads `current->cred` at a HARDCODED HEADER OFFSET
 *      (0x788) compiled from vanilla 5.15.178 task_struct layout.  The
 *      target is LDPlayer 14's 5.15.178+ clang-17 +LTO +PGO +BOLT build -
 *      a vendor kernel whose struct layouts need not match any published
 *      tree, and the module's 20+ other 0x788 readers are all in code that
 *      never ran at runtime (the passive gates, the retired stage-4/5
 *      layers, the feature handlers).  A wrong slot read as a pointer and
 *      dereferenced is an unhandled kernel fault: this module carries NO
 *      __ex_table, and Android kernels panic on oops.
 *      v51 CALIBRATES the cred offset at install time instead: it scans
 *      init_task (a kallsyms symbol, 0xffffffff822127c0 on this box) for
 *      the one adjacent 8-byte pair (real_cred, cred) that both equal
 *      &init_cred (0xffffffff82238f30) - true for the idle task for the
 *      whole boot - and verifies struct cred's uid offset against
 *      init_cred's own fields (usage small-positive at +0, the uid/gid/
 *      suid/sgid/euid/egid/fsuid/fsgid words at +8..+0x28 all zero,
 *      because init_cred IS root:root).  NO header-derived struct offset
 *      is left on the syscall path.
 *   3. The wrapper forwards non-susfs calls to the saved original handler
 *      through an indirect call (sc_call_orig) - also never exercised.
 *      v51's entry answers -EINVAL for everything it does not accept
 *      (which is exactly what the original ioperm(2) answers for the
 *      magic-shaped arguments; nothing on this box issues a genuine
 *      ioperm(2), and the stage-2 boot proved 8+ minutes of uptime with
 *      table[173] answering -EINVAL for every call).
 *
 * WHAT STAGE 3 DOES NOW (the v51 rung): accept the three SHOW commands
 * ONLY - SHOW_VERSION, SHOW_VARIANT, SHOW_ENABLED_FEATURES - answering in
 * payload.err and the syscall return, through the kernel's own
 * out-of-line _copy_from_user/_copy_to_user (both in this kernel's
 * kallsyms at 0xffffffff81436590/0xffffffff814365f0; SMAP is off on this
 * box anyway - /proc/cmdline carries nosmap nosmep).  The feature commands
 * (add_sus_path, add_sus_map, kstat, uname, ...) are answered "not
 * handled" (-EINVAL; the CLI keeps its pre-seeded 126 sentinel and exits
 * nonzero) - the apply scripts skip gracefully.  Forwarding those to the
 * v49 GCC feature handlers is the NEXT rung's business (v52+), one class
 * at a time, AFTER this rung proves the transport end-to-end.
 *
 * EVERY REFUSAL IS A RECEIPT, never an error return: layer 17 is FATAL in
 * the base's layer table, and the honest refusal state ("loaded, transport
 * not installed" / "installed, uid gate uncalibrated - not answering") is
 * visible in diag_log and the self-test output, with the box alive.
 *
 * Symbol contract with the v49 base object (verified after the merge by
 * scripts/build_v51_verify.py):
 *   susfs_diag_logf        T (v49) - variadic receipt logger
 *   susfs_current_arm_stage T(v49) - the ladder rung
 *   ksu_kallsyms_lookup_name T(v49)- resolver (KLN mode)
 *   susfs_fp_syscall_table T (v49) - the fp layer's cached live table
 *   ksu_patch_text         T (v49) - fixmap + stop_machine write primitive
 *   susfs_current_task_gs_off B(v49, non-static) - the SEEDED, per-boot
 *                                   validated per-CPU offset of current_task
 *   susfs_armed_features   B (v49 static, GLOBALIZED by build_v51_ko.sh) -
 *                                   the feature bitmap the armed layers set
 *   _copy_from_user / _copy_to_user - kernel imports, already in the base's
 *                                   import set (absolutized at load)
 *   sc_orig / sc_installed / sc_full_mode / susfs_sc_entry_count
 *                         b  (v49, globalized by build_v51_ko.sh)
 *   susfs_supercall_init / susfs_supercall_exit / susfs_sc_entry
 *                         T  (v49, WEAKENED; the strong definitions here win)
 *   susfs_sc_wrapper      - NOT REFERENCED.  The v49 wrapper body stays in
 *                          the image as dead code (nothing binds to it);
 *                          the full path below replaces it.
 *
 * Compile flags (build_v51_ko.sh): clang-17, -O2 -fsanitize=kcfi
 * -fcf-protection=branch -fno-stack-protector -fno-pic -mno-red-zone
 * -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 -ffreestanding -nostdinc
 * -fno-builtin.  No includes, no libcalls: every loop is open-coded so the
 * object adds ZERO new undefined symbols beyond the set above (all of
 * which the merged module already imports or defines).
 */

/* ---- SC_V51_HOSTTEST: the sandbox unit-test surface ---------------------
 * The ONLY kernel-only primitive is the %gs current read; the host test
 * provides same-named definitions for every extern below.  Everything
 * else (calibration scan, sanity check, answer builders, chunking) runs
 * unmodified on the host. */
#ifdef SC_V51_HOSTTEST
#include <stdio.h>
#include <string.h>
#include <stdint.h>
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
typedef int32_t  s32;
#define NULL ((void *)0)
/* host shims, defined in the test driver */
extern void susfs_diag_logf(const char *fmt, ...);
extern int  susfs_current_arm_stage(void);
extern u64  ksu_kallsyms_lookup_name(const char *name);
extern u64  susfs_fp_syscall_table(void);
extern int  ksu_patch_text(void *dst, void *src, u64 len, int flags);
extern u64  _copy_from_user(void *to, const void *from, u64 n);
extern u64  _copy_to_user(void *to, const void *from, u64 n);
extern volatile int susfs_sc_entry_count;
extern u8   sc_full_mode, sc_installed;
extern u64  sc_orig;
extern unsigned long susfs_current_task_gs_off;
extern unsigned long susfs_armed_features;
extern unsigned char *sc_v51_host_current;   /* the host stand-in for %gs:off */
#else
typedef unsigned long       u64;
typedef unsigned int        u32;
typedef unsigned char       u8;
typedef int                 s32;
#define NULL ((void *)0)
#endif

struct pt_regs;                     /* incomplete: the kCFI typeid is computed
                                     * from the prototype spelling
                                     * long (const struct pt_regs *) - it must
                                     * stay EXACTLY this (same as v50). */

/* ---- the v49 base symbols this graft binds to -------------------------- */
#ifndef SC_V51_HOSTTEST
extern void susfs_diag_logf(const char *fmt, ...);
extern int  susfs_current_arm_stage(void);
extern u64  ksu_kallsyms_lookup_name(const char *name);
extern u64  susfs_fp_syscall_table(void);
extern int  ksu_patch_text(void *dst, void *src, u64 len, int flags);
extern u64  _copy_from_user(void *to, const void *from, u64 n);
extern u64  _copy_to_user(void *to, const void *from, u64 n);
extern volatile int  susfs_sc_entry_count;   /* the sc_entry_count param    */
extern u8            sc_full_mode;           /* stage >= 3: accept + answer */
extern u8            sc_installed;           /* transport armed             */
extern u64           sc_orig;                /* saved __x64_sys_ioperm      */
extern unsigned long susfs_current_task_gs_off;  /* seeded per-CPU offset   */
extern unsigned long susfs_armed_features;       /* armed-layer feature bits */
#endif

/* ---- v51 constants ------------------------------------------------------ */
#define SC_V51_NR            173          /* __NR_ioperm - matches the CLI  */
#define SC_V51_HANDLER       "__x64_sys_ioperm"
#define SC_V51_SCAN_ENTRIES  512          /* liveness window (v49 value)    */
#define SC_V51_WINDOW        16           /* cloned preamble window bytes   */
#define SC_V51_PATCH_FLAGS   3            /* icache|dcache bits (x86 no-ops)*/

/* The CLI wire ABI (ksu_susfs, v45+v48 builds): syscall(173, magic1, magic2,
 * cmd, &payload).  Only the low 32 bits of each register are defined. */
#define SC_V51_MAGIC1        0xDEADBEEFu
#define SC_V51_MAGIC2        0xFAFAFAFAu

/* The susfs SHOW command ids ON THE WIRE - the stock ksu_susfs binary this
 * box runs is the ABI authority (v51 field run 2026-11-25: version
 * answered, variant/features failed, all three calls provably entered the
 * accept path with sc_entry_count 0->3; the CLI's own dispatch sites,
 * each tied to its payload shape and fail string, decode to):
 *   0x555e1  show version           20-byte answer   (str[16] + err@16)
 *   0x555e2  show enabled_features  8196-byte answer (str[8192] + err@8192)
 *   0x555e3  show variant           20-byte answer   (str[16] + err@16)
 * v51's transcription had variant and enabled_features SWAPPED: it
 * "confirmed" the numbers against the module's own cmd switch - circular.
 * The v47 report (gen_v47_report.js) and sc_probe.c carried the correct
 * table all along; sc_probe was never bundled-executable in the field,
 * which is exactly why the swap survived to v51's stage-3 boot.  v52:
 * constants corrected to the CLI wire ABI, nothing else changes. */
#define CMD_SUSFS_SHOW_VERSION          0x555e1u
#define CMD_SUSFS_SHOW_ENABLED_FEATURES 0x555e2u
#define CMD_SUSFS_SHOW_VARIANT          0x555e3u

/* x86_64 pt_regs field offsets (hardware-specified, config-independent;
 * the same offsets the v49 wrapper's disassembly uses: r10=0x38, dx=0x60,
 * si=0x68, di=0x70).  A mirror struct so the reads stay typed; the layout
 * is the user_regs_struct order and cannot move. */
struct sc_v51_regs {
        u64 r15, r14, r13, r12;     /* 0x00 .. 0x18 */
        u64 rbp, rbx, r11, r10;     /* 0x20 .. 0x38 */
        u64 r9,  r8,  ax,  cx;      /* 0x40 .. 0x58 */
        u64 dx,  si,  di,  orig_ax; /* 0x60 .. 0x78 */
        u64 ip,  cs,  flags, sp;    /* 0x80 .. 0x90 */
        u64 ss;                      /* 0x98 */
};

/* ---- the ABI answers (byte layouts are the userspace contract) --------- */
#define SC_V51_VER_SIZE      20     /* char susfs_version[16]; int err @16  */
#define SC_V51_VER_STR_MAX   16
#define SC_V51_FEATS_SIZE    8196   /* char enabled_features[8192]; err @8192 */
#define SC_V51_FEATS_STR_MAX 8192
#define SC_V51_CHUNK         256    /* copy granularity (stack buffer)      */

/* The strings the v49 base answers (extracted from its .rodata.str1.1 at
 * +0x11b4 / +0x11bb - the ABI the CLI prints and version_ge() checks
 * against SUSFS_MIN_VERSION="v2.2.0"). */
static const char sc_v51_version[] = "v2.3.0";
static const char sc_v51_variant[] = "GKI-LKM";

/* The base's feature table, byte-for-byte (enabled_features[] in
 * susfs_supercall.c; the enum order is SUSFS_FEAT_*).  Index 0 is always
 * present; every other entry is gated on its feature bit. */
struct sc_v51_feat {
        const char *name;
        int         bit;    /* -1 = always present */
};
static const struct sc_v51_feat sc_v51_feats[] = {
        { "SUSFS_LKM_MODULES\n",                         -1 },
        { "CONFIG_KSU_SUSFS_SUS_PATH\n",                  0 },
        { "CONFIG_KSU_SUSFS_SUS_MOUNT\n",                 1 },
        { "CONFIG_KSU_SUSFS_SUS_KSTAT\n",                 2 },
        { "CONFIG_KSU_SUSFS_SPOOF_UNAME\n",               3 },
        { "CONFIG_KSU_SUSFS_ENABLE_LOG\n",                4 },
        { "CONFIG_KSU_SUSFS_HIDE_KSU_SUSFS_SYMBOLS\n",    5 },
        { "CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG\n", 6 },
        { "CONFIG_KSU_SUSFS_OPEN_REDIRECT\n",             7 },
        { "CONFIG_KSU_SUSFS_SUS_MAP\n",                   8 },
};

/* ---- v51 calibrated uid gate -------------------------------------------- */
/* v26.11.51 CRITICAL LAYOUT NOTE: these two live in .data, NOT .bss.  The
 * graft object is FIRST in the ld -r merge, so any .bss content of ours
 * would land at merged .bss+0 - inside the 0x40-byte android struct-module
 * spill window the base's susfs_bss_stomp_pad exists to absorb (see the
 * base's stomp_pad.c: LDPlayer's 0x340-byte struct module spills 0x40
 * bytes past the module's 0x300-byte this_module into whatever follows,
 * which is .bss[0..0x40) - deterministic garbage on EVERY load, the v44
 * field evidence).  A calibration offset stomped to garbage is exactly
 * the wrong-pointer-dereference class this version exists to eliminate,
 * so the graft contributes ZERO .bss: the merged .bss stays byte-identical
 * to the field-proven v50 image (base pad first, base control vars past
 * +0x40), and these two variables ride in .data at +0/+8 instead - a
 * region no spill has ever touched on this box. */
__attribute__((section(".data"), used))
static u64 sc_v51_cred_off;   /* task_struct.cred offset, from init_task   */
__attribute__((section(".data"), used))
static u8  sc_v51_uid_ok;     /* calibration verified; 0 = refuse to answer */

/* The task_struct scan window.  Vanilla 5.15 has cred at 0x788; the scan
 * covers 0x1000 so a vendor layout a few hundred bytes larger still fits,
 * while staying far inside the mapped .data page init_task lives on. */
#define SC_V51_TASK_SCAN      0x1000
/* struct cred sanity window (usage at +0, uid..fsgid at +8..+0x28). */
#define SC_V51_CRED_CHECK_END 0x2cu

static u32 sc_v51_current_uid(void)
{
        u64 t, cred;
#ifdef SC_V51_HOSTTEST
        t = (u64)(unsigned long)sc_v51_host_current;
#else
        u64 off = susfs_current_task_gs_off;

        /* %gs:off is current_task for THIS cpu - the same per-CPU slot the
         * kernel itself reads; the offset is seeded and validated every
         * boot by susfs_current_init (field-proven value 0x1bc40 here). */
        __asm__ volatile("movq %%gs:0(,%1,1), %0"
                         : "=r" (t)
                         : "r" (off)
                         : "memory");
#endif
        if (t < 0x1000)
                return 0xffffffffu;         /* no plausible task: not root */
        cred = *(volatile u64 *)(t + sc_v51_cred_off);
        if (cred < 0x1000)
                return 0xffffffffu;         /* NULL/error-ish: not root    */
        /* uid sits right after the atomic_long_t usage counter (5.15
         * switched usage to atomic_long_t, so uid is at +8; verified at
         * install against init_cred's all-zero root fields). */
        return *(volatile u32 *)(cred + 8);
}

/* ======================================================================= */
/* THE ANSWER BUILDERS - all-clang, uaccess through the kernel's own       */
/* out-of-line _copy_from_user/_copy_to_user (SMAP handling and fault      */
/* recovery live in kernel text; this module carries no __ex_table).       */
/* ======================================================================= */

/* 20-byte version/variant answer: str[16] zero-padded + err=0 at +16. */
static long sc_v51_answer_str(u64 payload, const char *s)
{
        char v[SC_V51_VER_SIZE];
        u32 i;

        if (payload < 0x1000)
                return -22;
        if (_copy_from_user(v, (const void *)(unsigned long)payload, sizeof(v)))
                return -14;                 /* -EFAULT, pointer unusable */
        for (i = 0; i < SC_V51_VER_STR_MAX; i++)
                v[i] = 0;
        for (i = 0; i + 1 < SC_V51_VER_STR_MAX && s[i]; i++)
                v[i] = s[i];
        /* int err at offset 16: answer 0 (success) */
        v[SC_V51_VER_STR_MAX] = 0;
        v[SC_V51_VER_STR_MAX + 1] = 0;
        v[SC_V51_VER_STR_MAX + 2] = 0;
        v[SC_V51_VER_STR_MAX + 3] = 0;
        if (_copy_to_user((void *)(unsigned long)payload, v, sizeof(v)))
                return -14;
        return 0;
}

/* 8196-byte enabled_features answer, copied in 256-byte chunks so the
 * syscall-path stack frame stays tiny (the base's out-of-line handler
 * kzallocs 8196 bytes; a freestanding graft with no kmalloc machinery
 * chunks instead).  Names may straddle chunk boundaries - the builder
 * tracks (name index, byte position) across chunks. */
static long sc_v51_answer_features(u64 payload)
{
        char buf[SC_V51_CHUNK];
        u64 feats;
        u32 name_i = 0, name_off = 0;   /* current name cursor */
        u32 done = 0;                   /* string bytes emitted */
        int chunk;

        if (payload < 0x1000)
                return -22;
        /* pointer check first, same shape as the version answer */
        if (_copy_from_user(buf, (const void *)(unsigned long)payload, 16))
                return -14;

        feats = *(volatile u64 *)(unsigned long)&susfs_armed_features;

        for (chunk = 0; chunk < SC_V51_FEATS_STR_MAX / SC_V51_CHUNK; chunk++) {
                u32 fill = 0;

                /* zero the chunk */
                for (u32 z = 0; z < SC_V51_CHUNK; z++)
                        buf[z] = 0;

                /* drain names into the chunk */
                while (fill < SC_V51_CHUNK && name_i < (sizeof(sc_v51_feats) / sizeof(sc_v51_feats[0]))) {
                        const char *n = sc_v51_feats[name_i].name;
                        int bit = sc_v51_feats[name_i].bit;
                        u32 nlen = 0;

                        while (n[nlen])
                                nlen++;

                        if (bit >= 0 && !((feats >> bit) & 1)) {
                                /* feature not armed: skip the name whole */
                                name_i++;
                                name_off = 0;
                                continue;
                        }
                        while (name_off < nlen && fill < SC_V51_CHUNK)
                                buf[fill++] = n[name_off++];
                        if (name_off >= nlen) {
                                name_i++;
                                name_off = 0;
                        }
                        /* chunk full with a name half-done: keep cursor */
                }
                done += fill;
                if (done > SC_V51_FEATS_STR_MAX)
                        return -22;     /* cannot happen; belt */
                if (_copy_to_user((void *)(unsigned long)(payload + (u64)chunk * SC_V51_CHUNK),
                                  buf, SC_V51_CHUNK))
                        return -14;
        }
        /* err = 0 at offset 8192 */
        {
                char e[4];

                e[0] = e[1] = e[2] = e[3] = 0;
                if (_copy_to_user((void *)(unsigned long)(payload + SC_V51_FEATS_STR_MAX),
                                  e, sizeof(e)))
                        return -14;
        }
        return 0;
}

/* ======================================================================= */
/* THE ENTRY - the function sys_call_table[173] will point at.             */
/* clang-17 compiles this with the genuine kCFI preamble block            */
/* ([entry-16..entry-1): nop pad + movl $typeid,%eax); the installer then  */
/* clones the ORIGINAL entry's window over it (v50 mechanics, field-proven */
/* at stage 2 on this box).                                                */
/*                                                                         */
/* OBSERVE (stage 2): counter++ and -EINVAL.  Nothing else.  The rung that */
/* SURVIVED live fire in the field (boot 440a678a).                        */
/* FULL    (stage 3): the v51 all-clang accept path below - magic check,   */
/*                    calibrated-uid gate, SHOW answers.  The v49 GCC      */
/*                    wrapper is NEVER called.                             */
/* ======================================================================= */
__attribute__((used, noinline))
long susfs_sc_entry(const struct pt_regs *regs)
{
        const struct sc_v51_regs *r;
        u32 magic1, magic2, cmd;
        u64 payload;

        /* One locked increment: the userspace-visible counter the self-test
         * reads before/after (the sc_entry_count module parameter). */
        __asm__ volatile("lock incl %0"
                         : "+m" (susfs_sc_entry_count)
                         :
                         : "memory");

        if (!sc_full_mode)
                return -22;             /* -EINVAL: observe mode, by design */

        r = (const struct sc_v51_regs *)regs;
        magic1 = (u32)r->di;
        magic2 = (u32)r->si;
        cmd    = (u32)r->dx;
        payload = r->r10;

        /* Not a susfs supercall: answer exactly like the original ioperm(2)
         * answers magic-shaped arguments.  No forwarding to the saved
         * handler, no indirect calls, nothing unexercised. */
        if (magic1 != SC_V51_MAGIC1)
                return -22;
        if (magic2 != SC_V51_MAGIC2)
                return -22;

        /* uid gate, calibrated (see sc_v51_calibrate).  A failed calibration
         * answers nothing - the box stays alive and the receipts say why. */
        if (!sc_v51_uid_ok)
                return -22;
        if (sc_v51_current_uid() != 0)
                return -22;

        /* The v51 rung: the three SHOW commands only.  Feature commands
         * fall through as "not handled" (-EINVAL, the CLI keeps its 126
         * sentinel, the apply scripts skip) - forwarding them to the v49
 * GCC feature handlers is the next rung, after this one survives. */
        if (cmd == CMD_SUSFS_SHOW_VERSION)
                return sc_v51_answer_str(payload, sc_v51_version);
        if (cmd == CMD_SUSFS_SHOW_VARIANT)
                return sc_v51_answer_str(payload, sc_v51_variant);
        if (cmd == CMD_SUSFS_SHOW_ENABLED_FEATURES)
                return sc_v51_answer_features(payload);
        return -22;
}

/* ---- window helpers (open-coded: no memcpy/memcmp imports) ------------- */
static void sc_v51_read_window(u64 fn, volatile u32 *w)
{
        volatile u32 *p = (volatile u32 *)(fn - SC_V51_WINDOW);
        int i;

        for (i = 0; i < SC_V51_WINDOW / 4; i++)
                w[i] = p[i];
}

static int sc_v51_window_equal(volatile const u32 *a, volatile const u32 *b)
{
        int i;

        for (i = 0; i < SC_V51_WINDOW / 4; i++)
                if (a[i] != b[i])
                        return 0;
        return 1;
}

/* ---- v51: the cred-offset calibration ---------------------------------- */
static void sc_v51_calibrate(void)
{
        u64 it, ic;
        u32 i, hits = 0, hit_off = 0;

        sc_v51_uid_ok = 0;
        sc_v51_cred_off = 0;

        it = ksu_kallsyms_lookup_name("init_task");
        ic = ksu_kallsyms_lookup_name("init_cred");
        if (!it || !ic) {
                susfs_diag_logf("supercall: v52 calibrate: init_task=0x%lx init_cred=0x%lx - %s missing from kallsyms; uid gate stays uncalibrated (SHOW answers disabled, box safe)\n",
                                it, ic, it ? "init_cred" : "init_task");
                return;
        }

        /* Find the ONE adjacent (real_cred, cred) pair both equal to
         * &init_cred inside init_task.  The idle task's creds never change,
         * so the pair is stable for the whole boot; cred is the SECOND
         * slot (struct task_struct lists real_cred first). */
        for (i = 0; (i + 1) * 8 <= SC_V51_TASK_SCAN; i++) {
                u64 a = *(volatile u64 *)(it + (u64)i * 8);
                u64 b = *(volatile u64 *)(it + (u64)i * 8 + 8);

                if (a == ic && b == ic) {
                        hits++;
                        hit_off = i * 8 + 8;
                }
        }
        if (hits != 1 || !hit_off) {
                susfs_diag_logf("supercall: v52 calibrate: init_task pair scan found %u adjacent (real_cred,cred) pairs (want exactly 1) - refusing the hardcoded-0x788 read too; uid gate stays uncalibrated (SHOW answers disabled, box safe)\n",
                                hits);
                return;
        }
        sc_v51_cred_off = hit_off;

        /* Verify struct cred's uid offset against init_cred's own bytes:
         * usage (atomic_long, +0) must be a small positive refcount, and
         * the root credential's uid/gid/suid/sgid/euid/egid/fsuid/fsgid
         * words (+8..+0x28) must ALL be zero.  A wrong uid offset here
         * fails this check and the gate stays off. */
        {
                u64 usage = *(volatile u64 *)ic;
                u32 nonzero = 0;

                for (i = 8; i <= SC_V51_CRED_CHECK_END; i += 4)
                        if (*(volatile u32 *)(ic + i) != 0)
                                nonzero++;
                if (usage == 0 || usage > 0x10000 || nonzero) {
                        susfs_diag_logf("supercall: v52 calibrate: init_cred sanity failed (usage=%lu, nonzero uid-window words=%u) - uid gate stays uncalibrated (SHOW answers disabled, box safe)\n",
                                        usage, nonzero);
                        sc_v51_cred_off = 0;
                        return;
                }
        }

        sc_v51_uid_ok = 1;
        susfs_diag_logf("supercall: v52 calibrate: task_struct.cred at +0x%lx (the v49 wrapper's hardcoded header offset was 0x788%s); uid at cred+8 verified against init_cred - the uid gate is calibrated\n",
                        (u64)hit_off,
                        hit_off == 0x788 ? " - identical here, the wedge lived elsewhere in the GCC wrapper"
                                         : " - DIFFERENT, the hardcoded read was the wedge");
}

/* ======================================================================= */
/* THE INSTALLER - replaces v49/v50's susfs_supercall_init (weakened).     */
/* The transport mechanics are the field-proven v50 shape verbatim; the    */
/* only additions are the calibration call and the v51 receipts.           */
/* ======================================================================= */
int susfs_supercall_init(void)
{
        u64 table, entry, handler, dispatcher, me;
        volatile u32 want[SC_V51_WINDOW / 4];   /* original's preamble window */
        volatile u32 have[SC_V51_WINDOW / 4];   /* our window after the clone */
        int stage, i, live = 0, disp_idx = -1, err;

        stage = susfs_current_arm_stage();
        sc_full_mode = (stage >= 3) ? 1 : 0;

        susfs_diag_logf("supercall: v52 clang accept-path init (CLI wire ABI: e1=version e2=enabled_features e3=variant) (stage %d, mode=%s; entry AND accept path compiled by clang-17; the v49 GCC wrapper is never called - the v50 field verdict convicted its first execution)\n",
                        stage, sc_full_mode ? "FULL" : "OBSERVE-ONLY");

        /* 0. v51: calibrate the uid gate BEFORE anything can answer. */
        sc_v51_calibrate();

        /* 1. the live table (fp layer cache first, resolver fallback -
         *    the exact v49/v50 order). */
        table = susfs_fp_syscall_table();
        if (!table)
                table = ksu_kallsyms_lookup_name("sys_call_table");
        if (!table) {
                susfs_diag_logf("supercall: v52: sys_call_table not resolved - transport unavailable (loaded, not installed)\n");
                return 0;
        }

        /* 2. liveness proof, v49 shape: KernelSU-Next patched its own
         *    dispatcher INTO this table; finding it proves the table is
         *    what the live dispatch executes through. */
        dispatcher = ksu_kallsyms_lookup_name("ksu_syscall_dispatcher");
        if (dispatcher) {
                for (i = 0; i < SC_V51_SCAN_ENTRIES; i++) {
                        if (((u64 *)table)[i] == dispatcher) {
                                live++;
                                if (disp_idx < 0)
                                        disp_idx = i;
                        }
                }
        }

        entry   = ((u64 *)table)[SC_V51_NR];
        handler = ksu_kallsyms_lookup_name(SC_V51_HANDLER);
        me      = (u64)(unsigned long)&susfs_sc_entry;

        susfs_diag_logf("supercall: v52: table=0x%lx table[%d]=0x%lx handler(%s)=0x%lx dispatcher=0x%lx in %d entr%s (idx %d)\n",
                        table, SC_V51_NR, entry, SC_V51_HANDLER, handler,
                        dispatcher, live, live == 1 ? "y" : "ies", disp_idx);

        /* 3. idempotent re-init (same boot, second trigger). */
        if (entry == me) {
                susfs_diag_logf("supercall: v52: table[%d] already points at our entry (re-init) - transport LIVE\n",
                                SC_V51_NR);
                sc_orig = handler;
                sc_installed = 1;
                return 0;
        }

        /* 4. sanity gates (v49/v50 conditions; refuse = loaded, not installed). */
        if (handler && entry != handler) {
                susfs_diag_logf("supercall: v52: table[%d]=0x%lx is not %s=0x%lx - refusing (loaded, not installed)\n",
                                SC_V51_NR, entry, SC_V51_HANDLER, handler);
                return 0;
        }
        if (!live) {
                susfs_diag_logf("supercall: v52: ksu_syscall_dispatcher not found in the table - refusing (loaded, not installed)\n");
                return 0;
        }

        /* 5. our own landing pad must be intact (clang emitted endbr64). */
        if (*(volatile u32 *)&susfs_sc_entry != 0xfa1e0ff3u) {
                susfs_diag_logf("supercall: v52: our entry lost its endbr64 landing pad (0x%08x) - refusing (loaded, not installed)\n",
                                *(volatile u32 *)&susfs_sc_entry);
                return 0;
        }

        /* 6. THE PREAMBLE CLONE (v50, field-proven at stage 2): copy the
         *    ORIGINAL entry's ENTIRE 16-byte preamble window into ours,
         *    byte for byte, before the table write. */
        sc_v51_read_window(entry, want);
        sc_v51_read_window(me, have);
        susfs_diag_logf("supercall: v52 orig window [-16..-1): %08x %08x %08x %08x\n",
                        want[0], want[1], want[2], want[3]);
        susfs_diag_logf("supercall: v52 own window (clang preamble) : %08x %08x %08x %08x\n",
                        have[0], have[1], have[2], have[3]);

        err = ksu_patch_text((void *)(me - SC_V51_WINDOW),
                             (void *)want, SC_V51_WINDOW,
                             SC_V51_PATCH_FLAGS);
        if (err) {
                susfs_diag_logf("supercall: v52: preamble clone write FAILED rc=%d - refusing (loaded, not installed)\n",
                                err);
                return 0;
        }
        sc_v51_read_window(me, have);
        if (!sc_v51_window_equal(want, have)) {
                susfs_diag_logf("supercall: v52: preamble clone did not stick (%08x %08x %08x %08x vs %08x %08x %08x %08x) - refusing (loaded, not installed)\n",
                                have[0], have[1], have[2], have[3],
                                want[0], want[1], want[2], want[3]);
                return 0;
        }
        susfs_diag_logf("supercall: v52: preamble window cloned + verified (16 bytes, byte-exact)\n");

        /* 7. THE TABLE WRITE: table[173] = our entry, then read back. */
        err = ksu_patch_text((void *)&((u64 *)table)[SC_V51_NR],
                             &me, sizeof(me), SC_V51_PATCH_FLAGS);
        if (err) {
                susfs_diag_logf("supercall: v52: table entry write FAILED rc=%d - refusing (loaded, not installed)\n",
                                err);
                return 0;
        }
        if (((u64 *)table)[SC_V51_NR] != me) {
                susfs_diag_logf("supercall: v52: table entry write did not stick (0x%lx vs 0x%lx) - refusing (loaded, not installed)\n",
                                ((u64 *)table)[SC_V51_NR], me);
                return 0;
        }

        sc_orig = handler;
        sc_installed = 1;
        susfs_diag_logf("supercall: v52 transport LIVE - table[%d] -> susfs_sc_entry (clang-17 entry + ALL-CLANG accept path; observe = counter + -EINVAL; full = magic + calibrated-uid gate + SHOW_VERSION/SHOW_VARIANT/SHOW_ENABLED_FEATURES answers, feature commands not handled until the next rung; uid gate %s)\n",
                        SC_V51_NR,
                        sc_v51_uid_ok ? "CALIBRATED" : "UNCALIBRATED (answering nothing)");
        return 0;
}

/* Replaces v49/v50's susfs_supercall_exit (weakened in the base).  Only
 * reached from the layer teardown path; this kernel is built without
 * MODULE_UNLOAD so it is effectively a no-op - kept correct anyway. */
void susfs_supercall_exit(void)
{
        u64 table;

        if (!sc_installed)
                return;
        table = susfs_fp_syscall_table();
        if (!table)
                table = ksu_kallsyms_lookup_name("sys_call_table");
        if (table) {
                int err = ksu_patch_text((void *)&((u64 *)table)[SC_V51_NR],
                                         &sc_orig, sizeof(sc_orig),
                                         SC_V51_PATCH_FLAGS);
                susfs_diag_logf("supercall: v52 exit: table[%d] %s (0x%lx)\n",
                                SC_V51_NR,
                                err ? "restore FAILED" : "restored",
                                sc_orig);
        }
        sc_installed = 0;
}
