
## [v26.11.43-x86_64] - 2026-11-23

### x86_64 port (tri-channel trigger + console breadcrumbs)

- **milestone: the v42 field round completed its attribution contract.** The
  four evidence files (init_trace.txt, diag_last.txt [absent], boot.log,
  kernel_facts.txt) from wedge boot 18d64d21a9894b69bf76f81f3d5b00fa show:
  image load CLEAN (vanilla candidate, all relocations applied, zero kernel
  warnings — the android13 candidate failed init_module with ENOEXEC and the
  loader fell through), substep 0 armed, then at 18:59:37 the box died INSIDE
  the force_init write: the "force_init write returned" receipt never landed,
  the first 5s box heartbeat never landed (death bounded to <5s), the
  witness's @0s read succeeded (params alive at trigger+0s), no PARAM READ
  TIMEOUT receipts (NOT a param_lock deadlock), and no -50 sentinel (the
  kworker never executed the fn's first store). v39/v40/v41 showed the same
  signature with different images; the only context in which the dispatch
  verifiably RAN (v34-v37, gcc/kernel.org images) was the POST-FS-DATA
  trigger ("early"), never the boot-completed trigger. Also noted: kr_seed /
  arm_stage / init_maxstep writes all ride STOCK kernel param_ops code, so
  the force_init .set is the FIRST module FUNCTION CALL of the whole boot.

- **fix (module): the trigger is split from the queueing path.** `force_init`
  now takes a value: `2` = SYNC dispatch (susfs_init_body called DIRECTLY
  from the .set — with init_maxstep=0 that is stores + vsnprintf only, NO
  workqueue, NO wake-up, NO scheduling machinery at all); `1` = the v42
  deferred path (bare schedule_work + ret) kept byte-for-byte for
  comparison. Sync sentinels: -70 (.set entered the body call), -71
  (already-done). This isolates the last two suspects from each other: a
  box that freezes at the SYNC trigger indicts the sysfs write machinery
  itself; a box that survives SYNC where the deferred path froze indicts
  the queue_work path.

- **fix (module): console breadcrumbs that survive a dead box.** Both
  dispatch paths first hit a diag_printk-gated raw `printk(KERN_EMERG
  "XYZDIAG2: force_init .set ENTERED ...")`. printk takes NO param_lock,
  lands in the ring buffer AND on the console (cmdline: console=tty0
  ignore_loglevel), so the LDPlayer window itself shows the breadcrumb if
  the box dies at the write — the one witness that survives both a param
  deadlock and a hard freeze. Raw literal prefix, outside pr_fmt.

- **fix (scripts): trigger_mode default is now `sync`** (was `set`):
  boot-completed.sh writes force_init=2 for the dispatch-probe round and
  advances the ladder from there. `set` (force_init=1, deferred),
  `get` (probe .get READ channel) and `early` (post-fs-data write — the
  v35-v37 context) remain selectable via /data/adb/ReSuSFS/trigger_mode.
  The script also arms diag_printk=1 and snapshots a dmesg baseline right
  before the trigger, and the witness/heartbeat/timeout-guard machinery
  from v42 is unchanged.

- **fix (loader): the DEFAULT LKM candidate is now VANILLA.** The v42
  android13 image fails init_module with ENOEXEC on the box every attempt
  ("no symbol version for module_layout" + an x86 "Skipping invalid
  relocation target, existing value is nonzero" warning each boot before
  the fallthrough) — it stays shippable but is no longer tried first. The
  vanilla candidate is the one image that loads CLEAN in the field (all
  relocations applied, zero kernel warnings) and carries the v26.11.26-37
  build profile whose module code verifiably EXECUTED.

- **unchanged (field-proven): the ladder (init_seq 0..7, arm_stage 0..4,
  one rung per healthy boot, next-boot stand-down with the WEDGE DOSSIER),
  the two-step opt-in (enable_lkm + enable_force_init), the seed-v2
  resolver, Phase-0 kernel recon, and the payload-stamp self-heal (now
  v26.11.43, so a v43 flash refreshes the device image on the next boot).**

## [v26.11.42-x86_64] - 2026-11-23

### x86_64 port (ABI-correct build + freeze-proof attribution)

- **milestone: the freeze at the force_init write has been fully
  post-mortemed, and v42 removes every defect the post-mortem found.**
  The v39/v40/v41 field boots all froze the box AT the `force_init` echo —
  the FIRST module code the whole boot executes under the ksud zombie
  load — with the v41 witness reading `init_laststep=-1` once and then
  dying with the box. Every checkable thing in those images came back
  clean (setter machine code: no canary, plain stores, direct in-module
  calls, one external queue_work-family call, plain ret; 124/124 imports
  present in the uploaded field kernel_kallsyms.txt; params.c and
  moduleparam.h byte-identical between kernel.org 5.15.178 and the
  running kernel's android13-5.15-2025-03 lineage; .bss heads benign),
  and the v41 attribution contract itself had a blind spot: the witness
  read init_laststep through the same mod->param_lock the stuck write
  path holds, so "stuck at -1" proved nothing.

- **fix (ABI): the android13 candidate is now built against the EXACT
  running kernel lineage.** The running kernel's `struct module` is the
  Android one (scmversion + 4 ANDROID_KABI_RESERVEs = 0x340 bytes) while
  every kernel.org-built image since v26.11.26 shipped a 0x300-byte
  `.gnu.linkonce.this_module` section — the kernel initializes its own
  larger struct INSIDE that section at load time, writing 0x40 bytes
  past it into the module's .bss. v42's android13 candidate is built
  from the AOSP `kernel_common-ASB-2025-03-05_13-5.15` mirror (verified
  5.15.178) so the struct module section is the kernel's own size; the
  vanilla candidate keeps the kernel.org 0x300 section as the
  byte-faithful v37 rollback profile.

- **fix (toolchain/thunks): both candidates are built with HOST GCC and
  RETPOLINE/RETHUNK off.** The only images whose module code verifiably
  executed in the field (v26.11.34-37) all carry the GCC fingerprints
  (.text.unlikely + .rodata.str1.8) and zero thunk imports; the clang
  rebuilds (v40/v41) froze at the first call. The v42 verifier caught a
  live landmine in the first gcc build of this session: defconfig enables
  CONFIG_RETPOLINE, gcc-14 emitted seven `__x86_indirect_thunk_*`
  imports, and the field kernel's kallsyms has NO such symbols
  (LDPlayer built RETPOLINE=n) — that image would have resolved those
  imports to garbage and jumped into the void on its first indirect
  call. The rejected build never shipped; the shipped builds carry 124
  imports, all present in the field kallsyms, zero thunks, plain rets.

- **fix (module): the force_init setter is now BARE `schedule_work` +
  `ret` — no DIAG, no sentinel stores, no variable reads.** If the box
  still freezes at the write, the setter's own three instructions are
  ruled out by construction. All sentinels moved into the deferred
  kworker, which runs OUTSIDE mod->param_lock: init_laststep now
  carries -50 (kworker ENTERED — a raw store as its first executed
  instruction, before vsnprintf/any call), -51 (already initialized),
  -60 (the new probe param's .get entered), and 0..7 (body substeps;
  susfs_init_body also stores laststep=0 as its first statement).

- **fix (scripts): the witness can no longer be blinded and the box can
  no longer fake its own death.** Every param read in the trigger
  scripts goes through `timeout -s KILL 1 cat` (the param_lock mutex
  sleeps TASK_KILLABLE, so SIGKILL breaks a blocked read): a
  param_lock deadlock now prints "PARAM READ TIMEOUT" receipts with the
  exact adb dmesg-capture commands to run BEFORE rebooting — the one
  decisive capture every previous wedge lost. A pure-userspace box
  heartbeat (file+sync only, no module access) beats every 5s for 40s
  across the trigger window: beats continuing after a frozen trigger =
  kernel alive, only module-param traffic dead (capture dmesg, then
  reboot); beats stopping = the box itself died, window bounded to 5s.

- **feature (module): a READ-path dispatch channel.** New `probe`
  parameter with a custom `.get` (module code in the sysfs READ path —
  never exercised on this box) gated by `probe_arm` (a STANDARD int
  param: writing it is pure kernel code). `/data/adb/ReSuSFS/
  trigger_mode` selects the channel: `set` (default, the force_init
  WRITE channel), `get` (write probe_arm=1 then cat probe), `early`
  (post-fs-data writes force_init — the v35-v37 trigger context that
  verifiably ran). If `get` survives a boot that `set` froze, the sysfs
  WRITE path itself is the culprit; if both freeze, it is module code
  execution.

- **unchanged (field-proven): the ladder (init_seq 0..7, arm_stage
  0..4, one rung per healthy boot, next-boot stand-down with the WEDGE
  DOSSIER), the two-step opt-in (enable_lkm + enable_force_init), the
  seed-v2 resolver (kln= + gsoff=), Phase-0 kernel recon, and the
  payload-stamp self-heal (now v26.11.42, so a v42 flash refreshes the
  device image on the next boot).**

## [v26.11.27-x86_64] - 2026-11-22

### x86_64 port (the LKM loads - now hunting the dead supercall path)

- **milestone: the v26.11.26 LKM loads on LDPlayer 14, reproducibly.** The
  user's v26.11.26 boot.log is the first load success in the port's entire
  history: the loader resolved 122/122 imports (zero unresolved - the
  five-symbol fix worked exactly as designed), `init_module` returned 0
  WITHOUT the vermagic fixup ("vermagic fixup not needed" - the
  byte-identical vermagic held), `/sys/module/susfs_guard_lkm` exists,
  `/proc/susfs_path` was present right after the load, the module is Live
  in `/proc/modules` (`susfs_guard_lkm 593920 - - Live 0x0 (O)`), and the
  system booted to completion in ~10s twice in a row with the module
  loaded - no freeze, no watchdog skips, every module stage completed.
  The load wall (v26.11.22..v26.11.26) is over.

- **remaining issue (diagnosed from the same logs): the supercall path
  does not answer.** Every `ksu_susfs` command reports "no supercall
  answer", and stage-early's functional probe (`ksu_susfs show version`)
  failed ONE SECOND after the successful load - so the path was already
  dead at load time, not something that degraded later. Consistent
  corollaries: the module stays in userspace-only mode (stage-early
  skips susfs application), the WebUI shows "Unsupported ksu_susfs
  version / Kernel Version Unknown / no features", and `apply-*-settings`
  supercall-driven applies fail (the ksuctl EAGAIN on `selinux_hide` is
  KernelSU-side, unrelated). Also observed: the module's OWN control
  nodes vanish from stat after a few minutes (`ls -l /proc/susfs_path`
  fails in diagnose while the `-e` check passed right after load) and the
  module's self-hiding from `/proc/modules` is not active (its line
  shows) - both pointing at stealth layers that did not arm, the same
  class of failure as the supercall.

- **why no fix yet: the decisive evidence was never captured.** The
  module's init prints its layer results, the `current_task` %gs offset
  it resolved, the canary/skip state, and any non-fatal layer failure -
  all to dmesg. `susfs_insmod` seeks `/dev/kmsg` to the END before
  `init_module`, so none of those lines ever reached boot.log, and
  diagnose.sh never dumped dmesg either. The possibilities the evidence
  will separate: (a) the delayed canary recheck disarmed the supercall
  (its pr_err would be in dmesg), (b) the reboot kprobe registered at a
  wrong address (BOLT/LTO kallsyms quirk), (c) the `current_task` %gs
  offset assumption (kallsyms printed `0` for it under kptr_restrict=2,
  which may be the restricted print rather than the true offset), or
  (d) non-fatal layers failing to arm.

- **fix: post-fs-data now captures the evidence automatically after
  every successful load** (`capture_lkm_live_evidence()` in utils.sh,
  called in the LIVE branch of post-fs-data.sh, output into boot.log):
  a live supercall test (`ksu_susfs show version / variant /
  enabled_features`), the module's own init-time dmesg lines (grep -i
  susfs over the last 400), the kallsyms ground truth for
  `current_task`/`__x64_sys_reboot`/`__per_cpu_start`/
  `fixed_percpu_data`/`init_task` with kptr_restrict relaxed exactly the
  way the loader does it (restored right after; an 'A' record prints the
  per-CPU offset, which directly validates the offset the module
  chose), the kprobe registration state (best effort via
  /sys/kernel/debug/kprobes/list), the /proc/modules visibility of the
  module, and the control-node existence-vs-listing state (the -e check
  versus `ls /proc` - hidden-from-listing by the module's own stealth is
  EXPECTED, missing from stat is a bug). Everything best-effort and
  timeout-bounded; nothing can fail the boot stage.

- **fix: diagnose.sh STEP 00 now dumps the susfs-related dmesg tail
  too** (last 40 lines, busybox first) so the user-triggered diagnose
  carries the module state even when post-fs-data's capture was missed.

- **no LKM change this release:** the .ko is byte-identical to
  v26.11.26's (it loads and the system is stable - do not touch what
  works). The next LKM change lands after the captured evidence names
  the dead layer.

## [v26.11.26-x86_64] - 2026-11-22

### x86_64 port (the five leftover unresolved symbols, eliminated)

- **fix (critical): the bundled LKM now reaches ZERO unresolved symbols on
  LDPlayer 14.** The v26.11.25 boot log got the load through the vermagic and
  __versions gates and produced a clean list of exactly five names the kernel
  refused - `try_module_get`, `module_put`, `find_vma`, `current_task`,
  `saved_boot_config`. The first three are normally EXPORT_SYMBOL'd, the
  fourth is a per-CPU variable reached through EXPORT_PER_CPU_SYMBOL, and the
  fifth is an fs/init static that ksud/susfs_insmod relocates through
  kallsyms; LDPlayer's clang-LTO+trim build removed the EXPORT for all of them
  and the kallsyms listing for the fifth. The v26.11.26 build removes or
  replaces every reference at the source level so the compiler no longer
  emits the corresponding SHN_UNDEF entries; the loader's kallsyms walk now
  resolves every import that remains.

- **fix: CONFIG_MODULE_UNLOAD=n in the build config.** LDPlayer's kernel was
  built WITHOUT MODULE_UNLOAD - the v26.11.25 boot log shows its required
  vermagic is "5.15.178+ SMP preempt modversions " (34 bytes, no "mod_unload"
  token), and the kernel/module.c export of try_module_get/module_put lives
  behind `#ifdef CONFIG_MODULE_UNLOAD`. Building the LKM with
  CONFIG_MODULE_UNLOAD=y left both as `extern` declarations and the compiler
  emitted `R_X86_64_PLT32 try_module_get` / `module_put` relocations the
  kernel has no answer for ("Unknown symbol try_module_get (err -2)",
  "Unknown symbol module_put (err -2)"). With MODULE_UNLOAD=n in our kbuild
  config, `<linux/module.h>` resolves both to `static inline` no-ops, the
  relocations vanish, AND the resulting vermagic is byte-identical to the
  kernel's own (the loader's vermagic fixup is no longer needed for this
  token, though it stays in place as a safety net). The vermagic printed by
  the v26.11.26 build: `5.15.178+ SMP preempt modversions `.

- **fix: find_vma() replaced with the file-local sus_map_find_vma().**
  `sus_map.c` already defined a private `sus_map_find_vma(mm, start)` (used
  by the walk_page_range hook) that has the exact contract of the kernel's
  `find_vma()` - "first VMA whose vm_end > addr" - and walks the maple tree
  (>= 6.1) or the linked list (<= 6.0) under the mmap_read_lock the caller
  already holds. The one remaining direct `find_vma()` call at
  `sus_map_vm_access_pre` (sus_map.c:665, the access_remote_vm /
  get_user_pages_remote hook) is replaced with `sus_map_find_vma()`, so the
  `R_X86_64_PLT32 find_vma` relocation disappears and the "Unknown symbol
  find_vma (err -2)" reject is gone. No semantic change.

- **fix: <asm/current.h> overridden in the kbuild-x64 tree so `current` no
  longer references the trimmed EXPORT_PER_CPU_SYMBOL(current_task).** The
  kernel's stock `<asm/current.h>` defines `current` as
  `get_current() -> this_cpu_read_stable(current_task)`, whose inline-asm
  expansion (`movq %gs:current_task_offset, %reg`) emits an
  `R_X86_64_32S current_task` relocation. On a normal kernel the loader
  fills the displacement from `EXPORT_PER_CPU_SYMBOL(current_task)`; on
  LDPlayer's LTO+trim build that export is gone, so the kernel reports
  "Unknown symbol current_task (err -2)". The v26.11.26 build replaces
  `<asm/current.h>` (in kbuild-x64/source/arch/x86/include/asm/, only used
  for out-of-tree module builds - modules_prepare was the only kernel build
  step ever run against this tree) with a version that reads current_task
  through `movq %%gs:0(,%1,1), %0` (SIB-only addressing, displacement comes
  from a register load of `susfs_current_task_gs_off`). The displacement is
  resolved once at module init from `ksu_kallsyms_lookup_name("current_task")`
  (kernel/susfs_current.c, called from susfs_init() right after
  ksu_init_symbol_resolver() returns). On the LDPlayer kernel kallsyms
  reports `current_task` at address 0, which is also the correct per-CPU
  displacement there (current_task sits at offset 0 of the per-CPU section);
  on a stock 5.15 kernel where current_task is at offset 4096 (after
  fixed_percpu_data which is __aligned(PAGE_SIZE)) the same resolver sets
  the displacement to 4096. Either way, the compiler never emits a
  `current_task` relocation.

- **fix: saved_boot_config made a file-static in spoof_cmdline.c.** The
  original code declared `extern char *saved_boot_config;` and relied on
  ksud/susfs_insmod to relocate it from kallsyms (the variable is an
  fs/init-main.c static, never EXPORT_SYMBOL'd). The v26.11.25 boot log
  confirmed LDPlayer's kallsyms does not list `saved_boot_config` at all,
  so the import was left at SHN_UNDEF/0 and the kernel rejected it with
  "Unknown symbol saved_boot_config (err -2)". The v26.11.26 port makes
  `saved_boot_config` a `static char *` local to spoof_cmdline.c and
  removes the matching IMP_DATA entry from imports_guard.c. The
  spoof_cmdline feature is now INERT on LDPlayer: spoof_set() writes to
  the local copy, /proc/bootconfig keeps showing the kernel's original
  contents, and the supercall still answers success so callers do not fall
  back to ERR_CMD_NOT_SUPPORTED. The file header documents exactly how to
  re-arm the feature on a kernel that does list saved_boot_config in
  kallsyms (restore the extern + IMP_DATA entry). All other features are
  unaffected.

- **result:** the v26.11.26 .ko carries 122 SHN_UNDEF symbols, down from
  127 in v26.11.25 and 141 in v26.11.24, and the five names the kernel
  refused are no longer among them (verified with `objdump -t` and the
  bundled host-side loader simulation). The vermagic is byte-identical to
  the kernel's own. The next opt-in boot on LDPlayer 14 should be the first
  one where init_module returns 0 - please send the boot.log and the
  diagnose.log regardless of the outcome, so the load either confirms the
  fix end-to-end or surfaces whatever the next layer (kallrecon layout,
  kprobe registration, layer init order) runs into.

## [v26.11.25-x86_64] - 2026-11-22

### x86_64 port (the silent CONFIG_MODVERSIONS gate, found and passed)

- **fix (critical): the bundled LKM now passes the check that rejected every
  earlier build with ENOEXEC and an empty kernel log.** The v26.11.24 opt-in
  boot log was the key evidence: init_module returned errno 8 with the
  kernel printing NOTHING (no "Unknown symbol", no "version magic ... should
  be"). Walking every -ENOEXEC path in 5.15.178's kernel/module.c (the exact
  source the build uses) leaves exactly one silent one, and it fires BEFORE
  the vermagic check: load_module() calls check_modstruct_version() at
  module.c:4029, before layout_and_allocate()->check_modinfo() at :3575. On
  a CONFIG_MODVERSIONS=y kernel (an Android 14 GKI-style build like
  LDPlayer 14's) that exports module_layout with a CRC, a module with NO
  __versions section hits check_version()'s
  `versindex == 0 -> try_to_force_load() == 0` path, and
  try_to_force_load()'s `#else return -ENOEXEC;` branch (force-load off)
  never prints. That is the whole v26.11.22..24 wall - including ksud's
  identical "init_module failed without vermagic mismatch".
- **fix: the module now carries a neutral single-entry __versions section**
  (kernel/modver_dummy.c): a section that exists but has no
  "module_layout" entry only earns the kernel's own escape hatch -
  pr_warn_once("no symbol version for module_layout") + return 1 - and the
  gate passes on MODVERSIONS and non-MODVERSIONS kernels alike. A post-build
  normalizer (tools/normalize_modver.py) pins the section to exactly that
  one entry so a build against a tree with a full Module.symvers can never
  smuggle a disagreeing module_layout CRC back in. The build is
  CONFIG_MODVERSIONS=y, so the vermagic carries the "modversions" word the
  target expects, and with a __versions present same_magic() skips the
  release word anyway.
- **fix: 12 phantom imports eliminated by config-matching the build to the
  kernel the device logs describe.** v26.11.24 resolved 124 of 141 imports
  from /proc/kallsyms; the 17 misses split into 12 config-mismatch imports
  (the kernel runs without retpoline thunks x7, stack protector,
  hardened usercopy, 5-level paging, memory randomization - the import
  list named every one) and 5 names the kernel resolves itself through its
  export tables (try_module_get, module_put, find_vma are EXPORT_SYMBOLs;
  saved_boot_config/current_task come from kallsyms). The build now runs
  with -d RETPOLINE -d STACKPROTECTOR -d HARDENED_USERCOPY -d X86_5LEVEL
  -d RANDOMIZE_MEMORY (plus -fno-stack-protector pinned in the module
  Makefile, arm64-only exemption removed), so 141 -> 127 imports, all of
  them resolvable on the target.
- **fix: the module Makefile's recipe tabs** (spaces made `make modules`
  die with "missing separator" on a fresh tree).
- **fix: the build script now runs olddefconfig after its config edits** -
  without it, modules_prepare drops into an interactive kconfig prompt
  that looks exactly like a hung build (it cost this port two 10-minute
  timeouts).
- **feat: failure evidence upgraded.** A failed load now also records a
  MODVERSIONS probe (`grep __crc_module_layout /proc/kallsyms` - present
  with the CRC as the printed address on a MODVERSIONS kernel), per-name
  kallsyms status for the imports that matter, a RAW dmesg tail (the old
  filtered grep could hide unanticipated wording), and a raw+filtered
  symbol/CRC pattern set.
- **fix: the loader no longer runs twice per opt-in boot** (the custom-
  kernel path already tried it; the generic fallback re-ran it - visible
  in the v26.11.24 log).
- **feat: susfs_insmod explains the silent gate.** errno 8 with no kernel
  log record now prints a note naming the check_modstruct_version path and
  what kind of image triggers it (user-supplied .ko, older builds).
- offline verification: a gate simulator transcribing the exact 5.15.178
  load_module order proves the old .ko fails at check_modstruct_version
  silently (the device symptom, reproduced) and the new one passes; 22/22
  install simulation, 41/41 safeguard/watchdog, 16/16 utils tests.

## [v26.11.24-x86_64] - 2026-11-22

### x86_64 port (make the opt-in LKM load actually possible)

- **fix (critical): the ported susfs_insmod loader refused every x86_64
  module.** The port of the tool rewrote the syscall layer but kept
  upstream's ELF machine check (`e_machine == EM_AARCH64`), so the only
  loader that can load the bundled LKM on a stock kernel always died with
  "not an aarch64 module" (errno 8, ENOEXEC) before doing anything - that
  is exactly what the v26.11.23 opt-in boot log showed after
  `touch /data/adb/ReSuSFS/enable_lkm`. The check now verifies EM_X86_64.
  Verified offline against the shipped .ko with init_module intercepted:
  the loader parses it ("ELF64 x86_64, 51 sections, 1429 symbols"),
  enumerates its 141 undefined symbols and walks /proc/kallsyms correctly.
- **fix (history, corrected): the LKM never actually loaded on v26.11.22
  either.** v26.11.22 and v26.11.23 shipped the byte-identical .ko and the
  byte-identical broken loader (md5-verified), and the kernel rejects the
  .ko through ksud with ENOEXEC anyway ("init_module failed without
  vermagic mismatch" - the module deliberately imports symbols a stock
  kernel does not export, so plain init_module can never succeed). The
  v26.11.23 changelog's "LKM loaded and froze the system" theory was
  therefore wrong: the v26.11.22 freeze was userspace. Prime suspect:
  ReSuSFS_apply-settings.sh disabling adb_enabled/adb_wifi_enabled at
  boot-completed - on an emulator whose host-side window/input control
  rides on adb, a dead guest adb looks exactly like a "frozen" UI while
  the guest stays alive.
- **fix: adb_enabled / adb_wifi_enabled now ship commented out** in the
  default settings script with a note; uncomment only on physical devices.
- **feat: custom-kernel loader order + failure evidence.** On custom
  (non-GKI) x86_64 kernels susfs_insmod now runs FIRST (ksud can never
  succeed there) and with -v, so boot.log records every symbol it
  resolves and every kernel complaint. After any failed load the loader
  block dumps module-related dmesg lines, the load-relevant kernel config
  (when /proc/config.gz exists) and the module/kallsyms sysctls into
  boot.log, so the next report pinpoints the kernel's exact refusal
  reason without another round-trip.
- everything else unchanged: safe defaults, receipt/watchdog boot
  gating, userspace-only mode, diagnose.sh bisector.

## [v26.11.23-x86_64] - 2026-11-22

### x86_64 port (LDPlayer 14 freeze fix)

- **fix (critical): the susfs LKM is no longer auto-loaded on custom
  (non-GKI) x86_64 kernels.** v26.11.22 force-loaded the bundled
  `susfs_guard_lkm-x86_64-5.15.ko` - a runtime kernel-hooking module
  compiled against a generic 5.15 config, not against LDPlayer 14's
  actual kernel build - on every boot. The system booted fully and then
  froze ~10s after the home screen appeared, exactly when
  boot-completed's stage-late pushed ~50 susfs rules into the kernel and
  the media scanner / status loop started exercising the hooks. A
  kernel-level freeze is unrecoverable from userspace, so loading the LKM
  on a custom kernel is now strictly opt-in:
  `touch /data/adb/ReSuSFS/enable_lkm`. GKI/KMI kernels keep the
  automatic load (upstream prebuilts, verified per KMI).
- **fix: built-in kernel susfs is now detected functionally.** The old
  detection required `/proc/config.gz` (absent on LDPlayer), so a
  KernelSU kernel with built-in susfs was indistinguishable from a stock
  kernel and the LKM could be stacked on top of it - two hooking layers
  on the same syscalls. `susfs_kernel_alive()` now asks the kernel through
  the ksu_susfs supercall (`reboot(0xDEADBEEF, ...)` answers EINVAL
  instantly on kernels without susfs, so the probe is safe everywhere):
  built-in susfs => full features with no LKM at all.
- **feat: userspace-only mode.** With no kernel susfs and no LKM, the
  module stays installed and stable: stage-early/stage-late skip the susfs
  application, the module.prop status line reads `userspace-only`, and
  script/cron/prop features keep working.
- **feat: persistent boot instrumentation.** Every boot stage logs to
  `/data/adb/ReSuSFS/logs/boot.log` (timestamped, sync-ed after every
  line, mirrored to /dev/kmsg) so a frozen system still leaves readable
  evidence after a hard instance restart.
- **feat: hang watchdog.** Every stage runs under a receipt: a stage
  that never finished on the previous boot is skipped automatically
  (after two hangs it is quarantined), so a userspace hang can never
  trap the module in a boot loop.
- **fix: all supercalls timeout-bounded** (`rs_run`), `service.sh`'s
  status loop runs at a 30s cadence, exits when the module is disabled,
  and no longer rewrites module.prop on every pass (status_report
  dedupes).
- **fix: `set_cmdline_or_bootconfig` skips documentation-only files** -
  the stock default file is comments; passing it on would have spoofed
  /proc/cmdline with comment text for every non-su process.
- **safe defaults:** all postfs/bootcompleted user scripts ship
  commented out; config toggles blank; upgrading from v26.11.22
  force-resets the old aggressive config (backed up to
  `/data/adb/ReSuSFS.bak.<ts>`).
- **feat: `diagnose.sh` bisector** - applies each feature one step at a
  time, receipt-gated, logged to `diagnose.log`; the Action button runs
  it. On kernels without susfs it states up front that steps 01-08 are
  expected to answer "not supported".

## [v26.10.23] - 2026-10-23


### 🧹 Chores

- bump version to 26.10.23 (@ahmed-alnassif)

## [v26.10.21] - 2026-10-21


### 🌐 WebUI

- **fix:** fix the editor throwing an error when it closes (@ahmed-alnassif)

### 🧩 Module

- **refactor:** skip config prompts on fresh installs with no configs (@ahmed-alnassif)
- **fix:** default CONFIGURE to true so ReSuSFS dir isn't left empty (@ahmed-alnassif)

### ✨ Features

- update the module icon (@ahmed-alnassif)

### 📚 Documentation

- update README for LKM support, scheduling and UserHub (@ahmed-alnassif)
- update ReSuSFS description (@ahmed-alnassif)

### ⚙️ CI/CD

- use -9 max compression for smaller release zip to speed up user downloads (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.21 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump marked in /webui in the webui-deps group (#26)

## [v26.10.16] - 2026-10-16


### 🧩 Module

- **feat:** prompt before updating configs (@ahmed-alnassif)
- **fix:** remove hidden_api_policy to avoid enabling hidden API access, note: update your configuration in this update (close: #25) (@ahmed-alnassif)
- **feat:** full SuSFS LKM support with auto-download and load on boot (@ahmed-alnassif)
- **fix:** make download_file resilient to slow and unstable networks (@ahmed-alnassif)
- **fix:** verify LKM load via loader exit code instead of lsmod (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.16 (@ahmed-alnassif)

## [v26.10.13] - 2026-10-13


### 🌐 WebUI

- **fix:** route all editor close paths through one dirty-check, fixes back gesture skipping the unsaved-changes prompt and the title staying stuck after closing (fix: #23) (@ahmed-alnassif)
- **l10n:** update translations (#21) (@weblate)
- **fix:** stop the unsaved changes prompt from showing twice (@ahmed-alnassif)
- **fix:** keep the unsaved changes prompt from exiting the module on back (@ahmed-alnassif)

### ✨ Features

- add an icon for KernelSU modules (@ahmed-alnassif)

### 🔧 Fixes

- add icon metadata to module.yaml (@ahmed-alnassif)

### 📚 Documentation

- update banner image (@ahmed-alnassif)
- add a new logo (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.13 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 7 updates (#24)

## [v26.10.11] - 2026-10-11


### ✨ Features

- add module.yaml to add ReSuSFS to KernelSU manger (@ahmed-alnassif)

### 🔧 Fixes

- back button now works correctly for menus and dialogs (@ahmed-alnassif)
- one asset per release (@ahmed-alnassif)

### 📚 Documentation

- migrate ReSukiSU to BakaSU (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.11 (@ahmed-alnassif)

## [v2.3.0-f55930f] - 2026-10-05


### 🧩 Module

- **fix:** remove hot install since ReSuSFS requires a full reboot after installing or updating (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-f55930f (@ahmed-alnassif)

## [v2.3.0-1e6fb20] - 2026-10-05


### 🌐 WebUI

- **feat:** add clear button to log viewers (@ahmed-alnassif)
- **feat:** add color highlighting to log viewers (@ahmed-alnassif)
- **feat:** add color highlighting to terminal output by [symbol] tags (@ahmed-alnassif)
- **feat:** color a script's own output lines inside the cron log viewer, not just the start/end lines (@ahmed-alnassif)
- add Arabic translation setting and correct ar-SA (@ahmed-alnassif)
- migrate from crowdin to weblate (@ahmed-alnassif)
- **fix:** show a script's full output in its cron log, not just the start/end lines (@ahmed-alnassif)

### 🧩 Module

- **fix:** use status symbol instead success for script exit (@ahmed-alnassif)

### 📚 Documentation

- migrate from crowdin to weblate (@ahmed-alnassif)

### ⚙️ CI/CD

- migrate from crowdin to weblate (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-1e6fb20 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 3 updates (#22)

## [v2.3.0-99af3c2] - 2026-10-03


### 🌐 WebUI

- **fix:** move @lezer/common override to pnpm-workspace.yaml, fixes syntax highlighting broken by a duplicate package version (@ahmed-alnassif)
- update package.json metadata (version, author, license) (@ahmed-alnassif)
- **fix:** make @lezer/common fix self-updating instead of a hardcoded version (@ahmed-alnassif)
- **feat:** show each script's last cron run time and result in UserHub (@ahmed-alnassif)
- **feat:** add button to view a script's own cron run history (@ahmed-alnassif)
- **feat:** add schedule logs fab button (@ahmed-alnassif)
- **fix:** make the rest of the terminal usable after making it visible (@ahmed-alnassif)
- **fix:** don't show schedule log fab in SuSFS tab (@ahmed-alnassif)

### 🧩 Module

- **feat:** log start/end time and exit code for every cron-run script (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-99af3c2 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 6 updates (#19)

## [v2.3.0-eb224b2] - 2026-09-25


### 🌐 WebUI

- add translation link instead of documentation (closes #8) (@ahmed-alnassif)
- **feat:** make back button/gesture close dialogs, the editor, and terminals instead of exiting the app immediately (closes #18) (@ahmed-alnassif)

### ⚙️ CI/CD

- **fix:** don't upload local translations (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-eb224b2 (@ahmed-alnassif)

## [v2.3.0-edb5e2f] - 2026-09-23


### 🧩 Module

- ask for configs backup only when they exist (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-edb5e2f (@ahmed-alnassif)

### 🤖 Automated

- webui: new Crowdin translations by GitHub Action (#15)
- webui(deps): Bump the webui-deps group in /webui with 4 updates (#16)
- webui(deps): Bump the webui-deps group in /webui with 4 updates (#17)

## [v2.3.0-d348051] - 2026-09-12


### 🌐 WebUI

- **refactor:** add UserHub next to home tab (@ahmed-alnassif)
- **style:** change UserHub icon (@ahmed-alnassif)
- **feat:** add available languages to selector (@ahmed-alnassif)

### 📚 Documentation

- add GKID as the recommended kernel for full SuSFS support (@ahmed-alnassif)

### ⚙️ CI/CD

- fix Crowdin XML config to skip name attributes (@ahmed-alnassif)
- improve Crowdin workflow with official action pattern and proper branch handling (@ahmed-alnassif)
- use the correct secret variable for crowdin (@ahmed-alnassif)
- fix syntax error (@ahmed-alnassif)
- **crowdin:** don't start the workflow in every doc push (@ahmed-alnassif)
- **crowdin:** upload local translations (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-d348051 (@ahmed-alnassif)

### 🤖 Automated

- webui/locales: sync translation from Crowdin (#11)
- New Crowdin translations by GitHub Action (#12)
- webui: new Crowdin translations by GitHub Action (#14)

## [v2.3.0-47be13c] - 2026-09-11


### 🌐 WebUI

- **fix:** don't let other elements cover the editor (@ahmed-alnassif)
- **fix:** fix About version lookup and link handlers (@ahmed-alnassif)
- **refactor:** donations card in more tab (@ahmed-alnassif)
- **perf:** stop rebuilding every visible UserHub row on each search keystroke/tag click, reuse built elements via a persistent map, tighten IntersectionObserver margin (@ahmed-alnassif)
- **fix:** make UserHub load faster and feel smoother (@ahmed-alnassif)
- **fix:** stop scripts from losing their tags and the list shaking while scrolling (@ahmed-alnassif)

### 📚 Documentation

- add Crowdin badge (@ahmed-alnassif)
- add KernelSU Next warning to README (@ahmed-alnassif)
- fix formatting (@ahmed-alnassif)
- add KernelSU Next warning to changelog (@ahmed-alnassif)

### ⚙️ CI/CD

- move crowdin sync to dev, publish locales-dist branch (@ahmed-alnassif)
- simplify crowdin workflow to single branch (@ahmed-alnassif)
- drop locales.zip artifact (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-47be13c (@ahmed-alnassif)

### 📦 Other

- drop: remove KernelSU Next support (@ahmed-alnassif)

### 🤖 Automated

- webui/locales: sync translation from Crowdin (#5)
- webui/locales: sync translation from Crowdin (#6)

> [!Important]
> **KernelSU Next is not recommended.**
>
> KernelSU Next is currently **unmaintained** and has been observed engaging in anti-competitive behavior, including blacklisting the official ReSuSFS module without technical justification. This is not a security decision, it is a control decision.
>
> Using an unmaintained kernel root solution can lead to:
>
> - **Instability** and unexpected crashes.
> - **Bootloops** that can leave your device unusable.
> - **Security vulnerabilities** that will never be patched.
> - **Broken module compatibility** as the ecosystem moves forward.
>
> To protect your device and ensure you receive official support:
>
> - Use **KernelSU**: The upstream, official root solution.
> - Use **BakaSU**: A trusted, community-respected fork.
>
> ReSuSFS is the only official SuSFS module for KernelSU. It is fully supported on KernelSU and BakaSU only.
>
> Do not use KernelSU Next. Choose stability. Choose freedom. Choose official support.

---

## [v2.3.0-bc8e52b] - 2026-09-09


### 🌐 WebUI

- **fix:** replace hardcoded donation address with a link to the GitHub support page, remove now-unused clipboard-copy logic (@ahmed-alnassif)

### ✨ Features

- add custom sponsorship URL to FUNDING.yml (@ahmed-alnassif)

### 📚 Documentation

- I think it's working fine with/without SuSFS (@ahmed-alnassif)
- add ReSuSFS banner (@ahmed-alnassif)
- update donation info (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-bc8e52b (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump @codemirror/view in /webui in the webui-deps group (#4)
- ci(deps): Bump crowdin/github-action from 2 to 3 (#3)

## [v2.3.0-f851a6e] - 2026-09-06


### 🌐 WebUI

- **fix:** export full config directory without filtering (@ahmed-alnassif)
- **feat:** add user-friendly cron schedule field to UserHub script rows (@ahmed-alnassif)

### 🧩 Module

- **feat:** add sync_cron_scripts() via busybox crond, synced on boot-completed (@ahmed-alnassif)
- **fix:** prevent duplicate crond processes in sync_cron_scriptsci(fix): improve disk cleanup and swap to prevent build kill (@ahmed-alnassif)

### ⚙️ CI/CD

- add Dependabot (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-f851a6e (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 6 updates (#2)

## [v2.3.0-4d61c95] - 2026-09-05


### 🌐 WebUI

- **feat:** add script tags, filter bar, and inline editor (@ahmed-alnassif)

### 🧩 Module

- **feat:** improve config persistence handling (@ahmed-alnassif)
- **feat:** update scripts configuration handling (@ahmed-alnassif)
- **feat:** add ksu-settings script to bootcompleted (@ahmed-alnassif)

### ✨ Features

- add backup confirmation prompt before config handling (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-4d61c95 (@ahmed-alnassif)

## [v2.3.0-5ec5ad8] - 2026-09-05


### 🌐 WebUI

- fix UserHub tab loading/refreshing lag (@ahmed-alnassif)
- **fix:** write backup tar log to Download dir and ensure it exists before export (@ahmed-alnassif)
- **fix:** escape shell vars in backup script and move tar log to ReSuSFS dir (@ahmed-alnassif)
- **perf:** only refresh UserHub's script list when scripts actually change, not on every tab switch (@ahmed-alnassif)
- **feat:** add sort options to UserHub (name A-Z/Z-A, enabled first, recently/oldest modified) via header button (@ahmed-alnassif)
- **feat:** add search button to UserHub (@ahmed-alnassif)
- **feat:** add Telegram support group link to More, and a shared-configs hint to Home's backup card (@ahmed-alnassif)

### 📚 Documentation

- highlight strong hiding by default in readme (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-5ec5ad8 (@ahmed-alnassif)

## [v2.3.0-5556867] - 2026-09-04


### 🧩 Module

- **fix:** correct ksud command in uname spoofing script (@ahmed-alnassif)
- **fix:** set ksu features correctly (@ahmed-alnassif)
- **fix:** use full KMI tag and correct hash length in uname spoofing (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-5556867 (@ahmed-alnassif)

## [v2.3.0-145b96d] - 2026-09-04


### 🌐 WebUI

- regenerate pnpm-lock.yaml after adding syntax highlighting dependencies (@ahmed-alnassif)
- **feat:** add shell syntax highlighting to the code editor via CodeMirror language support (@ahmed-alnassif)

### 🧩 Module

- **fix:** correct kstat backend to support static and dynamic spoofing (@ahmed-alnassif)
- **fix:** simplify uname apply to replace values while preserving user comments (@ahmed-alnassif)
- **feat:** add spoofing and hiding scripts for cmdline, uname, paths, maps, mounts, props, settings, and kstat (@ahmed-alnassif)

### 📚 Documentation

- add built-in scripts documentation and update features, userhub, backup, and description sections (@ahmed-alnassif)

### ⚙️ CI/CD

- add build category (@ahmed-alnassif)

### 🏗️ Build

- add lockfile auto-regeneration fallback to local-build.sh when frozen install fails (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-145b96d (@ahmed-alnassif)

## [v2.3.0-9244d05] - 2026-09-03


### 🧩 Module

- **fix:** don't disable the module in every reboot (@ahmed-alnassif)
- **fix:** prevent setScriptStage from adding entries when disabling (@ahmed-alnassif)
- update module.prop description (@ahmed-alnassif)

### 📚 Documentation

- fix changelog (@ahmed-alnassif)
- my plan (@ahmed-alnassif)
- fix formatting (@ahmed-alnassif)

### ⚙️ CI/CD

- **fix:** prepend changelog entries instead of appending (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-9244d05 (@ahmed-alnassif)
## [v2.3.0-4171ba3] - 2026-09-03


### 🌐 WebUI

- add backup/restore in the home page at bottom (@ahmed-alnassif)
- **userhub:** add script metadata display, disable support with ! prefix, and automatic header migration (@ahmed-alnassif)
- **fix:** stop UserHub stage toggle from misfiring on programmatic .selected assignment (@ahmed-alnassif)
- **fix:** hide reboot button while a terminal or editor is open, only show it on normal page views (@ahmed-alnassif)
- **feat:** add reboot FAB next to close-terminal, shown once a running action/script finishes (@ahmed-alnassif)
- **fix:** hide reboot-terminal-btn when the terminal is closed, not just when a new run starts (@ahmed-alnassif)
- **fix:** make reboot terminal button clickable by fixing pointer-events and z-index stacking (@ahmed-alnassif)

### 🧩 Module

- **refactor:** use one directory for configs files (@ahmed-alnassif)
- **feat:** enhance config handling to support folders and any file types (@ahmed-alnassif)
- **fix:** exit when SuSFS download failed (@ahmed-alnassif)

### 📚 Documentation

- add my official telegram group (@ahmed-alnassif)
- update CLI output (@ahmed-alnassif)

### ⚙️ CI/CD

- **fix:** update module issue in the manager (@ahmed-alnassif)
- **feat:** add Telegram upload with commit and CI links (@ahmed-alnassif)
- **fix:** Telegram upload configuration (@ahmed-alnassif)
- **fix:** Telegram MarkdownV2 escaping (@ahmed-alnassif)
- **fix:** escape repository name for Telegram MarkdownV2 (@ahmed-alnassif)
- **fix:** escape CI number in Telegram MarkdownV2 (@ahmed-alnassif)
- add clickable repo link to Telegram caption (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-4171ba3 (@ahmed-alnassif)

## [v2.3.0-f454264] - 2026-09-01


### 🌐 WebUI

- add UserHub tab for creating, editing, running, and deleting user shell scripts (@ahmed-alnassif)
- add reboot button with confirmation dialog to header (@ahmed-alnassif)
- switch backup/restore from JSON to busybox tar archives (@ahmed-alnassif)
- add enabled scripts count to home summary, tapping it jumps to UserHub (@ahmed-alnassif)

### 🧩 Module

- fix exit with 1 if the download failed (@ahmed-alnassif)
- fix: prompt once for differing configs, auto-copy missing files (@ahmed-alnassif)
- add ReSuSFS.sh/post-fs-data.sh/boot-completed.sh support for running UserHub scripts at post-fs-data and boot-completed stages (@ahmed-alnassif)

### 📚 Documentation

- correct uname file format (@ahmed-alnassif)
- update README intro to cover UserHub, backup/restore, and reboot button (@ahmed-alnassif)

### ⚙️ CI/CD

- add detailed changelog using python (@ahmed-alnassif)
- add automated CHANGELOG.md update on release (@ahmed-alnassif)
- fetch full git history in release workflow to fix broken version-change detection (@ahmed-alnassif)
- **release:** fix PREVIOUS_VERSION being written to GITHUB_ENV before it was assigned (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-f454264 (@ahmed-alnassif)
