#!/bin/sh
rm -f /data/adb/ksu/bin/ksu_susfs
rm -f /data/adb/ksu/bin/susfs
rm -f /data/adb/ksu/bin/su
rm -f /data/adb/ksu/bin/ReSuSFS

# v26.11.23: also remove the module-owned LKM payload dir (the .ko never
# auto-loads on custom kernels, but do not leave it behind either).
rm -rf /data/adb/ReSuSFS_LKM

# EOF
