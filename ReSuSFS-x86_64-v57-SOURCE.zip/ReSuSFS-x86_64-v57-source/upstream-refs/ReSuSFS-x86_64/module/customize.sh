#!/bin/sh

DEST_BIN_DIR=/data/adb/ksu/bin
PERSISTENT_DIR=/data/adb/ReSuSFS

. "$MODPATH/utils.sh"

export MODULE_HOT_INSTALL_REQUEST="true"
export MODULE_HOT_RUN_SCRIPT="hotinstall.sh"

banner "$MODPATH"

ui_print "[%] customize.sh "

# v26.11.23 (safe-diagnostic build): when upgrading from an older build whose
# /data/adb/ReSuSFS configs enable boot-time hiding (the v26.11.22 default
# did: 4 postfs + 8 bootcompleted scripts), force-reset to the new safe
# defaults so a stale config cannot keep triggering the post-boot freeze.
# The old directory is preserved as a timestamped backup, nothing is lost.
SAFE_CFG_MARKER="$PERSISTENT_DIR/.safe_diag_v1"
if [ -d "$PERSISTENT_DIR" ] && [ ! -f "$SAFE_CFG_MARKER" ]; then
        ui_print "[*] old ReSuSFS config found - resetting to safe defaults"
        ts_backup="$(date '+%Y%m%d-%H%M%S' 2>/dev/null)"
        if mv "$PERSISTENT_DIR" "${PERSISTENT_DIR}.bak.${ts_backup}" 2>/dev/null; then
                ui_print "[+] backup saved: ${PERSISTENT_DIR}.bak.${ts_backup}"
        else
                rm -rf "$PERSISTENT_DIR" 2>/dev/null
                ui_print "[!] could not move old config, removed it instead"
        fi
fi

detect_key_press() {
        # x86_64 port: emulators (LDPlayer and friends) have no volume keys,
        # so getevent never yields KEY_VOLUME and the original timeout path
        # aborts config updates on them. Auto-answer "VOLUME UP" (the safe
        # default: keep existing configs) on x86_64 instead of blocking.
        case "$(uname -m 2>/dev/null)" in
                x86_64)
                        ui_print "[*] x86_64 device without volume keys: auto-selecting the safe default (keep configs)"
                        return 0
                        ;;
        esac
        timeout_seconds=6
        timeout 0.5 getevent -c 0 >/dev/null 2>&1
        # v26.11.23 portability fix: the original used the bashism
        # `read -t ... < <(getevent ...)`, which several Android shells and
        # any strict POSIX shell refuse to parse ("redirection unexpected" -
        # it aborts the whole installer). Pipe through timeout instead: no
        # volume event within the window simply yields an empty line.
        line="$(timeout $timeout_seconds getevent -ql 2>/dev/null | awk '/KEY_VOLUME/ {print; exit}')"
        if [ -z "$line" ]; then
                ui_print "[!] No key pressed within $timeout_seconds seconds. Skipping installation..."
                return 1
        fi
        if echo "$line" | grep -q "KEY_VOLUMEUP"; then
                return 0
        else
                ui_print "[+] Skipping reset..."
                return 1
        fi
}

CONFIGURE=true
if [ -d "$PERSISTENT_DIR" ]; then
        ui_print "[*] Will select NO in 6s if no volume buttons pressed"
        ui_print "[*] Do you want to update the configs?"
        ui_print "[*] VOLUME UP for NO, DOWN for YES"
        if detect_key_press; then
                CONFIGURE=false
        fi

        if $CONFIGURE; then
                ui_print "[*] Have you backed up your configuration?"
                ui_print "[*] VOLUME UP for YES, DOWN for NO"
                if ! detect_key_press; then
                        ui_print "[!] Please back up your configuration first"
                        exit 1
                fi
        fi
fi

CONFIG_DIR="$MODPATH/configs"

[ ! -d "$CONFIG_DIR" ] || [ -z "$(ls -A "$CONFIG_DIR" 2>/dev/null)" ] && ui_print "[!] No config files found" && exit 0

handle_files() {
        src_dir="$1"
        dst_dir="$2"
        files="$3"
        action="$4"
        DIFFERENT=""
        for file in $files; do
                src="$src_dir/$file"
                dst="$dst_dir/$file"
                if [ ! -f "$dst" ]; then
                        mkdir -p "$dst_dir/$(dirname "$file")"
                        cp "$src" "$dst"
                        ui_print "[+] $file copied"
                elif ! cmp -s "$src" "$dst"; then
                        DIFFERENT="$DIFFERENT $file"
                fi
        done
        if [ -n "$DIFFERENT" ]; then
                ui_print "[*] Changed files:"
                for file in $DIFFERENT; do
                        ui_print "    - $file"
                done
                ui_print "[*] VOLUME UP to $action, DOWN to keep"
                if detect_key_press; then
                        for file in $DIFFERENT; do
                                mkdir -p "$dst_dir/$(dirname "$file")"
                                cp "$src_dir/$file" "$dst_dir/$file"
                                ui_print "[+] $file $action"
                        done
                else
                        ui_print "[+] Kept existing files"
                fi
        fi
}

if $CONFIGURE; then
        handle_files "$CONFIG_DIR" "$PERSISTENT_DIR" "scripts_bootcompleted.txt scripts_postfs.txt" "updated"
        if [ -d "$CONFIG_DIR/scripts" ]; then
                handle_files "$CONFIG_DIR/scripts" "$PERSISTENT_DIR/scripts" "$(get_all_files "$CONFIG_DIR/scripts")" "updated"
        fi

        CONFIG_FILES=$(get_all_files "$CONFIG_DIR" | grep -v '^scripts/')
        [ -n "$CONFIG_FILES" ] && handle_files "$CONFIG_DIR" "$PERSISTENT_DIR" "$CONFIG_FILES" "reset"
fi

rm -rf "$CONFIG_DIR"

# mark this persistent dir as safe-diagnostic so a later upgrade knows the
# configs already carry the safe defaults (and to not re-back them up)
mkdir -p "$PERSISTENT_DIR" 2>/dev/null
: > "$SAFE_CFG_MARKER" 2>/dev/null
ui_print "[+] safe defaults installed: NO kernel hiding runs at boot"
ui_print "[+] boot stages are logged to $PERSISTENT_DIR/logs/boot.log"
ui_print "[+] run the Action button (or diagnose.sh) to bisect features"

download_susfs_guard_lkm
update_susfs || exit 1

# v26.11.23: report what the module will actually do on THIS kernel, so
# the post-install expectation matches reality:
#   - built-in susfs detected (or an LKM already live) -> full features
#   - otherwise -> userspace-only mode; the bundled LKM stays UNLOADED
#     unless the user opts in via /data/adb/ReSuSFS/enable_lkm
if check_susfs_support; then
        ui_print "[+] kernel susfs detected (built-in or already live): full features enabled"
else
        ui_print "[*] no kernel susfs detected on $(uname -r 2>/dev/null)"
        ui_print "[*] SAFE DEFAULT: the susfs LKM is NOT loaded on custom kernels."
        ui_print "[*] The module runs in userspace-only mode: install and boot"
        ui_print "[*] stay stable; kernel-side hiding stays dormant until a"
        ui_print "[*] susfs-capable kernel is used or you opt in."
        ui_print "[*] v26.11.34: two root causes fixed after the v26.11.33 boot"
        ui_print "[*] hang. (1) The hang: the force_init sysfs write ran"
        ui_print "[*] module init code that reached three __init functions in"
        ui_print "[*] .init.text - memory the kernel frees after module load."
        ui_print "[*] Executing freed pages wedged the boot at 50%. Those are"
        ui_print "[*] de-__init'd now, force_init defers to a workqueue, and"
        ui_print "[*] post-fs-data no longer auto-triggers it. (2) The"
        ui_print "[*] 'loads but never runs' state on LDPlayer: KernelSU-Next"
        ui_print "[*] is BUILT INTO LDPlayer 14's kernel (manager v3.3.1) and"
        ui_print "[*] neuters init_module called directly. Upstream susfs LKM"
        ui_print "[*] is loaded via 'ksud insmod' only - the same upstream"
        ui_print "[*] project is live-tested on emulator GKI kernels. This"
        ui_print "[*] release reverses the loader order: ksud insmod FIRST,"
        ui_print "[*] our custom loader only as fallback. init_done/diag_log/"
        ui_print "[*] sc_entry_count module params prove whether init ran."
        ui_print "[*] RECOVERY if a boot wedges with enable_lkm present:"
        ui_print "[*]   adb root && adb shell rm /data/adb/ReSuSFS/enable_lkm"
        ui_print "[*]   (then reboot) - or re-clone the instance."
        ui_print "[*] Still opt-in: generic 5.15.178 build that hooks live kernel"
        ui_print "[*] paths - a mismatch can wedge the kernel, at your own risk."
        ui_print "[*] Opt-in:   touch /data/adb/ReSuSFS/enable_lkm"
        ui_print "[*] Rollback: rm /data/adb/ReSuSFS/enable_lkm (then reboot)"
fi

chmod 755 "$MODPATH/ReSuSFS.sh"
chmod 644 "$MODPATH/post-fs-data.sh" "$MODPATH/service.sh" "$MODPATH/uninstall.sh" 2>/dev/null

if [ -d "$DEST_BIN_DIR" ]; then
        ui_print "[+] creating symlink in $DEST_BIN_DIR"
        ln -sf "/data/adb/modules/ReSuSFS/ReSuSFS.sh" "$DEST_BIN_DIR/ReSuSFS"
fi

if [ ! -d "$PERSISTENT_DIR/.webui_config" ] || [ ! -f "$PERSISTENT_DIR/.webui_config/custom.css" ]; then
        mkdir -p "$PERSISTENT_DIR/.webui_config"
        mv "$MODPATH/custom.css" "$PERSISTENT_DIR/.webui_config/custom.css"
else
        rm -f "$MODPATH/custom.css"
fi

# EOF
