# ReSuSFS x86_64 - v26.11.28

## v26.11.28: supercall path fixed (kprobe+skip+canary -> kretprobe)

The v26.11.27 boot.log proved the LKM loads and is stable, but every
`ksu_susfs` supercall came back with "no supercall answer".  Root cause
analysis of the v26.11.27 dmesg evidence (which the v27 capture filtered
too narrowly to show, but the failure mode was unambiguous):

1. **The canary's delayed recheck failed.**  `susfs_supercall_init()`
   first registers a kprobe on a self-test function (`susfs_sc_canary_fn`)
   and verifies the IP-write skip mechanism works (`susfs_kp_skip_return`
   sets `regs->ip = &susfs_just_return` so the probed function returns
   immediately with a forced value).  At init time the kprobe is still
   int3-based and the IP write is honored - canary passes, `sc_canary_ok`
   is set, `register_kprobe(&reboot_kp)` proceeds, the module loads.
   But `schedule_delayed_work(&canary_dw, msecs_to_jiffies(1000))` fires
   a recheck one second later, and by then the kprobe optimizer has armed
   (or the probe rides the ftrace trampoline on LDPlayer's clang-LTO
   kernel).  An optimized/ftrace probe IGNORES the IP write - the canary
   function returns its natural value, the recheck fails, `sc_canary_ok`
   goes false, and `reboot_pre` exits at its `if (!sc_canary_ok) return 0`
   gate.  Every subsequent `ksu_susfs` supercall hits that gate, the real
   `__x64_sys_reboot` runs with our magics, returns -EINVAL (our magics
   are not LINUX_REBOOT_MAGIC1/2), and the CLI reports "no supercall
   answer".

2. **A second latent crash bug on x86_64.**  Even if the canary had
   passed, `reboot_pre` followed an arm64 syscall-wrapper quirk:
   `real_regs = (struct pt_regs *)susfs_sc_arg(regs, 0)` dereferences
   magic1 (0xDEADBEEF) as a `struct pt_regs *`.  On arm64 the wrapper's
   first argument IS a nested pt_regs*; on x86_64 the syscall args live
   DIRECTLY in `regs->di/si/dx/r10`.  This would have been a page fault
   oops on the first supercall - masked only because `sc_canary_ok` was
   always false and the deref was never reached.

### The fix: kretprobe, not kprobe+skip

`v26.11.28` replaces the entire kprobe+IP-skip+canary mechanism with a
**kretprobe** on `__x64_sys_reboot`:

- **`susfs_sc_entry` (entry_handler)**: reads `magic1/magic2/cmd/payload`
  DIRECTLY from `regs` via `susfs_sc_arg(regs, N)` - no arm64 indirection.
  Returns 0 (arm the return handler) only for root callers with matching
  magics and a `susfs_cmd_handled()` command; returns -1 (don't arm)
  otherwise, so real `reboot(2)` calls and unsupported commands pass
  through untouched.

- **`susfs_sc_ret (return_handler)**: fires from the rethook trampoline
  AFTER `__x64_sys_reboot` returned -EINVAL for our magics (harmless:
  the kernel's reboot path does NOT act on bad magics).  Queues the
  actual command via `task_work_add(TWA_RESUME)` (process context,
  before the syscall returns to userspace), then overrides `regs->ax`
  to 0 via `susfs_kp_set_ret` so userspace sees success.

The rethook trampoline is reliable on EVERY kprobe backend (int3,
jump-optimized, ftrace) - there is no IP write to ignore, so no canary
is needed.  The `susfs_sc_canary_fn`/`canary_kp`/`canary_dw`/`sc_canary_ok`
symbols are all gone from the .ko.

### Verification

```
undefined symbols: 122  (same as v26.11.27 - all runtime-resolved)
vermagic: 5.15.178+ SMP preempt modversions   (byte-identical to kernel)
register_kretprobe, susfs_sc_entry, susfs_sc_ret, reboot_krp: present
canary/sc_canary/susfs_sc_canary/reboot_pre/reboot_kp: absent
try_module_get/module_put/find_vma/current_task/saved_boot_config: still absent
```

### What to expect when you flash v26.11.28

Flash, reboot, `touch /data/adb/ReSuSFS/enable_lkm`, reboot again, then
send `boot.log` + `diagnose.log`.  If the kretprobe registered and the
path works, you should see in the LKM live evidence block:

```
---- supercall live test (ksu_susfs show version / variant / enabled_features) ----
<the actual susfs version string, not "no supercall answer">
<the actual susfs variant string>
<the actual enabled_features list>
```

And in dmesg (now captured with a WIDER filter - the v27 `grep -i susfs`
missed `pr_warn("supercall delivery uses a kprobe path...")` because
"supercall" contains no "susfs" substring):

```
susfs supercall: armed (reboot ABI kretprobe, version ...)
susfs_guard_lkm: supercall delivery uses a kretprobe on __x64_sys_reboot - ...
```

If the supercall STILL doesn't answer, the widened dmesg capture will now
show exactly which layer failed (the v27 filter was the second bug after
the kprobe+skip design).  Next suspect in that case: `ksu_init_symbol_resolver()`
or `register_kretprobe` itself returning non-zero.

---

## Historical: v26.11.27

# ReSuSFS x86_64 - v26.11.27

## The v26.11.26 result: the LKM LOADS

The v26.11.26 boot.log is the breakthrough the port has been working
toward since v26.10.23:

```
susfs_insmod: resolved 122/122; unresolved 0
susfs_insmod: init_module(582192 bytes, 122 symbols absolutized, params "")
susfs_insmod: loaded (vermagic fixup not needed); checking /sys/module/susfs_guard_lkm
susfs_insmod: OK: /sys/module/susfs_guard_lkm exists
[+] LKM loaded successfully (susfs_insmod, custom-kernel path)
post-fs-data: LKM load rc=0
post-fs-data: susfs LKM is LIVE (/proc/susfs_path present)
```

The five-symbol fix worked exactly as designed: zero unresolved
imports, the kernel accepted the module WITHOUT the vermagic patch
("vermagic fixup not needed"), `/proc/susfs_path` was created at load
time, and the module shows Live in `/proc/modules`. The whole boot
completed in ~10s on TWO consecutive boots with the module loaded -
no freeze, no watchdog skips. The load wall is over.

## The remaining issue: the supercall path does not answer

Every `ksu_susfs` command reports "no supercall answer", and
stage-early's functional probe (`ksu_susfs show version`) failed one
second after the load - the path was dead from the start, not degraded
later. That keeps the module in userspace-only mode (kernel-side
features undriven; the WebUI's "Unsupported ksu_susfs version /
Unknown / no features" is the same symptom - the "3 Sus Kstat" there
is userspace bookkeeping from the apply scripts, not the kernel).
Two more observations point the same way: the module's own control
nodes disappear from stat minutes after the load (the `-e` check
passed at load time, `ls -l /proc/susfs_path` fails in diagnose), and
the module's self-hiding from `/proc/modules` is not active (its line
shows). Stealth layers that did not arm - the same failure class as
the supercall.

The kernel-side mechanism was verified in source: the supercall layer
is fatal, so a live module proves the canary and the reboot kprobe
registration both succeeded at init; the register mappings (di/si/dx/
r10) and the magic constants (0xDEADBEEF/0xFAFAFAFA) match between
the CLI and the handler. What the evidence must now separate: the
delayed canary recheck disarming the supercall, the reboot kprobe at a
wrong address (BOLT/LTO kallsyms quirk), the `current_task` %gs offset
assumption (kallsyms printed `0` for it under kptr_restrict=2, which
may be the restricted print rather than the true offset), or non-fatal
layers that failed to arm.

## What v26.11.27 changes: automatic evidence capture

The module's init-time lines (layer results, the current_task %gs
offset it chose, the canary state, non-fatal layer failures) all went
to dmesg - which nobody captured: `susfs_insmod` seeks /dev/kmsg to
the END before init_module, and diagnose.sh never dumped dmesg.
v26.11.27 captures it automatically. Right after every successful
load, post-fs-data now appends to boot.log:

- a **live supercall test** (`ksu_susfs show version / variant /
  enabled_features`, each timeout-bounded);
- the **module's own init-time dmesg** (the susfs-related lines of the
  last 400);
- the **kallsyms ground truth** for `current_task`, `__x64_sys_reboot`,
  `__per_cpu_start`, `fixed_percpu_data`, `init_task` - with
  kptr_restrict relaxed exactly the way the loader does (restored
  right after). An 'A' (per-CPU) record prints the symbol's true
  per-CPU offset, which directly validates the offset the module
  chose at init;
- the **kprobe registration state** (best effort via
  /sys/kernel/debug/kprobes/list);
- the module's **/proc/modules visibility** (self-hiding active or
  not);
- the **control-node state**: `-e` (existence) versus `ls /proc`
  (getdents view) - hidden from listing is the module's own stealth
  working as designed, missing from stat is a bug.

`diagnose.sh` STEP 00 dumps the same susfs-related dmesg tail, so the
user-triggered diagnose carries the module state too.

The bundled LKM is unchanged (byte-identical .ko to v26.11.26): it
loads and the system is stable - the next LKM change lands only after
this evidence names the dead layer.

## Flashing v26.11.27

Flash in KernelSU manager, reboot, and (for the LKM opt-in) `touch
/data/adb/ReSuSFS/enable_lkm` then reboot once more. After the boot,
send `/data/adb/ReSuSFS/logs/boot.log` (the live-evidence block will
be at the top of the LKM section) and, if convenient, the diagnose.log
from the Action button. `adb shell su -c "dmesg | grep -i susfs"`
right after a boot is an even faster shortcut.

---

# ReSuSFS x86_64 - v26.11.26 (historical, kept for reference)

## What the v26.11.25 log revealed

v26.11.25 got the LKM through the vermagic and `__versions` gates: the
loader parsed the module (42 sections, 1413 symbols, 127 imports), relaxed
`kptr_restrict`, resolved 122 of 127 imports to real kernel addresses from
`/proc/kallsyms`, patched the vermagic in place from
`"5.15.178+ SMP preempt mod_unload modversions "` (45 bytes) to
`"5.15.178+ SMP preempt modversions "` (34 bytes, the kernel's own), and
resubmitted. The kernel answered `ENOENT` (errno 2) and printed exactly
five rejects:

```
susfs_guard_lkm: Unknown symbol try_module_get (err -2)
susfs_guard_lkm: Unknown symbol find_vma (err -2)
susfs_guard_lkm: Unknown symbol module_put (err -2)
susfs_guard_lkm: Unknown symbol saved_boot_config (err -2)
```

(and `current_task`, the fifth, was named in the loader's own diagnostic).
No vermagic complaint, no `module_layout` rejection - the gate that
v26.11.25 fixed stays passed. The five names are the leftover: every one
of them is normally reachable through the kernel's export table or
kallsyms, and LDPlayer's `clang +pgo +bolt +lto` build removed the EXPORT
for each.

## What v26.11.26 changes

Each of the five names is eliminated at the source level - the compiler
no longer emits the corresponding `SHN_UNDEF` entry, so the kernel's
symbol-resolution pass has nothing to reject.

1. **`try_module_get` and `module_put`** - LDPlayer's kernel was built
   WITHOUT `CONFIG_MODULE_UNLOAD` (its required vermagic lacks the
   `mod_unload` token that v26.11.25 carried and had to patch out). The
   `extern` declarations of `try_module_get`/`module_put` in
   `<linux/module.h>` live behind `#ifdef CONFIG_MODULE_UNLOAD`, so
   building the LKM with `MODULE_UNLOAD=y` left them as real `extern`
   calls and the compiler emitted `R_X86_64_PLT32 try_module_get` /
   `module_put` relocations. Building with `MODULE_UNLOAD=n` turns both
   into `static inline` no-ops, the relocations vanish, and the resulting
   vermagic is byte-identical to the kernel's own
   (`5.15.178+ SMP preempt modversions ` - the loader's vermagic fixup is
   no longer needed for this token, though it stays as a safety net).
2. **`find_vma`** - replaced with the file-local `sus_map_find_vma(mm, addr)`
   already defined earlier in `sus_map.c` for the `walk_page_range` hook.
   Same contract (first VMA whose `vm_end > addr`), same maple-tree /
   linked-list walk under the `mmap_read_lock` the caller already holds.
   No semantic change; the `R_X86_64_PLT32 find_vma` relocation disappears.
3. **`current_task`** - the kernel's `<asm/current.h>` defines `current`
   as `this_cpu_read_stable(current_task)`, whose inline-asm expansion is
   `movq %gs:current_task_offset, %reg` - an `R_X86_64_32S current_task`
   relocation. The displacement is normally filled from
   `EXPORT_PER_CPU_SYMBOL(current_task)`, which LDPlayer's LTO+trim build
   removed. v26.11.26 overrides `<asm/current.h>` in the kbuild-x64 tree
   (only used for out-of-tree module builds - the kernel itself was never
   compiled against this tree) so `current` reads through
   `movq %%gs:0(,%1,1), %0` (SIB-only addressing), with the displacement
   loaded from a runtime global `susfs_current_task_gs_off`. That global
   is filled once at module init from `ksu_kallsyms_lookup_name("current_task")`
   (kernel/susfs_current.c, called right after `ksu_init_symbol_resolver()`
   returns). On LDPlayer kallsyms reports `current_task` at address 0,
   which is also the correct per-CPU displacement there; on a stock 5.15
   kernel where `current_task` is at offset 4096 (after `fixed_percpu_data`
   which is `__aligned(PAGE_SIZE)`) the same resolver sets the
   displacement to 4096. Either way the compiler never emits a
   `current_task` relocation.
4. **`saved_boot_config`** - the original code declared it `extern` and
   relied on ksud / susfs_insmod to relocate it from kallsyms (the
   variable is an fs/init-main.c static, never `EXPORT_SYMBOL`'d). The
   v26.11.25 boot log confirmed LDPlayer's kallsyms does not list
   `saved_boot_config` at all, so the import was left at `SHN_UNDEF/0`.
   v26.11.26 makes `saved_boot_config` a `static char *` local to
   `spoof_cmdline.c` and removes the matching `IMP_DATA` entry from
   `imports_guard.c`. The `spoof_cmdline` feature is now INERT on LDPlayer
   (`/proc/bootconfig` is not spoofed); the file header documents how to
   re-arm it on a kernel that does list the symbol.

## Verification

- `objdump -t susfs_guard_lkm.ko | grep -E 'try_module_get|find_vma|module_put|current_task|saved_boot_config'`
  returns no `*UND*` entries for any of the five names; `saved_boot_config`
  shows up as a local `.bss` symbol (the file-static), as expected.
- Undefined symbol count: 127 (v25) -> 122 (v26). Every remaining import
  was already resolvable on LDPlayer in the v25 boot log.
- Vermagic (from `strings`): `5.15.178+ SMP preempt modversions ` -
  byte-identical to what the v25 loader had to patch in place.
- Loader host simulation parses the new .ko (42 sections, 1409 symbols)
  without complaint; the kallsyms walk cannot run on the build host
  (non-root, kptr_restrict=2) but the parse / symbol-resolution-stage
  artifacts are identical to v25's.

## What to expect on the next opt-in boot

This is the first build that the kernel should accept: the vermagic
matches byte-for-byte, the `__versions` gate stays passed (unchanged from
v25), and every name the kernel refused in v25 is gone from the symbol
table. If the load still fails, the boot.log will say which layer is next
- most likely candidates are the kallrecon layout discovery (kernel
symbol-table variant detection, runs inside `ksu_init_symbol_resolver()`)
or the first kprobe registration in the layer init plan. Either way the
diagnostic block from v25 (dmesg tail + MODVERSIONS probe + per-name
kallsyms status) still ships and will print the evidence.

## Flashing v26.11.26

Same as v25: flash in KernelSU manager, reboot, and (for the LKM opt-in)
`touch /data/adb/ReSuSFS/enable_lkm` then reboot once more. The module
ships in userspace-only mode by default; the LKM is only attempted when
the opt-in flag is present.

---

# ReSuSFS x86_64 - v26.11.25 (historical, kept for reference)

## What the v26.11.24 log revealed

With the loader fixed, the opt-in boot finally ran the real load: the loader
parsed the module (51 sections, 1429 symbols, 141 imports), relaxed
kptr_restrict, resolved 124 imports to real kernel addresses from
/proc/kallsyms, and submitted the patched image. The kernel answered
ENOEXEC (errno 8) and printed NOTHING - no "Unknown symbol", no
"version magic ... should be ...". ksud failed identically. Reading the
exact 5.15.178 kernel/module.c source explains it completely:

- load_module() calls **check_modstruct_version() BEFORE the vermagic
  check** (module.c:4029 vs :3575).
- On a CONFIG_MODVERSIONS=y kernel (an Android 14 GKI-style build, which
  exports module_layout with a CRC), a module with **no __versions
  section** hits check_version()'s "versindex == 0" path, which calls
  try_to_force_load(), whose no-force-load branch is
  `return -ENOEXEC;` - **the single unprinted failure in the whole
  module loader**. Every earlier build of this port had MODVERSIONS off,
  so this is the wall every v26.11.22..24 load attempt died on.
- The same log named the other problem: 17 of 141 imports were unresolved.
  12 of them (7 retpoline thunks, __stack_chk_fail, __check_object_size,
  pgdir_shift, page_offset_base, ptrs_per_p4d) are imports for kernel
  features LDPlayer's kernel runs WITHOUT - build-config mismatches. The
  other 5 (try_module_get, module_put, find_vma, saved_boot_config,
  current_task) resolve kernel-side (export tables / kallsyms).

## What v26.11.25 changes

1. **The bundled LKM is rebuilt to pass the gate and match the kernel:**
   - a neutral single-entry `__versions` section (kernel/modver_dummy.c +
     tools/normalize_modver.py) turns the module_layout CRC check into the
     kernel's own escape hatch - `pr_warn_once("no symbol version for
     module_layout")` + accepted;
   - CONFIG_MODVERSIONS=y build, so the vermagic carries the "modversions"
     word the target expects ("5.15.178+ SMP preempt mod_unload
     modversions");
   - the 12 phantom imports are GONE: 141 -> 127 imports, all resolvable
     on the target (verified offline against the import list).
2. **Failed loads now dump decisive evidence** into boot.log: the
   MODVERSIONS probe (grep __crc_module_layout /proc/kallsyms - on a
   MODVERSIONS kernel the CRC is the printed address), per-name kallsyms
   status for the imports that matter, a raw dmesg tail, and the
   kernel-config snapshot when /proc/config.gz exists.
3. The loader no longer runs twice per opt-in boot, and errno-8 failures
   with an empty kernel log now print an explanation of the silent gate
   (for user-supplied or older .ko images).
4. Everything else is unchanged: opt-in-only LKM on custom kernels,
   functional built-in-susfs detection, userspace-only mode, safe
   defaults, receipt/hang-watchdog boot gating, diagnose.sh bisector.

Offline verification: a gate simulator that transcribes the exact
5.15.178 load_module order shows the OLD .ko failing silently at
check_modstruct_version (the device symptom, reproduced) and the NEW one
passing; 22/22 install simulation, 41/41 safeguard/watchdog tests.

## Flashing v26.11.25

Flash `ReSuSFS-x86_64-v26.11.25.zip` in the KernelSU manager (over the old
module is fine). Your `/data/adb/ReSuSFS/enable_lkm` flag and configs
survive the upgrade. Restart the instance.

Your `enable_lkm` flag is still in place, so the next boot's post-fs-data
runs the fixed loader over the NEW image. In boot.log you should see, in
order:

1. `[*] Trying susfs_insmod (custom-kernel primary path)...`
2. the loader's verbose report (127 undefined symbols now, and
   `resolved <n>/127` - expect only a handful unresolved: the exported
   names the kernel itself resolves, e.g. try_module_get, module_put,
   find_vma)
3. `init_module(...)` - and then, if the gate analysis is right, one of:
   - `[+] LKM loaded successfully (susfs_insmod, custom-kernel path)` -
     kernel susfs is live. Verify with `dmesg | grep -i susfs`,
     `ls /proc/susfs_path`, or re-run diagnose.sh (steps 01-08 start
     answering). Expect one harmless dmesg line:
     `susfs_guard_lkm: no symbol version for module_layout`.
   - a NEW kind of failure report - the loader's own lines plus the
     evidence block (MODVERSIONS probe, kallsyms status, raw dmesg tail)
     - send boot.log + dmesg back and the next fix targets exactly what
     the kernel names.

## If the system freezes after the load

The LKM is still a generic 5.15.178 x86_64 build (LDPlayer publishes no
kernel source/config), and it hooks live kernel paths - a mismatch can
wedge the kernel. Rollback: force-restart the instance, then immediately

```
adb shell su -c "rm /data/adb/ReSuSFS/enable_lkm"
```

(you have a window of several seconds before post-fs-data fires; if adb
is dead, connect right after the boot animation starts:
`adb connect 127.0.0.1:5555`). Last resort:
`adb shell su -c "touch /data/adb/modules/ReSuSFS/disable"`.

## Running the bisector (optional)

KernelSU manager -> module page -> **Action** button, or
`adb shell su -c "sh /data/adb/modules/ReSuSFS/diagnose.sh"`. On kernels
without susfs (LKM not loaded) steps 01-08 answer "not supported" - that
is expected. If a step freezes the system: force-restart; the watchdog
skips that step on the next run automatically.

## What to send back

```
adb shell su -c "cat /data/adb/ReSuSFS/logs/boot.log"     > boot.log
adb shell su -c "cat /data/adb/ReSuSFS/logs/diagnose.log" > diagnose.log
adb shell su -c "dmesg"                                   > dmesg.txt
```
