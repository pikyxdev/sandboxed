#!/bin/sh
# test_ladder_v38.sh - state-machine test of the v26.11.38 bring-up ladder.
#
# v38 restructure: post-fs-data.sh = recon + zombie image load + DEMOTION
# only; boot-completed.sh = seed + trigger + poll + witness + raise (AFTER
# the system is up). This test extracts the REAL logic blocks from the
# packaged post-fs-data.sh and boot-completed.sh (paths substituted into a
# sandbox, sleep/seed stubbed) and simulates boots, asserting:
#   A) healthy climb 0 -> 1 -> 2 -> 3 (one rung per boot, witness in bcom)
#   B) wedge at stage 3 (trigger started, witness never ran) -> next pfd
#      demotes + caps; bcom re-runs at 0
#   C) re-climb to the capped max and hold there
#   D) stage-0 wedge -> pfd removes BOTH opt-in flags + writes
#      no_init_this_boot; bcom skips the trigger + clears the file
#   E) same-boot double-run of post-fs-data -> NO spurious demote
#   F) same-boot double-run of boot-completed -> rung not skipped
#   G) pfd -> bcom -> pfd -> bcom same-boot reorder -> no skip, no demote
#   H) stage above stage_max -> clamped for this trigger (param write)
#   I) garbage arm_stage file -> floor (0)
#   J) init incomplete but boot completed -> nok marker, retry same rung
#   K) enable_lkm without enable_force_init -> NO trigger at all
set -e

PKG=/home/z/my-project/work/pkg38
BASE=$(mktemp -d)
trap 'rm -rf "$BASE"' EXIT
fails=0

check() {   # check <desc> <expected> <actual>
        if [ "$2" = "$3" ]; then
                echo "  ok: $1"
        else
                echo "  FAIL: $1: expected [$2] got [$3]"
                fails=$((fails+1))
        fi
}

# gen <phase> : build sandbox $BASE/<phase> with pfd.sh/bcom.sh generated
# from the REAL scripts with that sandbox's paths baked in.
gen() {
        local_d="$BASE/$1"
        mkdir -p "$local_d/ReSuSFS/logs" "$local_d/sysparams" "$local_d/sysmod"
        for f in arm_stage init_done diag_log force_init kr_seed; do : > "$local_d/sysparams/$f"; done
        sed -e "s#/data/adb/ReSuSFS#$local_d/ReSuSFS#g" \
            -e "s#/sys/module/susfs_guard_lkm/parameters#$local_d/sysparams#g" \
            -e "s#/proc/sys/kernel/random/boot_id#$local_d/boot_id#g" \
            "$PKG/post-fs-data.sh" | \
            awk '/^        STAGE_FILE=/{flag=1} /capture_lkm_live_evidence/{flag=0} flag' > "$local_d/pfd.block"
        sed -e "s#/data/adb/ReSuSFS#$local_d/ReSuSFS#g" \
            -e "s#/sys/module/susfs_guard_lkm/parameters#$local_d/sysparams#g" \
            -e "s#/sys/module/susfs_guard_lkm#$local_d/sysmod#g" \
            -e "s#/proc/sys/kernel/random/boot_id#$local_d/boot_id#g" \
            "$PKG/boot-completed.sh" | \
            awk '/^# ---- v26\.11\.38 POST-BOOT LADDER TRIGGER/{flag=1} /^# ---- end v26\.11\.38 ladder trigger/{print; flag=0} flag' > "$local_d/bcom.block"
        {
                echo 'log_boot() { echo "  [boot] $*" >> "$BOOT_LOG"; }'
                echo "BOOT_LOG=\"$local_d/boot.log\""
                echo 'sleep() { :; }'
                echo "PERSISTENT_DIR=\"$local_d/ReSuSFS\""
                echo 'seed_kallsyms_resolver() { echo "names=0xf0000 offsets=0xf1000 relative_base=0xffffffff80000000 num_syms=0x2000 markers=0x3000 token_table=0x4000 token_index=0x5000"; return 0; }'
                cat "$local_d/pfd.block"
        } > "$local_d/pfd.sh"
        {
                echo 'log_boot() { echo "  [boot] $*" >> "$BOOT_LOG"; }'
                echo "BOOT_LOG=\"$local_d/boot.log\""
                echo 'sleep() { :; }'
                echo "PERSISTENT_DIR=\"$local_d/ReSuSFS\""
                echo 'seed_kallsyms_resolver() { echo "names=0xf0000 offsets=0xf1000 relative_base=0xffffffff80000000 num_syms=0x2000 markers=0x3000 token_table=0x4000 token_index=0x5000"; return 0; }'
                cat "$local_d/bcom.block"
        } > "$local_d/bcom.sh"
        echo "DIAG step 1: susfs_init ENTERED" > "$local_d/sysparams/diag_log"
}

# boot <dir> <id> <init_done> : switch the simulated kernel to a new boot.
boot() {
        printf '%s-0000-0000-0000-000000000000\n' "$2" > "$1/boot_id"
        : > "$1/sysparams/arm_stage"
        : > "$1/sysparams/force_init"
        printf '%s' "$3" > "$1/sysparams/init_done"
}

ST() { d="$1"; [ -f "$d/ReSuSFS/arm_stage" ] && cat "$d/ReSuSFS/arm_stage" || echo "(absent)"; }
SM() { d="$1"; [ -f "$d/ReSuSFS/stage_max" ] && cat "$d/ReSuSFS/stage_max" || echo "(absent)"; }
SB() { d="$1"; [ -f "$d/ReSuSFS/stage_boot" ] && cat "$d/ReSuSFS/stage_boot" || echo "(absent)"; }
PRM() { cat "$1/sysparams/arm_stage" 2>/dev/null || echo "(none)"; }
FI() { cat "$1/sysparams/force_init" 2>/dev/null || echo "(none)"; }

echo "== A) healthy climb 0 -> 1 -> 2 -> 3 (one rung per boot, witness in bcom)"
D="$BASE/a"; gen a; touch "$D/ReSuSFS/enable_lkm" "$D/ReSuSFS/enable_force_init"
boot "$D" a1 1; sh "$D/pfd.sh"
check "A1 no demote (marker absent)" "(absent)" "$(SB "$D")"
sh "$D/bcom.sh"
check "A1 raised to 1"  "1" "$(ST "$D")"
check "A1 ok marker"    "ok 0 a1000000000000000000000000" "$(SB "$D")"
check "A1 force_init triggered" "1" "$(FI "$D")"
boot "$D" a2 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "A2 raised to 2"  "2" "$(ST "$D")"
boot "$D" a3 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "A3 raised to 3"  "3" "$(ST "$D")"
check "A3 ok marker (rung that ran)" "ok 2 a3000000000000000000000000" "$(SB "$D")"
check "A3 max default"  "(absent)" "$(SM "$D")"

echo "== B) wedge at stage 3: trigger started, witness never ran -> next pfd demotes"
boot "$D" b1 1; sh "$D/pfd.sh"
# the trigger starts in bcom (marker written), then the init wedges the box
# before the witness: simulate by writing the try marker the trigger wrote
printf 'try 3 %s\n' "b1000000000000000000000000" > "$D/ReSuSFS/stage_boot"
boot "$D" b2 1; sh "$D/pfd.sh"
check "B2 demoted stage"  "0" "$(ST "$D")"
check "B2 max capped 2"   "2" "$(SM "$D")"
sh "$D/bcom.sh"
check "B2 raised to 1"    "1" "$(ST "$D")"
check "B2 ok marker (stage-0 rerun witnessed)" "ok 0 b2000000000000000000000000" "$(SB "$D")"

echo "== C) re-climb to the cap and hold"
boot "$D" c1 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "C1 raised to 2"   "2" "$(ST "$D")"
boot "$D" c2 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "C2 holds at max"  "2" "$(ST "$D")"
check "C2 ok marker"     "ok 2 c2000000000000000000000000" "$(SB "$D")"

echo "== D) stage-0 wedge -> flags removed, trigger suppressed this boot"
D="$BASE/d"; gen d; touch "$D/ReSuSFS/enable_lkm" "$D/ReSuSFS/enable_force_init"
boot "$D" d1 1; sh "$D/pfd.sh"
printf 'try 0 %s\n' "d1000000000000000000000000" > "$D/ReSuSFS/stage_boot"
boot "$D" d2 1; sh "$D/pfd.sh"
check "D2 enable_lkm removed" "gone" "$([ -e "$D/ReSuSFS/enable_lkm" ] && echo present || echo gone)"
check "D2 enable_force_init removed" "gone" "$([ -e "$D/ReSuSFS/enable_force_init" ] && echo present || echo gone)"
check "D2 no_init_this_boot set" "1" "$(cat "$D/ReSuSFS/no_init_this_boot" 2>/dev/null || echo none)"
check "D2 marker cleared"     "(absent)" "$(SB "$D")"
check "D2 stage floor"        "0" "$(ST "$D")"
sh "$D/bcom.sh"
check "D2 force_init NOT triggered" "" "$(cat "$D/sysparams/force_init" 2>/dev/null)"
check "D2 no_init_this_boot cleared" "gone" "$([ -e "$D/ReSuSFS/no_init_this_boot" ] && echo present || echo gone)"

echo "== E) same-boot double-run of post-fs-data -> NO spurious demote"
D="$BASE/e"; gen e; touch "$D/ReSuSFS/enable_lkm" "$D/ReSuSFS/enable_force_init"
boot "$D" e1 1; sh "$D/pfd.sh"; sh "$D/pfd.sh"
check "E2 enable_lkm intact" "present" "$([ -e "$D/ReSuSFS/enable_lkm" ] && echo present || echo gone)"
check "E2 no demote (stage file untouched)" "(absent)" "$(ST "$D")"
check "E2 max untouched"     "(absent)" "$(SM "$D")"

echo "== F) same-boot double-run of boot-completed -> rung not skipped"
sh "$D/bcom.sh"                              # absent marker -> ok 0 + raise to 1
check "F1 raised to 1"        "1" "$(ST "$D")"
sh "$D/bcom.sh"                              # same boot again -> must NOT raise to 2
check "F2 still 1"            "1" "$(ST "$D")"

echo "== G) pfd -> bcom -> pfd -> bcom same-boot reorder -> no skip, no demote"
D="$BASE/g"; gen g; touch "$D/ReSuSFS/enable_lkm" "$D/ReSuSFS/enable_force_init"
boot "$D" g1 1
sh "$D/pfd.sh"                              # try-marker context (none yet)
sh "$D/bcom.sh"                              # ok 0 + raise to 1
sh "$D/pfd.sh"                              # re-run after bcom: must keep the ok marker
check "G1 ok marker kept"     "ok 0 g1000000000000000000000000" "$(SB "$D")"
sh "$D/bcom.sh"                              # re-run: marker ok+this boot -> skip
check "G2 still 1"            "1" "$(ST "$D")"

echo "== H) stage above stage_max -> clamped for this trigger"
D="$BASE/h"; gen h; touch "$D/ReSuSFS/enable_lkm" "$D/ReSuSFS/enable_force_init"
echo 4 > "$D/ReSuSFS/arm_stage"; echo 2 > "$D/ReSuSFS/stage_max"
boot "$D" h1 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "H1 param clamped"      "2" "$(PRM "$D")"

echo "== I) garbage arm_stage file -> floor"
D="$BASE/i"; gen i; touch "$D/ReSuSFS/enable_lkm" "$D/ReSuSFS/enable_force_init"
echo "9x" > "$D/ReSuSFS/arm_stage"
boot "$D" i1 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "I1 param floor"        "0" "$(PRM "$D")"

echo "== J) boot completes but init incomplete -> nok marker, retry same rung"
D="$BASE/j"; gen j; touch "$D/ReSuSFS/enable_lkm" "$D/ReSuSFS/enable_force_init"
boot "$D" j1 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "J1 raised to 1"        "1" "$(ST "$D")"
boot "$D" j2 0; sh "$D/pfd.sh"; sh "$D/bcom.sh"      # init incomplete, box alive
check "J2 nok marker"        "nok 1 j2000000000000000000000000" "$(SB "$D")"
check "J2 no raise"          "1" "$(ST "$D")"
boot "$D" j3 1; sh "$D/pfd.sh"                       # next boot: same rung, NOT demoted
check "J3 rung retried"      "1" "$(ST "$D")"
check "J3 max not capped"    "(absent)" "$(SM "$D")"
sh "$D/bcom.sh"                                     # retry succeeds this boot
check "J3 ok marker after retry+success" "ok 1 j3000000000000000000000000" "$(SB "$D")"
check "J3 raised after success" "2" "$(ST "$D")"

echo "== K) enable_lkm without enable_force_init -> NO trigger at all"
D="$BASE/k"; gen k; touch "$D/ReSuSFS/enable_lkm"
boot "$D" k1 1; sh "$D/pfd.sh"; sh "$D/bcom.sh"
check "K1 no marker written"   "(absent)" "$(SB "$D")"
check "K1 force_init NOT triggered" "" "$(cat "$D/sysparams/force_init" 2>/dev/null)"
check "K1 stage file untouched" "(absent)" "$(ST "$D")"

echo
if [ "$fails" -eq 0 ]; then
        echo "LADDER v38 STATE MACHINE: ALL SCENARIOS PASSED"
else
        echo "LADDER v38 STATE MACHINE: $fails FAILURE(S)"
        exit 1
fi
