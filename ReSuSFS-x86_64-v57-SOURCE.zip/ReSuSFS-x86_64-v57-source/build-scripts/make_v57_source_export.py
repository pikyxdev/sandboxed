#!/usr/bin/env python3
"""make_v57_source_export.py - complete v57 (v54.3) source export for download.

Builds download/ReSuSFS-x86_64-v57-SOURCE.zip: every source/build input of
v26.11.57 that is NOT re-downloadable from public sources.  Same shape as
the v54/v55/v56 exports.  NOTE: the original ReSuSFS-x86_64-port working
tree was lost to a sandbox overlay failure during this session (see
memory/LOG.md) and was rebuilt under port-v57 from the v56 source export;
historical pieces are sourced from the v56 export, current pieces from
port-v57 + scripts + work/pkg57.
"""
import hashlib
import os
import shutil
import subprocess
import zipfile

BASE = '/home/z/my-project'
STAGE = '/tmp/v57src'
TOP = f'{STAGE}/ReSuSFS-x86_64-v57-source'
OUT_SRC = f'{BASE}/download/ReSuSFS-x86_64-v57-SOURCE.zip'
V56REF = '/tmp/v56ref'          # extracted v56 source export (history)


def sh(cmd, **kw):
    print(f'[cmd] {cmd}')
    return subprocess.run(cmd, shell=True, check=True, **kw)


def copy_rel(src, dst_rel):
    dst = os.path.join(TOP, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_stats(path):
    n, total = 0, 0
    for root, _d, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            if os.path.islink(fp):
                continue
            n += 1
            total += os.path.getsize(fp)
    return n, total


print('== staging ==', flush=True)
shutil.rmtree(STAGE, ignore_errors=True)
os.makedirs(TOP)

# the v56 export = history reference
if not os.path.isdir(f'{V56REF}/ReSuSFS-x86_64-v56-source'):
    os.makedirs(V56REF, exist_ok=True)
    sh(f'cd {V56REF} && unzip -q {BASE}/download/ReSuSFS-x86_64-v56-SOURCE.zip')
V56 = f'{V56REF}/ReSuSFS-x86_64-v56-source'

P = f'{BASE}/port-v57'          # the rebuilt port working tree
S = f'{BASE}/scripts'
W = f'{BASE}/work'

# 1. LKM sources: history from the v56 export, v57 from port-v57
copy_rel(f'{V56}/lkm-source/susfs4ksu-lkm-x64-5.15', 'lkm-source/susfs4ksu-lkm-x64-5.15')
for f in ('sc_v50.c', 'sc_v51.c', 'sc_v53.c', 'sc_v54.c', 'sc_v55.c',
          'sc_v50.o', 'sc_v51.o', 'sc_v53.o', 'sc_v54.o', 'sc_v55.o',
          'test_sc_v51_host.c', 'test_sc_v51_host',
          'test_sc_v53_host.c', 'test_sc_v54_host.c', 'test_sc_v55_host.c',
          'test_v55_ladder.sh', 'test_v56_ladder.sh'):
    copy_rel(f'{V56}/lkm-source/{f}', f'lkm-source/{f}')
# the v54.3 graft + its build/verify/test chain (current)
for f in ('sc_v55.c', 'sc_v56.c', 'sc_v56.o'):
    copy_rel(f'{P}/{f}', f'lkm-source/{f}')
copy_rel('/tmp/sc_v55_ref.o', 'lkm-source/sc_v55_ref.o')  # reference-diff base
for f in ('sc_probe.c', 'sc_probe',
          'test_sc_v56_host.c',
          'test_v57_ladder.sh', 'test_v56_ladder.sh',
          'test_sc_probe_walk_host.sh'):
    copy_rel(f'{S}/{f}', f'lkm-source/{f}')
copy_rel(f'{W}/sc_probe_v543', 'lkm-source/sc_probe_v543')
copy_rel(f'{W}/sc_probe_v543.build.log', 'lkm-source/sc_probe_v543.build.log')

# 2. userspace sources (from the v56 export - unchanged)
copy_rel(f'{V56}/userspace-src', 'userspace-src')

# 3. module staging tree (current port-v57 tree with the v57 payload)
copy_rel(f'{P}/ReSuFS', 'module-template/ReSuFS')

# 4. the EXACT v57 flashable staging tree
copy_rel(f'{W}/pkg57', 'package-v57')

# 5. build scripts (the whole lineage + the v57 chain, current)
for f in sorted(os.listdir(S)):
    fp = os.path.join(S, f)
    if os.path.isfile(fp):
        copy_rel(fp, f'build-scripts/{f}')

# 6. bit-exact build outputs (frozen v49 bases + the graft lineage)
os.makedirs(f'{TOP}/binaries', exist_ok=True)
for f in ('susfs_guard_lkm-x86_64-android13-5.15.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v55.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v55.ko'):
    copy_rel(f'{V56}/binaries/{f}', f'binaries/{f}')
for f in ('susfs_guard_lkm-x86_64-android13-5.15-v57.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v57.ko'):
    copy_rel(f'{P}/{f}', f'binaries/{f}')

# 7. kernel tree fragments + upstream refs + docs + build logs (history)
copy_rel(f'{V56}/kernel-fragments', 'kernel-fragments')
copy_rel(f'{V56}/upstream-refs', 'upstream-refs')
copy_rel(f'{V56}/docs', 'docs')
copy_rel(f'{V56}/field-logs', 'field-logs')

# the v54.3 design note: the TESTPLAN + the cred.h receipts
os.makedirs(f'{TOP}/docs', exist_ok=True)
copy_rel(f'{P}/ReSuFS/docs/test-plans/ReSuSFS-v54.3-TESTPLAN.md',
         'docs/test-plans/ReSuSFS-v54.3-TESTPLAN.md')
copy_rel(f'{P}/ReSuFS/docs/test-plans/ReSuSFS-v54.3-TESTPLAN.md',
         'module-template/ReSuFS/docs/test-plans/ReSuSFS-v54.3-TESTPLAN.md')
for f in ('cred_515.h', 'cred_a13.h'):
    copy_rel(f'/tmp/{f}', f'docs/kernel-headers/{f}')

# 8. field evidence: the v56 run (two fetches)
copy_rel(f'{BASE}/upload/v56-field', 'field-logs/v56-field')
copy_rel(f'{BASE}/upload/v56-field-2', 'field-logs/v56-field-2')

# 9. the flashable
copy_rel(f'{BASE}/download/ReSuSFS-x86_64-v26.11.57.zip',
         'flashable/ReSuSFS-x86_64-v26.11.57.zip')

# ---------------------------------------------------------------- metadata
print('== metadata ==', flush=True)
ko_a13 = f'{W}/pkg57/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko'
ko_van = f'{W}/pkg57/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
sums = [
    ('flashable/ReSuSFS-x86_64-v26.11.57.zip',
     sha256(f'{BASE}/download/ReSuSFS-x86_64-v26.11.57.zip')),
    ('package-v57/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko (v54.3 uid-fix build)',
     sha256(ko_a13)),
    ('package-v57/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko (ditto)',
     sha256(ko_van)),
    ('lkm-source/sc_v56.c (THE v54.3 graft source: uid@cred+4 + honest calibrate window)',
     sha256(f'{P}/sc_v56.c')),
    ('lkm-source/sc_v56.o', sha256(f'{P}/sc_v56.o')),
    ('lkm-source/sc_v55_ref.o (the reference-diff base: pristine v55 recompile)',
     sha256('/tmp/sc_v55_ref.o')),
    ('lkm-source/sc_probe.c (v54.3: gid canary + v54.2 full walk)',
     sha256(f'{S}/sc_probe.c')),
    ('package-v57/bin/x86_64/sc_probe (v54.3 probe, canary + walk)',
     sha256(f'{W}/pkg57/bin/x86_64/sc_probe')),
    ('package-v57/bin/x86_64/ksu_susfs (stock CLI, ABI authority)',
     sha256(f'{W}/pkg57/bin/x86_64/ksu_susfs')),
    ('package-v57/bin/x86_64/susfs_insmod', sha256(f'{W}/pkg57/bin/x86_64/susfs_insmod')),
]
open(f'{TOP}/SHA256SUMS.key', 'w').write(
    '\n'.join(f'{h}  {n}' for n, h in sums) + '\n')

rows = []
for d in ('lkm-source', 'userspace-src', 'module-template', 'package-v57',
          'build-scripts', 'binaries', 'kernel-fragments', 'upstream-refs',
          'docs', 'field-logs', 'flashable'):
    n, total = tree_stats(os.path.join(TOP, d))
    rows.append(f'| {d} | {n} | {total} |')

man = f"""# ReSuSFS x86_64 v57 (v54.3) source export

Everything needed to reproduce ReSuSFS-x86_64-v26.11.57.zip from scratch
(sources, build scripts, verified outputs, field evidence), plus the
full lineage back to v50.

## v54.3 = THE UID-READ FIX (first kernel-side change since v54.1)

The v26.11.55/.56 field runs: arm OK, box survived, features flashed 7,
uid-drop test failed 1s after the arm TWICE (v54.1 single-batch probe AND
v54.2 full-walk probe).  Root cause, header-verified against torvalds
v5.15 AND aosp android13-5.15 (docs/kernel-headers/): struct cred is
{{ atomic_t usage@+0, kuid_t uid@+4, kgid_t gid@+8 }}; the module read
the uid at cred+8 = the GID.  Every root:root field caller passed both
uid==0 gates by coincidence; the test (setresuid 101234, gid stays 0)
was never filtered.

Fix: uid@cred+4 (both gates), honest calibrate window (u32 usage, ids
+4..+0x2c), and the probe's GID CANARY (root drops gid to 54321;
show_version must still answer - a gid-keyed gate rejects exactly that
call) so the receipt proves which word the gate reads.  Change set
proven by reference-diff disassembly (build_v57_ko.sh): the ONLY code
deltas vs the field-run object are the two gate reads and the calibrate
window; imports still 15, zero ud2, wire ids unchanged.

Offline chain: 45+9 host checks (real 5.15 cred layout; three cases fail
against the old graft), 293 binary-verifier checks, 21 ladder checks,
walk regression (entry counts identical to v54.2, canary gates on a
module-less host).

## Layout

| dir | files | bytes |
| --- | --- | --- |
{chr(10).join(rows)}

Key checksums in SHA256SUMS.key.  The flashable zip is
flashable/ReSuSFS-x86_64-v26.11.57.zip.  Field evidence for this run:
field-logs/v56-field + v56-field-2 (the run that convicted the gid
read).  The sandbox note: the original ReSuFS-x86_64-port tree was lost
to an overlay failure and rebuilt under build-scripts/../port-v57; this
export is the authoritative copy.
"""
open(f'{TOP}/MANIFEST.md', 'w').write(man)

print('== zipping ==', flush=True)
if os.path.exists(OUT_SRC):
    os.remove(OUT_SRC)
with zipfile.ZipFile(OUT_SRC, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(STAGE):
        dirs.sort()
        for d in sorted(dirs):
            dp = os.path.join(root, d)
            z.writestr(os.path.relpath(dp, STAGE).replace(os.sep, '/') + '/', b'')
        for f in sorted(files):
            fp = os.path.join(root, f)
            z.write(fp, os.path.relpath(fp, STAGE).replace(os.sep, '/'))

n_files = sum(1 for _ in zipfile.ZipFile(OUT_SRC).namelist() if not _.endswith('/'))
print('source zip:', OUT_SRC)
print('size:', os.path.getsize(OUT_SRC))
print('sha256:', sha256(OUT_SRC))
print('files:', n_files)
print('V57 SOURCE EXPORT OK')
