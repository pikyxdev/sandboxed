#!/usr/bin/env python3
"""Compare stage-1-relevant functions between two .ko files.
Normalizes addresses/immediates so only instruction structure + symbol refs survive."""
import subprocess, re, sys, collections

def funcs(path):
    out = subprocess.check_output(["objdump", "-dr", "--no-show-raw-insn",
                                   "-j", ".text", path]).decode(errors="replace")
    f = {}
    cur = None
    for line in out.splitlines():
        m = re.match(r"^[0-9a-f]+ <(.+)>:", line)
        if m:
            cur = m.group(1)
            f[cur] = []
            continue
        if cur is None:
            continue
        if re.match(r"^\s*$", line) or line.startswith("Disassembly") or "/susfs" in line or line.startswith("("):
            continue
        insn = line.split("\t")[-1].strip() if "\t" in line else line.strip()
        if not insn or re.match(r"^[0-9a-f]+:", line) is None and "\t" not in line:
            # objdump format: "  addr:\tinsn"; lines without tab+addr are noise
            if not re.match(r"^\s*[0-9a-f]+:", line):
                continue
        # normalize: absolute immediates and offsets
        n = re.sub(r"\$0x[0-9a-f]+", "$IMM", insn)
        n = re.sub(r"0x[0-9a-f]+\(%rip\)", "RIP(%rip)", n)
        n = re.sub(r"^[0-9a-f]+:\s*", "", n)
        # relocation lines: keep symbol only
        if n.startswith("R_X86_64"):
            n = re.sub(r"0x[0-9a-f]+", "0xX", n)
        f[cur].append(n)
    return f

WANT = ["susfs_load_layer", "susfs_layers_down", "susfs_init_body",
        "susfs_fp_init", "susfs_ksu_umount_gate_init", "susfs_ksu_allow_gate_init",
        "susfs_sus_map_init", "susfs_sus_mount_init", "susfs_spoof_cmdline_init",
        "susfs_open_redirect_init", "susfs_prop_view_init", "susfs_enable_log_init",
        "susfs_avc_spoof_init", "ksu_patch_memory_init", "susfs_supercall_init"]

a, b = funcs(sys.argv[1]), funcs(sys.argv[2])
print(f"{'function':35s} {'v51':>8s} {'v53':>8s}  verdict")
for w in WANT:
    la, lb = a.get(w), b.get(w)
    if la is None or lb is None:
        print(f"{w:35s} {len(la) if la else -1:8d} {len(lb) if lb else -1:8d}  {'MISSING in ' + ('v53' if lb is None else 'v51')}")
        continue
    same = la == lb
    if not same:
        # count differing lines
        diff = sum(1 for x, y in zip(la, lb) if x != y) + abs(len(la) - len(lb))
        print(f"{w:35s} {len(la):8d} {len(lb):8d}  DIFFERS ({diff} lines)")
    else:
        print(f"{w:35s} {len(la):8d} {len(lb):8d}  identical")
