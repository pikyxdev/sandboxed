#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.51.zip from work/pkg51 (pkg50 tree + v51 edits).

- Reproduces the v50 zip layout EXACTLY (same entries - v51 adds no files).
- The two module .kos are the clang-17 accept-path grafts; everything else
  is pkg50's except module.prop / customize.sh / boot-completed.sh / README /
  utils.sh / payload stamp (the asserted change set).
- Verifies: entry list identical to v50, change set exactly as expected,
  the reference payload byte-identical, v51 markers present in the .kos
  and scripts, CLI still riding syscall 173.
"""
import zipfile, os, hashlib, re

SRC = '/home/z/my-project/work/pkg51'
V50 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.50.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.51.zip'

v50_names = zipfile.ZipFile(V50).namelist()

file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
v50_dir_set = set(n for n in v50_names if n.endswith('/'))

missing_dirs = v50_dir_set - dir_set
extra_dirs = dir_set - v50_dir_set
missing_files = set(v50_names) - set(file_paths) - v50_dir_set
extra_files = set(file_paths) - set(v50_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v50'

file_set = set(file_paths)
ordered = [n for n in v50_names if n in dir_set or n in file_set]
assert len(ordered) == len(v50_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
z50, z51 = zipfile.ZipFile(V50), zipfile.ZipFile(OUT)
n50, n51 = z50.namelist(), z51.namelist()
assert n51 == n50, 'entry list mismatch vs v50'

changed = []
for n in n51:
    if z50.read(n) != z51.read(n):
        changed.append(n)
print('changed vs v50:', sorted(changed))
assert set(changed) == {
    'README-DIAGNOSTIC.md', 'boot-completed.sh', 'customize.sh', 'module.prop',
    'utils.sh',
    'lkm/x86_64/.payload_stamp',
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
}, f'unexpected change set: {sorted(changed)}'

mp = z51.read('module.prop').decode()
assert 'version=v26.11.51-x86_64' in mp and 'versionCode=129' in mp, 'module.prop version'
assert 'THE CLANG ACCEPT PATH' in mp, 'module.prop headline'
assert 'CALIBRATED' in mp and 'init_task' in mp, 'module.prop names the calibration'
stamp = z51.read('lkm/x86_64/.payload_stamp').decode()
assert 'v26.11.51' in stamp, 'payload stamp'
bc = z51.read('boot-completed.sh').decode()
assert 'v51 CLANG ACCEPT PATH' in bc, 'self-test names the v51 transport'
assert 'CALIBRATED at install from init_task/init_cred' in bc, 'self-test names the calibration'
assert 'SC_DEFER_ADVANCE' in bc, 'deferred confirmation kept'
pfd = z51.read('post-fs-data.sh').decode()
assert 're-basing the stage ladder' in pfd, 'post-fs-data re-base receipt kept'
us = z51.read('utils.sh').decode()
assert 'try_list="susfs_guard_lkm-x86_64-vanilla-5.15.ko susfs_guard_lkm-x86_64-android13-5.15.ko' in us, \
    'default candidate chain is vanilla-first now'
assert 'the default chain is already vanilla-first (v26.11.51)' in us, 'preference case updated'

van = z51.read('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
a13 = z51.read('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
for label, ko in (('vanilla', van), ('android13', a13)):
    assert b'v51 clang accept-path init' in ko, f'{label}: v51 init receipt'
    assert b'v51 calibrate' in ko, f'{label}: calibration receipt'
    assert b'v51 transport LIVE' in ko, f'{label}: v51 LIVE receipt'
    assert b'uid gate stays uncalibrated' in ko, f'{label}: calibration refusal receipt'
    assert b'preamble window cloned + verified' in ko, f'{label}: clone receipt'
    assert b'refusing (loaded, not installed)' in ko, f'{label}: refusal receipts'
    # the ABI answers
    assert b'v2.3.0\x00' in ko, f'{label}: SUSFS_VERSION_STR'
    assert b'GKI-LKM\x00' in ko, f'{label}: SUSFS_VARIANT_STR'
    # the calibration targets
    assert b'init_task\x00' in ko and b'init_cred\x00' in ko, f'{label}: calibration symbol strings'
    # the clang graft's genuine preamble (endianness: 90*11 b8 d9 34 2b b0)
    assert b'\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\xb8\xd9\x34\x2b\xb0\xf3\x0f\x1e\xfa' in ko, \
        f'{label}: genuine clang preamble block before the entry'
    # compiled by clang: the .comment carries clang-17, not only GCC
    assert b'clang version 17' in ko, f'{label}: .comment names clang-17'
    # the v50 receipts are GONE (replaced by v51's)
    assert b'v50 clang transport init' not in ko, f'{label}: stale v50 receipt must not survive'
ym = z51.read('lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')
assert hashlib.sha256(ym).hexdigest() == hashlib.sha256(z50.read(
    'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')).hexdigest(), \
    'reference payload must stay byte-identical'

cli = z51.read('bin/x86_64/ksu_susfs')
sites = sum(1 for m in re.finditer(b'\xb8\xad\x00\x00\x00', cli)
            if cli.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert sites == 9, f'CLI 173 sites: {sites}'
print('CLI 173-riding sites:', sites)
print('zip size:', os.path.getsize(OUT))
print('sha256:', hashlib.sha256(open(OUT, 'rb').read()).hexdigest())
print('V51 ZIP OK')
