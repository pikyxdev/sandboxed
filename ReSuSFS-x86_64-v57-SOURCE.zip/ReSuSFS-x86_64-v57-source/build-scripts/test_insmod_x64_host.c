// SPDX-License-Identifier: GPL-2.0
/*
 * test_insmod_x64_host.c - offline validation of the x86_64 susfs_insmod port
 * (v26.11.24 fix: EM_X86_64 machine check).
 *
 * Includes the ported loader with SUSFS_INSMOD_HOSTTEST and provides a sys6()
 * shim: every syscall runs for real (openat/read/lseek/mmap/close/(/dev/kmsg
 * open+read), so the tool maps the REAL shipped .ko and walks the REAL
 * /proc/kallsyms) - EXCEPT SYS_init_module, which is intercepted and made to
 * fail with ENOEXEC, exactly like LDPlayer 14's kernel. The complete
 * parse -> absolutize -> diagnose path therefore runs against the real
 * artifacts with zero possibility of loading anything into the host kernel.
 *
 * Build: cc -O1 -DSUSFS_INSMOD_HOSTTEST=0 \
 *            -o /tmp/insmod_x64_hosttest scripts/test_insmod_x64_host.c
 * Run:   /tmp/insmod_x64_hosttest -v \
 *            ReSuSFS-x86_64/module/lkm/x86_64/susfs_guard_lkm-x86_64-5.15.ko
 */
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>

#define SUSFS_INSMOD_HOSTTEST 1
#include "susfs_insmod_x64.c"

sysarg sys6(sysarg n, sysarg a, sysarg b, sysarg c, sysarg d, sysarg e, sysarg f)
{
        if (n == SYS_init_module) {
                o_put(P "[hosttest] init_module INTERCEPTED: would submit ");
                o_dec(b);
                o_put(" bytes, params \"");
                o_put((const char *)c);
                o_put("\"; returning ENOEXEC(8) like LDPlayer's kernel\n");
                o_flush();
                return -8;
        }
        return (sysarg)syscall((long)n, (long)a, (long)b, (long)c, (long)d,
                               (long)e, (long)f);
}

int main(int argc, char **argv)
{
        insmod_main((long)argc, argv);
        return 0;
}
