#!/usr/bin/env python3
"""Recreate port-v57/sc_v56.c from port-v57/sc_v55.c with the v54.3 edits.
One-shot deterministic transform (the sandbox FS proved too flaky for the
interactive Edit tool on the old path; this writes the full file once)."""
import sys

SRC = '/home/z/my-project/port-v57/sc_v55.c'
DST = '/home/z/my-project/port-v57/sc_v56.c'

s = open(SRC).read()

def rep(old, new, n=1):
    global s
    c = s.count(old)
    if c != n:
        print('MISMATCH (%d of %r):' % (c, old[:60]))
        sys.exit(1)
    s = s.replace(old, new)

# 1. header: identify + the v54.3 root-cause block
rep("/* sc_v55.c - v26.11.55 THE ENFORCEMENT BRIDGE, v54.1 hotfix (x86_64, freestanding).\n *\n * v54.1 ROOT CAUSE (field-tested 2026-11-27, boot e3580bfc): the v54 rung",
    "/* sc_v56.c - v26.11.57 THE ENFORCEMENT BRIDGE, v54.3 uid-read fix (x86_64, freestanding).\n *\n"
    " * v54.3 ROOT CAUSE (field 2026-11-27, boots 2920320b v26.11.55 and\n"
    " * 2920320b v26.11.56): the arm succeeded, the box survived, features\n"
    " * even flashed 7 - but the uid-drop self-test failed on BOTH field runs,\n"
    " * one second after the arm, with the v54.1 single-batch probe AND the\n"
    " * v54.2 full-walk probe.  A test that survives two independent walk\n"
    " * implementations is not failing on walking.  Static audit against the\n"
    " * REAL headers found it: sc_v51_current_uid() read the uid at\n"
    " * `*(u32 *)(cred + 8)` with the justification \"5.15 switched usage to\n"
    " * atomic_long_t\" - FALSE for 5.15.  Verified against both trees this\n"
    " * .ko family targets (torvalds v5.15 and aosp android13-5.15\n"
    " * include/linux/cred.h, byte-identical):\n"
    " *     struct cred { atomic_t usage;   (4 bytes, +0)\n"
    " *                  kuid_t   uid;     (+4)\n"
    " *                  kgid_t   gid;     (+8)  ... }\n"
    " * so cred+8 is the GID.  Every field caller so far was root:root\n"
    " * (uid 0, gid 0) - the +8 read returned 0, the transport root gate\n"
    " * (uid == 0) passed BY COINCIDENCE, and the calibration's \"uid offset\n"
    " * verified against init_cred\" was vacuous: init_cred is all-zero\n"
    " * across every id slot, so +4 and +8 are indistinguishable there (the\n"
    " * u64 usage read also passes under both layouts: 4 | 0<<32 = 4).  The\n"
    " * test's setresuid(101234) leaves gid at 0 -> the gd64 filter gate\n"
    " * read 0 -> pass-through -> the marker stayed visible in the app-uid\n"
    " * view -> FAIL (see the views above) with calls>0 filtered=0 hidden=0.\n"
    " * The same wrong word is the MAIN transport gate (line: \"uid gate,\n"
    " * calibrated\"), so v49..v56 answered every supercall on GID: a gid-0\n"
    " * non-root caller would have been accepted, a root caller with a\n"
    " * non-zero gid rejected.  No field evidence of either ever firing\n"
    " * (all callers were root:root), but both are wrong.\n"
    " * v54.3 FIX: read the uid at cred+4 (the layout BOTH headers show),\n"
    " * make the calibration check the honest window (+4..+0x2c, usage as\n"
    " * the u32 it is), and let the on-box proof close the loop: the v54.3\n"
    " * probe runs a GID CANARY (root drops gid to 54321, uid stays 0 - the\n"
    " * show_version supercall MUST still answer; the old +8 gate rejects\n"
    " * exactly this call) before the walk test, so the receipt proves\n"
    " * which word the gate reads even if this analysis were wrong again.\n"
    " *\n"
    " * v54.1 ROOT CAUSE (field-tested 2026-11-27, boot e3580bfc): the v54 rung")

# 2. sanity window comment
rep("/* struct cred sanity window (usage at +0, uid..fsgid at +8..+0x28). */",
    "/* struct cred sanity window (5.15 layout: atomic_t usage at +0, kuid_t\n"
    " * uid at +4, kgid_t gid at +8, ids through fsgid at +0x24; the check\n"
    " * window covers +4..+0x2c). */")

# 3. the uid read
rep("        /* uid sits right after the atomic_long_t usage counter (5.15\n"
    "         * switched usage to atomic_long_t, so uid is at +8; verified at\n"
    "         * install against init_cred's all-zero root fields). */\n"
    "        return *(volatile u32 *)(cred + 8);",
    "        /* 5.15 struct cred (verified against torvalds v5.15 AND aosp\n"
    "         * android13-5.15 include/linux/cred.h - identical):\n"
    "         *   atomic_t usage (+0, 4 bytes - the atomic_long_t switch is\n"
    "         *                   LATER than 5.15; the v54.2 field failure\n"
    "         *                   read gid here),\n"
    "         *   kuid_t uid (+4), kgid_t gid (+8).\n"
    "         * The old cred+8 read returned the GID: every root:root field\n"
    "         * caller passed the uid==0 gates by coincidence, and the\n"
    "         * uid-drop test (uid 101234, gid 0) was never filtered.  The\n"
    "         * on-box proof is the probe's v54.3 gid canary (root, gid\n"
    "         * dropped to 54321: show_version must STILL answer). */\n"
    "        return *(volatile u32 *)(cred + 4);")

# 4. the calibration sanity block
rep("        /* Verify struct cred's uid offset against init_cred's own bytes:\n"
    "         * usage (atomic_long, +0) must be a small positive refcount, and\n"
    "         * the root credential's uid/gid/suid/sgid/euid/egid/fsuid/fsgid\n"
    "         * words (+8..+0x28) must ALL be zero.  A wrong uid offset here\n"
    "         * fails this check and the gate stays off. */\n"
    "        {\n"
    "                u64 usage = *(volatile u64 *)ic;\n"
    "                u32 nonzero = 0;\n"
    "\n"
    "                for (i = 8; i <= SC_V51_CRED_CHECK_END; i += 4)\n"
    "                        if (*(volatile u32 *)(ic + i) != 0)\n"
    "                                nonzero++;\n"
    "                if (usage == 0 || usage > 0x10000 || nonzero) {\n"
    "                        susfs_diag_logf(\"supercall: v53 calibrate: init_cred sanity failed (usage=%lu, nonzero uid-window words=%u) - uid gate stays uncalibrated (answering nothing, box safe)\\n\",\n"
    "                                        usage, nonzero);\n"
    "                        sc_v51_cred_off = 0;\n"
    "                        return;\n"
    "                }\n"
    "        }",
    "        /* init_cred sanity (v54.3, honest window): usage is the u32\n"
    "         * atomic_t at +0 (small positive refcount; the old u64 read\n"
    "         * passed under BOTH layouts - 4 | 0<<32 - and proved nothing),\n"
    "         * and every id word +4..+0x2c must be zero.  NOTE: this still\n"
    "         * cannot distinguish uid@+4 from uid@+8 - init_cred is all\n"
    "         * zeros across the whole window - the layout is settled by the\n"
    "         * two verified headers, and the PROOF is the probe's v54.3 gid\n"
    "         * canary on the live box (root, gid 54321: show_version must\n"
    "         * still answer; the old +8 gate rejects exactly that call). */\n"
    "        {\n"
    "                u32 usage = *(volatile u32 *)ic;\n"
    "                u32 nonzero = 0;\n"
    "\n"
    "                for (i = 4; i <= SC_V51_CRED_CHECK_END; i += 4)\n"
    "                        if (*(volatile u32 *)(ic + i) != 0)\n"
    "                                nonzero++;\n"
    "                if (usage == 0 || usage > 0x10000 || nonzero) {\n"
    "                        susfs_diag_logf(\"supercall: v53 calibrate: init_cred sanity failed (usage=%u, nonzero id-window words=%u) - uid gate stays uncalibrated (answering nothing, box safe)\\n\",\n"
    "                                        usage, nonzero);\n"
    "                        sc_v51_cred_off = 0;\n"
    "                        return;\n"
    "                }\n"
    "        }")

# 5. calibrate log line
rep("        susfs_diag_logf(\"supercall: v53 calibrate: task_struct.cred at +0x%lx (the v49 wrapper's hardcoded header offset was 0x788%s); uid at cred+8 verified against init_cred - the uid gate is calibrated\\n\",",
    "        susfs_diag_logf(\"supercall: v53 calibrate: task_struct.cred at +0x%lx (the v49 wrapper's hardcoded header offset was 0x788%s); uid at cred+4 (5.15: atomic_t usage@+0, kuid_t uid@+4, kgid_t gid@+8 - the v54.2 field runs read GID at +8 and every root:root caller passed by coincidence; proof on-box = the v54.3 gid canary) - the uid gate is calibrated\\n\",")

# 6. rung banner
rep("        susfs_diag_logf(\"supercall: v54.1 ENFORCEMENT RUNG loaded (not armed): the forward to the saved getdents64 handler is kCFI-UNCHECKED (v54 field root cause: this kernel's table targets have no preamble and a checked forward ud2'd on the first call; the kernel's own dispatch calls them unchecked); resolved (name,ino) rules via private cmd 0x55f55 (48 slots), gd64 filter entry for table[217]/getdents64 armed on demand via private cmd 0x55f54 AFTER the stage-3 self-test (the scripts' gd64_stage ladder gates it); matching is upstream susfs4ksu's own (name,ino) rule; the ino is resolved userspace-side (stat) so the kernel touches no struct offset; filter gate: uid >= 10000, fail-open everywhere\\n\");",
    "        susfs_diag_logf(\"supercall: v54.3 ENFORCEMENT RUNG loaded (not armed): v54.3 = THE UID-READ FIX - v54.1/v54.2 armed fine, the box survived, but the uid-drop test failed twice with the same terminal line because the gate read cred+8 = GID on 5.15 (atomic_t usage@+0, kuid_t uid@+4 - verified against vanilla 5.15.178 and android13-5.15 headers; root:root callers passed the uid==0 gates by coincidence); the read is now uid@+4 and the probe's gid canary (root, gid 54321: show_version must still answer) proves the word on-box BEFORE the walk test; forward still kCFI-UNCHECKED (v54.0 root cause); resolved (name,ino) rules via private cmd 0x55f55 (48 slots), gd64 filter entry for table[217]/getdents64 armed on demand via private cmd 0x55f54 AFTER the stage-3 self-test (the scripts' gd64_stage ladder gates it); matching is upstream susfs4ksu's own (name,ino) rule; the ino is resolved userspace-side (stat) so the kernel touches no struct offset; filter gate: uid >= 10000, fail-open everywhere\\n\");")

# 7. arm banner
rep("        susfs_diag_logf(\"supercall: v54.1 ENFORCEMENT LIVE - table[%d] -> susfs_gd64_entry (orig=0x%lx; orig window [-16..-1): %08x %08x %08x %08x - NO kCFI preamble, the forward is UNCHECKED by design (kernel convention for table targets; the v54 checked forward ud2'd on the first getdents64); (name,ino) rules; app-uid gate >= 10000; fail-open filter)\\n\",",
    "        susfs_diag_logf(\"supercall: v54.3 ENFORCEMENT LIVE - table[%d] -> susfs_gd64_entry (orig=0x%lx; orig window [-16..-1): %08x %08x %08x %08x - NO kCFI preamble, the forward is UNCHECKED by design (kernel convention for table targets; the v54 checked forward ud2'd on the first getdents64); (name,ino) rules; app-uid gate >= 10000 reads uid@cred+4 (the v54.2 field runs read GID at +8 - fixed); fail-open filter)\\n\",")

open(DST, 'w').write(s)
print('sc_v56.c written: %d bytes' % len(s))
# verify the key bytes
assert 'return *(volatile u32 *)(cred + 4);' in s
assert 'return *(volatile u32 *)(cred + 8);' not in s
assert 'v54.3 ENFORCEMENT RUNG loaded' in s
assert 'for (i = 4; i <= SC_V51_CRED_CHECK_END; i += 4)' in s
print('all v54.3 markers verified in the output')
