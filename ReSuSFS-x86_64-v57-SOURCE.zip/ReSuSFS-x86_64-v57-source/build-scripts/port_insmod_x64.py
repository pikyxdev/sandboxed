#!/usr/bin/env python3
"""Port tools/susfs_insmod.c (arm64) to x86_64.

Transforms:
  1. syscall numbers -> x86_64 ABI numbers
  2. sys6() inline asm -> x86_64 syscall ABI (rax/rdi/rsi/rdx/r10/r8/r9)
  3. _start block    -> x86_64 stack-layout entry
  4. header comment  -> document the port

Everything else (ELF64 parsing, kallsyms walk, SHN_ABS absolutization,
vermagic in-place fixup, /dev/kmsg diagnostics) is arch-independent and kept
byte-identical to upstream.
"""
import re
import sys

SRC = "/home/z/my-project/susfs4ksu-lkm-x64/tools/susfs_insmod.c"
DST = "/home/z/my-project/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/tools/susfs_insmod_x64.c"

src = open(SRC).read()
orig_len = len(src)

# ---- 1. syscall numbers ------------------------------------------------
syscalls = {
    "SYS_exit": "60",
    "SYS_read": "0",
    "SYS_write": "1",
    "SYS_openat": "257",
    "SYS_close": "3",
    "SYS_lseek": "8",
    "SYS_mmap": "9",
    "SYS_init_module": "175",
}
for name, num in syscalls.items():
    src, n = re.subn(r"(#define\s+%s\s+)-?\d+" % name, r"\g<1>%s" % num, src)
    assert n == 1, "syscall define not found: %s (%d)" % (name, n)

# ---- 2. sys6() body ------------------------------------------------------
old_sys6 = re.compile(
    r"static sysarg sys6\(sysarg n, sysarg a, sysarg b, sysarg c, sysarg d, sysarg e, sysarg f\)\n"
    r"\{\n"
    r".*?"
    r"\n\}\n#endif",
    re.DOTALL,
)
new_sys6 = """static sysarg sys6(sysarg n, sysarg a, sysarg b, sysarg c, sysarg d, sysarg e, sysarg f)
{
        register sysarg rax __asm__("rax") = n;
        register sysarg rdi __asm__("rdi") = a;
        register sysarg rsi __asm__("rsi") = b;
        register sysarg rdx __asm__("rdx") = c;
        register sysarg r10 __asm__("r10") = d;
        register sysarg r8 __asm__("r8") = e;
        register sysarg r9 __asm__("r9") = f;

        __asm__ volatile("syscall"
                         : "+r"(rax)
                         : "r"(rdi), "r"(rsi), "r"(rdx), "r"(r10), "r"(r8), "r"(r9)
                         : "memory", "cc", "rcx", "r11");
        return rax;
}
#endif"""
src, n = old_sys6.subn(new_sys6, src)
assert n == 1, "sys6() body not replaced (%d)" % n

# ---- 3. _start block ----------------------------------------------------
# NOTE: must NOT go through re.sub's replacement template: it would eat the
# literal \n escapes we need to keep in the C source. Extract the exact
# original block with a regex, then splice the new block in with plain
# string slicing.
new_start_lines = [
    "#if !defined(SUSFS_INSMOD_HOSTTEST)",
    "__asm__(",
    r'".text\n"',
    r'".global _start\n"',
    r'".type _start,@function\n"',
    r'"_start:\n"',
    r'"       xor     %rbp, %rbp\n"',
    r'"       movq    (%rsp), %rdi\n"',
    r'"       leaq    8(%rsp), %rsi\n"',
    r'"       call    insmod_main\n"',
    r'"       movl    %eax, %edi\n"',
    r'"       movl    $60, %eax\n"',
    r'"       syscall\n"',
    ");",
    "#endif",
]
new_start = "\n".join(new_start_lines) + "\n"

m = re.search(
    r"#if !defined\(SUSFS_INSMOD_HOSTTEST\)\n__asm__\(\n(?:[^\n]*\n)*?\);\n#endif\n",
    src,
)
assert m, "old _start block not found"
src = src[: m.start()] + new_start + src[m.end():]

# ---- 4. header note ------------------------------------------------------
port_note = """/*
 * x86_64 port of susfs_insmod (for the ReSuSFS x86_64 port, LDPlayer 14 /
 * kernel 5.15.178+). Syscall numbers, the syscall ABI and the _start entry
 * were ported; the ELF/kallsyms/vermagic logic is unchanged from upstream.
 *
 * Build:
 *   gcc -O2 -nostdlib -static-pie -fno-stack-protector -fno-builtin \\
 *       -Wl,-e,_start -o susfs_insmod_x64 tools/susfs_insmod_x64.c
 */
"""
src = src.replace(
    "// SPDX-License-Identifier: GPL-2.0\n",
    "// SPDX-License-Identifier: GPL-2.0\n" + port_note,
    1,
)

open(DST, "w").write(src)
print("wrote %s (%d -> %d bytes)" % (DST, orig_len, len(src)))
print("syscalls:      ", {k: v for k, v in syscalls.items()})
print("sanity: no 'svc' left:", "svc #0" not in src)
print("sanity: no 'x0' reg left:", 'register sysarg x0' not in src)
print("sanity: has 'syscall':", '"syscall"' in src)
