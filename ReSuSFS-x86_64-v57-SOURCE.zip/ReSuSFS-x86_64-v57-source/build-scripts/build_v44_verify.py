#!/usr/bin/env python3
"""build_v44_verify.py - fail the v44 build on any regression.

Carries every v43 structural check (vermagic byte-exact, this_module
section size, imports all present in the field kallsyms, no thunks/panic,
the SYNC setter profile, kworker sentinel, probe params) AND adds the
v44 resolver-probe checks:

  kr_kln_activate probes _printk -> printk -> vprintk:
    - the three NUL-terminated candidate strings are in the image
    - the success breadcrumb names the winning probe ("%s")
    - the refuse message lists all three candidates
    - the OLD single-'printk' refuse format is GONE
    - kr_kln_activate still calls kr_kln_call and logs each miss
"""
import subprocess, sys, re

A13 = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15.ko'
KORG = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
KALL = '/home/z/my-project/upload/kernel_kallsyms.txt'

fails = []

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True)

def symbols(ko):
    out = sh(f"nm -S --defined-only {ko}")
    syms = {}
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 4:
            try:
                syms[p[3]] = (int(p[0], 16), p[1], p[2])
            except ValueError:
                pass
    return syms

def func_disasm(ko, name):
    """Full disasm of every symbol starting with `name` (main + .cold/.part)."""
    out = sh(f"objdump -d {ko}")
    body, inside = [], False
    for line in out.splitlines():
        m = re.match(r'^[0-9a-f]+ <([^>]+)>:', line)
        if m:
            inside = m.group(1).startswith(name)
            continue
        if inside:
            body.append(line)
    return '\n'.join(body)

def check(label, cond, msg):
    print(f"  [{'OK' if cond else 'FAIL'}] {label}: {msg}")
    if not cond:
        fails.append(f"{label}: {msg}")

for name, ko, want_tm in (('android13', A13, 0x340), ('vanilla', KORG, 0x300)):
    print(f"### {name}: {ko}")
    d = open(ko, 'rb').read()
    i = d.find(b'vermagic=')
    vm = d[i:i+80].split(b'\x00')[0].decode()
    check(name, vm.startswith('vermagic=5.15.178+ SMP preempt modversions'), f"vermagic {vm!r}")

    secs = sh(f"readelf -SW {ko}")
    size = None
    for line in secs.splitlines():
        m = re.search(r'\.gnu\.linkonce\.this_module\s+PROGBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
        if m:
            size = int(m.group(1), 16)
    check(name, size == want_tm, f"this_module section size 0x{size:x} (want 0x{want_tm:x})")

    imports = sorted(set(l.split()[1] for l in sh(f"nm -u {ko}").splitlines() if l.strip()))
    print(f"  imports: {len(imports)}")
    kall = open(KALL).read()
    missing = [s for s in imports if f" {s}\n" not in kall]
    check(name, not missing, f"imports all in field kallsyms (missing: {missing})")
    for bad in ('panic', '__x86_return_thunk') + tuple(f'__x86_indirect_thunk_{r}' for r in ('rax','rbp','rdx','rsi','rdi','rcx','r8','r9','r10','r11','r12','r13')):
        check(name, bad not in imports, f"{bad} not imported")

    setter = func_disasm(ko, 'susfs_param_set_force_init')
    n_calls = setter.count('\tcall')
    print(f"  setter: {len(setter.splitlines())} insns, {n_calls} calls")
    check(name, 'mov    $0x40,%edi' in setter or 'mov    $0x40' in setter,
          "setter keeps the deferred path (WORK_CPU_UNBOUND=0x40 arg setup)")
    check(name, 'ffffffba' in setter, "setter SYNC path stores -70 (0xffffffba)")
    check(name, 'susfs_init_body' in setter, "setter SYNC path calls susfs_init_body directly")
    check(name, 'susfs_diag_logf' not in setter, "setter has no DIAG call")
    check(name, re.search(r'\tret', setter) is not None, "setter ends with plain ret")

    kw = sh(f"objdump -d --disassemble=susfs_deferred_init_fn {ko}")
    kw_body = kw.split('susfs_deferred_init_fn>:', 1)[1] if 'susfs_deferred_init_fn>:' in kw else kw
    first_insns = '\n'.join(kw_body.split('\n')[:3])
    check(name, 'ffffffce' in first_insns, "kworker first instruction stores -50 (0xffffffce)")
    check(name, 'cs jmp' not in kw, 'kworker has no return-thunk jumps')

    bod = sh(f"objdump -d --disassemble=susfs_init_body {ko}")
    check(name, 'c7 05' in bod or 'movl' in bod, "init_body contains stores")

    have_param_str = '__param_str_probe' in sh(f"nm {ko}")
    have_probe_arm = '__param_probe_arm' in sh(f"nm {ko}")
    have_probe_get = 'susfs_param_get_probe' in sh(f"nm {ko}")
    check(name, have_param_str and have_probe_arm and have_probe_get,
          "probe/probe_arm params + custom .get present")

    syms = symbols(ko)
    check(name, 'susfs_init_work' in syms, "susfs_init_work present")

    # ---- v44: the resolver probe candidates ----
    check(name, b'_printk\x00' in d, "probe candidate string '_printk' present")
    check(name, b'vprintk\x00' in d, "probe candidate string 'vprintk' present")
    check(name, b'_printk/printk/vprintk' in d,
          "refuse message lists all three candidates")
    check(name, b"probe '%s'=0x%lx" in d,
          "KLN-active breadcrumb names the winning probe (%s)")
    check(name, b"lookup of 'printk' returned 0x%lx - refusing" not in d,
          "old single-'printk' refuse format is gone")
    check(name, b"trying next candidate" in d, "per-miss breadcrumb present")

    act = func_disasm(ko, 'kr_kln_activate')
    check(name, '<kr_kln_call>' in act,
          "kr_kln_activate calls kr_kln_call (probe loop present)")
    # relocated cross-TU calls render as `call <self+off>` without a symbol
    # annotation - count ALL call instructions instead (sprint_symbol,
    # kr_kln_call, miss/refuse/active logf, ... >= 7 expected)
    n_calls = len(re.findall(r'\bcall\b', act))
    check(name, n_calls >= 7,
          f"kr_kln_activate makes {n_calls} calls (want >= 7: sprint_symbol + probe + breadcrumbs)")
    # a backward conditional branch inside the function = the candidate loop
    # (objdump renders targets as `<kr_kln_activate+0xNN>')
    back = any(int(t, 16) < int(a, 16)
               for a, t in re.findall(r'^\s*([0-9a-f]+):[^\n]*\bj[a-z]+\s+([0-9a-f]+) <kr_kln_activate\+0x[0-9a-f]+>', act, re.M))
    check(name, back, "probe loop has a backward branch (candidate iteration)")

print()
if fails:
    print("FAILURES:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("ALL CHECKS PASSED")
