#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.53.1.zip from work/pkg531 (pkg53 tree + the
v53.1 honest-wedge-attribution script fix).

v53.1 is a SCRIPT-ONLY hotfix: every .ko is byte-identical to v53. The change
set must be exactly {module.prop, post-fs-data.sh}. Layout identical to v53.
"""
import zipfile, os, hashlib, re, subprocess, tempfile

SRC = '/home/z/my-project/work/pkg531'
V53 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.53.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.53.1.zip'

v53_names = zipfile.ZipFile(V53).namelist()

file_paths, dir_paths = [], []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set, v53_dir_set = set(dir_paths), set(n for n in v53_names if n.endswith('/'))
missing_files = set(v53_names) - set(file_paths) - v53_dir_set
extra_files = set(file_paths) - set(v53_names)
assert not (v53_dir_set - dir_set) and not (dir_set - v53_dir_set), 'dir layout mismatch'
assert not missing_files and not extra_files, f'file layout mismatch: {sorted(missing_files)} / {sorted(extra_files)}'

file_set = set(file_paths)
ordered = [n for n in v53_names if n in dir_set or n in file_set]
assert len(ordered) == len(v53_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name), b'')
        else:
            z.write(os.path.join(SRC, name), name)

z531, z53 = zipfile.ZipFile(OUT), zipfile.ZipFile(V53)
assert z531.namelist() == z53.namelist(), 'entry list mismatch vs v53'

changed = [n for n in z531.namelist() if z531.read(n) != z53.read(n)]
print('changed vs v53:', sorted(changed))
assert set(changed) == {'module.prop', 'post-fs-data.sh'}, f'unexpected change set: {sorted(changed)}'

mp = z531.read('module.prop').decode()
assert 'version=v26.11.53.1-x86_64' in mp and 'versionCode=132' in mp
assert 'SCRIPT-ONLY HOTFIX' in mp and 'byte-identical to v53' in mp

pfd = z531.read('post-fs-data.sh').decode()
assert 'HONEST WEDGE ATTRIBUTION' in pfd
assert '"writing force_init"*) INIT_TRIGGERED=1' in pfd
assert 'freeze_retries' in pfd and 'FREEZE DRILL' in pfd
assert 'pstore/last_kmsg' in pfd
import shlex
subprocess.run(['sh', '-n', '/home/z/my-project/work/pkg531/post-fs-data.sh'], check=True)
print('post-fs-data.sh: sh -n OK, v53.1 markers present')

# every .ko byte-identical to the v53 zip
for e in ('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
          'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
          'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko'):
    h1 = hashlib.sha256(z531.read(e)).hexdigest()
    h2 = hashlib.sha256(z53.read(e)).hexdigest()
    assert h1 == h2, f'{e} drifted from v53!'
    print(f'  {e.split("/")[-1]}: {h1[:16]}... == v53 (byte-identical)')

stamp = z531.read('lkm/x86_64/.payload_stamp').decode()
assert 'v26.11.53' in stamp, 'payload stamp unchanged (module image unchanged)'

cli = z531.read('bin/x86_64/ksu_susfs')
assert hashlib.sha256(cli).hexdigest() == hashlib.sha256(z53.read('bin/x86_64/ksu_susfs')).hexdigest(), \
    'the stock CLI binary must never change'
info = z531.getinfo('bin/x86_64/sc_probe')
assert (info.external_attr >> 16) & 0o111, 'sc_probe must carry exec bits'

print('entries:', len(z531.namelist()))
print('zip size:', os.path.getsize(OUT))
print('sha256:', hashlib.sha256(open(OUT, 'rb').read()).hexdigest())
print('V53.1 ZIP OK')
