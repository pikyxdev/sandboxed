#!/bin/bash
# Functional test suite for the ported ksu_susfs CLI (host test build).
# Runs on a stock x86_64 Linux: kernel ops must degrade gracefully.
# NOTE: the CLI exits with negative errnos, the shell sees them mod 256:
#   -EINVAL -> 234, -EPERM -> 255, kernel-op "not supported" -> 126.
set -u
T=/home/z/my-project/testbuild/ksu_susfs_hosttest
pass=0; fail=0

check() {
    # check <desc> <expect_exit> <expect_output_substr> <cmd...>
    local desc="$1"; shift
    local expect_exit="$1"; shift
    local expect_out="$1"; shift
    local out rc
    out="$("$T" "$@" 2>&1)"; rc=$?
    if [ "$rc" = "$expect_exit" ] && echo "$out" | grep -qF "$expect_out"; then
        echo "PASS: $desc (exit=$rc)"
        pass=$((pass+1))
    else
        echo "FAIL: $desc (exit=$rc expected=$expect_exit)"
        echo "$out" | head -2 | sed 's/^/      /'
        fail=$((fail+1))
    fi
}

NOT_SUP="SUSFS operation not supported"

# argument validation
check "no args -> help"          234 "usage: ksu_susfs <CMD>"
check "unknown cmd -> help"      234 "usage: ksu_susfs <CMD>"
check "show bogus -> help"       234 "show <version|enabled_features|variant>"
check "enable_log bad arg"       234 "enable_log <0|1>"
check "add_sus_path missing arg" 234 "add_sus_path </path/of/file_or_directory>"
check "set_uname missing arg"    234 "set_uname <release> <version>"
check "hide_mnts bad arg"        234 "hide_sus_mnts_for_non_su_procs <0|1>"
check "open_redirect bad scheme" 234 "uid_scheme"
check "kstat_statically bad ino" 234 "ino -> %i"

# realpath failure path (ENOENT)
check "add_sus_path non-existent" 2 "failed to get realpath from path: /nonexistent-path-xyz" add_sus_path /nonexistent-path-xyz

# kernel-op paths on a non-susfs kernel: 'not supported', exit 126
check "show version"            126 "$NOT_SUP" show version
check "show variant"            126 "$NOT_SUP" show variant
check "show enabled_features"   126 "$NOT_SUP" show enabled_features
check "add_sus_path /etc"       126 "$NOT_SUP" add_sus_path /etc
check "add_sus_path_loop /etc"  126 "$NOT_SUP" add_sus_path_loop /etc
check "add_sus_map /etc"       126 "$NOT_SUP" add_sus_map /etc
check "add_sus_kstat /etc"     126 "$NOT_SUP" add_sus_kstat /etc
check "update_sus_kstat /etc"  126 "$NOT_SUP" update_sus_kstat /etc
check "update_kstat_full_clone /etc" 126 "$NOT_SUP" update_sus_kstat_full_clone /etc
check "set_uname a b"           126 "$NOT_SUP" set_uname "5.10.0-x" "#1 SMP"
check "enable_log 1"            126 "$NOT_SUP" enable_log 1
check "enable_avc_log_spoofing" 126 "$NOT_SUP" enable_avc_log_spoofing 1
check "hide_sus_mnts 1"         126 "$NOT_SUP" hide_sus_mnts_for_non_su_procs 1
check "set_sus_path_uid_filter" 126 "$NOT_SUP" set_sus_path_uid_filter "com.foo"
check "set_priority_uid_filter" 126 "$NOT_SUP" set_priority_uid_filter "com.foo"
check "add_open_redirect"       126 "$NOT_SUP" add_open_redirect /etc /tmp 0
check "set_cmdline_or_bootconfig" 126 "$NOT_SUP" set_cmdline_or_bootconfig /etc/hostname
check "kstat_statically full"   126 "$NOT_SUP" add_sus_kstat_statically /etc 100 default default 4096 default default default default default default 1 512

echo
echo "RESULT: pass=$pass fail=$fail"
[ "$fail" = 0 ]
