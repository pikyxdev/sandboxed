#!/bin/sh
# Offline test of the v54.2 gd64 ladder block (extracted verbatim from
# work/pkg56/boot-completed.sh) with a stubbed sc_probe.  Cases:
#   1. fresh marker + arm OK + test PASS  -> 'ok 1 <boot>' marker
#   2. fresh marker + arm REJECTED        -> 'disabled' marker
#   3. fresh marker + arm OK + test FAIL  -> 'disabled' marker
#      + the receipt is ARCHIVED (v54.2: the failing views survive the
#        next boot's sc_selftest.txt overwrite)
#   4. stale 'try' from a previous boot   -> 'disabled' marker, NO arm call
#   5. 'disabled' marker                  -> no arm, no marker change
#   6. steady state ('ok' from a previous boot) -> re-arms + re-tests -> 'ok'
#   7. empty boot_id                      -> receipt archived as _unknown
set -u
SCRIPT=/home/z/my-project/work/pkg56/boot-completed.sh
PASS=0; FAIL=0

expect() { # $1 label, $2 got, $3 want
    if [ "$2" = "$3" ]; then
        echo "  [OK] $1: $2"; PASS=$((PASS+1))
    else
        echo "  [FAIL] $1: got '$2' want '$3'"; FAIL=$((FAIL+1))
    fi
}

run_case() {
    # $1 name, $2 initial gd64_stage content ('' for none), $3 arm_rc
    # ('ok'/'reject'), $4 test_rc ('pass'/'fail'), $5 bootid, $6 prev_bootid
    NAME="$1"; INIT_MARKER="$2"; ARM="$3"; TEST="$4"; BOOTID="$5"
    T=$(mktemp -d)
    mkdir -p "$T/persist/logs" "$T/logs" "$T/bin" "$T/tmpdir" "$T/trace"
    GD64_FILE="$T/persist/gd64_stage"
    [ -n "$INIT_MARKER" ] && echo "$INIT_MARKER" > "$GD64_FILE"
    SC_TEST_LOG="$T/logs/sc_selftest.txt"
    BOOT_LOG="$T/logs/boot.log"
    : > "$SC_TEST_LOG"
    : > "$BOOT_LOG"
    CUR_BOOT="$BOOTID"
    PERSISTENT_DIR="$T/persist"
    ARM_STAGE=3
    SC_MODE=FULL
    SC_DEFER_ADVANCE=1
    MODDIR="$T"
    ARM_CALLS=0; TEST_CALLS=0
    log_boot() { echo "LOG: $*"; }
    # stub sc_probe: gd64_arm -> err per case; gd64_test -> v54.2-style
    # full-walk output, pass/fail per case; readback -> a receipt line
    cat > "$T/bin/sc_probe" <<EOF
#!/bin/sh
case "\$1" in
gd64_arm)  echo "\$0 cmd=0x55f54"; if [ "$ARM" = ok ]; then echo "gd64_arm cmd=0x0000000000055f54 -> syscall rc=0x0000000000000000"; echo "   payload.err=0 (0=ok/answered; 126=seed untouched, not answered)"; else echo "gd64_arm cmd=0x0000000000055f54 -> syscall rc=0xffffffffffffffea"; echo "   payload.err=-22"; fi ;;
gd64_test) echo "v54_test: root walk entries=12 marker=found control=found"; echo "v54_test: marker resusfs_v54_gdtest_marker ino=4242"; echo "v54_test: add_resolved rc=0 err=0"; if [ "$TEST" = pass ]; then echo "v54_test: root view entries=12 marker=present control=present"; echo "v54_test: app-uid view entries=11 marker=ABSENT control=present"; echo "v54_test: PASS (enforcement end-to-end)"; else echo "v54_test: app-uid view entries=12 marker=present control=present"; echo "v54_test: FAIL (see the views above)"; fi ;;
readback)  echo "v53_v54_readback cmd=0x55f53" ;;
*) exit 2 ;;
esac
EOF
    chmod +x "$T/bin/sc_probe"
    # extract the gd64 ladder block verbatim (v26.11.54 marker .. its fi)
    awk '/---- v26.11.54: THE ENFORCEMENT BRIDGE/,/^                        fi$/' "$SCRIPT" \
      > "$T/block_head.sh"
    # the extraction ends at the first column-24 'fi' - verify it captured the ladder
    grep -q "gd64_arm" "$T/block_head.sh" || { echo "EXTRACTION FAILED"; cat "$T/block_head.sh"; exit 1; }
    grep -q "gd64_receipt" "$T/block_head.sh" || { echo "V54.2 RECEIPT LINES MISSING FROM BLOCK"; exit 1; }
    # stub the test-marker creation commands (they write to real /data - no)
    sed -e "s|GDTEST_DIR=/data/local/tmp|GDTEST_DIR=$T/tmpdir|" \
        -e "s|/data/adb/ksu/bin/sc_probe|\$T/bin/sc_probe|" \
        -e "s|\"\$MODDIR/bin/x86_64/sc_probe\"|\$T/bin/sc_probe|" \
        "$T/block_head.sh" > "$T/block.sh"
    ( . "$T/block.sh" ) > "$T/out" 2>&1
    ARMS=$(grep -c "gd64_arm cmd" "$SC_TEST_LOG" 2>/dev/null)
    ARMS=${ARMS:-0}
    echo "== $NAME"
    sed 's/^/   /' "$T/out"
    RESULT_MARKER="$(cat "$GD64_FILE" 2>/dev/null)"
    # v54.2 receipt archive checks
    RECEIPT_NAME="gd64_receipt_$( [ -n "$BOOTID" ] && echo "$BOOTID" || echo unknown ).txt"
    if [ -f "$T/persist/logs/$RECEIPT_NAME" ]; then
        RECEIPT_OUT="yes"
        grep -q "v54_test:" "$T/persist/logs/$RECEIPT_NAME" \
            && RECEIPT_HAS_TEST="yes" || RECEIPT_HAS_TEST="no"
        grep -q "FAIL (see the views above)" "$T/persist/logs/$RECEIPT_NAME" \
            && RECEIPT_HAS_FAILVIEW="yes" || RECEIPT_HAS_FAILVIEW="no"
    else
        RECEIPT_OUT="no"; RECEIPT_HAS_TEST="no"; RECEIPT_HAS_FAILVIEW="no"
    fi
    rm -rf "$T"
    MARKER_OUT="$RESULT_MARKER"; ARMS_OUT="$ARMS"
}

echo "################ CASE 1: fresh + arm OK + test PASS -> ok marker"
run_case "fresh-pass" "" ok pass boot111
expect "marker" "$MARKER_OUT" "ok 1 boot111"
expect "arm ran" "$ARMS_OUT" "1"
expect "receipt archived" "$RECEIPT_OUT" "yes"
expect "receipt has test output" "$RECEIPT_HAS_TEST" "yes"

echo "################ CASE 2: fresh + arm REJECTED -> disabled"
run_case "fresh-reject" "" reject pass boot222
expect "marker" "$MARKER_OUT" "disabled"

echo "################ CASE 3: fresh + arm OK + test FAIL -> disabled + archived receipt"
run_case "fresh-fail" "" ok fail boot333
expect "marker" "$MARKER_OUT" "disabled"
expect "receipt archived" "$RECEIPT_OUT" "yes"
expect "receipt kept the FAIL views (v54.2: the v54.1 mystery must never recur)" "$RECEIPT_HAS_FAILVIEW" "yes"

echo "################ CASE 4: stale try from a previous boot -> disabled, no arm"
run_case "stale-try" "try 1 deadboot" ok pass boot444
expect "marker" "$MARKER_OUT" "disabled"
expect "arm NOT called" "$ARMS_OUT" "0"

echo "################ CASE 5: disabled marker -> stays disabled, no arm"
run_case "already-disabled" "disabled" ok pass boot555
expect "marker" "$MARKER_OUT" "disabled"
expect "arm NOT called" "$ARMS_OUT" "0"

echo "################ CASE 6: steady state (previous ok) -> re-arm + re-test -> ok"
run_case "steady" "ok 1 prevboot" ok pass boot666
expect "marker" "$MARKER_OUT" "ok 1 boot666"
expect "arm ran" "$ARMS_OUT" "1"
expect "receipt archived" "$RECEIPT_OUT" "yes"

echo "################ CASE 7: empty boot_id -> receipt archived as _unknown"
run_case "no-bootid" "" ok fail ""
expect "marker" "$MARKER_OUT" "disabled"
expect "receipt archived (unknown name)" "$RECEIPT_OUT" "yes"
expect "receipt kept the FAIL views" "$RECEIPT_HAS_FAILVIEW" "yes"

echo
if [ "$FAIL" = 0 ]; then
        echo "ALL V54.2 LADDER TESTS PASSED ($PASS checks)"
        exit 0
fi
echo "V54.2 LADDER TESTS FAILED ($FAIL failures)"
exit 1
