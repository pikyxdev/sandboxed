/* test_sc_v54_host.c - sandbox unit test for the v54 graft (enforcement
 * bridge).
 *
 * Compiles sc_v55.c with -DSC_V51_HOSTTEST on the host.  Inherits the
 * v51/v52/v53 coverage shape (calibration, SHOW layouts, entry gating,
 * installer gates, feature rung) and adds THE ENFORCEMENT RUNG cases:
 *  20. add_resolved (0x55f55): valid (name, ino) -> err=0, stored in the
 *      resolved table; dedupe on (name, ino) -> err=0, dups++;
 *      validation: empty name, no NUL, '/' in name, ino==0 -> err=-22;
 *      capacity: 49th distinct rule -> err=-28;
 *  21. gd64_arm (0x55f54): arms only with the transport live (sc_installed)
 *      + dispatcher in the table + table[217]==__x64_sys_getdents64:
 *      patches table[217] -> &susfs_gd64_entry, installed=1, feature bit 0
 *      set (SHOW prints SUS_PATH); refusal paths -> err=-22; idempotent
 *      re-arm -> err=0;
 *  22. THE FILTER, via the real susfs_gd64_entry against a fake orig
 *      handler that writes synthetic dirent64 buffers:
 *      - root (uid 0) and system (uid 1000): unfiltered, buffer untouched;
 *      - app uid (101234): registered (name, ino) removed, everything
 *        else kept, rc = compacted length;
 *      - name matches but ino differs: kept;
 *      - all entries hidden: rc=0 (dir looks empty);
 *      - entry without a NUL in its reclen: kept (fail-open);
 *      - malformed reclen tail: tail kept verbatim, no data loss;
 *      - no rules: passthrough (orig called, no staging);
 *      - __kmalloc failure: fail-open (unfiltered, alloc_fail++);
 *  23. readback 0x55f53: the v54 section (installed, stats, resolved
 *      rules, slots_used) appended after the v53 content, bounded;
 *  24. regression: the three SHOW answers, add_sus_path storage, the
 *      not-handled shape (-22) for unknown cmds - the v53 surface is
 *      unchanged by the additions.
 *
 * Build: gcc -DSC_V51_HOSTTEST -O1 -o /tmp/test_sc_v54_host scripts/test_sc_v54_host.c
 */
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>

/* ---- forward declarations of the hosted knobs --------------------------- */
static int g_stage = 3;
static uint64_t g_dispatcher = 0;
static int g_handler_valid = 1, g_have_init_cred = 1, g_fault_uaccess = 0;
static int g_kmalloc_fail = 0;
static int g_orig_calls = 0;

/* ---- the kernel surface, hosted ---------------------------------------- */
static unsigned char fake_kernel[0x100000];        /* "kernel" memory blob */
#define FAKE_INIT_TASK   ((uint64_t)(uintptr_t)(fake_kernel + 0x1000))
#define FAKE_INIT_CRED   ((uint64_t)(uintptr_t)(fake_kernel + 0x8000))
#define FAKE_TABLE       ((uint64_t)(uintptr_t)(fake_kernel + 0x10000))
#define FAKE_HANDLER     ((uint64_t)(uintptr_t)(fake_kernel + 0x20000))
#define FAKE_GD64_ORIG   ((uint64_t)(uintptr_t)(fake_kernel + 0x28000))
static uint64_t fake_task_area[0x10000];           /* current task_structs */
static uint64_t fake_cred_area[0x1000];
static uint64_t fake_task_slot;                    /* the current fake task */

void susfs_diag_logf(const char *fmt, ...)
{
        va_list ap;

        va_start(ap, fmt);
        vprintf(fmt, ap);
        va_end(ap);
}

int susfs_current_arm_stage(void) { return g_stage; }

uint64_t ksu_kallsyms_lookup_name(const char *name)
{
        if (!strcmp(name, "init_task"))       return FAKE_INIT_TASK;
        if (!strcmp(name, "init_cred"))       return g_have_init_cred ? FAKE_INIT_CRED : 0;
        if (!strcmp(name, "sys_call_table"))  return FAKE_TABLE;
        if (!strcmp(name, "ksu_syscall_dispatcher")) return g_dispatcher;
        if (!strcmp(name, "__x64_sys_ioperm")) return g_handler_valid ? FAKE_HANDLER : 0;
        if (!strcmp(name, "__x64_sys_getdents64")) return FAKE_GD64_ORIG;
        return 0;
}

uint64_t susfs_fp_syscall_table(void) { return FAKE_TABLE; }

int ksu_patch_text(void *dst, void *src, uint64_t len, int flags)
{
        memcpy(dst, src, len);
        return 0;
}

uint64_t _copy_from_user(void *to, const void *from, uint64_t n)
{
        if (g_fault_uaccess) return n;
        memcpy(to, from, n);
        return 0;
}

uint64_t _copy_to_user(void *to, const void *from, uint64_t n)
{
        if (g_fault_uaccess) return n;
        memcpy(to, from, n);
        return 0;
}

void *__kmalloc(unsigned long size, unsigned int flags)
{
        (void)flags;
        if (g_kmalloc_fail) return 0;
        return malloc(size);
}

void kfree(const void *objp)
{
        free((void *)(uintptr_t)objp);
}

volatile int susfs_sc_entry_count;
unsigned char sc_full_mode, sc_installed;
uint64_t sc_orig;
unsigned long susfs_current_task_gs_off;
unsigned long susfs_armed_features;
unsigned char *sc_v51_host_current;

/* pull in the graft (statics become same-TU visible) */
#include "../ReSuSFS-x86_64-port/sc_v55.c"

/* ---- helpers ------------------------------------------------------------ */
static int fails = 0;

static void check(const char *label, int cond, const char *detail)
{
        printf("  [%s] %s%s%s\n", cond ? "OK" : "FAIL", label,
               detail && detail[0] ? ": " : "", detail ? detail : "");
        if (!cond) fails++;
}

static void put_pair(uint64_t task, uint32_t off)
{
        *(uint64_t *)(uintptr_t)(task + off) = FAKE_INIT_CRED;
        *(uint64_t *)(uintptr_t)(task + off + 8) = FAKE_INIT_CRED;
}

/* one supercall through the REAL entry, with a fresh payload buffer */
static char sc_payload[8300];
static long entry_call(uint32_t cmd, void *payload)
{
        struct sc_v51_regs regs;

        memset(&regs, 0, sizeof(regs));
        regs.di = 0xDEADBEEF;
        regs.si = 0xFAFAFAFA;
        regs.dx = cmd;
        regs.r10 = (uint64_t)(uintptr_t)payload;
        return susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
}

static void fill_res_payload(char *p, const char *name, uint64_t ino)
{
        memset(p, 0, SC_V54_RES_WIRE);
        if (name)
                snprintf(p, SC_V54_NAME_WIRE, "%s", name);
        for (int i = 0; i < 8; i++)
                p[SC_V54_INO_OFF + i] = (char)((ino >> (8 * i)) & 0xff);
        *(int *)(uintptr_t)(p + SC_V54_USED_OFF) = 126;
}

/* ---- synthetic dirent64 machinery --------------------------------------- */
static char snap_j[32];
#define MAX_DIRENTS 16
static uint64_t dirent_buf[8192 / 8];              /* the "user" buffer    */
static struct { char name[64]; uint64_t ino; } want_entries[MAX_DIRENTS];
static int want_n;
static long fake_orig_rc;

/* the fake __x64_sys_getdents64: writes want_entries into buf, returns rc */
static long fake_getdents64(const struct pt_regs *regs)
{
        struct sc_v51_regs *r = (struct sc_v51_regs *)regs;
        char *buf = (char *)(uintptr_t)r->si;
        uint64_t pos = 0;
        int i;

        g_orig_calls++;
        for (i = 0; i < want_n; i++) {
                size_t nl = strlen(want_entries[i].name);
                uint16_t reclen = (uint16_t)((19 + nl + 1 + 7) & ~7UL);
                char *e = buf + pos;

                memset(e, 0xAA, reclen);           /* garbage padding */
                *(uint64_t *)(void *)(e + 0) = want_entries[i].ino;
                *(int64_t *)(void *)(e + 8) = (int64_t)(100 + i);
                *(uint16_t *)(void *)(e + 16) = reclen;
                *(uint8_t *)(void *)(e + 18) = 4;  /* DT_DIR */
                memcpy(e + 19, want_entries[i].name, nl);
                e[19 + nl] = 0;                    /* filldir64 writes the NUL */
                pos += reclen;
        }
        fake_orig_rc = (long)pos;
        return (long)pos;
}

/* the accept path is root-only: the scripts add rules as root, so every
 * add section in the test must return to uid 0 first */
static void become_root(void)
{
        *(volatile uint32_t *)(uintptr_t)(*(uint64_t *)(uintptr_t)(fake_task_slot + sc_v51_cred_off) + 8) = 0;
}

/* call the REAL gd64 entry with a fake current task at the given uid */
static long gd64_call(uint32_t uid)
{
        struct sc_v51_regs regs;

        put_pair(fake_task_slot, sc_v51_cred_off);
        *(volatile uint32_t *)(uintptr_t)(*(uint64_t *)(uintptr_t)(fake_task_slot + sc_v51_cred_off) + 8) = uid;
        sc_v51_host_current = (unsigned char *)(uintptr_t)fake_task_slot;

        memset(&regs, 0, sizeof(regs));
        regs.di = 0;                                /* fd */
        regs.si = (uint64_t)(uintptr_t)dirent_buf;  /* the dirent buffer */
        regs.dx = sizeof(dirent_buf);               /* count */
        return susfs_gd64_entry((const struct pt_regs *)(uintptr_t)&regs);
}

/* count how many of want_entries survived in dirent_buf */
static long g_last_rc;
static int survived(const char *name, uint64_t ino)
{
        uint64_t pos = 0;

        while (pos + 24 <= (uint64_t)g_last_rc) {
                uint16_t reclen = *(uint16_t *)(void *)((char *)dirent_buf + pos + 16);
                char *nm = (char *)dirent_buf + pos + 19;
                uint64_t n_ino = *(uint64_t *)(void *)((char *)dirent_buf + pos);

                if (reclen < 24 || (reclen & 7)) return -1;
                if (n_ino == ino && !strcmp(nm, name))
                        return 1;
                pos += reclen;
        }
        return 0;
}

/* walk names in the buffer: returns the number of entries whose name==want */
static int name_count(const char *name)
{
        uint64_t pos = 0;
        int n = 0;

        while (pos + 24 <= (uint64_t)g_last_rc) {
                uint16_t reclen = *(uint16_t *)(void *)((char *)dirent_buf + pos + 16);
                char *nm = (char *)dirent_buf + pos + 19;

                if (reclen < 24 || (reclen & 7)) break;
                if (!strcmp(nm, name))
                        n++;
                pos += reclen;
        }
        return n;
}

/* one-shot orig variants used by tests 22i/22j: return a fixed rc leaving
 * the caller's buffer exactly as pre-arranged */
static long fake_getdents64_ret64(const struct pt_regs *regs)
{
        (void)regs;
        g_orig_calls++;
        return 64;
}
static long fake_getdents64_ret64b(const struct pt_regs *regs)
{
        (void)regs;
        g_orig_calls++;
        return 64;
}

/* ---- the tests ---------------------------------------------------------- */
int main(void)
{
        long rc;
        char payload[8300];
        int i;

        memset(fake_kernel, 0, sizeof(fake_kernel));
        memset(fake_task_area, 0, sizeof(fake_task_area));
        memset(fake_cred_area, 0, sizeof(fake_cred_area));
        memset(&sc_v53_paths, 0, sizeof(sc_v53_paths));
        memset(&sc_v54_res, 0, sizeof(sc_v54_res));
        sc_v53_next_slot = 0; sc_v53_add_calls = 0; sc_v53_dups_skipped = 0;
        sc_v53_toggle_calls = 0; sc_v53_hide_mnts_on = 0;
        sc_v54_next_slot = 0; sc_v54_res_adds = 0; sc_v54_res_dups = 0;
        sc_v54_res_rejects = 0;
        sc_v54_gd64_calls = 0; sc_v54_gd64_filtered = 0; sc_v54_gd64_hidden = 0;
        sc_v54_gd64_alloc_fail = 0; sc_v54_gd64_copy_fail = 0;
        sc_v54_gd64_installed = 0; sc_v54_gd64_orig = 0;
        susfs_armed_features = 0;

        /* calibrate: the fake init_task carries the (real_cred,cred) pair
         * (v53-test shape: usage=4 at init_cred, pair at a non-vanilla
         * offset).  The installer runs its REFUSAL paths only (the v53-test
         * discipline: the success path writes 16 bytes before the entry,
         * which are sacrificial in the merged .ko but a live function's
         * tail in a host binary); the transport state is then set the way
         * a successful arm leaves it. */
        *(uint64_t *)(uintptr_t)FAKE_INIT_CRED = 4;   /* usage refcount */
        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x788);

        /* refusal 1: table[173] clobbered */
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 173] = 0xdeadbeefdeadbeefUL;
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 217] = FAKE_GD64_ORIG;
        g_dispatcher = (uint64_t)(uintptr_t)(fake_kernel + 0x40000);
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 134] = g_dispatcher;
        sc_installed = 0;
        rc = susfs_supercall_init();
        check("installer refuses on entry/handler mismatch (loads, not installs)",
              rc == 0 && sc_installed == 0, 0);
        check("cred offset calibrated even when the arm refuses",
              sc_v51_uid_ok == 1 && sc_v51_cred_off == 0x790, 0);

        /* refusal 2: no dispatcher in the table */
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 173] = FAKE_HANDLER;
        g_dispatcher = 0;
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 134] = 0;
        rc = susfs_supercall_init();
        check("installer refuses when dispatcher not in table",
              rc == 0 && sc_installed == 0, 0);

        /* the transport state a successful v53 arm leaves (the field-proven
         * shape; sc_installed gates the v54 arm command) */
        sc_installed = 1;
        sc_full_mode = 1;
        sc_orig = FAKE_HANDLER;
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 173] = FAKE_HANDLER;
        g_dispatcher = (uint64_t)(uintptr_t)(fake_kernel + 0x40000);
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 134] = g_dispatcher;
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 217] = FAKE_GD64_ORIG;

        /* the fake current task must use the CALIBRATED offset; the
         * regression SHOW calls need it to look like root (uid 0) */
        fake_task_slot = (uint64_t)(uintptr_t)fake_task_area;
        memset(fake_task_area, 0, sizeof(fake_task_area));
        put_pair(fake_task_slot, sc_v51_cred_off - 8);  /* real_cred first */
        sc_v51_host_current = (unsigned char *)(uintptr_t)fake_task_slot;

        /* ---- 24. regression: the v53 surface --------------------------- */
        memset(payload, 0, sizeof(payload));
        *(int *)(uintptr_t)(payload + 16) = 126;
        rc = entry_call(CMD_SUSFS_SHOW_VERSION, payload);
        check("regression: show version answers v2.3.0",
              rc == 0 && !strcmp(payload, "v2.3.0"), payload);
        memset(payload, 0, sizeof(payload));
        *(int *)(uintptr_t)(payload + 16) = 126;
        rc = entry_call(CMD_SUSFS_SHOW_VARIANT, payload);
        check("regression: show variant answers GKI-LKM",
              rc == 0 && !strcmp(payload, "GKI-LKM"), payload);
        memset(payload, 0, 260);
        *(int *)(uintptr_t)(payload + 256) = 126;
        snprintf(payload, 256, "/data/local/tmp/.resusfs_v54_selftest");
        rc = entry_call(CMD_SUSFS_ADD_SUS_PATH, payload);
        check("regression: add_sus_path still stores (err=0)",
              rc == 0 && *(int *)(uintptr_t)(payload + 256) == 0, 0);
        rc = entry_call(0x55590, payload);          /* set_uname */
        check("regression: set_uname stays not-handled (-22)", rc == -22, 0);

        /* ---- 20. add_resolved ------------------------------------------- */
        memset(payload, 0, sizeof(payload));
        fill_res_payload(payload, "resusfs_v54_marker", 4711);
        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        check("add_resolved: err=0, rc=0",
              rc == 0 && *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) == 0, 0);
        check("add_resolved: stored in slot 0",
              sc_v54_res[0][SC_V54_USED_OFF] == 1 &&
              !strcmp((char *)sc_v54_res[0], "resusfs_v54_marker"), 0);

        fill_res_payload(payload, "resusfs_v54_marker", 4711);
        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        check("add_resolved: dedupe -> err=0, dups++",
              rc == 0 && sc_v54_res_dups == 1, 0);

        fill_res_payload(payload, "resusfs_v54_other", 4711);
        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        check("add_resolved: same ino different name -> new slot",
              rc == 0 && sc_v54_res[1][SC_V54_USED_OFF] == 1, 0);

        fill_res_payload(payload, "resusfs_v54_marker", 4712);
        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        check("add_resolved: same name different ino -> new slot",
              rc == 0 && sc_v54_res[2][SC_V54_USED_OFF] == 1, 0);

        memset(payload, 0, SC_V54_RES_WIRE);        /* empty name */
        *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) = 126;
        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        check("add_resolved: empty name -> err=-22",
              rc == 0 && *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) == -22, 0);

        fill_res_payload(payload, "bad/name", 99);
        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        check("add_resolved: '/' in name -> err=-22",
              rc == 0 && *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) == -22, 0);

        fill_res_payload(payload, "zero_ino", 0);
        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        check("add_resolved: ino==0 -> err=-22",
              rc == 0 && *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) == -22, 0);

        {       /* no NUL in name[256] */
                memset(payload, 'A', SC_V54_RES_WIRE);
                *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) = 126;
                rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
                check("add_resolved: no NUL in 256 bytes -> err=-22",
                      rc == 0 && *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) == -22, 0);
        }

        {       /* capacity: fill to 48, the 49th distinct -> -28 */
                char nm[32];

                for (i = 3; i < SC_V54_RES_SLOTS; i++) {
                        snprintf(nm, sizeof(nm), "cap%d", i);
                        fill_res_payload(payload, nm, (uint64_t)(10000 + i));
                        rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
                        if (rc != 0 ||
                            *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) != 0) {
                                check("add_resolved: capacity fill", 0, nm);
                                break;
                        }
                }
                check("add_resolved: 48 slots filled", sc_v54_next_slot == 48, 0);
                fill_res_payload(payload, "overflow", 999999);
                rc = entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
                check("add_resolved: 49th distinct -> err=-28",
                      rc == 0 && *(int *)(uintptr_t)(payload + SC_V54_USED_OFF) == -28, 0);
        }

        /* reset the table to a small controlled set for the filter tests */
        memset(&sc_v54_res, 0, sizeof(sc_v54_res));
        sc_v54_next_slot = 0; sc_v54_res_adds = 0; sc_v54_res_dups = 0;
        fill_res_payload(payload, "resusfs_v54_marker", 4711);
        entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);

        /* ---- 21. gd64_arm ----------------------------------------------- *
         * The first-arm success path (clone + table write) is the
         * field-proven v49/v53 recipe byte-for-byte and runs only in the
         * field (a host .text clone would corrupt the preceding function);
         * here: every refusal gate + the idempotent re-arm branch. */
        {       /* refusal: transport down */
                int saved = sc_installed;

                sc_installed = 0;
                memset(payload, 0, 8);
                *(int *)(uintptr_t)(payload + 4) = 126;
                rc = entry_call(CMD_SUSFS_V54_GD64_ARM, payload);
                check("gd64_arm: transport down -> err=-22, not installed",
                      rc == 0 && *(int *)(uintptr_t)(payload + 4) == -22 &&
                      sc_v54_gd64_installed == 0, 0);
                sc_installed = saved;
        }
        {       /* refusal: table[217] clobbered by someone else */
                ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 217] = 0xdead0000beefUL;
                memset(payload, 0, 8);
                *(int *)(uintptr_t)(payload + 4) = 126;
                rc = entry_call(CMD_SUSFS_V54_GD64_ARM, payload);
                check("gd64_arm: clobbered table[217] -> err=-22",
                      rc == 0 && *(int *)(uintptr_t)(payload + 4) == -22, 0);
                ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 217] = FAKE_GD64_ORIG;
        }
        {       /* refusal: flags != 0 (only arm=0 defined) */
                memset(payload, 0, 8);
                payload[0] = 1;
                *(int *)(uintptr_t)(payload + 4) = 126;
                rc = entry_call(CMD_SUSFS_V54_GD64_ARM, payload);
                check("gd64_arm: flags!=0 -> err=-22",
                      rc == 0 && *(int *)(uintptr_t)(payload + 4) == -22, 0);
        }

        /* the state a successful arm leaves (the re-arm branch then proves
         * idempotence through the REAL command path) */
        ((uint64_t *)(void *)fake_kernel)[(0x10000) / 8 + 217] =
                (uint64_t)(uintptr_t)&susfs_gd64_entry;
        memset(payload, 0, 8);                      /* idempotent re-arm */
        *(int *)(uintptr_t)(payload + 4) = 126;
        rc = entry_call(CMD_SUSFS_V54_GD64_ARM, payload);
        check("gd64_arm: idempotent re-arm (entry==me) -> err=0",
              rc == 0 && *(int *)(uintptr_t)(payload + 4) == 0, 0);
        check("gd64_arm: installed=1 and orig saved",
              sc_v54_gd64_installed == 1 && sc_v54_gd64_orig == FAKE_GD64_ORIG, 0);
        check("gd64_arm: SUSFS_FEAT_SUS_PATH bit set",
              (susfs_armed_features & 1UL) == 1, 0);

        memset(payload, 0, sizeof(payload));       /* SHOW now prints SUS_PATH */
        *(int *)(uintptr_t)(payload + 8192) = 126;
        rc = entry_call(CMD_SUSFS_SHOW_ENABLED_FEATURES, payload);
        check("gd64_arm: SHOW enabled_features includes SUS_PATH",
              rc == 0 && strstr(payload, "CONFIG_KSU_SUSFS_SUS_PATH") != 0, 0);

        /* ---- 22. THE FILTER --------------------------------------------- */
        /* the orig pointer the entry calls: our fake handler.  The arm
         * saved FAKE_GD64_ORIG; make that address a callable function. */
        *(uint64_t *)(void *)(FAKE_GD64_ORIG) = (uint64_t)(uintptr_t)&fake_getdents64;
        /* (a trampoline at FAKE_GD64_ORIG: jmp *fake_getdents64 is hard in
         * portable C - instead point the saved orig straight at the fake) */
        sc_v54_gd64_orig = (uint64_t)(uintptr_t)&fake_getdents64;

        /* 22a: root uid -> unfiltered */
        want_n = 3;
        strcpy(want_entries[0].name, "keep_me");   want_entries[0].ino = 1;
        strcpy(want_entries[1].name, "resusfs_v54_marker"); want_entries[1].ino = 4711;
        strcpy(want_entries[2].name, "keep_me_too"); want_entries[2].ino = 2;
        g_orig_calls = 0;
        rc = gd64_call(0);
        g_last_rc = rc;
        check("filter: root uid passes through (orig called, all 3 visible)",
              rc > 0 && g_orig_calls == 1 &&
              name_count("resusfs_v54_marker") == 1, 0);

        /* 22b: system uid 1000 -> unfiltered */
        rc = gd64_call(1000);
        g_last_rc = rc;
        check("filter: system uid 1000 passes through",
              rc > 0 && name_count("resusfs_v54_marker") == 1, 0);

        /* 22c: shell uid 2000 -> unfiltered */
        rc = gd64_call(2000);
        g_last_rc = rc;
        check("filter: shell uid 2000 passes through",
              rc > 0 && name_count("resusfs_v54_marker") == 1, 0);

        /* 22d: app uid 101234 -> marker hidden, others kept */
        {
                char snap[8192];
                uint64_t full_len = (uint64_t)rc;

                memcpy(snap, dirent_buf, full_len);
                rc = gd64_call(101234);
                g_last_rc = rc;
                check("filter: app uid hides the registered (name, ino)",
                      rc > 0 && name_count("resusfs_v54_marker") == 0, 0);
                check("filter: the other entries survive",
                      name_count("keep_me") == 1 && name_count("keep_me_too") == 1, 0);
                check("filter: rc shrank (compacted)",
                      (uint64_t)rc < full_len, 0);
        }

        /* 22e: name matches, ino differs -> kept */
        become_root();
        fill_res_payload(payload, "keep_me", 999999);
        entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        rc = gd64_call(101234);
        g_last_rc = rc;
        check("filter: same name different ino is NOT hidden",
              name_count("keep_me") == 1, 0);

        /* 22f: all entries hidden -> rc == 0 */
        become_root();
        memset(&sc_v54_res, 0, sizeof(sc_v54_res));
        sc_v54_next_slot = 0;
        fill_res_payload(payload, "keep_me", 1);
        entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        fill_res_payload(payload, "keep_me_too", 2);
        entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        fill_res_payload(payload, "resusfs_v54_marker", 4711);
        entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        rc = gd64_call(101234);
        g_last_rc = rc;
        {
                char d[48];

                snprintf(d, sizeof(d), "rc=%ld", rc);
                check("filter: everything hidden -> rc=0 (dir looks empty)",
                      rc == 0, d);
        }

        /* 22g: no rules -> passthrough */
        memset(&sc_v54_res, 0, sizeof(sc_v54_res));
        sc_v54_next_slot = 0;
        {
                char snap[8192];

                memcpy(snap, dirent_buf, (size_t)fake_orig_rc);
                g_orig_calls = 0;
                rc = gd64_call(101234);
                g_last_rc = rc;
                check("filter: no rules -> passthrough, orig called once",
                      g_orig_calls == 1 && rc == fake_orig_rc &&
                      !memcmp(snap, dirent_buf, (size_t)rc), 0);
        }

        /* 22h: kmalloc failure -> fail-open */
        become_root();
        fill_res_payload(payload, "resusfs_v54_marker", 4711);
        entry_call(CMD_SUSFS_V54_ADD_RESOLVED, payload);
        g_kmalloc_fail = 1;
        rc = gd64_call(101234);
        g_last_rc = rc;
        g_kmalloc_fail = 0;
        check("filter: kmalloc failure -> unfiltered (fail-open)",
              rc == fake_orig_rc && name_count("resusfs_v54_marker") == 1 &&
              sc_v54_gd64_alloc_fail == 1, 0);

        /* 22i: entry without NUL inside its reclen -> kept */
        {
                /* hand-craft: one good entry, then one whose name fills the
                 * whole reclen window without a NUL */
                uint64_t pos = 0;
                char *e;

                memset((char *)dirent_buf, 0, 256);
                e = (char *)dirent_buf;
                *(uint64_t *)(void *)(e + 0) = 1;
                *(uint16_t *)(void *)(e + 16) = 32;
                memcpy(e + 19, "good", 4);
                e[23] = 0;
                pos = 32;
                e = (char *)dirent_buf + pos;
                *(uint64_t *)(void *)(e + 0) = 4711;
                *(uint16_t *)(void *)(e + 16) = 32;
                memcpy(e + 19, "resusfs_v54_markerXXXX", 22);  /* no NUL, ino matches */
                /* the entry's "name" runs to reclen without NUL */
                /* route through the filter with a hand-set rc path: we
                 * cannot call the entry's internals, so simulate by making
                 * the fake orig write exactly this buffer once */
                want_n = 0;               /* fake orig writes nothing  */
                fake_orig_rc = 64;
                /* temporarily make orig return 64 with our buffer: the
                 * fake handler returns pos; use a custom one-shot buffer */
                {
                        struct sc_v51_regs regs;

                        put_pair(fake_task_slot, sc_v51_cred_off);
                        *(volatile uint32_t *)(uintptr_t)(*(uint64_t *)(uintptr_t)(fake_task_slot + sc_v51_cred_off) + 8) = 101234;
                        sc_v51_host_current = (unsigned char *)(uintptr_t)fake_task_slot;
                        memset(&regs, 0, sizeof(regs));
                        regs.si = (uint64_t)(uintptr_t)dirent_buf;
                        /* one-shot orig: returns 64 leaving the buffer as-is */
                        sc_v54_gd64_orig = (uint64_t)(uintptr_t)&fake_getdents64_ret64;
                        rc = susfs_gd64_entry((const struct pt_regs *)(uintptr_t)&regs);
                        sc_v54_gd64_orig = (uint64_t)(uintptr_t)&fake_getdents64;
                }
                g_last_rc = rc;
                check("filter: name without NUL inside reclen is kept",
                      rc == 64 && survived("resusfs_v54_markerXXXX", 4711) == 1, 0);
        }

        /* 22j: malformed reclen tail -> kept verbatim */
        {
                struct sc_v51_regs regs;

                memset((char *)dirent_buf, 0, 256);
                *(uint64_t *)(void *)((char *)dirent_buf + 0) = 1;
                *(uint16_t *)(void *)((char *)dirent_buf + 16) = 32;
                memcpy((char *)dirent_buf + 19, "good", 4);
                /* malformed: reclen=5 at offset 32 (< 24) */
                *(uint16_t *)(void *)((char *)dirent_buf + 32 + 16) = 5;
                memcpy((char *)dirent_buf + 32 + 19, "resusfs_v54_marker", 18);
                *(uint64_t *)(void *)((char *)dirent_buf + 32) = 4711;
                memcpy(snap_j, (char *)dirent_buf + 32, 32);

                put_pair(fake_task_slot, sc_v51_cred_off);
                *(volatile uint32_t *)(uintptr_t)(*(uint64_t *)(uintptr_t)(fake_task_slot + sc_v51_cred_off) + 8) = 101234;
                sc_v51_host_current = (unsigned char *)(uintptr_t)fake_task_slot;
                memset(&regs, 0, sizeof(regs));
                regs.si = (uint64_t)(uintptr_t)dirent_buf;
                sc_v54_gd64_orig = (uint64_t)(uintptr_t)&fake_getdents64_ret64b;
                rc = susfs_gd64_entry((const struct pt_regs *)(uintptr_t)&regs);
                sc_v54_gd64_orig = (uint64_t)(uintptr_t)&fake_getdents64;
                g_last_rc = rc;
                check("filter: malformed reclen tail kept verbatim (len 64)",
                      rc == 64, 0);
                check("filter: malformed tail bytes are data-preserving",
                      !memcmp((char *)dirent_buf + 32, snap_j, 32), 0);
        }

        /* ---- 23. readback ------------------------------------------------ *
         * (accept-path command: the caller must look like root again) */
        *(volatile uint32_t *)(uintptr_t)(*(uint64_t *)(uintptr_t)(fake_task_slot + sc_v51_cred_off) + 8) = 0;
        memset(payload, 0, sizeof(payload));
        *(int *)(uintptr_t)(payload + 8192) = 126;
        rc = entry_call(CMD_SUSFS_V53_DEBUG_LIST, payload);
        check("readback: answers with err=0",
              rc == 0 && *(int *)(uintptr_t)(payload + 8192) == 0, 0);
        check("readback: v54 section present",
              strstr(payload, "---- v54 enforcement rung ----") != 0, 0);
        check("readback: installed=1 reported",
              strstr(payload, "gd64: installed=1") != 0, 0);
        check("readback: stats line present",
              strstr(payload, "gd64 stats: calls=") != 0, 0);
        check("readback: resolved rule listed with its ino",
              strstr(payload, "resusfs_v54_marker ino=4711") != 0, 0);
        check("readback: resolved slots_used present",
              strstr(payload, "resolved slots_used=") != 0, 0);
        check("readback: NUL-terminated inside 8192",
              memchr(payload, 0, 8192) != 0, 0);

        /* ---- verdict ----------------------------------------------------- */
        printf("\n%s (%d failures)\n", fails ? "TESTS FAILED" : "ALL TESTS PASSED", fails);
        return fails ? 1 : 0;
}
