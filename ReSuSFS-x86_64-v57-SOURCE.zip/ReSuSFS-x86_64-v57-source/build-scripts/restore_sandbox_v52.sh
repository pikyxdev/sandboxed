#!/bin/bash
# restore_sandbox_v52.sh - restore the v52 campaign sandbox layout from
# upload/ReSuSFS-x86_64-v52-SOURCE.zip + ALL-BUILDS zip, per the reverse
# mapping in make_v52_source_export.py (BASE=/home/z/my-project).
set -e
BASE=/home/z/my-project
SRC=$BASE/work/v52-source-extract/ReSuSFS-x86_64-v52-source
P=$BASE/ReSuSFS-x86_64-port
S=$BASE/scripts
W=$BASE/work

echo "[*] 1. LKM sources -> $P"
mkdir -p "$P"
cp -a "$SRC/lkm-source/susfs4ksu-lkm-x64-5.15" "$P/"
for f in sc_v50.c sc_v51.c sc_v50.o sc_v51.o; do
    cp -a "$SRC/lkm-source/$f" "$P/"
done

echo "[*] 2. sc_probe + host tests -> $S"
for f in sc_probe.c sc_probe test_sc_v51_host.c test_sc_v51_host; do
    cp -a "$SRC/lkm-source/$f" "$S/"
done

echo "[*] 3. userspace sources"
cp -a "$SRC/userspace-src/ksu_susfs.c" "$BASE/ksu_susfs.c"
cp -a "$SRC/userspace-src/libredir.c" "$S/libredir.c"
cp -a "$SRC/userspace-src/port_insmod_x64.py" "$S/port_insmod_x64.py"
cp -a "$SRC/userspace-src/testbuild" "$BASE/testbuild"

echo "[*] 4. build scripts (top level) -> $S"
for f in "$SRC/build-scripts/"*; do
    b=$(basename "$f")
    case "$b" in
        port-scripts|port-bin) continue ;;
    esac
    [ -f "$f" ] && cp -a "$f" "$S/"
done

echo "[*] 5. port-scripts/port-bin -> \$P/scripts, \$P/bin"
mkdir -p "$P/scripts" "$P/bin"
cp -a "$SRC/build-scripts/port-scripts/." "$P/scripts/"
cp -a "$SRC/build-scripts/port-bin/." "$P/bin/"

echo "[*] 6. module template -> $P/ReSuSFS"
cp -a "$SRC/module-template/ReSuSFS" "$P/ReSuSFS"

echo "[*] 7. package-v52 -> $W/pkg52"
mkdir -p "$W"
cp -a "$SRC/package-v52" "$W/pkg52"

echo "[*] 8. reference .ko outputs -> $P"
cp -a "$SRC/binaries/"*.ko "$P/"

echo "[*] 9. kernel fragments -> \$BASE/{linux-5.15.178,a13,a13-full}"
mkdir -p "$BASE/linux-5.15.178" "$BASE/a13" "$BASE/a13-full"
cp -a "$SRC/kernel-fragments/linux-5.15.178/." "$BASE/linux-5.15.178/"
cp -a "$SRC/kernel-fragments/a13/." "$BASE/a13/"
cp -a "$SRC/kernel-fragments/a13-full/." "$BASE/a13-full/"

echo "[*] 10. upstream refs -> \$BASE root"
cp -a "$SRC/upstream-refs/ReSuSFS-x86_64" "$BASE/ReSuSFS-x86_64"
cp -a "$SRC/upstream-refs/susfs_lkm_x64.zip" "$BASE/"
cp -a "$SRC/upstream-refs/susfs4ksu_LICENSE" "$BASE/"
for f in branches.json kp.json lkm_release.json test.tab.c tree.json; do
    cp -a "$SRC/upstream-refs/$f" "$BASE/" 2>/dev/null || true
done

echo "[*] 11. docs restore"
mkdir -p "$P/ReSuSFS/docs/test-plans" "$BASE/logs" "$BASE/field-logs"
cp -a "$SRC/docs/README-x86_64-PORT.md" "$P/README-x86_64-PORT.md"
cp -a "$SRC/docs/PORTING_x86_64.md" "$SRC/docs/CHANGELOG.md" "$SRC/docs/update.json" "$P/ReSuSFS/"
for f in "$SRC/docs/test-plans/"*; do cp -a "$f" "$P/ReSuSFS/docs/test-plans/"; done
for f in "$SRC/docs/ReSuSFS-v47-Field-Validation-Report.docx" "$SRC/docs/ReSuSFS-v47-Field-Validation-Report.pdf"; do
    cp -a "$f" "$P/ReSuSFS/docs/" 2>/dev/null || true
done
cp -a "$SRC/docs/build-logs/." "$BASE/logs/" 2>/dev/null || true
# field evidence: original lived in upload/ but that dir now holds the new
# archives; restore to $BASE/field-logs instead (no clash)
cp -a "$SRC/field-logs/." "$BASE/field-logs/" 2>/dev/null || true

echo "[*] 12. export metadata -> \$BASE/export-v52"
mkdir -p "$BASE/export-v52"
cp -a "$SRC/MANIFEST.md" "$SRC/README-BUILD-V52.md" "$SRC/SHA256SUMS.key" \
       "$SRC/git-provenance.txt" "$BASE/export-v52/"
cp -a "$SRC/flashable" "$BASE/export-v52/flashable"

echo "[*] 13. ALL-BUILDS -> download/ + work/pkg51"
mkdir -p "$BASE/download"
unzip -q -o "$BASE/upload/ReSuSFS-x86_64-ALL-BUILDS-v22-v52.zip" -d "$BASE/download"
mkdir -p "$W/pkg51"
unzip -q -o "$BASE/download/ReSuSFS-x86_64-v26.11.51.zip" -d "$W/pkg51"

echo "[*] 14. v52 flashable -> download/"
cp -a "$SRC/flashable/ReSuSFS-x86_64-v26.11.52.zip" "$BASE/download/"

echo "[+] RESTORE DONE"
