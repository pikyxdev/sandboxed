#!/usr/bin/env python3
"""make_pkg53.py - build work/pkg53 from work/pkg52 with the v53 content.

Changed vs pkg52 (the zip builder asserts exactly this set):
  module.prop                        - v26.11.53 / versionCode 131 + v53 story
  customize.sh                       - v53 install banner (prepended)
  boot-completed.sh                  - v53 self-test: the FEATURE RUNG block
                                       (add_sus_path/add_sus_path_loop/
                                       hide_sus_mnts live calls + regression
                                       show) between the SHOW block and
                                       sc_probe (whose readback now dumps
                                       what the block just stored)
  README-DIAGNOSTIC.md               - v53 section prepended
  lkm/x86_64/.payload_stamp          - v26.11.53
  lkm/.../susfs_guard_lkm-*-5.15.ko  - v53 graft (first feature rung)
  bin/x86_64/sc_probe                - v53 probe (self-test now calls the
                                       private readback 0x55f53)

Everything else - the stock CLI binary (ksu_susfs, ABI authority, NEVER
rebuilt), susfs_insmod, ymuuu reference payload, utils.sh, service.sh -
is byte-identical to the v52 zip.
"""
import os, shutil

BASE = '/home/z/my-project'
SRC = f'{BASE}/work/pkg52'
DST = f'{BASE}/work/pkg53'
PAYLOAD = f'{BASE}/ReSuSFS-x86_64-port/ReSuSFS/module'

MODULE_PROP = '''id=ReSuSFS
name=ReSuSFS x86_64
version=v26.11.53-x86_64
versionCode=131
author=ReSuSFS port campaign
description=SuSFS for KernelSU (x86_64 port) | v26.11.53: THE FIRST FEATURE RUNG. The v52 clean-room run (2026-11-25, full 10-boot ladder, zero wedges) proved the whole SHOW channel end-to-end: show version=v2.3.0, show variant=GKI-LKM, show enabled_features=the armed list, confirmed three independent ways (stock CLI sha256-matched to the zip, sc_probe raw-syscall view, and the v51->v52 differential isolating the swapped constants). Feature commands still answered 126 - by design that rung. v53 LIGHTS UP THE FIRST FEATURE COMMANDS on that proven transport, from the stock CLI's own dispatch sites (decoded from the shipped binary): add_sus_path (0x55550) and add_sus_path_loop (0x55553) are accepted, validated (leading-slash, 1..255 bytes, NUL-terminated), deduped and stored into a 32-slot .data table inside the clang-17 graft (full -> err=-28/-ENOSPC, bad shape -> err=-22/-EINVAL, overlong -> -36); hide_sus_mnts_for_non_su_procs (0x55561) records the toggle. A private readback cmd (0x55f53, NOT a stock CLI id) dumps the stored table + counters + toggle state - sc_probe's self-test calls it, so the receipt is CLI-independent. THE SAFETY SHAPE IS UNCHANGED: same clang entry, same cloned 16-byte kCFI preamble, same magic + calibrated-uid gate, same stage ladder; the new handlers live in the clang graft, import NOTHING new (13-symbol set exact), contribute ZERO .bss (storage rides in .data, the spill window stays untouched), call NOTHING from the v49 base (only the kernel's own _copy_from_user/_copy_to_user, already field-proven by the SHOW answers). Accept-and-store is the whole rung: the hiding machinery that CONSUMES sus_path rules is stage-4+ and stays retired; set_uname (0x55590) and set_cmdline_or_bootconfig (0x555b0) stay not-handled until this rung survives. The wire-dispatch lock now machine-checks all four new ids against the stock CLI binary's literal dispatch sites. LADDER: 52->53 re-bases automatically (arm_stage=0, stage_max=3; in-place flash-over = 4 reboots: 0, 1, 2=OBSERVE, 3=FULL; fresh instance = full 10-boot climb). AT STAGE 3 EXPECT: the three SHOW answers unchanged; add_sus_path/add_sus_path_loop/hide_sus_mnts exit 0 SILENTLY (first feature commands ever answered on this box); the sc_probe readback prints the v53-feature-rung dump with the self-test paths stored. After any wedge send back the five logs (logs/init_trace.txt + logs/diag_last.txt + logs/boot.log + logs/kernel_facts.txt + logs/sc_selftest.txt) | opt-in only, at your own risk | built-in kernel susfs auto-detected | all boot stages logged with a hang watchdog | step-by-step diagnostics via the Action button
'''

CUSTOMIZE_BANNER = '''        ui_print "[*] v26.11.52 -> v26.11.53: THE FIRST FEATURE RUNG."
        ui_print "[*] Your v52 clean-room run proved the SHOW channel"
        ui_print "[*] end-to-end (version/variant/features all answered,"
        ui_print "[*] zero wedges). v53 keeps that transport byte-for-byte"
        ui_print "[*] and adds the first FEATURE commands from the stock"
        ui_print "[*] CLI's own wire: add_sus_path + add_sus_path_loop"
        ui_print "[*] (accepted, validated, deduped, stored in a 32-slot"
        ui_print "[*] .data table in the clang graft) and the"
        ui_print "[*] hide_sus_mnts toggle - plus a private readback"
        ui_print "[*] (0x55f53) sc_probe dumps as the receipt. Zero new"
        ui_print "[*] imports, zero .bss, zero base-module calls: the"
        ui_print "[*] accept path stays all-clang. 52->53 re-bases the"
        ui_print "[*] ladder: 4 reboots in-place (fresh instance = the"
        ui_print "[*] full 10-boot climb). At stage 3 expect the three"
        ui_print "[*] SHOW answers unchanged and the add_* commands"
        ui_print "[*] exiting 0 silently."
'''

README_SECTION = '''# v26.11.53 - THE FIRST FEATURE RUNG (2026-11-27)

## What v52 proved (the base this rung builds on)

Two consecutive clean-room 10-boot ladders (v51, v52), zero wedges. At
stage 3 the self-test answered all three SHOW commands and sc_probe (the
raw-syscall view) agreed. The transport, the wire ABI, the calibrated uid
gate and the ladder are all field-proven. Feature commands answered 126
("not handled") by design.

## What v53 adds

The first FEATURE commands, on the same transport, from the stock CLI's
own dispatch sites (decoded from the shipped ksu_susfs binary, never from
module source - the v52 lesson):

| cmd | command | wire payload | v53 behavior |
|-----|---------|--------------|--------------|
| 0x55550 | add_sus_path | path[256] + err@256 (260B) | validate -> dedupe -> store (32 slots) -> err=0 |
| 0x55553 | add_sus_path_loop | same | same, marked loop |
| 0x55561 | hide_sus_mnts_for_non_su_procs | on/off byte + err@4 (8B) | toggle recorded -> err=0 |
| 0x55f53 | (private, NOT a CLI id) | dump[8192] + err@8192 | the receipt: table + counters + toggle |

Error answers: bad shape -> err=-22 (-EINVAL), overlong path -> -36
(-ENAMETOOLONG), table full -> -28 (-ENOSPC), duplicate -> err=0 with no
re-store (idempotent apply). The stock CLI prints "susfs: <cmd> failed
(kernel err N)" for nonzero err and exits 0 silently on success.

## Why this cannot regress the box

The new code runs ONLY at stage 3 behind the same magic + calibrated-uid
gate. It lives in the clang-17 graft, imports nothing new (the 13-symbol
undefined set is asserted at build time), contributes zero .bss (storage
rides in .data; the android struct-module spill window .bss[0..0x40) stays
untouched), and calls NOTHING from the v49 base module - the only extern
calls are the kernel's own _copy_from_user/_copy_to_user, already
exercised under fire by the SHOW answers. No locks, no allocation, no
logging from the accept path; slot allocation is one capped lock-xadd.

## What is still NOT done (honest scope)

- The stored paths are not yet ENFORCED: the layers that consume sus_path
  rules are stage-4+ machinery that stays retired (the v49 ceiling).
  Wiring storage into enforcement is the next rung, after this one
  survives the field.
- The hide_sus_mnts toggle is recorded but does not yet drive the base's
  sus_mount machinery (no verified symbol contract in the exported tree;
  a data-only bridge is the candidate design for a later rung).
- set_uname (0x55590) and set_cmdline_or_bootconfig (0x555b0) stay
  not-handled (next rung after this one survives).

## Field procedure

Flash v53 over v52 (KernelSU or Magisk). The 52->53 upgrade re-bases the
stage ladder automatically: **4 reboots in-place** (0 -> 1 -> 2=OBSERVE ->
3=FULL). Fresh instance = the full 10-boot climb.

At stage 3 the self-test receipt should show, in order:

```
-- ksu_susfs show version:            v2.3.0        (unchanged)
-- ksu_susfs show variant:            GKI-LKM       (unchanged)
-- ksu_susfs show enabled_features:   the armed list (unchanged)
---- v53 FEATURE RUNG ----
-- add_sus_path /data/local/tmp/.resusfs_v53_selftest      exit=0
-- add_sus_path_loop /data/local/tmp/.resusfs_v53_selftest_loop  exit=0
-- hide_sus_mnts_for_non_su_procs 1                        exit=0
-- regression show version:           v2.3.0        (still answering)
---- sc_probe ... ----
v53_feature_readback cmd=0x55f53 -> rc=0 err=0
answer: v53-feature-rung add_calls=3 dups=0 toggle_calls=1 hide_mnts=1
[0] /data/local/tmp/.resusfs_v53_selftest
[1] /data/local/tmp/.resusfs_v53_selftest_loop (loop)
slots_used=2/32 loops=1
```

After the ladder completes you can also run the real apply flows:
`sh $MODDIR/ReSuSFS.sh --apply-sus-paths` (each line exits 0 now) and
`--apply-toggles late` (the hide_mnts line exits 0). One wedge boot
maximum by design; after ANY wedge send back the five logs.

'''

FEATURE_BLOCK = '''                                # ---- v26.11.53: THE FEATURE RUNG (stage >= 3 only) ---------------
                                # The first live FEATURE commands on this box, from the stock
                                # CLI's own wire ids: add_sus_path (0x55550), add_sus_path_loop
                                # (0x55553), hide_sus_mnts_for_non_su_procs (0x55561). Expect
                                # SILENT SUCCESS (exit 0, no output) for all three; the readback
                                # below (sc_probe) dumps what got stored. At stage 2 (OBSERVE)
                                # this block is skipped - feature calls there answer 126 like
                                # every other not-yet-accepted command.
                                if [ "$ARM_STAGE" -ge 3 ]; then
                                        echo "---- v53 FEATURE RUNG @ $(date '+%Y-%m-%d %H:%M:%S') ----"
                                        echo "feature before: sc_entry_count=$(tread $SC_CNT)"
                                        mkdir -p /data/local/tmp 2>/dev/null
                                        : > /data/local/tmp/.resusfs_v53_selftest 2>/dev/null
                                        : > /data/local/tmp/.resusfs_v53_selftest_loop 2>/dev/null
                                        echo '-- ksu_susfs add_sus_path /data/local/tmp/.resusfs_v53_selftest (timeout 3; EXPECT silent success, exit=0):'
                                        $BB timeout 3 "$SC_CLI" add_sus_path /data/local/tmp/.resusfs_v53_selftest 2>&1
                                        echo "   exit=$?"
                                        echo '-- ksu_susfs add_sus_path_loop /data/local/tmp/.resusfs_v53_selftest_loop (timeout 3; EXPECT silent success, exit=0):'
                                        $BB timeout 3 "$SC_CLI" add_sus_path_loop /data/local/tmp/.resusfs_v53_selftest_loop 2>&1
                                        echo "   exit=$?"
                                        echo '-- ksu_susfs hide_sus_mnts_for_non_su_procs 1 (timeout 3; EXPECT silent success, exit=0):'
                                        $BB timeout 3 "$SC_CLI" hide_sus_mnts_for_non_su_procs 1 2>&1
                                        echo "   exit=$?"
                                        echo '-- regression: ksu_susfs show version (timeout 3; MUST still answer v2.3.0):'
                                        $BB timeout 3 "$SC_CLI" show version 2>&1
                                        echo "feature after: sc_entry_count=$(tread $SC_CNT)"
                                fi
'''

def main():
    if os.path.exists(DST):
        shutil.rmtree(DST)
    shutil.copytree(SRC, DST)

    # 1. module.prop
    open(f'{DST}/module.prop', 'w').write(MODULE_PROP)

    # 2. customize.sh - prepend the v53 banner before the v52 banner
    cs = open(f'{DST}/customize.sh').read()
    anchor = '        ui_print "[*] v26.11.51 -> v26.11.52: THE CMD-TABLE FIX."'
    assert anchor in cs, 'v52 banner anchor not found in customize.sh'
    cs = cs.replace(anchor, CUSTOMIZE_BANNER + anchor, 1)
    open(f'{DST}/customize.sh', 'w').write(cs)

    # 3. boot-completed.sh - v53 wording + THE FEATURE RUNG block
    bc = open(f'{DST}/boot-completed.sh').read()

    old_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v52 CLANG ACCEPT PATH + CLI WIRE ABI, nr 173; CLI: $SC_CLI)"'
    new_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v53 CLANG ACCEPT PATH + CLI WIRE ABI + THE FIRST FEATURE RUNG, nr 173; CLI: $SC_CLI)"'
    assert old_line in bc, 'self-test start line not found'
    bc = bc.replace(old_line, new_line, 1)

    old_hdr = "echo \"---- v52 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    new_hdr = "echo \"---- v53 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    assert old_hdr in bc, 'self-test header not found'
    bc = bc.replace(old_hdr, new_hdr, 1)

    # insert THE FEATURE RUNG block between the after-count and sc_probe
    anchor_probe = '''                                echo "after: sc_entry_count=$(tread $SC_CNT)"
                                SC_PROBE=""'''
    assert anchor_probe in bc, 'feature block anchor (after-count -> sc_probe) not found'
    bc = bc.replace(anchor_probe,
                    '''                                echo "after: sc_entry_count=$(tread $SC_CNT)"
''' + FEATURE_BLOCK + '''                                SC_PROBE=""''', 1)

    old_note = "echo 'NOTE: v52 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry AND the whole accept path are clang-17; the uid gate reads the cred offset CALIBRATED at install from init_task/init_cred (no header-derived struct offsets); the SHOW cmd ids follow the STOCK CLI wire ABI (0x555e1=version 20B, 0x555e2=enabled_features 8196B, 0x555e3=variant 20B - v51 had e2/e3 swapped, v52 fixes it); feature commands answer not-handled this rung (CLI keeps 126), the v49 GCC wrapper is never called.'"
    new_note = "echo 'NOTE: v53 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry AND the whole accept path are clang-17; the uid gate reads the cred offset CALIBRATED at install from init_task/init_cred; the SHOW ids follow the STOCK CLI wire ABI (e1=version 20B, e2=enabled_features 8196B, e3=variant 20B); v53 adds THE FIRST FEATURE RUNG: 0x55550=add_sus_path and 0x55553=add_sus_path_loop (accepted, validated, deduped, stored in a 32-slot .data table - full -> -ENOSPC), 0x55561=hide_sus_mnts (recorded), private readback 0x55f53 via sc_probe; set_uname (0x55590) / set_cmdline (0x555b0) stay not-handled until the next rung; the stored paths are NOT yet enforced (accept+store is this rung); the v49 GCC wrapper is never called.'"
    assert old_note in bc, 'self-test NOTE not found'
    bc = bc.replace(old_note, new_note, 1)
    open(f'{DST}/boot-completed.sh', 'w').write(bc)

    # 4. README - prepend the v53 section
    rd = open(f'{DST}/README-DIAGNOSTIC.md').read()
    open(f'{DST}/README-DIAGNOSTIC.md', 'w').write(README_SECTION + rd)

    # 5. the rebuilt .kos + stamp from the staged payload
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                    f'{DST}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
                    f'{DST}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
    open(f'{DST}/lkm/x86_64/.payload_stamp', 'w').write('v26.11.53\n')

    # 6. the v53 sc_probe (self-test now carries the 0x55f53 readback)
    shutil.copyfile(f'{PAYLOAD}/bin/x86_64/sc_probe',
                    f'{DST}/bin/x86_64/sc_probe')
    os.chmod(f'{DST}/bin/x86_64/sc_probe', 0o755)

    print('pkg53 ready:', DST)
    for root, dirs, files in os.walk(DST):
        for f in files:
            p = os.path.join(root, f)
            rel = os.path.relpath(p, DST)
            if rel in ('module.prop', 'customize.sh', 'boot-completed.sh',
                       'README-DIAGNOSTIC.md',
                       'lkm/x86_64/.payload_stamp',
                       'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                       'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
                       'bin/x86_64/sc_probe'):
                print('  CHANGED', rel)

if __name__ == '__main__':
    main()
