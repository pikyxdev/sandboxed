#!/bin/bash
# build_v48_ko.sh - reproducible v26.11.48 x86_64 LKM dual-candidate build.
#
# v48 is THE LIVE-TABLE TRANSPORT FIX (see kernel/susfs_supercall.c header):
# the v47 campaign (boots 09/10, 2026-11-24) proved the dispatcher-arm redirect
# installs cleanly but NEVER FIRES (sc_entry_count 0 on both transport boots):
# this kernel's BUILT-IN KernelSU-Next (CONFIG_KSU_X86_PATCH_SYSCALL_DISPATCHER)
# patches do_syscall_64/x64_sys_call at boot so EVERY syscall dispatches through
# ksu_syscall_table[nr] - x64_sys_call's arms (where v47 patched) are dead code.
# v48 patches the LIVE sys_call_table[173] entry via the fp_hook patcher, with
# a pre-patch liveness proof (ksu_syscall_dispatcher found IN the table) and
# the v47 arm scan kept as fallback.  Wrapper + ABI + CLI (173) all unchanged.
#
#   - sys_call_table[] entry writes are INERT on this kernel: 5.15 dispatches
#     via x64_sys_call() (a direct-call switch - the Retbleed-era hardening;
#     "The sys_call_table[] is no longer used for system calls",
#     arch/x86/entry/syscall_64.c).  KernelSU's own x86_64 answer to that is
#     KSU_X86_PATCH_SYSCALL_DISPATCHER - "dynamically patches the hardened
#     syscall dispatcher at runtime" - and v47 ships exactly that class.
set -e
BASE=/home/z/my-project
A13=$BASE/a13-full
KORG=$BASE/linux-5.15.178
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
OUT=$BASE/ReSuSFS-x86_64-port
MOD=$BASE/ReSuSFS-x86_64-port/ReSuSFS/module
V=26.11.48

# 0. tree restore (recycle-proof): re-extract from the kept tarballs
restore_tree() {            # $1 = tarball, $2 = expected dir, $3 = inner name
        local TB=$1 DIR=$2 INNER=$3
        if [ ! -f "$DIR/Makefile" ]; then
                echo "[*] restoring $DIR from $TB"
                rm -rf "$DIR"
                tar -xf "$TB" -C "$BASE"
                if [ "$DIR" != "$BASE/$INNER" ]; then
                        mv "$BASE/$INNER" "$DIR"
                fi
        fi
}
restore_tree "$BASE/linux-5.15.178.tar.xz" "$KORG" "linux-5.15.178"
restore_tree "$BASE/a13-mirror.tar.gz"     "$A13"  "kernel_common-ASB-2025-03-05_13-5.15"

prepare_tree() {          # $1 = tree root, $2 = label
        local TREE=$1 LABEL=$2
        echo "[*] preparing $LABEL tree ($TREE)"

        # current.h override (identical for both trees - the LDPlayer kernel
        # trimmed EXPORT_PER_CPU_SYMBOL(current_task); see restore_build_env.sh)
        CURH="$TREE/arch/x86/include/asm/current.h"
        if ! grep -q susfs_current_task_gs_off "$CURH" 2>/dev/null; then
                cp "$BASE/scripts/current.h.override" "$CURH"
        fi

        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                if [ ! -f .config ]; then
                        make defconfig >/dev/null
                        ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                                --enable PREEMPT --enable SMP \
                                --disable MODULE_UNLOAD --disable X86_5LEVEL \
                                --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY
                fi
                # RETPOLINE/RETHUNK OFF (the v42 profile): the field kernel's
                # kallsyms has NO __x86_indirect_thunk_* symbols - a module
                # importing them resolves them to garbage and its very first
                # indirect call jumps into the void.
                ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                        --enable PREEMPT --enable SMP \
                        --disable MODULE_UNLOAD --disable X86_5LEVEL \
                        --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY \
                        --disable RETPOLINE --disable RETHUNK
                make olddefconfig >/dev/null
                make LOCALVERSION= modules_prepare >/dev/null
        )
        echo "[+] $LABEL tree ready"
}

build_tree() {             # $1 = tree root, $2 = output name
        local TREE=$1 NAME=$2
        echo "[*] building $NAME from $TREE"
        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                make M="$LKM" clean >/dev/null 2>&1 || true
                make LOCALVERSION= M="$LKM" CC=gcc modules 2>&1 | tail -5
                cp -f "$LKM/susfs_guard_lkm.ko" "$OUT/$NAME"
        )
        echo "[+] built: $OUT/$NAME ($(stat -c%s "$OUT/$NAME") bytes)"
}

# 1. trees
[ -f "$BASE/linux-5.15.178.tar.xz" ] || { echo "[!] kernel.org tarball missing"; exit 1; }
[ -f "$BASE/a13-mirror.tar.gz" ] || { echo "[!] a13 tarball missing"; exit 1; }

# 2. current.h override source file (kept as a file so both trees get the
# identical bytes)
if [ ! -f "$BASE/scripts/current.h.override" ]; then
        cp "$KORG/arch/x86/include/asm/current.h" "$BASE/scripts/current.h.override"
fi

prepare_tree "$A13"    "a13-ASB-2025-03"
build_tree   "$A13"    "susfs_guard_lkm-x86_64-android13-5.15.ko"
prepare_tree "$KORG"   "kernel.org-5.15.178"
build_tree   "$KORG"   "susfs_guard_lkm-x86_64-vanilla-5.15.ko"

# 3. payload install + stamp
echo "[*] installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$OUT/susfs_guard_lkm-x86_64-android13-5.15.ko" "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$OUT/susfs_guard_lkm-x86_64-vanilla-5.15.ko"   "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v$V" > "$MOD/lkm/x86_64/.payload_stamp"

# 4. CLI patch (the v47 syscall number: 169 -> 173)
echo "[*] patching the CLI supercall sites (169 -> 173)"
python3 "$BASE/scripts/patch_ksu_cli_v47.py" "$MOD/bin/x86_64/ksu_susfs"

# 5. verification (after the CLI patch: the verifier checks the patched sites)
python3 "$BASE/scripts/build_v48_verify.py"

echo "[+] v47 module build complete (payload staged in $MOD)"
