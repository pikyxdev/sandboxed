#!/usr/bin/env python3
"""dedup_toc.py - drop the docx-js sample TOC entry (renders without a page
number) so the TOC shows exactly the injected placeholder entries.

The docx-js TableOfContents emits its own sample hyperlink entry as runs inside
the field's first paragraph (after the 'separate' fldChar). The placeholder
script then injects full entries, so entry #1 appears twice - once with a
PAGEREF that has no cached page text (blank pre-update) and once as a proper
placeholder. Word replaces everything between 'separate' and 'end' on field
update, so dropping the sample now is safe and makes the pre-update TOC clean.
"""
import re
import shutil
import sys
import zipfile

path = sys.argv[1]
tmp = path + ".dedup"

with zipfile.ZipFile(path, "r") as zin:
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}

doc = data["word/document.xml"].decode("utf-8")
# The sample entry: a hyperlink anchored to the first heading bookmark whose
# PAGEREF field carries no cached text, sitting inside the TOC field paragraph.
pat = re.compile(
    r'<w:hyperlink w:history="1" w:anchor="_Toc\d+">'
    r'<w:r><w:t[^>]*>[^<]*</w:t></w:r>'
    r'<w:r><w:tab/></w:r>'
    r'<w:r>(?:(?!</w:hyperlink>).)*?PAGEREF(?:(?!</w:hyperlink>).)*?</w:r>'
    r"</w:hyperlink>",
    re.S,
)
new, n = pat.subn("", doc, count=1)
if n == 1:
    data["word/document.xml"] = new.encode("utf-8")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for name in names:
            zout.writestr(name, data[name])
    shutil.move(tmp, path)
    print("removed docx-js sample TOC entry")
else:
    print("sample entry not found (nothing changed)")
