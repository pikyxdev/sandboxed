#!/usr/bin/env python3
"""make_pkg52.py - build work/pkg52 from work/pkg51 with the v52 content.

Changed vs pkg51 (the zip builder asserts exactly this set):
  module.prop                        - v26.11.52 / versionCode 130 + v52 story
  customize.sh                       - v52 install banner (prepended)
  boot-completed.sh                  - v52 self-test wording + the sc_probe
                                       lookup fix (try /data/adb/ksu/bin
                                       first, then the module's own copy)
  post-fs-data.sh                    - sc_probe SELF-HEAL: install it the
                                       field-proven way (copy to
                                       /data/adb/ksu/bin + chmod 755), the
                                       same contract as the CLI
  README-DIAGNOSTIC.md               - v52 section prepended
  lkm/x86_64/.payload_stamp          - v26.11.52
  lkm/.../susfs_guard_lkm-*-5.15.ko  - rebuilt graft with the CMD-TABLE FIX
                                       (variant/enabled_features corrected
                                       to the stock CLI's wire ABI)

Everything else - the CLI binaries, ymuuu reference payload, utils.sh,
service.sh - is byte-identical to the v51 zip.
"""
import os, shutil

BASE = '/home/z/my-project'
SRC = f'{BASE}/work/pkg51'
DST = f'{BASE}/work/pkg52'
PAYLOAD = f'{BASE}/ReSuSFS-x86_64-port/ReSuSFS/module'

MODULE_PROP = '''id=ReSuSFS
name=ReSuSFS x86_64
version=v26.11.52-x86_64
versionCode=130
author=ReSuSFS port campaign
description=SuSFS for KernelSU (x86_64 port) | v26.11.52: THE CMD-TABLE FIX. The v51 field run (2026-11-25, fresh instance, full 10-boot ladder: substeps 0-7 then arm_stage 1-3, every rung healthy, no wedge) PROVED the transport end-to-end - and for the first time on this box 'ksu_susfs show version' ANSWERED (v2.3.0, sc_entry_count 0->3: every call provably reached the accept path). But show variant and show enabled_features still failed. ROOT CAUSE (found by disassembling the STOCK ksu_susfs binary this box actually runs): the CLI's wire cmd ids are version=0x555e1 (20-byte answer), ENABLED_FEATURES=0x555e2 (8196-byte answer), VARIANT=0x555e3 (20-byte answer) - v51's graft had variant and enabled_features SWAPPED, so 0x555e2 got a 20-byte 'GKI-LKM' answer while the CLI read err at +8192 (still its preset 126) and reported failure. The bug was a transcription error 'confirmed' against the module's own switch (circular); the v47 report and sc_probe.c carried the correct table all along, but sc_probe never ran in the field ('not bundled' - the exec bit was lost). THE v52 FIX: the two constants are corrected to the CLI wire ABI - nothing else in the accept path changes (same clang entry, same calibrated uid gate, same ladder); a WIRE-DISPATCH LOCK now machine-checks the merged .ko's dispatch against the CLI's literal cmd ids at build time; the host test gained literal-id cases; sc_probe is now installed to /data/adb/ksu/bin (the field-proven CLI install path, chmod 755) and the self-test looks there first. LADDER: 51->52 re-bases automatically (arm_stage=0, stage_max=3; fresh instance = full 10-boot climb, in-place flash-over = 4 reboots: 0, 1, 2=OBSERVE, 3=FULL). AT STAGE 3 EXPECT: show version -> v2.3.0, show variant -> GKI-LKM, show enabled_features -> the armed feature list (SUSFS_LKM_MODULES + sus_mount/enable_log/spoof_cmdline/open_redirect/sus_map). Feature commands still answer not-handled this rung (CLI keeps 126); the susfs list application lights up rung by rung from v53. After any wedge send back the five logs (logs/init_trace.txt + logs/diag_last.txt + logs/boot.log + logs/kernel_facts.txt + logs/sc_selftest.txt) | opt-in only, at your own risk | built-in kernel susfs auto-detected | all boot stages logged with a hang watchdog | step-by-step diagnostics via the Action button
'''

CUSTOMIZE_BANNER = '''        ui_print "[*] v26.11.51 -> v26.11.52: THE CMD-TABLE FIX."
        ui_print "[*] Your v51 10-reboot run COMPLETED the whole ladder"
        ui_print "[*] (substeps 0-7, arm_stage 1-3, no wedge) and show"
        ui_print "[*] version ANSWERED (v2.3.0) for the first time - but"
        ui_print "[*] show variant / show enabled_features failed with all"
        ui_print "[*] three calls provably inside the accept path. The stock"
        ui_print "[*] CLI's own dispatch (disassembled) says: e1=version,"
        ui_print "[*] e2=enabled_features (8196B), e3=variant (20B) - v51"
        ui_print "[*] had e2/e3 SWAPPED. v52 corrects the two constants; a"
        ui_print "[*] wire-dispatch lock now machine-checks the shipped .ko"
        ui_print "[*] at build time; sc_probe (which always had the right"
        ui_print "[*] table) is now installed and runs in every self-test."
        ui_print "[*] 51->52 re-bases the ladder: 4 reboots in-place (a"
        ui_print "[*] fresh instance = the full 10-boot climb). At stage 3"
        ui_print "[*] expect: version=v2.3.0, variant=GKI-LKM,"
        ui_print "[*] enabled_features=the armed list."
'''

README_SECTION = '''# v26.11.52 - THE CMD-TABLE FIX (2026-11-25)

## What your v51 10-reboot run proved

The fresh-instance run completed the ENTIRE ladder with zero wedges:

| boot | rung | result |
|------|------|--------|
| 1-3  | substeps 0-2 (dispatch, imports, resolver) | healthy |
| 4-7  | substeps 3-6 (gs_off, deadman, crosscheck, patch) | healthy |
| 8    | substep 7 + arm_stage 1 (10 layers live) | healthy |
| 9    | arm_stage 2 (supercall transport, OBSERVE-ONLY) | healthy, self-test survived, sc_entry_count 0->3 |
| 10   | arm_stage 3 (FULL mode) | healthy - **`ksu_susfs show version` ANSWERED `v2.3.0`** |

The transport works. The accept path works. The calibration works. But
`show variant` and `show enabled_features` still printed "failed".

## The bug (found by disassembling the stock CLI the box actually runs)

All three calls provably entered the accept path (counter 0->3), version
answered - so the transport, magic check and uid gate were fine. The
difference was in the COMMAND IDS. The stock `ksu_susfs` binary's own
dispatch sites decode to:

| cmd | the stock CLI's command | payload shape |
|-----|-------------------------|---------------|
| 0x555e1 | show version | 20 bytes (str[16] + err@16) |
| 0x555e2 | show enabled_features | 8196 bytes (str[8192] + err@8192) |
| 0x555e3 | show variant | 20 bytes (str[16] + err@16) |

v51's graft had **variant and enabled_features swapped**: `0x555e2` got the
20-byte "GKI-LKM" answer (the CLI then read `err` at +8192, which still
held its own preset 126 -> "failed"), and `0x555e3` got the 8196-byte
feature dump (the CLI read `err` at +16 - feature-name bytes -> "failed").

How the error survived: the constants were "confirmed" by disassembling
**the module's own cmd switch** - circular proof. The v47-era report
(`gen_v47_report.js`: "0x555e1 / 0x555e3 / 0x555e2") and `sc_probe.c` both
carried the CORRECT table all along - but sc_probe never ran in the field
because its exec bit was lost through module extraction ("not bundled").

## The fix (v52)

1. **The two constants are corrected** to the CLI wire ABI. Nothing else
   in the accept path changes - same clang entry, same calibrated uid
   gate, same ladder, same self-test.
2. **A wire-dispatch lock** (`scripts/build_v52_verify.py`) now
   disassembles the merged .ko's `susfs_sc_entry` at build time and
   requires `0x555e2 -> sc_v51_answer_features` and
   `0x555e3 -> sc_v51_answer_str` in the machine code. Internal
   consistency can drift again; the wire cannot.
3. **The host test gained literal-id cases** (section 4b): the exact
   bytes the stock CLI sends, asserted against the exact answer shapes.
4. **sc_probe is now field-installed**: post-fs-data copies it to
   `/data/adb/ksu/bin/sc_probe` (chmod 755, the same field-proven
   contract as the CLI), and the self-test runs it from there first. The
   raw-syscall verifier that always had the right table finally runs on
   every box.

## Field procedure

Flash v52. The 51->52 upgrade re-bases the stage ladder automatically
(arm_stage=0, stage_max=3): **4 reboots in-place** (0 -> 1 -> 2=OBSERVE ->
3=FULL). On a fresh instance the substep ladder also starts from 0 - the
full 10-boot climb, exactly your standard test.

At stage 3 the self-test should print:

```
-- ksu_susfs show version (timeout 3):
v2.3.0
-- ksu_susfs show variant (timeout 3):
GKI-LKM
-- ksu_susfs show enabled_features (timeout 3):
SUSFS_LKM_MODULES
CONFIG_KSU_SUSFS_SUS_MOUNT
CONFIG_KSU_SUSFS_ENABLE_LOG
CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
CONFIG_KSU_SUSFS_OPEN_REDIRECT
CONFIG_KSU_SUSFS_SUS_MAP
```

(exact feature list depends on the armed layers; the five gated entries
above are the stage-3 armed set.) One wedge boot maximum by design; after
ANY wedge send back the five logs (logs/init_trace.txt + logs/diag_last.txt
+ logs/boot.log + logs/kernel_facts.txt + logs/sc_selftest.txt).

'''

def main():
    if os.path.exists(DST):
        shutil.rmtree(DST)
    shutil.copytree(SRC, DST)

    # 1. module.prop
    open(f'{DST}/module.prop', 'w').write(MODULE_PROP)

    # 2. customize.sh - prepend the v52 banner before the v51 banner
    cs = open(f'{DST}/customize.sh').read()
    anchor = '        ui_print "[*] v26.11.50 -> v26.11.51: THE CLANG ACCEPT PATH."'
    assert anchor in cs, 'v51 banner anchor not found in customize.sh'
    cs = cs.replace(anchor, CUSTOMIZE_BANNER + anchor, 1)
    open(f'{DST}/customize.sh', 'w').write(cs)

    # 3. boot-completed.sh - v52 wording + the sc_probe lookup fix
    bc = open(f'{DST}/boot-completed.sh').read()

    old_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v51 CLANG ACCEPT PATH, nr 173; CLI: $SC_CLI)"'
    new_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v52 CLANG ACCEPT PATH + CLI WIRE ABI, nr 173; CLI: $SC_CLI)"'
    assert old_line in bc, 'self-test start line not found'
    bc = bc.replace(old_line, new_line, 1)

    old_hdr = "echo \"---- v51 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    new_hdr = "echo \"---- v52 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    assert old_hdr in bc, 'self-test header not found'
    bc = bc.replace(old_hdr, new_hdr, 1)

    old_probe = """                                if [ -x "$MODDIR/bin/x86_64/sc_probe" ]; then
                                        echo '---- sc_probe (raw syscall view, independent of any CLI) ----'
                                        $BB timeout 10 "$MODDIR/bin/x86_64/sc_probe" 2>&1
                                else
                                        echo 'sc_probe: not bundled (expected at bin/x86_64/sc_probe)'
                                fi"""
    new_probe = """                                SC_PROBE=""
                                for p in /data/adb/ksu/bin/sc_probe "$MODDIR/bin/x86_64/sc_probe"; do
                                        [ -x "$p" ] && { SC_PROBE="$p"; break; }
                                done
                                if [ -n "$SC_PROBE" ]; then
                                        echo "---- sc_probe ($SC_PROBE, raw syscall view, independent of any CLI) ----"
                                        $BB timeout 10 "$SC_PROBE" 2>&1
                                else
                                        echo 'sc_probe: not found (expected at /data/adb/ksu/bin/sc_probe or bin/x86_64/sc_probe)'
                                fi"""
    assert old_probe in bc, 'sc_probe block not found'
    bc = bc.replace(old_probe, new_probe, 1)

    old_note = "echo 'NOTE: v51 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry AND the whole accept path are clang-17; the uid gate reads the cred offset CALIBRATED at install from init_task/init_cred (no header-derived struct offsets); stage 3 answers SHOW_VERSION/SHOW_VARIANT/SHOW_ENABLED_FEATURES in payload.err and the syscall return - feature commands answer not-handled this rung (CLI keeps 126), the v49 GCC wrapper is never called.'"
    new_note = "echo 'NOTE: v52 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry AND the whole accept path are clang-17; the uid gate reads the cred offset CALIBRATED at install from init_task/init_cred (no header-derived struct offsets); the SHOW cmd ids follow the STOCK CLI wire ABI (0x555e1=version 20B, 0x555e2=enabled_features 8196B, 0x555e3=variant 20B - v51 had e2/e3 swapped, v52 fixes it); feature commands answer not-handled this rung (CLI keeps 126), the v49 GCC wrapper is never called.'"
    assert old_note in bc, 'self-test NOTE not found'
    bc = bc.replace(old_note, new_note, 1)
    open(f'{DST}/boot-completed.sh', 'w').write(bc)

    # 4. post-fs-data.sh - the sc_probe SELF-HEAL install block
    pf = open(f'{DST}/post-fs-data.sh').read()
    anchor_cli = """                        else
                                log_boot "post-fs-data: WARNING - ksu_susfs install to $CLI_DST failed; the self-test will use the module's own copy"
                        fi
                fi
        fi"""
    probe_block = anchor_cli + """

        # ---- v26.11.52: sc_probe SELF-HEAL (every boot) -----------------------
        # The v51 field run printed 'sc_probe: not bundled' every boot while
        # the probe sat right in the zip at bin/x86_64/sc_probe - the exec
        # bit was lost through module extraction, so the self-test's -x
        # check never passed. Install it the field-proven way (same contract
        # as the CLI above): copy to /data/adb/ksu/bin + chmod 755. The
        # self-test looks there first. sc_probe is the raw-syscall verifier
        # that carries the CORRECT cmd table (variant=0x555e3) - v51's
        # 'not bundled' is exactly why the e2/e3 swap survived to the field.
        PROBE_MOD="$MODDIR/bin/x86_64/sc_probe"
        PROBE_DST=/data/adb/ksu/bin/sc_probe
        if [ -f "$PROBE_MOD" ]; then
                if ! cmp -s "$PROBE_MOD" "$PROBE_DST" 2>/dev/null; then
                        if cp -f "$PROBE_MOD" "$PROBE_DST" && chmod 755 "$PROBE_DST"; then
                                log_boot "post-fs-data: sc_probe installed at $PROBE_DST (sha256 $(sha256sum "$PROBE_MOD" 2>/dev/null | awk '{print $1}'))"
                        else
                                log_boot "post-fs-data: WARNING - sc_probe install to $PROBE_DST failed; the self-test falls back to the module's own copy"
                        fi
                fi
        fi"""
    assert anchor_cli in pf, 'CLI install block anchor not found in post-fs-data.sh'
    pf = pf.replace(anchor_cli, probe_block, 1)
    open(f'{DST}/post-fs-data.sh', 'w').write(pf)

    # 5. README - prepend the v52 section
    rd = open(f'{DST}/README-DIAGNOSTIC.md').read()
    open(f'{DST}/README-DIAGNOSTIC.md', 'w').write(README_SECTION + rd)

    # 6. the rebuilt .kos + stamp from the staged payload
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                    f'{DST}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
                    f'{DST}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
    open(f'{DST}/lkm/x86_64/.payload_stamp', 'w').write('v26.11.52\n')

    print('pkg52 ready:', DST)
    for root, dirs, files in os.walk(DST):
        for f in files:
            p = os.path.join(root, f)
            rel = os.path.relpath(p, DST)
            if rel in ('module.prop', 'customize.sh', 'boot-completed.sh',
                       'post-fs-data.sh', 'README-DIAGNOSTIC.md',
                       'lkm/x86_64/.payload_stamp',
                       'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                       'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko'):
                print('  CHANGED', rel)

if __name__ == '__main__':
    main()
