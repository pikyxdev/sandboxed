/* libredir.so - LD_PRELOAD path redirector (no-root bison support)
 *
 * Redirects every "/usr/share/bison/..." path to the dpkg-extracted prefix
 * at /home/z/my-project/tools/root/usr/share/bison/, so the extracted bison
 * can find its m4sugar data files on a system where /usr/share/bison is
 * absent and cannot be created without root.
 *
 * Covers open/open64/openat, fopen/fopen64/freopen, stat/lstat/__xstat/
 * __lxstat, access/faccessat, execv/execvp/execve (argv rewrite too) and
 * posix_spawn*. Passthrough for everything else.
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdarg.h>
#include <spawn.h>
#include <errno.h>

#define REDIR_FROM "/usr/share/bison/"
#define REDIR_TO   "/home/z/my-project/tools/root/usr/share/bison/"
#define FLEN (int)sizeof(REDIR_FROM) - 1

static const char *map_path(const char *p)
{
    static __thread char buf[4096];
    if (p && strncmp(p, REDIR_FROM, FLEN) == 0) {
        snprintf(buf, sizeof(buf), "%s%s", REDIR_TO, p + FLEN);
        return buf;
    }
    return p;
}

/* ---------------- open family ---------------- */
int open(const char *path, int flags, ...)
{
    static int (*real_fn)(const char *, int, ...);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "open");
    va_list ap; va_start(ap, flags);
    int mode = va_arg(ap, int); va_end(ap);
    return real_fn(map_path(path), flags, mode);
}

int open64(const char *path, int flags, ...)
{
    static int (*real_fn)(const char *, int, ...);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "open64");
    va_list ap; va_start(ap, flags);
    int mode = va_arg(ap, int); va_end(ap);
    return real_fn(map_path(path), flags, mode);
}

int openat(int dirfd, const char *path, int flags, ...)
{
    static int (*real_fn)(int, const char *, int, ...);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "openat");
    va_list ap; va_start(ap, flags);
    int mode = va_arg(ap, int); va_end(ap);
    return real_fn(dirfd, map_path(path), flags, mode);
}

/* ---------------- stdio family ---------------- */
FILE *fopen(const char *path, const char *mode)
{
    static FILE *(*real_fn)(const char *, const char *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "fopen");
    return real_fn(map_path(path), mode);
}

FILE *fopen64(const char *path, const char *mode)
{
    static FILE *(*real_fn)(const char *, const char *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "fopen64");
    return real_fn(map_path(path), mode);
}

FILE *freopen(const char *path, const char *mode, FILE *stream)
{
    static FILE *(*real_fn)(const char *, const char *, FILE *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "freopen");
    return real_fn(map_path(path), mode, stream);
}

/* ---------------- stat family ---------------- */
int stat(const char *path, struct stat *st)
{
    static int (*real_fn)(const char *, struct stat *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "stat");
    return real_fn(map_path(path), st);
}

int lstat(const char *path, struct stat *st)
{
    static int (*real_fn)(const char *, struct stat *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "lstat");
    return real_fn(map_path(path), st);
}

int __xstat(int ver, const char *path, struct stat *st)
{
    static int (*real_fn)(int, const char *, struct stat *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "__xstat");
    return real_fn(ver, map_path(path), st);
}

int __lxstat(int ver, const char *path, struct stat *st)
{
    static int (*real_fn)(int, const char *, struct stat *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "__lxstat");
    return real_fn(ver, map_path(path), st);
}

int stat64(const char *path, struct stat64 *st)
{
    static int (*real_fn)(const char *, struct stat64 *);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "stat64");
    return real_fn(map_path(path), st);
}

/* ---------------- access ---------------- */
int access(const char *path, int mode)
{
    static int (*real_fn)(const char *, int);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "access");
    return real_fn(map_path(path), mode);
}

int faccessat(int dirfd, const char *path, int mode, int flags)
{
    static int (*real_fn)(int, const char *, int, int);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "faccessat");
    return real_fn(dirfd, map_path(path), mode, flags);
}

/* ---------------- exec family (argv rewrite) ---------------- */
static char **map_argv(char *const argv[])
{
    if (!argv) return NULL;
    int n = 0;
    while (argv[n]) n++;
    char **out = malloc((n + 1) * sizeof(char *));
    if (!out) return (char **)argv; /* OOM: passthrough */
    for (int i = 0; i < n; i++) {
        const char *m = map_path(argv[i]);
        size_t len = strlen(m) + 1;
        out[i] = malloc(len);
        if (!out[i]) out[i] = argv[i]; else memcpy(out[i], m, len);
    }
    out[n] = NULL;
    return out;
}

int execv(const char *path, char *const argv[])
{
    static int (*real_fn)(const char *, char *const []);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "execv");
    return real_fn(map_path(path), map_argv(argv));
}

int execvp(const char *file, char *const argv[])
{
    static int (*real_fn)(const char *, char *const []);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "execvp");
    return real_fn(map_path(file), map_argv(argv));
}

int execve(const char *path, char *const argv[], char *const envp[])
{
    static int (*real_fn)(const char *, char *const [], char *const []);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "execve");
    return real_fn(map_path(path), map_argv(argv), envp);
}

int posix_spawn(pid_t *pid, const char *path,
                const posix_spawn_file_actions_t *fa,
                const posix_spawnattr_t *attr,
                char *const argv[], char *const envp[])
{
    static int (*real_fn)(pid_t *, const char *,
                          const posix_spawn_file_actions_t *,
                          const posix_spawnattr_t *,
                          char *const [], char *const []);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "posix_spawn");
    return real_fn(pid, map_path(path), fa, attr, map_argv(argv), envp);
}

int posix_spawnp(pid_t *pid, const char *file,
                 const posix_spawn_file_actions_t *fa,
                 const posix_spawnattr_t *attr,
                 char *const argv[], char *const envp[])
{
    static int (*real_fn)(pid_t *, const char *,
                          const posix_spawn_file_actions_t *,
                          const posix_spawnattr_t *,
                          char *const [], char *const []);
    if (!real_fn) real_fn = dlsym(RTLD_NEXT, "posix_spawnp");
    return real_fn(pid, map_path(file), fa, attr, map_argv(argv), envp);
}
