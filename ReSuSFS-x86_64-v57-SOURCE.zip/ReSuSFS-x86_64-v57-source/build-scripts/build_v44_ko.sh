#!/bin/bash
# build_v44_ko.sh - reproducible v26.11.44 x86_64 LKM dual-candidate build.
#
# v44 is THE RESOLVER PROBE FIX (see the v26.11.44 entry in
# ReSuSFS/CHANGELOG.md and kernel/symbol_resolver.c):
#
#   The v43 field result: SYNC trigger proven safe (substeps 0/1 clean),
#   substep 2 refused BY DESIGN - 'kln probe lookup of 'printk' returned
#   0x0 - refusing'.  Field greps + the kallsyms snapshot proved the seed
#   PERFECT (kln=ffffffff810fd360 IS kallsyms_lookup_name) and the NAME
#   wrong: this GKI-style clang-17 LTO kernel lists _printk and vprintk
#   but has ZERO 'printk' entries.  v44 probes _printk -> printk ->
#   vprintk; first hit validates KLN mode and the breadcrumb names the
#   winner.
#
#   android13 -> susfs_guard_lkm-x86_64-android13-5.15.ko
#                AOSP android13-5.15 ASB-2025-03-05 (a13-full/), HOST GCC.
#                NOT the default candidate (the image fails init_module
#                with ENOEXEC on the box; kept shippable for re-testing).
#   vanilla   -> susfs_guard_lkm-x86_64-vanilla-5.15.ko
#                kernel.org linux-5.15.178 (linux-5.15.178/), HOST GCC.
#                THE DEFAULT - loads CLEAN in the field and carries the
#                build profile whose module code verifiably EXECUTED.
#
# Module changes in v44 (kernel/symbol_resolver.c):
#   - kr_kln_activate: probe candidate list (_printk, printk, vprintk),
#     per-miss breadcrumbs, refuse message lists all three candidates,
#     KLN-active breadcrumb names the winning probe.
#   - module-side: recon summary only claims kernel_config.txt when the
#     file was really written (/proc/config.gz absent is normal here).
#
# Trees may be pruned by a sandbox recycle: this script re-extracts them
# from the kept tarballs (linux-5.15.178.tar.xz / a13-mirror.tar.gz) when
# their Makefile is missing, then re-applies the current.h override.
set -e
BASE=/home/z/my-project
A13=$BASE/a13-full
KORG=$BASE/linux-5.15.178
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
OUT=$BASE/ReSuSFS-x86_64-port
MOD=$BASE/ReSuSFS-x86_64-port/ReSuSFS/module

# 0. tree restore (recycle-proof): re-extract from the kept tarballs
restore_tree() {            # $1 = tarball, $2 = expected dir, $3 = inner name
        local TB=$1 DIR=$2 INNER=$3
        if [ ! -f "$DIR/Makefile" ]; then
                echo "[*] restoring $DIR from $TB"
                rm -rf "$DIR"
                tar -xf "$TB" -C "$BASE"
                [ "$DIR" != "$BASE/$INNER" ] && mv "$BASE/$INNER" "$DIR"
        fi
}
restore_tree "$BASE/linux-5.15.178.tar.xz" "$KORG" "linux-5.15.178"
restore_tree "$BASE/a13-mirror.tar.gz"     "$A13"  "kernel_common-ASB-2025-03-05_13-5.15"

prepare_tree() {          # $1 = tree root, $2 = label
        local TREE=$1 LABEL=$2
        echo "[*] preparing $LABEL tree ($TREE)"

        # current.h override (identical for both trees - the LDPlayer kernel
        # trimmed EXPORT_PER_CPU_SYMBOL(current_task); see restore_build_env.sh)
        CURH="$TREE/arch/x86/include/asm/current.h"
        if ! grep -q susfs_current_task_gs_off "$CURH" 2>/dev/null; then
                cp "$BASE/scripts/current.h.override" "$CURH"
        fi

        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                if [ ! -f .config ]; then
                        make defconfig >/dev/null
                        ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                                --enable PREEMPT --enable SMP \
                                --disable MODULE_UNLOAD --disable X86_5LEVEL \
                                --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY
                fi
                # RETPOLINE/RETHUNK OFF (the v42 profile): the field kernel's
                # kallsyms has NO __x86_indirect_thunk_* symbols - a module
                # importing them resolves them to garbage and its very first
                # indirect call jumps into the void.
                ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                        --enable PREEMPT --enable SMP \
                        --disable MODULE_UNLOAD --disable X86_5LEVEL \
                        --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY \
                        --disable RETPOLINE --disable RETHUNK
                make olddefconfig >/dev/null
                make LOCALVERSION= modules_prepare >/dev/null
        )
        echo "[+] $LABEL tree ready (this_module will be $(grep -q ANDROID_KABI_RESERVE "$TREE/include/linux/module.h" && echo 0x340 || echo 0x300))"
}

build_tree() {             # $1 = tree root, $2 = output name
        local TREE=$1 NAME=$2
        echo "[*] building $NAME from $TREE"
        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                make M="$LKM" clean >/dev/null 2>&1 || true
                make LOCALVERSION= M="$LKM" CC=gcc modules 2>&1 | tail -5
                cp -f "$LKM/susfs_guard_lkm.ko" "$OUT/$NAME"
        )
        echo "[+] built: $OUT/$NAME ($(stat -c%s "$OUT/$NAME") bytes)"
}

# 1. trees
[ -f "$BASE/linux-5.15.178.tar.xz" ] || { echo "[!] kernel.org tarball missing"; exit 1; }
[ -f "$BASE/a13-mirror.tar.gz" ] || { echo "[!] a13 tarball missing"; exit 1; }

# 2. current.h override source file (kept as a file so both trees get the
# identical bytes)
if [ ! -f "$BASE/scripts/current.h.override" ]; then
        cp "$KORG/arch/x86/include/asm/current.h" "$BASE/scripts/current.h.override"
fi

prepare_tree "$A13"    "a13-ASB-2025-03"
build_tree   "$A13"    "susfs_guard_lkm-x86_64-android13-5.15.ko"
prepare_tree "$KORG"   "kernel.org-5.15.178"
build_tree   "$KORG"   "susfs_guard_lkm-x86_64-vanilla-5.15.ko"

# 3. verification
python3 "$BASE/scripts/build_v44_verify.py"

# 4. payload install + stamp + module zip
echo "[*] installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$OUT/susfs_guard_lkm-x86_64-android13-5.15.ko" "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$OUT/susfs_guard_lkm-x86_64-vanilla-5.15.ko"   "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v26.11.44" > "$MOD/lkm/x86_64/.payload_stamp"

echo "[*] zipping ReSuSFS-x86_64-v26.11.44.zip"
(
        cd "$MOD"
        rm -f "$OUT/ReSuSFS-x86_64-v26.11.44.zip" "$BASE/download/ReSuSFS-x86_64-v26.11.44.zip"
        zip -9 -r "$OUT/ReSuSFS-x86_64-v26.11.44.zip" . -x 'webroot/CNAME' > /dev/null
)
mkdir -p "$BASE/download"
cp -f "$OUT/ReSuSFS-x86_64-v26.11.44.zip" "$BASE/download/ReSuSFS-x86_64-v26.11.44.zip"
echo "[+] shipped: $BASE/download/ReSuSFS-x86_64-v26.11.44.zip ($(stat -c%s "$BASE/download/ReSuSFS-x86_64-v26.11.44.zip") bytes)"
