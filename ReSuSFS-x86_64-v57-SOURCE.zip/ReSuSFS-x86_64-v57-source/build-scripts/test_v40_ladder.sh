#!/bin/sh
# ============================================================================
# v26.11.40 substep-ladder regression test (host).
#
# Verifies the v40 userspace protocol against a fake module tree with a fake
# /sys/module/susfs_guard_lkm/parameters, a fake /proc/kallsyms that models
# the FIELD DEVICE (kernel 5.15.178+, kallsyms_lookup_name listed, current_task
# at 0x1bc40, kallsyms TABLE variables NOT listed), and a fake ksud.
#
#   T1  seed v2 emits kln=+gsoff= from the field-shaped /proc/kallsyms
#   T2  seed v2 falls back to the table form when tables ARE listed
#   T3  seed v2 refuses (rc 1, plain message) when neither is visible
#   T4  boot-completed drives substep N: writes init_maxstep, force_init,
#       receipts BEFORE each action, advances init_seq on ok
#   T5  nok leaves init_seq untouched (same-rung retry)
#   T6  seq 6 ok -> seq 7 + arm_stage 1 (the layer rung)
#   T7  seq 7 ok -> arm_stage +1 capped by stage_max
#   T8  stand-down dossier: a stale "try" marker copies init_trace +
#       diag_last into boot.log and removes the flags (stage-0)
#   T9  stale "try" at stage > 0 demotes + caps (regression of v37 logic)
#   T10 suppression: no_init_this_boot skips the trigger and is consumed
#   T11 payload stamp: install gate refreshes module-issued .kos on stamp
#       mismatch; same stamp keeps them (user-supplied wins preserved)
#   T12 the self-heal fires on stamp mismatch even when the .ko exists
#
# All hardcoded /data paths are substituted into scratch copies of utils.sh
# / boot-completed.sh / post-fs-data.sh; nothing on the host is touched.
# ============================================================================
SRC=/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module
T=/tmp/v40test
FB=$T/fakebin
FAIL=0

ok()   { echo "  [PASS] $1"; }
bad()  { echo "  [FAIL] $1"; FAIL=$((FAIL+1)); }
has()  { grep -qF "$2" "$1" 2>/dev/null && ok "$3" || bad "$3"; }
lacks(){ { ! grep -qF "$2" "$1" 2>/dev/null; } && ok "$3" || bad "$3"; }

rm -rf "$T"; mkdir -p "$T/adb/ReSuSFS_LKM" "$T/adb/ReSuSFS/logs" \
                "$T/adb/modules/ReSuSFS" "$T/persist" "$T/out" "$FB" "$T/kasym"

# ---- fake /proc/kallsyms: the FIELD shape ---------------------------------
# (tables NOT listed; kallsyms_lookup_name + current_task listed)
cat > "$T/kasym/field" <<'EOF'
000000000001bc40 A current_task
ffffffff810fd360 t kallsyms_lookup_name
ffffffff810fd840 t kallsyms_lookup
ffffffff810fdce0 t sprint_symbol
ffffffff81067820 t panic
ffffffff81476500 t bcmp
EOF
cat > "$T/kasym/tables" <<'EOF'
000000000001bc40 A current_task
ffffffff810fd360 t kallsyms_lookup_name
ffffffff82074a60 d kallsyms_names
ffffffff82074b00 d kallsyms_offsets
ffffffff81000000 d kallsyms_relative_base
ffffffff82074b40 d kallsyms_num_syms
ffffffff82074c00 d kallsyms_markers
ffffffff82074c40 d kallsyms_token_table
ffffffff82074c80 d kallsyms_token_index
EOF
cat > "$T/kasym/empty" <<'EOF'
000000000001bc40 A current_task
ffffffff81067820 t panic
EOF

# ---- fake /proc / /sys trees ----------------------------------------------
mkdir -p "$T/proc/sys/kernel/random" "$T/proc/sys/kernel"
echo "0123456789abcdef0123456789abcdef" > "$T/proc/sys/kernel/random/boot_id"
echo 2 > "$T/proc/sys/kernel/kptr_restrict"

MODP="$T/sys/module/susfs_guard_lkm"
make_params() {
        rm -rf "$MODP"; mkdir -p "$MODP/parameters"
        for p in arm_stage force_init init_done init_maxstep init_laststep \
                 wd_timeout_s diag_log kr_seed kr_scan sc_entry_count; do
                : > "$MODP/parameters/$p"
        done
        # a fake module: init_done flips to 1 after force_init is written,
        # and diag_log/laststep emulate the substep body's behavior
        cat > "$MODP/parameters/.sim" <<'EOF'
EOF
}

# the ksud fake: records argv, "loads" the module by creating the sysfs tree
V40_SYS="$T/sys"
export V40_SYS
cat > "$FB/ksud" <<'EOF'
#!/bin/sh
echo "ksud $*" >> "$V40_SIM_DIR/ksud.log"
if [ "$1" = "insmod" ]; then
        mkdir -p "$V40_SYS/module/susfs_guard_lkm/parameters"
        for p in arm_stage force_init init_done init_maxstep init_laststep \
                 wd_timeout_s diag_log kr_seed kr_scan sc_entry_count; do
                [ -f "$V40_SYS/module/susfs_guard_lkm/parameters/$p" ] || : > "$V40_SYS/module/susfs_guard_lkm/parameters/$p"
        done
        exit 0
fi
exit 1
EOF
chmod +x "$FB/ksud"

cat > "$FB/uname" <<'EOF'
#!/bin/sh
case "$1" in
  -m) echo "x86_64" ;;
  -r) echo "5.15.178+" ;;
  *)  echo "Linux (none) 5.15.178+ #1 SMP PREEMPT x86_64 Android" ;;
esac
EOF
cat > "$FB/getprop" <<'EOF'
#!/bin/sh
case "$1" in
  ro.product.cpu.abi) echo "x86_64" ;;
  *) : ;;
esac
EOF
cat > "$FB/busybox" <<'EOF'
#!/bin/sh
a="$1"; shift
case "$a" in
  dmesg) echo "" ;;
  sleep) /bin/sleep "$@" ;;
  cp)    /bin/cp "$@" ;;
  chmod) /bin/chmod "$@" ;;
  rmmod) exit 1 ;;
  *)     command "$a" "$@" ;;
esac
EOF
chmod +x "$FB/uname" "$FB/getprop" "$FB/busybox"

# ---- module tree + path substitution --------------------------------------
MODDIR="$T/adb/modules/ReSuSFS"
mkdir -p "$MODDIR/lkm/x86_64/candidates" "$MODDIR/bin/x86_64" "$MODDIR/logs"
sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS_LKM|$T/adb/ReSuSFS_LKM|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/proc/kallsyms|$T/kasym/current|g" \
    -e "s|/proc/sys/kernel|$T/proc/sys/kernel|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/utils.sh" > "$MODDIR/utils.sh"

sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/boot-completed.sh" > "$T/out/boot-completed.sh"
sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/post-fs-data.sh" > "$T/out/post-fs-data.sh"
# substitute the moddir include + shellcheck-proof the scratch copies
for f in "$MODDIR/utils.sh" "$T/out/boot-completed.sh" "$T/out/post-fs-data.sh"; do
        # replace the WHOLE PATH= line (the real one carries a termux segment too)
        sed -i "s|^PATH=.*|PATH=$FB:\$PATH|" "$f"
done

# payload: a fake .ko + stamp (the v40 payload shape)
echo "V40KO-ANDROID13" > "$MODDIR/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
echo "V39KO-VANILLA"    > "$MODDIR/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "YMUUU"            > "$MODDIR/lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko"
echo "v26.11.40"        > "$MODDIR/lkm/x86_64/.payload_stamp"
cp "$MODDIR/utils.sh" "$T/out/utils.keep"

PERSIST="$T/adb/ReSuSFS"
BOOTLOG="$PERSIST/logs/boot.log"
mkdir -p "$PERSIST/logs"

# the fake module "firmware": reads force_init, sets init_done + diag_log,
# honouring init_maxstep like the real v40 body does
sim_trigger() {
        local maxstep laststep
        maxstep="$(cat "$MODP/parameters/init_maxstep" 2>/dev/null)"
        case "$maxstep" in ''|*[!0-9]*) maxstep=0 ;; esac
        laststep=0
        # emulate DIAG crumbs per step
        {
                echo "DIAG step 1: susfs_init ENTERED (maxstep=$maxstep)"
                echo "watchdog: armed (15s)"
                [ "$maxstep" -ge 1 ] && { echo "DIAG step 2: imports_guard ok"; laststep=1; }
                [ "$maxstep" -ge 2 ] && { echo "resolver: KLN mode ACTIVE"; laststep=2; }
                [ "$maxstep" -ge 3 ] && { echo "current_task: gs_off=0x1bc40"; laststep=3; }
                [ "$maxstep" -ge 4 ] && { echo "DIAG step 4b: deadman ok"; laststep=4; }
                [ "$maxstep" -ge 5 ] && { echo "DIAG step 5: crosscheck ok"; laststep=5; }
                [ "$maxstep" -ge 6 ] && { echo "DIAG step 5a: patch ok"; laststep=6; }
                [ "$maxstep" -ge 7 ] && { echo "DIAG step 6: layer loop ok"; laststep=7; }
                echo "DIAG step 9: RETURNING 0 (laststep=$laststep)"
        } > "$MODP/parameters/diag_log"
        echo "$laststep" > "$MODP/parameters/init_laststep"
        echo 1 > "$MODP/parameters/init_done"
}

reset_boot() {
        rm -rf "$PERSIST" "$T/adb/ReSuSFS_LKM"
        mkdir -p "$PERSIST/logs" "$T/adb/ReSuSFS_LKM"
        : > "$BOOTLOG"
        make_params
        cp "$T/out/utils.keep" "$MODDIR/utils.sh"
}

run_bc() { sh "$T/out/boot-completed.sh" >/dev/null 2>&1; }

echo "== T1: seed v2 emits kln=+gsoff= from the field-shaped kallsyms =="
cp "$T/kasym/field" "$T/kasym/current"
reset_boot
. "$MODDIR/utils.sh"
S="$(seed_kallsyms_resolver_v2)"
case "$S" in
        kln=ffffffff810fd360* ) ok "seed v2 kln/gsoff: $S" ;;
        * ) bad "seed v2 kln/gsoff: got '$S'" ;;
esac
echo "kln=ffffffff810fd360 gsoff=0x1bc40" > "$MODP/parameters/kr_seed"
has "$MODP/parameters/kr_seed" "kln=ffffffff810fd360 gsoff=0x1bc40" "T1b kr_seed param written"

echo "== T2: seed v2 falls back to the table form =="
cp "$T/kasym/tables" "$T/kasym/current"
S="$(seed_kallsyms_resolver_v2)"
case "$S" in
        *"kln=ffffffff810fd360"*"offsets=ffffffff82074b00"* ) ok "T2 table form present with kln: $S" ;;
        * ) bad "T2 table form: got '$S'" ;;
esac

echo "== T3: seed v2 refuses when neither is visible =="
cp "$T/kasym/empty" "$T/kasym/current"
S="$(seed_kallsyms_resolver_v2 2>/dev/null)"
rc=$?
if [ "$rc" = "1" ] && [ -z "$S" ]; then ok "T3 refused (rc=1, no seed written)"
else bad "T3: rc=$rc seed='$S'"; fi
cp "$T/kasym/field" "$T/kasym/current"

echo "== T4: substep N dispatch + receipts + advance on ok =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 0 > "$PERSIST/init_seq"
# a fake sysfs write simulator: force_init write triggers the module sim.
# emulate: after boot-completed writes force_init, the poll loop reads
# init_done... we hook it by pre-setting init_done AFTER the maxstep write.
# Simplest deterministic emulation: patch the scratch copy so each sleep
# iteration triggers the sim once.
sed -i 's|sleep 1|sleep 1; [ -f '"$MODP"'/parameters/force_init ] \&\& sim_trigger \|\| :|' "$T/out/boot-completed.sh" 2>/dev/null
# sim_trigger is defined in this test file - export it for the child shell
sim_trigger_x() { sim_trigger; }
export sim_trigger_x
# shell function export trick: sh functions can't be exported portably; instead
# wrap via env file
cat > "$FB/simhook" <<EOF
#!/bin/sh
. "$T/out/simfn.sh"
[ -f "$MODP/parameters/force_init" ] && sim_trigger || :
EOF
chmod +x "$FB/simhook"
cat > "$T/out/simfn.sh" <<EOF
sim_trigger() {
        maxstep="\$(cat "$MODP/parameters/init_maxstep" 2>/dev/null)"
        case "\$maxstep" in ''|*[!0-9]*) maxstep=0 ;; esac
        echo "DIAG step 1: ENTERED (maxstep=\$maxstep)" > "$MODP/parameters/diag_log"
        echo "\$maxstep" > "$MODP/parameters/init_laststep"
        echo 1 > "$MODP/parameters/init_done"
}
EOF
sed -i "s|sleep 1|sleep 1; $FB/simhook|" "$T/out/boot-completed.sh"
run_bc
# the sim fired during the poll loop; the witness advanced init_seq
seq="$(cat "$PERSIST/init_seq" 2>/dev/null)"
[ "$seq" = "1" ] && ok "T4 init_seq advanced 0 -> 1" || bad "T4 init_seq=$seq (want 1)"
[ -f "$PERSIST/logs/init_trace.txt" ] && ok "T4b init_trace.txt exists" || bad "T4b init_trace.txt missing"
has "$PERSIST/logs/init_trace.txt" "STEP 0/7 DISPATCHING" "T4c receipt BEFORE dispatch"
has "$PERSIST/logs/init_trace.txt" "writing force_init=1" "T4d receipt before the trigger"
has "$PERSIST/stage_boot" "ok 0 " "T4e ok marker written"
has "$PERSIST/logs/diag_last.txt" "DIAG step 1" "T4f diag snapshot salvaged"

echo "== T5: nok leaves init_seq untouched =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 3 > "$PERSIST/init_seq"
# no simhook fire: remove it for this run
sed -i "s|; $FB/simhook||" "$T/out/boot-completed.sh"
run_bc
seq="$(cat "$PERSIST/init_seq" 2>/dev/null)"
[ "$seq" = "3" ] && ok "T5 nok kept seq=3 (same-rung retry)" || bad "T5 seq=$seq"
has "$PERSIST/stage_boot" "nok 0 " "T5b nok marker written"

echo "== T6: seq 6 ok -> seq 7 + arm_stage 1 =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 6 > "$PERSIST/init_seq"
echo 0 > "$MODP/parameters/init_done" # will be set by the hook
sed -i "s|sleep 1|sleep 1; $FB/simhook|" "$T/out/boot-completed.sh"
run_bc
seq="$(cat "$PERSIST/init_seq" 2>/dev/null)"
arm="$(cat "$PERSIST/arm_stage" 2>/dev/null)"
[ "$seq" = "7" ] && ok "T6 seq 6->7" || bad "T6 seq=$seq"
[ "$arm" = "1" ] && ok "T6b arm_stage raised to 1" || bad "T6b arm=$arm"
sed -i "s|; $FB/simhook||" "$T/out/boot-completed.sh"

echo "== T7: seq 7 ok at arm 1 -> arm_stage 2 (cap respected) =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 7 > "$PERSIST/init_seq"
echo 1 > "$PERSIST/arm_stage"
sed -i "s|sleep 1|sleep 1; $FB/simhook|" "$T/out/boot-completed.sh"
run_bc
arm="$(cat "$PERSIST/arm_stage" 2>/dev/null)"
[ "$arm" = "2" ] && ok "T7 arm_stage 1->2" || bad "T7 arm=$arm"
sed -i "s|; $FB/simhook||" "$T/out/boot-completed.sh"

echo "== T8: stale try + stage 0 -> stand-down dossier + flags removed =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo "try 0 deadbeefdeadbeefdeadbeefdeadbeef" > "$PERSIST/stage_boot"
echo 0 > "$PERSIST/arm_stage"
echo "[receipt] STEP 2/7 DISPATCHING (resolver)" > "$PERSIST/logs/init_trace.txt"
echo "resolver: KLN mode ACTIVE" > "$PERSIST/logs/diag_last.txt"
# the module is "live" for post-fs-data's checks
mkdir -p "$MODP/parameters"
sh "$T/out/post-fs-data.sh" >/dev/null 2>&1
[ ! -f "$PERSIST/enable_lkm" ] && ok "T8 enable_lkm removed" || bad "T8 enable_lkm still present"
[ ! -f "$PERSIST/enable_force_init" ] && ok "T8b enable_force_init removed" || bad "T8b still present"
[ -f "$PERSIST/no_init_this_boot" ] && ok "T8c no_init_this_boot sentinel written" || bad "T8c sentinel missing"
has "$BOOTLOG" "WEDGE DOSSIER" "T8d dossier in boot.log"
has "$BOOTLOG" "STEP 2/7 DISPATCHING" "T8e dossier carries the receipt line"
has "$BOOTLOG" "resolver: KLN mode ACTIVE" "T8f dossier carries diag_last content"

echo "== T9: stale try at stage 2 -> demote to 0 + cap stage_max =="
reset_boot
echo "try 2 deadbeefdeadbeefdeadbeefdeadbeef" > "$PERSIST/stage_boot"
echo 2 > "$PERSIST/arm_stage"
sh "$T/out/post-fs-data.sh" >/dev/null 2>&1
arm="$(cat "$PERSIST/arm_stage" 2>/dev/null)"
max="$(cat "$PERSIST/stage_max" 2>/dev/null)"
[ "$arm" = "0" ] && ok "T9 demoted to 0" || bad "T9 arm=$arm"
[ "$max" = "1" ] && ok "T9b stage_max capped at 1" || bad "T9b max=$max"

echo "== T10: suppression branch consumes no_init_this_boot =="
reset_boot
echo 1 > "$PERSIST/no_init_this_boot"
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
run_bc
has "$BOOTLOG" "init suppressed this boot" "T10 suppression logged"
[ ! -f "$PERSIST/no_init_this_boot" ] && ok "T10b sentinel consumed" || bad "T10b sentinel left behind"

echo "== T11: payload stamp refresh in the install gate =="
reset_boot
# v39-era state: old ko in place, no stamp
echo "V39KO-OLD" > "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko"
. "$MODDIR/utils.sh" >/dev/null 2>&1
install_susfs_guard_lkm_x86_64 > "$T/out/inst.log" 2>&1
inst="$(cat "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" 2>/dev/null)"
[ "$inst" = "V40KO-ANDROID13" ] && ok "T11 v40 ko refreshed over v39" || bad "T11 ko='$inst'"
[ "$(cat "$T/adb/ReSuSFS_LKM/.payload_stamp" 2>/dev/null)" = "v26.11.40" ] && ok "T11b stamp written" || bad "T11b stamp missing"
# same-stamp reflash keeps files (user-supplied wins preserved)
echo "USERKO" > "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko"
install_susfs_guard_lkm_x86_64 > "$T/out/inst2.log" 2>&1
inst="$(cat "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" 2>/dev/null)"
[ "$inst" = "USERKO" ] && ok "T11c same-stamp keeps user file" || bad "T11c ko='$inst'"

echo "== T12: self-heal fires on stamp mismatch =="
reset_boot
echo "V39KO-OLD" > "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko"
rm -f "$T/adb/ReSuSFS_LKM/.payload_stamp"
touch "$PERSIST/enable_lkm"
# the module must not look "already live" to check_susfs_support: drop the
# fake sysfs tree (the ksud shim recreates it during the fake load)
rm -rf "$MODP"
rm -rf "$MODP"   # not live yet for this run
V40_SYS="$T/sys"; export V40_SYS
sh -c ". $MODDIR/utils.sh; V40_SYS='$T/sys'; load_susfs_lkm" > "$T/out/heal.log" 2>&1
# the self-heal's install output is redirected to /dev/null by design, so
# assert on the OUTCOME: the stamp landed and the v40 ko replaced v39's
[ "$(head -n 1 "$T/adb/ReSuSFS_LKM/.payload_stamp" 2>/dev/null)" = "v26.11.40" ] && ok "T12 stamp written by self-heal" || bad "T12 stamp missing"
inst="$(cat "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" 2>/dev/null)"
[ "$inst" = "V40KO-ANDROID13" ] && ok "T12b v40 ko in place after heal" || bad "T12b ko='$inst'"
has "$T/out/heal.log" "LKM loaded successfully" "T12c fake ksud load succeeded"

echo
if [ "$FAIL" = "0" ]; then
        echo "v26.11.40 regression suite: ALL PASS"
else
        echo "v26.11.40 regression suite: $FAIL FAILURE(S)"
fi
exit $FAIL
