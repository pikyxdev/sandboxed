#!/bin/sh
# Tier-2 (path-rewritten) test suite for the ReSuSFS x86_64 v26.11.23
# safeguard logic. Runs inside the fake tree $FAKE with command stubs.
# FAKE is passed via the environment; all module .sh files in
# $FAKE/data/adb/... have been rewritten so that /data/* -> $FAKE/data/*
# and command stubs shadow the Android binaries.
#
# PASS/FAIL summary at the end; exit code 0 only if everything passed.

FAKE="${FAKE:?FAKE root not set}"
ADB="$FAKE/data/adb"
MODDIR="$ADB/modules/ReSuSFS"
STAGE="$ADB/modules_update/ReSuSFS"
PERSISTENT="$ADB/ReSuSFS"
LOGS="$PERSISTENT/logs"
export PATH="$ADB/ksu/bin:$PATH"

PASS=0
FAIL=0

report() { # name result(0/1) detail
        if [ "$2" = "0" ]; then
                PASS=$((PASS + 1))
                echo "PASS: $1"
        else
                FAIL=$((FAIL + 1))
                echo "FAIL: $1 ${3:-}"
        fi
}

assert_contains() { # name file needle
        if grep -q "$3" "$2" 2>/dev/null; then
                report "$1 (contains '$3')" 0
        else
                report "$1 (contains '$3')" 1 "file: $2"
        fi
}

assert_not_contains() { # name file needle
        if grep -q "$3" "$2" 2>/dev/null; then
                report "$1 (must NOT contain '$3')" 1 "file: $2"
        else
                report "$1 (must NOT contain '$3')" 0
        fi
}

assert_exists() { # name path
        [ -e "$2" ] && report "$1 (exists: $2)" 0 || report "$1 (exists: $2)" 1
}

assert_absent() { # name path
        [ -e "$2" ] && report "$1 (absent: $2)" 1 || report "$1 (absent: $2)" 0
}

echo "=============================================================="
echo " T0: install simulation (customize.sh over a v22 leftover)"
echo "=============================================================="

# --- simulate the v26.11.22 leftovers (aggressive active config) ---
mkdir -p "$PERSISTENT/scripts"
printf 'ReSuSFS_apply-mount-hiding.sh\nReSuSFS_apply-props.sh\nReSuSFS_apply-ksu-settings.sh\nReSuSFS_apply-settings.sh\nReSuSFS_apply-sus-maps.sh\nReSuSFS_apply-sus-paths-loop.sh\nReSuSFS_apply-sus-paths.sh\nReSuSFS_cleanup-markers.sh\n' > "$PERSISTENT/scripts_bootcompleted.txt"
printf 'ReSuSFS_apply-cmdline-bootconfig.sh\nReSuSFS_apply-kstat-add.sh\nReSuSFS_apply-ksu-settings.sh\nReSuSFS_apply-uname.sh\n' > "$PERSISTENT/scripts_postfs.txt"
printf 'HIDE_SUS_MNTS_NON_SU=1\nENABLE_LOG=0\nENABLE_AVC_LOG_SPOOFING=1\n' > "$PERSISTENT/config.txt"
cp "$STAGE/configs/scripts/"*.sh "$PERSISTENT/scripts/" 2>/dev/null

# --- run the installer the way KernelSU does (source + ui_print) ---
# NOTE: the output file MUST live outside $PERSISTENT - customize.sh moves
# the whole persistent dir to a timestamped backup during the reset.
INSTALL_OUT="$FAKE/install_out.txt"
(
        ui_print() { echo "[UI] $*"; }
        export MODPATH="$STAGE"
        . "$STAGE/customize.sh"
) > "$INSTALL_OUT" 2>&1
rc=$?
report "T0 customize.sh exits 0" $([ $rc -eq 0 ] && echo 0 || echo 1) "rc=$rc"

ls -d "$PERSISTENT".bak.* >/dev/null 2>&1
report "T0 v22 config was backed up" $([ -d "$(ls -d "$PERSISTENT".bak.* 2>/dev/null | head -1)" ] && echo 0 || echo 1)
assert_exists "T0 safe-default marker" "$PERSISTENT/.safe_diag_v1"

ACTIVE_LINES=$(sed 's/#.*//' "$PERSISTENT/scripts_bootcompleted.txt" | grep -c '[^[:space:]]' || true)
report "T0 bootcompleted scripts all disabled" $([ "${ACTIVE_LINES:-0}" = "0" ] && echo 0 || echo 1) "active lines: $ACTIVE_LINES"
ACTIVE_LINES2=$(sed 's/#.*//' "$PERSISTENT/scripts_postfs.txt" | grep -c '[^[:space:]]' || true)
report "T0 postfs scripts all disabled" $([ "${ACTIVE_LINES2:-0}" = "0" ] && echo 0 || echo 1) "active lines: $ACTIVE_LINES2"

assert_exists "T0 ksu_susfs CLI installed" "$ADB/ksu/bin/ksu_susfs"
assert_exists "T0 LKM payload copied (inert)" "$ADB/ReSuSFS_LKM/susfs_guard_lkm-x86_64-5.15.ko"
assert_contains "T0 install reports userspace-only" "$INSTALL_OUT" "no kernel susfs detected"

mkdir -p "$LOGS"

# move the module to its runtime location (KernelSU post-install step)
rm -rf "$MODDIR"
cp -a "$STAGE" "$MODDIR"

# wrap the installed CLI so every call is counted, behavior unchanged
mv "$ADB/ksu/bin/ksu_susfs" "$ADB/ksu/bin/ksu_susfs.real"
cat > "$ADB/ksu/bin/ksu_susfs" <<'WRAP'
#!/bin/sh
mkdir -p /data/adb/ReSuSFS/logs 2>/dev/null || mkdir -p "${FAKE}/data/adb/ReSuSFS/logs" 2>/dev/null
echo "ksu_susfs $*" >> "${FAKE}/data/adb/ReSuSFS/logs/ksu_calls.log" 2>/dev/null
exec "${FAKE}/data/adb/ksu/bin/ksu_susfs.real" "$@"
WRAP
sed -i "s|\${FAKE}|$FAKE|g" "$ADB/ksu/bin/ksu_susfs"
chmod 755 "$ADB/ksu/bin/ksu_susfs"
: > "$LOGS/ksu_calls.log"
: > "$LOGS/ksud_calls.log"
rm -f "$LOGS/ksud_calls.log"

echo
echo "=============================================================="
echo " T1: safeguard refuses the LKM on a custom kernel by default"
echo "=============================================================="

T1_OUT="$LOGS/t1_out.txt"
(
        . "$MODDIR/utils.sh"
        load_susfs_lkm
) > "$T1_OUT" 2>&1
rc=$?
report "T1 load_susfs_lkm returns nonzero (refused)" $([ $rc -ne 0 ] && echo 0 || echo 1) "rc=$rc"
assert_contains "T1 SAFEGUARD message" "$T1_OUT" "SAFEGUARD"
assert_contains "T1 names the opt-in flag" "$T1_OUT" "enable_lkm"
[ -f "$LOGS/ksud_calls.log" ]
report "T1 no insmod attempted" $([ $? -ne 0 ] && echo 0 || echo 1)

echo
echo "=============================================================="
echo " T2: opt-in flag allows the LKM load path"
echo "=============================================================="

touch "$PERSISTENT/enable_lkm"
T2_OUT="$LOGS/t2_out.txt"
(
        . "$MODDIR/utils.sh"
        load_susfs_lkm
) > "$T2_OUT" 2>&1
rc=$?
rm -f "$PERSISTENT/enable_lkm"
report "T2 load_susfs_lkm returns 0 (loaded via stub ksud)" $([ $rc -eq 0 ] && echo 0 || echo 1) "rc=$rc"
assert_contains "T2 opt-in acknowledged" "$T2_OUT" "user opt-in"
assert_exists "T2 ksud insmod was attempted" "$LOGS/ksud_calls.log"
assert_contains "T2 ksud insmod call" "$LOGS/ksud_calls.log" "insmod"
rm -f "$LOGS/ksud_calls.log"

echo
echo "=============================================================="
echo " T3: built-in susfs detection via functional probe"
echo "=============================================================="

# swap the CLI for an 'alive' stub: kernel answers the supercall
mv "$ADB/ksu/bin/ksu_susfs" "$ADB/ksu/bin/ksu_susfs.wrapper"
cat > "$ADB/ksu/bin/ksu_susfs" <<'ALIVE'
#!/bin/sh
if [ "$1" = "show" ] && [ "$2" = "version" ]; then echo "v2.5.2"; exit 0; fi
if [ "$1" = "show" ] && [ "$2" = "variant" ]; then echo "GKI"; exit 0; fi
if [ "$1" = "show" ]; then echo "add_sus_path:Y add_sus_map:Y"; exit 0; fi
exit 0
ALIVE
chmod 755 "$ADB/ksu/bin/ksu_susfs"

T3_OUT="$LOGS/t3_out.txt"
(
        . "$MODDIR/utils.sh"
        check_susfs_support
        echo "check_susfs_support rc=$?"
        susfs_kernel_alive
        echo "susfs_kernel_alive rc=$?"
        load_susfs_lkm
        echo "load_susfs_lkm rc=$?"
) > "$T3_OUT" 2>&1
assert_contains "T3 check_susfs_support detects built-in" "$T3_OUT" "check_susfs_support rc=0"
assert_contains "T3 susfs_kernel_alive detects built-in" "$T3_OUT" "susfs_kernel_alive rc=0"
assert_contains "T3 load_susfs_lkm skips (built-in)" "$T3_OUT" "Built-in SuSFS support detected"
assert_contains "T3 load_susfs_lkm rc=0" "$T3_OUT" "load_susfs_lkm rc=0"
[ -f "$LOGS/ksud_calls.log" ]
report "T3 no LKM load attempt on built-in" $([ $? -ne 0 ] && echo 0 || echo 1)

# restore the real CLI wrapper (stock-kernel behavior)
mv "$ADB/ksu/bin/ksu_susfs" "$ADB/ksu/bin/ksu_susfs.alive_stub"
mv "$ADB/ksu/bin/ksu_susfs.wrapper" "$ADB/ksu/bin/ksu_susfs"

echo
echo "=============================================================="
echo " T4: stage-early skips susfs application (userspace-only)"
echo "=============================================================="

: > "$LOGS/ksu_calls.log"
T4_OUT="$LOGS/t4_out.txt"
sh "$MODDIR/ReSuSFS.sh" --stage-early > "$T4_OUT" 2>&1
assert_contains "T4 stage-early reports userspace-only" "$T4_OUT" "userspace-only mode"
BAD_CALLS=$(grep -cv "show version" "$LOGS/ksu_calls.log" || true)
report "T4 no susfs rule calls issued" $([ "${BAD_CALLS:-0}" = "0" ] && echo 0 || echo 1) "non-probe calls: $BAD_CALLS"

echo
echo "=============================================================="
echo " T5: status-report -> userspace-only status line"
echo "=============================================================="

sh "$MODDIR/ReSuSFS.sh" --status-report > "$LOGS/t5_out.txt" 2>&1
assert_contains "T5 module.prop gets userspace-only status" "$MODDIR/module.prop" "status: userspace-only"

echo
echo "=============================================================="
echo " T6: post-fs-data.sh end-to-end (no hang, safeguard, logs)"
echo "=============================================================="

rm -rf "$PERSISTENT/logs/receipts"
timeout 60 sh "$MODDIR/post-fs-data.sh" > "$LOGS/t6_out.txt" 2>&1
rc=$?
report "T6 post-fs-data.sh completes within 60s" $([ $rc -eq 0 ] && echo 0 || echo 1) "rc=$rc"
assert_contains "T6 boot.log has START marker" "$LOGS/boot.log" "post-fs-data START"
assert_contains "T6 boot.log records the safeguard" "$LOGS/boot.log" "SAFEGUARD: custom-kernel LKM"
assert_contains "T6 boot.log records userspace-only mode" "$LOGS/boot.log" "userspace-only mode"
assert_contains "T6 boot.log has DONE marker" "$LOGS/boot.log" "post-fs-data DONE"
assert_absent  "T6 lkm-load receipt cleaned up" "$PERSISTENT/logs/receipts/lkm-load.open"

echo
echo "=============================================================="
echo " T7: boot-completed.sh end-to-end"
echo "=============================================================="

timeout 60 sh "$MODDIR/boot-completed.sh" > "$LOGS/t7_out.txt" 2>&1
rc=$?
report "T7 boot-completed.sh completes within 60s" $([ $rc -eq 0 ] && echo 0 || echo 1) "rc=$rc"
assert_contains "T7 boot.log has boot-completed DONE" "$LOGS/boot.log" "boot-completed DONE"

echo
echo "=============================================================="
echo " T8: hang watchdog skips a stage that never finished"
echo "=============================================================="

mkdir -p "$PERSISTENT/logs/receipts"
echo "$(date '+%Y-%m-%d %H:%M:%S') boot=deadbeefcafe0000" > "$PERSISTENT/logs/receipts/lkm-load.open"
timeout 60 sh "$MODDIR/post-fs-data.sh" > "$LOGS/t8_out.txt" 2>&1
rc=$?
report "T8 post-fs-data.sh still completes" $([ $rc -eq 0 ] && echo 0 || echo 1) "rc=$rc"
assert_contains "T8 watchdog announces the skip" "$LOGS/boot.log" "WATCHDOG: 'lkm-load' never finished"
assert_absent  "T8 stale receipt removed" "$PERSISTENT/logs/receipts/lkm-load.open"

# opt-in at post-fs-data level: flag present -> load path actually runs
touch "$PERSISTENT/enable_lkm"
timeout 60 sh "$MODDIR/post-fs-data.sh" > "$LOGS/t8b_out.txt" 2>&1
rc=$?
rm -f "$PERSISTENT/enable_lkm"
report "T8b flagged post-fs-data completes" $([ $rc -eq 0 ] && echo 0 || echo 1) "rc=$rc"
assert_contains "T8b boot.log records opt-in load" "$LOGS/boot.log" "loading custom-kernel LKM"
assert_contains "T8b ksud insmod attempted" "$LOGS/ksud_calls.log" "insmod"

echo
echo "=============================================================="
echo " T9: diagnose.sh completes and self-identifies its state"
echo "=============================================================="

timeout 150 sh "$MODDIR/diagnose.sh" > "$LOGS/t9_out.txt" 2>&1
rc=$?
report "T9 diagnose.sh completes within 150s" $([ $rc -eq 0 ] && echo 0 || echo 1) "rc=$rc"
assert_contains "T9 diagnose.log notes userspace-only" "$LOGS/diagnose.log" "kernel susfs: NOT ALIVE"
assert_contains "T9 diagnose.log completes" "$LOGS/diagnose.log" "DIAGNOSE COMPLETE"

echo
echo "=============================================================="
echo " RESULT: $PASS passed, $FAIL failed"
echo "=============================================================="
[ "$FAIL" -eq 0 ]
