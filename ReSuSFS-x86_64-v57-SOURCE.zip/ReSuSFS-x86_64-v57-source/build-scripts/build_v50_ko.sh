#!/bin/bash
# build_v50_ko.sh - v26.11.50 CLANG ENTRY build (graft onto the v49 .ko).
#
# THE IDEA (see sc_v50.c header for the full rationale): the v49 module
# object is field-proven everywhere except the ONE thing that killed the
# box - the table[173] entry thunk.  v50 replaces exactly that (plus its
# installer) with a clang-17-compiled graft object:
#
#   1. compile sc_v50.c with clang-17 (kernel codegen flags + kCFI):
#        susfs_sc_entry        - REAL clang function, genuine kCFI preamble
#                                (movl $hash,%eax at [entry-5..-1), endbr64)
#        susfs_supercall_init  - the v50 installer: liveness gates, 16-byte
#                                preamble-window CLONE from the original
#                                entry (byte-exact readback), then the
#                                table write via the proven ksu_patch_text
#        susfs_supercall_exit  - restore path
#   2. weaken the v49 definitions of those three symbols in the base .ko
#      (plus globalize the four .bss state vars the graft writes), so that
#   3. ld -r with the GRAFT FIRST drops the weak v49 defs and binds every
#      reference (the susfs_layers[] function pointers in susfs_main.c
#      included) to the clang graft.  Empirically verified: ld -r keeps the
#      FIRST definition and discards later duplicates (scripts/
#      kcfi_caller_probe.sh PART 2).
#
# Everything else - the wrapper body, ladder, witness, all 19 other layers,
# vermagic, this_module, the __versions/modver dummy, the .bss stomp pad -
# is the v49 object, unchanged by the merge (verified by
# scripts/build_v50_verify.py).
set -e
BASE=/home/z/my-project
PORT=$BASE/ReSuSFS-x86_64-port
CC=$BASE/toolchain/clang17/usr/lib/llvm-17/bin/clang
GRAFT_SRC=$PORT/sc_v50.c
GRAFT_OBJ=$PORT/sc_v50.o
MOD=$PORT/ReSuSFS/module
V=26.11.50

export LD_LIBRARY_PATH=$BASE/toolchain/clang17/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
[ -x "$CC" ] || { echo "[!] clang-17 missing at $CC"; exit 1; }

echo "[*] v50: compiling the clang-17 graft object"
"$CC" -target x86_64-linux-gnu -c "$GRAFT_SRC" -o "$GRAFT_OBJ" \
        -O2 -fsanitize=kcfi -fcf-protection=branch \
        -fno-stack-protector -fno-pic -mno-red-zone \
        -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 \
        -ffreestanding -nostdinc -fno-builtin -std=gnu11 -Wall
echo "[+] graft object: $GRAFT_OBJ ($(stat -c%s "$GRAFT_OBJ") bytes)"

echo "[*] graft object self-checks"
nm -u "$GRAFT_OBJ" | awk '{print $2}' | sort > /tmp/v50_graft_u.txt
cat /tmp/v50_graft_u.txt
# the graft may reference NOTHING outside the v49 base object: 6 base
# globals + 4 globalized .bss state vars, exact set, no libcalls.
cat > /tmp/v50_graft_expected.txt <<'EOF'
ksu_kallsyms_lookup_name
ksu_patch_text
sc_full_mode
sc_installed
sc_orig
susfs_current_arm_stage
susfs_diag_logf
susfs_fp_syscall_table
susfs_sc_entry_count
susfs_sc_wrapper
EOF
diff -u /tmp/v50_graft_expected.txt /tmp/v50_graft_u.txt
echo "[+] undefined set exact (10 symbols, all defined in the v49 base)"
nm "$GRAFT_OBJ" | grep -E ' T (susfs_sc_entry|susfs_supercall_init|susfs_supercall_exit)$'
objdump -d --disassemble=susfs_sc_entry "$GRAFT_OBJ" | head -22

graft_ko() {      # $1 = base .ko, $2 = output name
        local SRC_KO=$1 NAME=$2
        local WEAK=$(mktemp /tmp/v50_weak_XXXX.ko)
        echo "[*] v50: grafting $NAME <- $SRC_KO"
        objcopy \
                --weaken-symbol=susfs_supercall_init \
                --weaken-symbol=susfs_supercall_exit \
                --weaken-symbol=susfs_sc_entry \
                --globalize-symbol=sc_orig \
                --globalize-symbol=sc_installed \
                --globalize-symbol=sc_full_mode \
                --globalize-symbol=susfs_sc_entry_count \
                "$SRC_KO" "$WEAK"
        # graft FIRST: ld -r keeps the first definition of each symbol; the
        # weakened v49 defs of the three overridden symbols are dropped and
        # all references (susfs_layers[].init/.exit, the old dead init's
        # own code) bind to the clang graft.
        ld -r -o "$PORT/$NAME" "$GRAFT_OBJ" "$WEAK"
        rm -f "$WEAK"
        echo "[+] merged: $PORT/$NAME ($(stat -c%s "$PORT/$NAME") bytes)"
}

graft_ko "$PORT/susfs_guard_lkm-x86_64-android13-5.15.ko" \
         "susfs_guard_lkm-x86_64-android13-5.15-v50.ko"
graft_ko "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15.ko" \
         "susfs_guard_lkm-x86_64-vanilla-5.15-v50.ko"

echo "[*] v50: installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$PORT/susfs_guard_lkm-x86_64-android13-5.15-v50.ko" \
      "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15-v50.ko" \
      "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v$V" > "$MOD/lkm/x86_64/.payload_stamp"
ls -la "$MOD/lkm/x86_64" "$MOD/lkm/x86_64/candidates"

echo "[*] v50: CLI + insmod carried over from the field-proven v49 payload"
# The CLI source (tools/susfs_cli_x64.c) was lost with the November partial
# tree loss; the v50 CLI contract is byte-identical to v49 (syscall 173 +
# payload.err + the nop'd return-checks), so the shipped v49 binary IS the
# v50 binary.  Copy from work/pkg49 and verify the 173-site patch held.
for b in ksu_susfs susfs_insmod sc_probe; do
        if [ -f "$BASE/work/pkg49/bin/x86_64/$b" ]; then
                cp -f "$BASE/work/pkg49/bin/x86_64/$b" "$MOD/bin/x86_64/$b"
                chmod 755 "$MOD/bin/x86_64/$b"
        fi
done
ls -la "$MOD/bin/x86_64/"
python3 - "$MOD/bin/x86_64/ksu_susfs" <<'EOF'
import re, sys
cd = open(sys.argv[1], 'rb').read()
sites = 0
for m in re.finditer(b'\xb8\xad\x00\x00\x00', cd):
    s = m.start()
    sc = cd.find(b'\x0f\x05', s, s + 80)
    if sc < 0:
        continue
    if cd[sc+2:sc+5] == b'\x48\x85\xc0':
        sites += 1
assert sites == 9, f'CLI 173-riding sites: {sites} (want 9)'
old = sum(1 for m in re.finditer(b'\xb8\xa9\x00\x00\x00', cd)
          if cd.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert old == 0, f'old 169 sites remain: {old}'
print(f'[+] CLI verified: 9 syscall-173 sites, 0 old 169 sites')
EOF

echo "[+] v50 graft build complete (payload staged in $MOD)"
