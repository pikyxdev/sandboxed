#!/usr/bin/env python3
"""make_v56_source_export.py - complete v56 (v54.2) source export for download.

Builds download/ReSuSFS-x86_64-v56-SOURCE.zip: every source/build input of
v26.11.56 that is NOT re-downloadable from public sources.  Same shape as
the v54/v55 exports; adds the v54.2 test fix (sc_probe full-walk), the
receipt-persistence script edits, the v56 build/verify/package chain, the
v54.1+v54.2 test plans, the v55 field logs and the v56 flashable.
"""
import hashlib
import os
import shutil
import subprocess
import zipfile

BASE = '/home/z/my-project'
STAGE = '/tmp/v56src'
TOP = f'{STAGE}/ReSuSFS-x86_64-v56-source'
OUT_SRC = f'{BASE}/download/ReSuSFS-x86_64-v56-SOURCE.zip'


def sh(cmd, **kw):
    print(f'[cmd] {cmd}')
    return subprocess.run(cmd, shell=True, check=True, **kw)


def copy_rel(src, dst_rel):
    dst = os.path.join(TOP, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_stats(path):
    n, total = 0, 0
    for root, _d, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            if os.path.islink(fp):
                continue
            n += 1
            total += os.path.getsize(fp)
    return n, total


print('== staging ==', flush=True)
shutil.rmtree(STAGE, ignore_errors=True)
os.makedirs(TOP)

P = f'{BASE}/ReSuSFS-x86_64-port'
S = f'{BASE}/scripts'
W = f'{BASE}/work'

# 1. LKM sources + graft sources + probe + host/ladder/walk tests
copy_rel(f'{P}/susfs4ksu-lkm-x64-5.15', 'lkm-source/susfs4ksu-lkm-x64-5.15')
for f in ('sc_v50.c', 'sc_v51.c', 'sc_v53.c', 'sc_v54.c', 'sc_v55.c',
          'sc_v50.o', 'sc_v51.o', 'sc_v53.o', 'sc_v54.o', 'sc_v55.o'):
    copy_rel(f'{P}/{f}', f'lkm-source/{f}')
for f in ('sc_probe.c', 'sc_probe',
          'test_sc_v51_host.c', 'test_sc_v51_host',
          'test_sc_v53_host.c', 'test_sc_v54_host.c', 'test_sc_v55_host.c',
          'test_v55_ladder.sh', 'test_v56_ladder.sh',
          'test_sc_probe_walk_host.sh'):
    copy_rel(f'{S}/{f}', f'lkm-source/{f}')

# 2. userspace sources
copy_rel(f'{S}/libredir.c', 'userspace-src/libredir.c')
copy_rel(f'{S}/port_insmod_x64.py', 'userspace-src/port_insmod_x64.py')
copy_rel(f'{BASE}/testbuild', 'userspace-src/testbuild')
open(f'{TOP}/userspace-src/README.txt', 'w').write(
    'ksu_susfs.c is NOT shipped: the only copy in the sandbox is a broken\n'
    'GitLab 404 HTML page from session 1. The wire-ABI authority is the\n'
    'stock CLI BINARY at package-v56/bin/x86_64/ksu_susfs (sha256\n'
    '7a30fa745a523a4e2897023086a2ef08d773899394781d131f68676227e80e9f,\n'
    'not stripped - disassemble sc_main for the dispatch sites). The full\n'
    'wire table is recorded in memory/FINDINGS.md and in sc_v53.c.\n')

# 3. module staging tree
copy_rel(f'{P}/ReSuSFS', 'module-template/ReSuSFS')

# 4. the EXACT v56 flashable staging tree
copy_rel(f'{W}/pkg56', 'package-v56')

# 5. build scripts (the whole lineage + the v56 chain)
for f in sorted(os.listdir(S)):
    fp = os.path.join(S, f)
    if os.path.isfile(fp):
        copy_rel(fp, f'build-scripts/{f}')
copy_rel(f'{P}/scripts', 'build-scripts/port-scripts')
copy_rel(f'{P}/bin', 'build-scripts/port-bin')

# 6. bit-exact build outputs (v49 base + grafts; the v56 .ko IS the v55 .ko)
os.makedirs(f'{TOP}/binaries', exist_ok=True)
for f in ('susfs_guard_lkm-x86_64-android13-5.15.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v51.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v53.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v54.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v55.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v51.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v53.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v54.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v55.ko'):
    copy_rel(f'{P}/{f}', f'binaries/{f}')

# 7. kernel tree fragments (tiny overrides; the tarballs are re-fetchable)
copy_rel(f'{BASE}/linux-5.15.178', 'kernel-fragments/linux-5.15.178')
copy_rel(f'{BASE}/a13', 'kernel-fragments/a13')
copy_rel(f'{BASE}/a13-full', 'kernel-fragments/a13-full')

# 8. upstream refs
copy_rel(f'{BASE}/ReSuSFS-x86_64', 'upstream-refs/ReSuSFS-x86_64')
copy_rel(f'{BASE}/susfs_lkm_x64.zip', 'upstream-refs/susfs_lkm_x64.zip')
copy_rel(f'{BASE}/susfs4ksu_LICENSE', 'upstream-refs/susfs4ksu_LICENSE')
for f in ('branches.json', 'kp.json', 'lkm_release.json', 'test.tab.c', 'tree.json'):
    fp = f'{BASE}/{f}'
    if os.path.isfile(fp):
        copy_rel(fp, f'upstream-refs/{f}')

# 9. docs
copy_rel(f'{P}/docs-DESIGN-v54.md', 'docs/DESIGN-v54.md')
copy_rel(f'{P}/README-x86_64-PORT.md', 'docs/README-x86_64-PORT.md')
copy_rel(f'{P}/ReSuSFS/PORTING_x86_64.md', 'docs/PORTING_x86_64.md')
copy_rel(f'{P}/ReSuSFS/CHANGELOG.md', 'docs/CHANGELOG.md')
copy_rel(f'{P}/ReSuSFS/update.json', 'docs/update.json')
os.makedirs(f'{TOP}/docs/test-plans', exist_ok=True)
for f in sorted(os.listdir(f'{P}/ReSuSFS/docs/test-plans')):
    copy_rel(f'{P}/ReSuSFS/docs/test-plans/{f}', f'docs/test-plans/{f}')
copy_rel(f'{BASE}/logs', 'docs/build-logs')

# 10. field evidence (v53, v53.1, v54, v55)
copy_rel(f'{BASE}/field-logs', 'field-logs')

# 11. the flashable
copy_rel(f'{BASE}/download/ReSuSFS-x86_64-v26.11.56.zip',
         'flashable/ReSuSFS-x86_64-v26.11.56.zip')

# ---------------------------------------------------------------- metadata
print('== metadata ==', flush=True)
ko_a13 = f'{W}/pkg56/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko'
ko_van = f'{W}/pkg56/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
sums = [
    ('flashable/ReSuSFS-x86_64-v26.11.56.zip', sha256(f'{BASE}/download/ReSuSFS-x86_64-v26.11.56.zip')),
    ('package-v56/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko (BYTE-IDENTICAL to the field-run v54.1/v26.11.55 image)',
     sha256(ko_a13)),
    ('package-v56/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko (ditto)',
     sha256(ko_van)),
    ('lkm-source/sc_v55.c (THE v54/v54.1/v54.2 graft source - v54.2 changes userspace only)',
     sha256(f'{P}/sc_v55.c')),
    ('lkm-source/sc_v55.o', sha256(f'{P}/sc_v55.o')),
    ('lkm-source/sc_probe.c (v54.2: full-directory walk gd64_test)',
     sha256(f'{S}/sc_probe.c')),
    ('package-v56/bin/x86_64/sc_probe (v54.2 probe)', sha256(f'{W}/pkg56/bin/x86_64/sc_probe')),
    ('package-v56/bin/x86_64/ksu_susfs (stock CLI, ABI authority)',
     sha256(f'{W}/pkg56/bin/x86_64/ksu_susfs')),
    ('package-v56/bin/x86_64/susfs_insmod', sha256(f'{W}/pkg56/bin/x86_64/susfs_insmod')),
]
open(f'{TOP}/SHA256SUMS.key', 'w').write(
    '\n'.join(f'{h}  {n}' for n, h in sums) + '\n')

rows = []
for d in ('lkm-source', 'userspace-src', 'module-template', 'package-v56',
          'build-scripts', 'binaries', 'kernel-fragments', 'upstream-refs',
          'docs', 'field-logs', 'flashable'):
    n, b = tree_stats(os.path.join(TOP, d))
    rows.append((d, n, b))

readme = f'''# MANIFEST - ReSuSFS x86_64 v26.11.56 source export

Exported: 2026-11-27 (Asia/Jakarta). Sandbox: /home/z/my-project
Flashable v56 SHA256: {sums[0][1]}

Contents: the full v53/v54 lineage plus v54.2 THE TEST FIX + RECEIPT
PERSISTENCE (userspace only - both .kos byte-identical to the field-run
v26.11.55): sc_probe gd64_test v2 walks the WHOLE directory (32K
getdents64 batches until rc==0) for every view with per-view entry counts
(the v54.1 single-batch read was the reproduced root cause of the field
disable); boot-completed.sh archives the arm+test receipts to
logs/gd64_receipt_<boot_id>.txt after each rung step (the v54.1 failure
was undiagnosable because the next boot's self-test overwrote
sc_selftest.txt); module.prop v26.11.56/versionCode 135 re-bases the
ladders on flash.  Field logs for v53, v53.1, v54 AND v54.1 (v55) are in
field-logs/.  See docs/DESIGN-v54.md and docs/test-plans/
ReSuSFS-v54.2-TESTPLAN.md.

| directory | files | bytes | contents |
|-----------|-------|-------|----------|
''' + '\n'.join(f'| {d}/ | {n} | {b} | see build-scripts headers |'
                 for d, n, b in rows) + '''

Rebuild/verify v56 from this archive (after restoring the layout per
build-scripts/restore_sandbox_v52.sh mapping; sc_v55.* goes to
ReSuSFS-x86_64-port/; work/pkg56 needs the v26.11.55 zip from download/
as the layout/change-set input):
    bash scripts/fetch_clang17.sh          # the 4 Debian debs (35 MB)
    # (NO .ko rebuild in v54.2 - the shipped .kos ARE the v55 images;
    #  build_v55_ko.sh reproduces them from the FROZEN v49 base if ever needed)
    gcc -O2 -static-pie -nostdlib -fno-stack-protector -Wl,-e,_start \\
        -o sc_probe scripts/sc_probe.c
    sh scripts/test_sc_probe_walk_host.sh  # the 30000-entry walk regression
    sh scripts/test_v56_ladder.sh          # the gd64 ladder + receipt archive offline
    python3 scripts/build_v56_zip.py       # layout-asserted vs the v55 zip

The v49 BASE .ko is bit-frozen (binaries/) and is never rebuilt; the
susfs4ksu-lkm-x64-5.15 tree in lkm-source/ is INCOMPLETE (14 kernel
sources - cleaned after v49; the base .ko is the only ground truth).
'''
open(f'{TOP}/MANIFEST.md', 'w').write(readme)

if os.path.exists(OUT_SRC):
    os.remove(OUT_SRC)
with zipfile.ZipFile(OUT_SRC, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(STAGE):
        for f in sorted(files):
            fp = os.path.join(root, f)
            z.write(fp, os.path.relpath(fp, STAGE))

n_files, total = tree_stats(TOP)
print(f'export: {OUT_SRC}')
print(f'  files: {n_files}, bytes: {total}')
print('  sha256:', sha256(OUT_SRC))
with zipfile.ZipFile(OUT_SRC) as z:
    names = z.namelist()
print('  entries:', len(names))
print('V56 SOURCE EXPORT OK')
