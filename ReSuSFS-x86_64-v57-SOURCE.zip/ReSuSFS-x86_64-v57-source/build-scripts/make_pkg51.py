#!/usr/bin/env python3
"""make_pkg51.py - build work/pkg51 from work/pkg50 with the v51 content.

Changed vs pkg50 (the zip builder asserts exactly this set):
  module.prop                        - v26.11.51 / versionCode 129 + v51 story
  customize.sh                       - v51 install banner (prepended)
  boot-completed.sh                  - v51 self-test/transport wording (3 strings)
  README-DIAGNOSTIC.md               - v51 section prepended
  utils.sh                           - v51 loader order fix: the default
                                       candidate chain is now VANILLA first
                                       (the only image that loads clean on
                                       this box; the android13 image
                                       ENOEXECs on every attempt - one
                                       wasted insmod + scary kernel
                                       warnings per boot, 40 boots running)
  lkm/x86_64/.payload_stamp          - v26.11.51
  lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko          - clang graft
  lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko - clang graft

Everything else - post-fs-data.sh (whose version-change re-base fires
automatically for the 50->51 upgrade: arm_stage=0, stage_max=3), the CLI
binaries, the ymuuu reference payload - is byte-identical to the v50 zip.
"""
import os, re, shutil, sys

BASE = '/home/z/my-project'
SRC = f'{BASE}/work/pkg50'
DST = f'{BASE}/work/pkg51'
PAYLOAD = f'{BASE}/ReSuSFS-x86_64-port/ReSuSFS/module'

MODULE_PROP = '''id=ReSuSFS
name=ReSuSFS x86_64
version=v26.11.51-x86_64
versionCode=129
author=ReSuSFS port campaign
description=SuSFS for KernelSU (x86_64 port) | v26.11.51: THE CLANG ACCEPT PATH. THE v50 FIELD VERDICT (2026-11-25, 10-boot ladder): the clang ENTRY is PROVEN under live fire - the stage-2 boot ran the patched sys_call_table[173] entry for a whole boot (counter increments, -EINVAL answers, clean handoff to the next boot). The stage-3 boot (FULL mode) died at the first ksu_susfs show version of the self-test - i.e. at the FIRST EXECUTION of the v49 GCC-compiled wrapper susfs_sc_wrapper, the one component that had never run live (v47's transport sat in dead code; v48/v49 died at their first dispatched syscall(173) too - 3 transport generations, 7 wedge boots, ONE common factor: the wrapper). Binary analysis of the shipped image then isolated the wrapper's never-field-proven memory read: current->cred at a HARDCODED HEADER OFFSET (0x788, vanilla 5.15.178 task_struct layout) - the target is LDPlayer's custom clang-17 +LTO +PGO +BOLT 5.15.178+ whose struct layouts match no published tree, the module's 20+ other 0x788 readers all sit in code that never ran at runtime, and this module carries NO __ex_table, so a wrong-slot pointer deref is an unhandled kernel fault on a panic-on-oops kernel. THE v51 FIX: the ENTIRE accept path moves into the clang graft - the v49 GCC wrapper is NEVER CALLED. Stage 3 now: magic check + uid gate through a RUNTIME-CALIBRATED cred offset (scan init_task - a kallsyms symbol - for the one adjacent (real_cred, cred) pair both equal to &init_cred, then verify struct cred's uid offset against init_cred's own root-zero fields; every step leaves a diag receipt and ANY failure just refuses to answer, box alive) + self-contained SHOW_VERSION / SHOW_VARIANT / SHOW_ENABLED_FEATURES answers via the kernel's own _copy_from_user/_copy_to_user (both in this kernel's kallsyms; SMAP is off on this box anyway). Feature commands answer not-handled this rung (the CLI keeps its 126 sentinel; the apply scripts skip gracefully) - forwarding them to the v49 handlers is the NEXT rung after this one survives. LAYOUT HARDENING caught by the build verifier: the graft contributes ZERO .bss (its state vars ride in .data) so the merged .bss stays byte-identical to the field-proven image - the android struct-module spill window (.bss[0..0x40), the v44 evidence) keeps landing on the sacrificial stomp pad, NOT on v51's calibration vars. Also: the default LKM candidate chain is now VANILLA first (the android13 image ENOEXECs on this box every single attempt - one wasted insmod and a scary kernel relocation warning per boot, now gone). LADDER: 50->51 re-bases automatically (arm_stage=0, stage_max=3 - expect 4 reboots: 0, 1, 2=OBSERVE, 3=FULL where ksu_susfs show version ANSWERS for the first time on this box), rungs confirm only after the self-test survives, one wedge boot maximum (stale try-marker demotion), stages 4/5 stay retired. KNOWN LIMITS, stated honestly: sus_path file-hiding and the LSM class stay retired; only the three SHOW commands answer this rung; the susfs list application (add_sus_path/sus_map/etc.) lights up rung by rung from v52. After any wedge send back: logs/init_trace.txt + logs/diag_last.txt + logs/boot.log + logs/kernel_facts.txt + logs/sc_selftest.txt | opt-in only, at your own risk | built-in kernel susfs auto-detected | all boot stages logged with a hang watchdog | step-by-step diagnostics via the Action button
'''

CUSTOMIZE_BANNER = '''        ui_print "[*] v26.11.50 -> v26.11.51: THE CLANG ACCEPT PATH."
        ui_print "[*] Your 10-reboot v50 run proved the ENTRY (stage 2"
        ui_print "[*] survived a full boot) and convicted the v49 GCC"
        ui_print "[*] wrapper at its first execution (stage 3 died at"
        ui_print "[*] the self-test - same as v48/v49: 3 generations,"
        ui_print "[*] 7 wedges, one common factor). The binary analysis"
        ui_print "[*] isolated the wrapper's never-proven read: current->"
        ui_print "[*]cred at a HARDCODED vanilla-header offset (0x788) on"
        ui_print "[*] LDPlayer's custom clang-LTO kernel, in a module with"
        ui_print "[*] NO exception table. v51 moves the WHOLE accept path"
        ui_print "[*] into the clang graft: magic check + a RUNTIME-"
        ui_print "[*] CALIBRATED cred offset (init_task/init_cred pair"
        ui_print "[*] scan, receipted, refuses instead of guessing) +"
        ui_print "[*] self-contained SHOW answers through the kernel's own"
        ui_print "[*] copy_from_user/copy_to_user. The GCC wrapper is never"
        ui_print "[*] called. The graft adds zero .bss (your .bss spill"
        ui_print "[*] guard stays first - the verifier enforces it), and"
        ui_print "[*] the loader now tries the vanilla image first (the"
        ui_print "[*] android13 image ENOEXECs on this box every boot -"
        ui_print "[*] that noise is gone). 50->51 re-bases the ladder: 4"
        ui_print "[*] reboots (0, 1, 2=OBSERVE, 3=FULL - show version"
        ui_print "[*] ANSWERS). One wedge boot maximum by design."
'''

README_SECTION = '''# v26.11.51 - THE CLANG ACCEPT PATH (2026-11-25)

## The v50 field verdict (your 10-reboot run)

The ladder did exactly what it was built to do:

- **Stage 2 (boot 440a678a) PROVED the clang entry under live fire**: the
  patched `sys_call_table[173]` entry ran for a whole boot (counter
  increments, `-EINVAL` answers, full 40s heartbeat window, clean handoff).
- **Stage 3 (boot 777e7068) died at the first `ksu_susfs show version` of
  the self-test** - i.e. at the FIRST EXECUTION of the v49 GCC-compiled
  `susfs_sc_wrapper`. The stand-down worked as designed: the next boot
  read the stale `try 3` marker, demoted to stage 0, capped stage_max at 2,
  and the box came back clean.
- v47's transport never went live (dead code), v48/v49 died at their first
  dispatched syscall(173) - which was ALSO the wrapper's first execution.
  **3 transport generations, 7 wedge boots, one common factor: the
  wrapper.**

## What the binary analysis found

The wrapper's common path contains exactly one never-field-proven memory
access: `current->cred` at a **hardcoded header offset (0x788)** compiled
from vanilla 5.15.178 `task_struct` layout. The target kernel is
LDPlayer 14's `5.15.178+` (Android clang-17, +LTO +PGO +BOLT, custom
config) - its struct layouts match no published tree. The module's 20+
other `0x788` readers all sit in code that never ran at runtime (the
passive gate layers, the retired stage-4/5 layers, the feature handlers),
and the module carries **no `__ex_table`**, so a wrong-slot read
dereferenced as a pointer is an unhandled kernel fault on a
panic-on-oops kernel. That is a precise, sufficient wedge mechanism, and
it is gone in v51 - whether or not it was THE one, because:

## The v51 fix

**The v49 GCC wrapper is never called.** The whole accept path is clang-17
(the compiler family that built the target kernel), grafted onto the
field-proven v49 object exactly like v50:

1. **Entry**: the v50 shape byte-for-byte (endbr64, genuine kCFI
   preamble, 16-byte clone of the original entry's window, locked
   counter, observe = `-EINVAL`).
2. **Magic check** on the same pt_regs offsets the ABI defines.
3. **uid gate through a RUNTIME-CALIBRATED cred offset** - no
   header-derived struct offsets on the syscall path:
   - scan `init_task` (kallsyms: 0xffffffff822127c0) for the one
     adjacent `(real_cred, cred)` pair both equal to `&init_cred`
     (0xffffffff82238f30) - true for the idle task for the whole boot;
   - verify `struct cred`'s uid offset against init_cred's own bytes
     (usage small-positive at +0, uid/gid/suid/sgid/euid/egid/fsuid/fsgid
     at +8..+0x28 all zero, because init_cred IS root:root);
   - every step leaves a diag receipt; ANY failure (symbol missing, not
     exactly one pair, sanity failed) just refuses to answer - the box
     stays alive and the receipts say why. The success receipt also
     prints whether the calibrated offset differs from the old hardcoded
     0x788 - direct evidence for the wedge attribution.
4. **SHOW_VERSION / SHOW_VARIANT / SHOW_ENABLED_FEATURES answered
   in-graft** through the kernel's own out-of-line
   `_copy_from_user`/`_copy_to_user` (both in this kernel's kallsyms;
   SMAP/SMEP are off on this box per /proc/cmdline). The 8196-byte
   features answer is copied in 256-byte chunks - no big stack frames on
   the syscall path.
5. **Feature commands answer not-handled this rung** (`-EINVAL`; the CLI
   keeps its pre-seeded 126 sentinel and exits nonzero; the apply scripts
   skip gracefully). Forwarding them to the v49 handlers is the NEXT
   rung, one class at a time, after this one survives.

Layout hardening the build verifier caught (and now enforces): the graft
contributes **zero `.bss`** - its two state vars ride in `.data` - so the
merged `.bss` stays byte-identical to the field-proven image and the
android struct-module spill window (`.bss[0..0x40)`, the v44 evidence)
keeps landing on the sacrificial stomp pad instead of on v51's
calibration vars.

Also: the default LKM candidate chain now tries the **vanilla image
first** - the android13 image ENOEXECs on this box on every single
attempt (one wasted insmod + a scary "Skipping invalid relocation" kernel
warning per boot). That noise is gone.

## Field procedure

Flash over v50. The 50->51 upgrade re-bases the ladder automatically
(arm_stage=0, stage_max=3). Keep `enable_lkm` + `enable_force_init`
present. **Expect 4 reboots**: stage 0 (evidence) -> 1 (layers) ->
2 (OBSERVE - the proven rung) -> 3 (FULL - `ksu_susfs show version`
ANSWERS for the first time on this box; the self-test receipt shows the
version string `v2.3.0`, variant `GKI-LKM`, and the armed feature list).
One wedge boot maximum by design; after ANY wedge send back the five logs
(logs/init_trace.txt + logs/diag_last.txt + logs/boot.log +
logs/kernel_facts.txt + logs/sc_selftest.txt).

The stage-3 boot's diag receipts to look for: `v51 calibrate:
task_struct.cred at +0x...` (the calibrated offset, and whether it
matches or differs from 0x788), and `v51 transport LIVE ... uid gate
CALIBRATED`.

'''

UTILS_EDITS = [
    # 1. the default try_list: vanilla first
    (
        '''
        # Now a failed candidate falls through to the next one in the SAME
        # boot: android13 (default) -> vanilla (the v26.11.26-37 image,
        # proven image-load on this kernel family) -> ymuuu13 -> legacy
        # ${kmi}. Every attempt is bounded (20s); the whole stage stays well
        # inside the post-fs-data lkm-load gate (150s). arm64 keeps the
        # original single-file flow.
        if [ "$ARCH" = "x86_64" ] && [ "$custom_lkm" = "1" ]; then
                try_list="susfs_guard_lkm-x86_64-android13-5.15.ko susfs_guard_lkm-x86_64-vanilla-5.15.ko ymuuu_android13-5.15_susfs_guard_lkm.ko"''',
        '''
        # Now a failed candidate falls through to the next one in the SAME
        # boot: vanilla (v26.11.51 DEFAULT - the only candidate that loads
        # CLEAN in the field; the android13 image ENOEXECs on this box on
        # every attempt: one wasted insmod + a scary "Skipping invalid
        # relocation" kernel warning per boot) -> android13 (the
        # v26.11.26-37 profile) -> ymuuu13 -> legacy
        # ${kmi}. Every attempt is bounded (20s); the whole stage stays well
        # inside the post-fs-data lkm-load gate (150s). arm64 keeps the
        # original single-file flow.
        if [ "$ARCH" = "x86_64" ] && [ "$custom_lkm" = "1" ]; then
                try_list="susfs_guard_lkm-x86_64-vanilla-5.15.ko susfs_guard_lkm-x86_64-android13-5.15.ko ymuuu_android13-5.15_susfs_guard_lkm.ko"''',
    ),
    # 2. the preference case: explicit android13 still reorders; empty = the
    #    (now vanilla-first) default chain
    (
        '''
                case "$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)" in
                        android13|"") : ;;
                        vanilla)      try_list="susfs_guard_lkm-x86_64-vanilla-5.15.ko" ;;
                        ymuuu13)      try_list="ymuuu_android13-5.15_susfs_guard_lkm.ko" ;;
                        *)            log_boot "LKM: unknown lkm_candidate '$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)' - using default chain" ;;
                esac''',
        '''
                case "$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)" in
                        "")           : ;;  # the default chain is already vanilla-first (v26.11.51)
                        vanilla)      try_list="susfs_guard_lkm-x86_64-vanilla-5.15.ko" ;;
                        android13)    try_list="susfs_guard_lkm-x86_64-android13-5.15.ko susfs_guard_lkm-x86_64-vanilla-5.15.ko ymuuu_android13-5.15_susfs_guard_lkm.ko" ;;
                        ymuuu13)      try_list="ymuuu_android13-5.15_susfs_guard_lkm.ko" ;;
                        *)            log_boot "LKM: unknown lkm_candidate '$(cat $PERSISTENT_DIR/lkm_candidate 2>/dev/null | head -n 1)' - using default chain" ;;
                esac''',
    ),
    # 3. the self-heal re-selection: prefer vanilla when no explicit pick
    (
        '''
                                *)
                                        [ -f "$SUSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" ] && kmi="susfs_guard_lkm-x86_64-android13-5.15.ko"
                                        ;;
                        esac
                        lkm_file="$SUSFS_LKM/${kmi}"''',
        '''
                                *)
                                        if [ -f "$SUSFS_LKM/susfs_guard_lkm-x86_64-vanilla-5.15.ko" ]; then
                                                kmi="susfs_guard_lkm-x86_64-vanilla-5.15.ko"
                                        elif [ -f "$SUSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" ]; then
                                                kmi="susfs_guard_lkm-x86_64-android13-5.15.ko"
                                        fi
                                        ;;
                        esac
                        lkm_file="$SUSFS_LKM/${kmi}"''',
    ),
]

def main():
    if os.path.exists(DST):
        shutil.rmtree(DST)
    shutil.copytree(SRC, DST)

    # 1. module.prop
    open(f'{DST}/module.prop', 'w').write(MODULE_PROP)

    # 2. customize.sh - prepend the v51 banner before the v50 banner
    cs = open(f'{DST}/customize.sh').read()
    anchor = '        ui_print "[*] v26.11.50: THE CLANG ENTRY."'
    assert anchor in cs, 'v50 banner anchor not found in customize.sh'
    cs = cs.replace(anchor, CUSTOMIZE_BANNER + anchor, 1)
    open(f'{DST}/customize.sh', 'w').write(cs)

    # 3. boot-completed.sh - the three v51 runtime strings
    bc = open(f'{DST}/boot-completed.sh').read()
    old_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v50 CLANG ENTRY, nr 173; CLI: $SC_CLI)"'
    new_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v51 CLANG ACCEPT PATH, nr 173; CLI: $SC_CLI)"'
    assert old_line in bc, 'self-test start line not found'
    bc = bc.replace(old_line, new_line, 1)

    old_hdr = "echo \"---- v50 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    new_hdr = "echo \"---- v51 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    assert old_hdr in bc, 'self-test header not found'
    bc = bc.replace(old_hdr, new_hdr, 1)

    old_note = "echo 'NOTE: v50 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry is a REAL clang-17 function whose 16-byte preamble window is CLONED byte-for-byte from the original entry before the table write; observe mode (stage 2) increments sc_entry_count and returns -EINVAL only; stage 3 answers in payload.err and the syscall return.'"
    new_note = "echo 'NOTE: v51 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry AND the whole accept path are clang-17; the uid gate reads the cred offset CALIBRATED at install from init_task/init_cred (no header-derived struct offsets); stage 3 answers SHOW_VERSION/SHOW_VARIANT/SHOW_ENABLED_FEATURES in payload.err and the syscall return - feature commands answer not-handled this rung (CLI keeps 126), the v49 GCC wrapper is never called.'"
    assert old_note in bc, 'self-test NOTE not found'
    bc = bc.replace(old_note, new_note, 1)
    open(f'{DST}/boot-completed.sh', 'w').write(bc)

    # 4. README - prepend the v51 section
    rd = open(f'{DST}/README-DIAGNOSTIC.md').read()
    open(f'{DST}/README-DIAGNOSTIC.md', 'w').write(README_SECTION + rd)

    # 5. utils.sh - the loader order fix (three anchored edits)
    us = open(f'{DST}/utils.sh').read()
    for n, (old, new) in enumerate(UTILS_EDITS, 1):
        assert old in us, f'utils.sh edit {n} anchor not found'
        us = us.replace(old, new, 1)
    open(f'{DST}/utils.sh', 'w').write(us)

    # 6. the grafted .kos + stamp from the staged payload
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                    f'{DST}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
                    f'{DST}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
    open(f'{DST}/lkm/x86_64/.payload_stamp', 'w').write('v26.11.51\n')

    print('pkg51 ready:', DST)
    for root, dirs, files in os.walk(DST):
        for f in files:
            p = os.path.join(root, f)
            rel = os.path.relpath(p, DST)
            if rel in ('module.prop', 'customize.sh', 'boot-completed.sh',
                       'README-DIAGNOSTIC.md', 'utils.sh',
                       'lkm/x86_64/.payload_stamp',
                       'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                       'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko'):
                print('  CHANGED', rel)

if __name__ == '__main__':
    main()
