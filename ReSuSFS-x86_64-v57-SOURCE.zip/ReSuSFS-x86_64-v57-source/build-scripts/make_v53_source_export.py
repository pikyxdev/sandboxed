#!/usr/bin/env python3
"""make_v53_source_export.py - complete v53 source export for download.

Builds download/ReSuSFS-x86_64-v53-SOURCE.zip: every source/build input of
v26.11.53 that is NOT re-downloadable from public sources. Same shape as
the v52 export (see make_v52_source_export.py); adds the v53 graft source,
the v53 build/verify/package chain, the v53 host test, the updated
sc_probe and the v53 flashable.
"""
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile

BASE = '/home/z/my-project'
STAGE = '/tmp/v53src'
TOP = f'{STAGE}/ReSuSFS-x86_64-v53-source'
OUT_SRC = f'{BASE}/download/ReSuSFS-x86_64-v53-SOURCE.zip'


def sh(cmd, **kw):
    print(f'[cmd] {cmd}')
    return subprocess.run(cmd, shell=True, check=True, **kw)


def copy_rel(src, dst_rel):
    dst = os.path.join(TOP, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_stats(path):
    n, total = 0, 0
    for root, _d, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            if os.path.islink(fp):
                continue
            n += 1
            total += os.path.getsize(fp)
    return n, total


print('== staging ==', flush=True)
shutil.rmtree(STAGE, ignore_errors=True)
os.makedirs(TOP)

P = f'{BASE}/ReSuSFS-x86_64-port'
S = f'{BASE}/scripts'
W = f'{BASE}/work'

# 1. LKM sources + graft sources + probe + host tests
copy_rel(f'{P}/susfs4ksu-lkm-x64-5.15', 'lkm-source/susfs4ksu-lkm-x64-5.15')
for f in ('sc_v50.c', 'sc_v51.c', 'sc_v53.c', 'sc_v50.o', 'sc_v51.o', 'sc_v53.o'):
    copy_rel(f'{P}/{f}', f'lkm-source/{f}')
for f in ('sc_probe.c', 'sc_probe', 'test_sc_v51_host.c', 'test_sc_v51_host',
          'test_sc_v53_host.c'):
    copy_rel(f'{S}/{f}', f'lkm-source/{f}')

# 2. userspace sources (ksu_susfs.c at BASE root is the broken GitLab 404
# page - the REAL wire truth is the stock CLI binary in the package; ship
# both the broken file (marked) and a README note)
copy_rel(f'{S}/libredir.c', 'userspace-src/libredir.c')
copy_rel(f'{S}/port_insmod_x64.py', 'userspace-src/port_insmod_x64.py')
copy_rel(f'{BASE}/testbuild', 'userspace-src/testbuild')
open(f'{TOP}/userspace-src/README.txt', 'w').write(
    'ksu_susfs.c is NOT shipped: the only copy in the sandbox is a broken\n'
    'GitLab 404 HTML page from session 1. The wire-ABI authority is the\n'
    'stock CLI BINARY at package-v53/bin/x86_64/ksu_susfs (sha256\n'
    '7a30fa745a523a4e2897023086a2ef08d773899394781d131f68676227e80e9f,\n'
    'not stripped - disassemble sc_main for the dispatch sites). The full\n'
    'v53 wire table is recorded in memory/FINDINGS.md and in sc_v53.c.\n')

# 3. module staging tree (carries the v53 .ko payload + the new sc_probe)
copy_rel(f'{P}/ReSuSFS', 'module-template/ReSuSFS')

# 4. the EXACT v53 flashable staging tree
copy_rel(f'{W}/pkg53', 'package-v53')

# 5. build scripts (the whole lineage + the v53 chain)
for f in sorted(os.listdir(S)):
    fp = os.path.join(S, f)
    if os.path.isfile(fp):
        copy_rel(fp, f'build-scripts/{f}')
copy_rel(f'{P}/scripts', 'build-scripts/port-scripts')
copy_rel(f'{P}/bin', 'build-scripts/port-bin')

# 6. bit-exact build outputs (v49 base, v50, v51 graft, v53 graft)
os.makedirs(f'{TOP}/binaries', exist_ok=True)
for f in ('susfs_guard_lkm-x86_64-android13-5.15.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v51.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v53.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v51.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v53.ko'):
    copy_rel(f'{P}/{f}', f'binaries/{f}')

# 7. kernel tree fragments (tiny overrides; the tarballs are re-fetchable)
copy_rel(f'{BASE}/linux-5.15.178', 'kernel-fragments/linux-5.15.178')
copy_rel(f'{BASE}/a13', 'kernel-fragments/a13')
copy_rel(f'{BASE}/a13-full', 'kernel-fragments/a13-full')

# 8. upstream refs
copy_rel(f'{BASE}/ReSuSFS-x86_64', 'upstream-refs/ReSuSFS-x86_64')
copy_rel(f'{BASE}/susfs_lkm_x64.zip', 'upstream-refs/susfs_lkm_x64.zip')
copy_rel(f'{BASE}/susfs4ksu_LICENSE', 'upstream-refs/susfs4ksu_LICENSE')
for f in ('branches.json', 'kp.json', 'lkm_release.json', 'test.tab.c', 'tree.json'):
    fp = f'{BASE}/{f}'
    if os.path.isfile(fp):
        copy_rel(fp, f'upstream-refs/{f}')

# 9. docs
copy_rel(f'{P}/README-x86_64-PORT.md', 'docs/README-x86_64-PORT.md')
copy_rel(f'{P}/ReSuSFS/PORTING_x86_64.md', 'docs/PORTING_x86_64.md')
copy_rel(f'{P}/ReSuSFS/CHANGELOG.md', 'docs/CHANGELOG.md')
copy_rel(f'{P}/ReSuSFS/update.json', 'docs/update.json')
os.makedirs(f'{TOP}/docs/test-plans', exist_ok=True)
for f in sorted(os.listdir(f'{P}/ReSuSFS/docs/test-plans')):
    copy_rel(f'{P}/ReSuSFS/docs/test-plans/{f}', f'docs/test-plans/{f}')
copy_rel(f'{BASE}/logs', 'docs/build-logs')

# 10. field evidence
copy_rel(f'{BASE}/field-logs', 'field-logs')

# 11. the flashable + key metadata
copy_rel(f'{BASE}/download/ReSuSFS-x86_64-v26.11.53.zip',
         'flashable/ReSuSFS-x86_64-v26.11.53.zip')

# ---------------------------------------------------------------- metadata
print('== metadata ==', flush=True)
sums = [
    ('flashable/ReSuSFS-x86_64-v26.11.53.zip', sha256(f'{BASE}/download/ReSuSFS-x86_64-v26.11.53.zip')),
    ('package-v53/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
     sha256(f'{W}/pkg53/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')),
    ('binaries/susfs_guard_lkm-x86_64-android13-5.15-v53.ko (THE v53 graft)',
     sha256(f'{P}/susfs_guard_lkm-x86_64-android13-5.15-v53.ko')),
    ('lkm-source/sc_v53.c (THE v53 graft source)', sha256(f'{P}/sc_v53.c')),
    ('lkm-source/sc_v53.o', sha256(f'{P}/sc_v53.o')),
    ('lkm-source/sc_probe.c', sha256(f'{S}/sc_probe.c')),
    ('package-v53/bin/x86_64/ksu_susfs (stock CLI, ABI authority)',
     sha256(f'{W}/pkg53/bin/x86_64/ksu_susfs')),
    ('package-v53/bin/x86_64/sc_probe (v53 readback probe)',
     sha256(f'{W}/pkg53/bin/x86_64/sc_probe')),
    ('package-v53/bin/x86_64/susfs_insmod', sha256(f'{W}/pkg53/bin/x86_64/susfs_insmod')),
]
open(f'{TOP}/SHA256SUMS.key', 'w').write(
    '\n'.join(f'{h}  {n}' for n, h in sums) + '\n')

rows = []
for d in ('lkm-source', 'userspace-src', 'module-template', 'package-v53',
          'build-scripts', 'binaries', 'kernel-fragments', 'upstream-refs',
          'docs', 'field-logs', 'flashable'):
    n, b = tree_stats(os.path.join(TOP, d))
    rows.append((d, n, b))

readme = f'''# MANIFEST - ReSuSFS x86_64 v26.11.53 source export

Exported: 2026-11-27 (Asia/Jakarta). Sandbox: /home/z/my-project
Flashable v53 SHA256: {sums[0][1]}
(v52 source export + ALL-BUILDS zips still in download/ from the previous
session; the v53 build chain needs the v52 zip as layout input.)

Contents: the v52 export + THE FIRST FEATURE RUNG (sc_v53.c graft:
add_sus_path/add_sus_path_loop/hide_sus_mnts accept+store, 32-slot .data
table, private readback 0x55f53; sc_probe self-test extended; the v53
build/verify/package chain; the v53 host test).

| directory | files | bytes | contents |
|-----------|-------|-------|----------|
''' + '\n'.join(f'| {d}/ | {n} | {b} | see README-BUILD-v53 notes in build-scripts headers |'
                 for d, n, b in rows) + '''

Rebuild v53 from this archive (after restoring the layout per
build-scripts/restore_sandbox_v52.sh mapping + make_v52_source_export.py
reverse mapping; sc_v53.* goes to ReSuSFS-x86_64-port/):
    bash scripts/fetch_clang17.sh          # the 4 Debian debs (35 MB)
    bash scripts/build_v53_ko.sh           # graft sc_v53.c onto the FROZEN v49 base
    gcc -DSC_V51_HOSTTEST -O1 -o /tmp/t scripts/test_sc_v53_host.c && /tmp/t
    python3 scripts/build_v53_verify.py    # ALL V53 CHECKS PASSED
    python3 scripts/make_pkg53.py          # work/pkg52 -> work/pkg53
    python3 scripts/build_v53_zip.py       # layout-asserted vs the v52 zip

The v49 BASE .ko is bit-frozen (binaries/) and is never rebuilt; the
susfs4ksu-lkm-x64-5.15 tree in lkm-source/ is INCOMPLETE (14 kernel
sources - cleaned after v49; the base .ko is the only ground truth).
The big public inputs (kernel tarball, a13 mirror) are only needed for a
base rebuild, which nothing in the v53 chain does.
'''
open(f'{TOP}/MANIFEST.md', 'w').write(readme)

if os.path.exists(OUT_SRC):
    os.remove(OUT_SRC)
with zipfile.ZipFile(OUT_SRC, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(STAGE):
        for f in sorted(files):
            fp = os.path.join(root, f)
            z.write(fp, os.path.relpath(fp, STAGE))

n, b = tree_stats(TOP)
print(f'== export ready ==')
print(f'{OUT_SRC} ({os.path.getsize(OUT_SRC)} bytes, {n} files staged)')
print(f'sha256: {sha256(OUT_SRC)}')
for d, cn, cb in rows:
    print(f'  {d:16s} {cn:4d} files {cb:9d} bytes')
