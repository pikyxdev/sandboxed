// SPDX-License-Identifier: GPL-2.0
/*
 * sc_probe - ReSuSFS v47 transport probe (x86_64, freestanding, static-PIE).
 *
 * The v47 supercall channel is:
 *     syscall(173 __NR_ioperm, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload)
 * redirected by the module's patch of the hardened dispatcher's cold
 * ioperm(2) arm into susfs_sc_wrapper.  This tool talks that ABI directly,
 * independent of whatever ksu_susfs binary is installed on the box, and
 * prints:
 *   - the raw syscall return value (0 = the wrapper accepted the call;
 *     -EINVAL = the real ioperm(2) ran, i.e. the arm did NOT intercept),
 *   - payload.err (the kernel writes 0 = ok, else errno-style; 126 is the
 *     userspace ERR_CMD_NOT_SUPPORTED seed - still 126 means "never
 *     answered"),
 *   - the payload bytes (string answers are readable as ASCII),
 *   - the module's sc_entry_count from sysfs, before and after: the wrapper
 *     increments it on EVERY entry before any magic check, so if the count
 *     moves, the transport is LIVE regardless of answers.
 *
 * Usage:
 *   sc_probe                              self-test (SHOW_VERSION + SHOW_VARIANT + counter)
 *   sc_probe <cmd-hex> [payload-hex]      one raw supercall on the v47 channel
 *
 * Example:
 *   sc_probe 0x555e1 0000000000000000000000000000000000000000
 *   (40 hex zeros = the 20-byte st_susfs_sus_version payload)
 *
 * Build (gcc flavor of the port's freestanding recipe):
 *   gcc -O2 -static-pie -nostdlib -fno-stack-protector -fuse-ld=lld \
 *       -Wl,-e,_start -o sc_probe sc_probe.c
 */

typedef unsigned long u64;

/* gcc -O2 rewrites strlen-idiom loops into libc strlen() calls; we are
 * freestanding (-nostdlib), so the transform must stay off. */
#pragma GCC optimize("no-tree-loop-distribute-patterns")

#define SYS_read 0
#define SYS_write 1
#define SYS_open 2
#define SYS_close 3
#define SYS_lseek 8
#define SYS_getdents64 217      /* the v54 enforcement slot */
#define SYS_setresuid 117
#define SYS_setresgid 119
#define SYS_exit 60
#define SYS_ioperm 173          /* the v47 cold channel; reboot(169) is NEVER touched */

#define KSU_INSTALL_MAGIC1 0xDEADBEEFUL
#define SUSFS_MAGIC 0xFAFAFAFAUL

/* susfs_abi.h command ids */
#define CMD_SUSFS_SHOW_VERSION 0x555e1UL
#define CMD_SUSFS_SHOW_VARIANT 0x555e3UL

/* v53 private feature-rung readback (NOT a stock CLI id; collides with
 * no CLI and no base constant).  8196-byte answer: the module's stored
 * sus_path table + counters + hide_sus_mnts state + (v54) the enforcement
 * section. */
#define CMD_SUSFS_V53_DEBUG_LIST 0x55f53UL

/* v54 private enforcement-rung commands (same collision discipline). */
#define CMD_SUSFS_V54_GD64_ARM   0x55f54UL
#define CMD_SUSFS_V54_ADD_RESOLVED 0x55f55UL

#define PAYLOAD_MAX 8196        /* largest ABI struct: st_susfs_enabled_features */
#define ERR_SEED 126

static const char CNT_PATH[] = "/sys/module/susfs_guard_lkm/parameters/sc_entry_count";

static char payload[PAYLOAD_MAX] __attribute__((aligned(16)));
static char out[512];
static char cnt[64];

static long sys5(long n, long a, long b, long c, long d, long e)
{
        register long rax __asm__("rax") = n;
        register long rdi __asm__("rdi") = a;
        register long rsi __asm__("rsi") = b;
        register long rdx __asm__("rdx") = c;
        register long r10 __asm__("r10") = d;
        register long r8 __asm__("r8") = e;

        __asm__ volatile("syscall"
                         : "+r"(rax)
                         : "r"(rdi), "r"(rsi), "r"(rdx), "r"(r10), "r"(r8)
                         : "memory", "cc", "rcx", "r11");
        return rax;
}

static int str_eq(const char *a, const char *b)
{
        unsigned long i = 0;

        while (a[i] && a[i] == b[i])
                i++;
        return a[i] == 0 && b[i] == 0;
}

static unsigned long slen(const char *s)
{
        unsigned long n = 0;

        while (s[n])
                n++;
        return n;
}

static void puts_len(const char *s, unsigned long n)
{
        sys5(SYS_write, 1, (long)s, (long)n, 0, 0);
}

static void say(const char *s)
{
        puts_len(s, slen(s));
}

static void say_hex(unsigned long v)
{
        static const char d[] = "0123456789abcdef";
        char *p = out;
        int i;

        p[0] = '0';
        p[1] = 'x';
        p += 2;
        for (i = 60; i >= 0; i -= 4)
                *p++ = d[(v >> i) & 0xf];
        puts_len(out, p - out);
}

static void say_hex_line(unsigned long v)
{
        say_hex(v);
        puts_len("\n", 1);
}

static void say_dec(long v)
{
        char tmp[24];
        char *p = out;
        int n = 0;
        unsigned long u;

        if (v < 0) {
                *p++ = '-';
                u = (unsigned long)(-v);
        } else {
                u = (unsigned long)v;
        }
        if (!u)
                tmp[n++] = '0';
        while (u) {
                tmp[n++] = (char)('0' + (u % 10));
                u /= 10;
        }
        while (n)
                *p++ = tmp[--n];
        puts_len(out, p - out);
}

static void dump_payload(long len)
{
        static const char d[] = "0123456789abcdef";
        char *p = out;
        long i;

        for (i = 0; i < len; i++) {
                unsigned char c = (unsigned char)payload[i];

                if (i && (i & 15) == 0) {
                        *p++ = '\n';
                        puts_len(out, p - out);
                        p = out;
                }
                *p++ = d[c >> 4];
                *p++ = d[c & 0xf];
                if ((i & 15) == 15)
                        *p++ = ' ';
        }
        if (p != out) {
                *p++ = '\n';
                puts_len(out, p - out);
        }
}

/* the payload as a NUL-terminated ASCII string (answers are plain text) */
static void say_answer(void)
{
        say("answer: ");
        say(payload);
        puts_len("\n", 1);
}

static int hexval(char c)
{
        if (c >= '0' && c <= '9')
                return c - '0';
        if (c >= 'a' && c <= 'f')
                return c - 'a' + 10;
        if (c >= 'A' && c <= 'F')
                return c - 'A' + 10;
        return -1;
}

static long parse_hex(const char *s, char *dst, long cap)
{
        long n = 0;

        if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X'))
                s += 2;
        while (s[0] && s[1] && n < cap) {
                int hi = hexval(s[0]);
                int lo = hexval(s[1]);

                if (hi < 0 || lo < 0)
                        return -1;
                dst[n++] = (char)((hi << 4) | lo);
                s += 2;
        }
        if (s[0] == ' ' || s[0] == '\n')
                return n;
        if (s[0])
                return -1;
        return n;
}

static long parse_cmd(const char *s)
{
        long v = 0;
        int i;

        if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X'))
                s += 2;
        for (i = 0; s[i]; i++) {
                int d = hexval(s[i]);

                if (d < 0)
                        return -1;
                v = (v << 4) | d;
        }
        return v;
}

/* one v47 supercall: syscall(173, magic1, magic2, cmd, payload).
 * seeds payload's last 4 bytes with ERR_SEED, prints rc + err + answer. */
static long sc_once(unsigned long cmd, long len, const char *label)
{
        long rc;
        int err;

        if (len >= 4)
                *(int *)(payload + len - 4) = ERR_SEED;
        rc = sys5(SYS_ioperm, (long)KSU_INSTALL_MAGIC1, (long)SUSFS_MAGIC,
                  (long)cmd, (long)payload, 0);
        say(label);
        say(" cmd=");
        say_hex(cmd);
        say(" -> syscall rc=");
        say_hex_line((unsigned long)rc);
        err = (len >= 4) ? *(int *)(payload + len - 4) : 0;
        say("   payload.err=");
        say_dec(err);
        say(" (0=ok/answered; 126=seed untouched, not answered)\n");
        if (rc == 0 && err == 0 && len > 4)
                say_answer();
        return rc;
}

static long read_small_file(const char *path, char *buf, long cap)
{
        long fd = sys5(SYS_open, (long)path, 0 /* O_RDONLY */, 0, 0, 0);
        long n;

        if (fd < 0)
                return fd;
        n = sys5(SYS_read, fd, (long)buf, cap - 1, 0, 0);
        sys5(SYS_close, fd, 0, 0, 0, 0);
        if (n >= 0)
                buf[n] = 0;
        return n;
}

static void say_count(const char *when)
{
        long n = read_small_file(CNT_PATH, cnt, sizeof(cnt));

        say("sc_entry_count ");
        say(when);
        say(": ");
        if (n < 0) {
                say("<unreadable - susfs_guard_lkm not loaded?>");
        } else {
                say(cnt);       /* raw sysfs content, may carry a newline */
        }
        if (n < 0)
                puts_len("\n", 1);
}

/* ---- v54: the enforcement-rung helpers ----------------------------------- */

/* build the 268-byte add_resolved payload from name + ino */
static long v54_add_resolved(const char *name, unsigned long ino)
{
        long i;

        for (i = 0; i < PAYLOAD_MAX; i++)
                payload[i] = 0;
        for (i = 0; name[i] && i < 255; i++)
                payload[i] = name[i];
        for (i = 0; i < 8; i++)
                payload[256 + i] = (char)((ino >> (8 * i)) & 0xff);
        *(int *)(payload + 264) = ERR_SEED;
        return sys5(SYS_ioperm, (long)KSU_INSTALL_MAGIC1, (long)SUSFS_MAGIC,
                    (long)CMD_SUSFS_V54_ADD_RESOLVED, (long)payload, 0);
}

/* ---- v54.2: full-directory walk ------------------------------------------
 * The v54.1 field run (2026-11-27, boot 4 of the v26.11.55 ladder): the arm
 * succeeded, the filter ran ~3 minutes with a live rule and the box never
 * panicked - but the uid-drop test FAILED on its first field execution, and
 * the receipt that would have named the failing check died with the next
 * boot's self-test overwrite.  The structural suspect: the v54.1 test read
 * ONE 4096-byte getdents64 batch and required the marker (and the control)
 * to sit inside it - a busy /data/local/tmp defeats that assumption, and no
 * offline test ever exercised a listing bigger than one batch.  v2 walks
 * the WHOLE directory (32K batches until getdents64 returns 0) for every
 * view, so the verdict never depends on readdir order, hash layout or
 * directory size; every view also prints its entry count so the field
 * receipt is decisive on its own. */

static int v54_name_is(const char *nm, long namemax, const char *want)
{
        long i;

        if (!want || !want[0])
                return 0;
        for (i = 0; want[i] && i < namemax && want[i] == nm[i]; i++)
                ;
        return !want[i] && i < namemax && !nm[i];
}

/* Walk the whole dir from the fd's current position (caller rewinds).
 * Returns -1 on a read error, else found-bits (bit0 marker, bit1 control);
 * *ino_out captures the marker's d_ino when seen, *entries_out the total
 * dirents walked.  Malformed dirents stop the walk with what was found so
 * far - the same keep-the-tail rule as the module's filter. */
static int v54_walk_dir(long fd, const char *marker, const char *control,
                        unsigned long *ino_out, long *entries_out)
{
        static char wbuf[32768];
        int found = 0;
        long n, entries = 0;

        for (;;) {
                n = sys5(SYS_getdents64, fd, (long)wbuf, sizeof(wbuf), 0, 0);
                if (n < 0)
                        return -1;
                if (n == 0)
                        break;
                {
                        long pos = 0;

                        while (pos + 24 <= n) {
                                unsigned short reclen =
                                        *(unsigned short *)(wbuf + pos + 16);
                                char *nm = wbuf + pos + 19;

                                if (reclen < 24 || (reclen & 7) ||
                                    pos + reclen > n)
                                        goto done;
                                entries++;
                                if (v54_name_is(nm, (long)reclen - 19, marker)) {
                                        long b;
                                        unsigned long ino = 0;

                                        for (b = 0; b < 8; b++)
                                                ino |= (unsigned long)(unsigned char)wbuf[pos + b] << (8 * b);
                                        if (ino_out)
                                                *ino_out = ino;
                                        found |= 1;
                                }
                                if (control && v54_name_is(nm, (long)reclen - 19, control))
                                        found |= 2;
                                pos += reclen;
                        }
                }
        }
done:
        if (entries_out)
                *entries_out = entries;
        return found;
}

/* the uid-drop functional test (v54.3 = gid canary + v54.2 full walks):
 *   sc_probe gd64_test <dir> <marker-name> [control-name] [skipcanary]
 *     (the 5th arg skips ONLY the gid canary - a host-test seam; the
 *     boot script never passes it, so the field always runs the canary)
 * 0. GID CANARY: root drops ONLY its gid to 54321 - a gid-keyed gate
 *    rejects the show_version supercall, a uid-keyed gate answers it
 *    (the v54.1/v54.2 field failures: the gate read cred+8 = GID on
 *    5.15; atomic_t usage@+0, kuid_t uid@+4 - every root:root caller
 *    passed by coincidence, and the uid-drop walk never filtered)
 * 1. FULL root walk: find the marker in ANY batch, capture its ino
 * 2. register (marker, ino) via 0x55f55
 * 3. FULL root walk again: marker AND control visible (root is never
 *    filtered)
 * 4. setresuid(101234) + FULL walk: marker ABSENT, control PRESENT
 * Prints v54_test: PASS/FAIL lines the boot script greps. */
static int v54_gid_canary(void)
{
        long rc;
        int err, ok;

        rc = sys5(SYS_setresgid, 54321, 54321, 54321, 0, 0);
        if (rc != 0) {
                say("v54_test: FAIL setresgid rc=");
                say_dec(rc);
                puts_len("\n", 1);
                return 0;
        }
        payload[0] = 0;
        *(int *)(payload + 16) = ERR_SEED;
        rc = sys5(SYS_ioperm, (long)KSU_INSTALL_MAGIC1, (long)SUSFS_MAGIC,
                  (long)CMD_SUSFS_SHOW_VERSION, (long)payload, 0);
        err = *(int *)(payload + 16);
        sys5(SYS_setresgid, 0, 0, 0, 0, 0);      /* restore root gid */
        ok = (rc == 0 && err == 0);
        say(ok ? "v54_test: gid canary OK (root, gid 54321, uid 0 - show_version answered: the gate keys on UID, not GID)\n"
               : "v54_test: FAIL gid canary (root, gid 54321, uid 0 - the transport gate still reads GID at cred+8; do NOT trust the walk verdict)\n");
        if (!ok) {
                say("v54_test: canary show_version rc=");
                say_dec(rc);
                say(" err=");
                say_dec(err);
                puts_len("\n", 1);
        }
        return ok;
}

static long v54_gd64_test(const char *dir, const char *marker, const char *control,
                          int run_canary)
{
        unsigned long ino = 0;
        long fd, r1, r2, e1 = 0, e2 = 0, e3 = 0;
        int root1, root2, app, pass;

        if (run_canary && !v54_gid_canary())
                return 1;

        fd = sys5(SYS_open, (long)dir, 0 /* O_RDONLY */, 0, 0, 0);
        if (fd < 0) {
                say("v54_test: FAIL open dir rc=");
                say_hex_line((unsigned long)fd);
                return 1;
        }
        sys5(SYS_lseek, fd, 0, 0, 0, 0);
        root1 = v54_walk_dir(fd, marker, control, &ino, &e1);
        if (root1 < 0) {
                say("v54_test: FAIL root getdents64 walk rc=");
                say_hex_line((unsigned long)root1);
                sys5(SYS_close, fd, 0, 0, 0, 0);
                return 1;
        }
        say("v54_test: root walk entries=");
        say_dec(e1);
        say(" marker=");
        say(root1 & 1 ? "found" : "MISSING");
        say(" control=");
        say(root1 & 2 ? "found" : (control ? "MISSING" : "n/a"));
        puts_len("\n", 1);
        if (!(root1 & 1)) {
                sys5(SYS_close, fd, 0, 0, 0, 0);
                say("v54_test: FAIL marker not present in the root listing (full walk)\n");
                return 1;
        }
        say("v54_test: marker ");
        say(marker);
        say(" ino=");
        say_dec((long)ino);
        puts_len("\n", 1);

        /* register the resolved rule */
        r1 = v54_add_resolved(marker, ino);
        {
                int err = *(int *)(payload + 264);

                say("v54_test: add_resolved rc=");
                say_dec(r1);
                say(" err=");
                say_dec(err);
                puts_len("\n", 1);
                if (r1 != 0 || err != 0) {
                        sys5(SYS_close, fd, 0, 0, 0, 0);
                        say("v54_test: FAIL registration rejected\n");
                        return 1;
                }
        }

        /* root view (rewind, full walk) */
        sys5(SYS_lseek, fd, 0, 0, 0, 0);
        root2 = v54_walk_dir(fd, marker, control, 0, &e2);
        say("v54_test: root view entries=");
        say_dec(e2);
        say(" marker=");
        say(root2 & 1 ? "present" : "ABSENT");
        say(" control=");
        say(root2 & 2 ? "present" : (control ? "ABSENT" : "n/a"));
        puts_len("\n", 1);

        /* drop to an app uid and re-walk through the SAME fd */
        r2 = sys5(SYS_setresuid, 101234, 101234, 101234, 0, 0);
        if (r2 != 0) {
                say("v54_test: FAIL setresuid rc=");
                say_dec(r2);
                puts_len("\n", 1);
                sys5(SYS_close, fd, 0, 0, 0, 0);
                return 1;
        }
        sys5(SYS_lseek, fd, 0, 0, 0, 0);
        app = v54_walk_dir(fd, marker, control, 0, &e3);
        if (app < 0) {
                say("v54_test: FAIL app getdents64 walk rc=");
                say_hex_line((unsigned long)app);
                return 1;
        }
        say("v54_test: app-uid view entries=");
        say_dec(e3);
        say(" marker=");
        say(app & 1 ? "present" : "ABSENT");
        say(" control=");
        say(app & 2 ? "present" : (control ? "ABSENT" : "n/a"));
        puts_len("\n", 1);

        pass = (root1 & 1) &&
               (!control || (root1 & 2)) &&
               (root2 & 1) &&
               (!control || (root2 & 2)) &&
               !(app & 1) &&
               (!control || (app & 2));

        say(pass ? "v54_test: PASS (enforcement end-to-end)\n"
                 : "v54_test: FAIL (see the views above)\n");
        return pass ? 0 : 1;
}

long probe_main(long argc, char **argv)
{
        long cmd, len;

        say("ReSuSFS v47 transport probe (syscall 173 / 0xDEADBEEF / 0xFAFAFAFA)\n");

        /* ---- v54 command modes (used by the module scripts) -------------- */
        if (argc >= 2 && str_eq(argv[1], "readback")) {
                /* the v53+v54 state dump only (private cmd 0x55f53) */
                long i;

                for (i = 0; i < PAYLOAD_MAX; i++)
                        payload[i] = 0;
                sc_once(CMD_SUSFS_V53_DEBUG_LIST, PAYLOAD_MAX, "v53_v54_readback");
                return 0;
        }
        if (argc >= 2 && str_eq(argv[1], "gd64_arm")) {
                say("v54 gd64_arm (private cmd 0x55f54)\n");
                for (len = 0; len < PAYLOAD_MAX; len++)
                        payload[len] = 0;
                *(int *)(payload + 4) = ERR_SEED;
                sc_once(CMD_SUSFS_V54_GD64_ARM, 8, "gd64_arm");
                say_count("after");
                return 0;
        }
        if (argc >= 4 && str_eq(argv[1], "add_resolved")) {
                unsigned long ino = 0;
                long i;

                for (i = 0; argv[3][i]; i++)
                        ino = ino * 10 + (argv[3][i] - '0');
                say("v54 add_resolved (private cmd 0x55f55)\n");
                {
                        long rc = v54_add_resolved(argv[2], ino);
                        int err = *(int *)(payload + 264);

                        say("add_resolved ");
                        say(argv[2]);
                        say(" ino=");
                        say_dec((long)ino);
                        say(" rc=");
                        say_dec(rc);
                        say(" err=");
                        say_dec(err);
                        puts_len("\n", 1);
                }
                return 0;
        }
        if (argc >= 4 && str_eq(argv[1], "gd64_test")) {
                return v54_gd64_test(argv[2], argv[3], argc >= 5 ? argv[4] : 0,
                                     !(argc >= 6 && str_eq(argv[5], "skipcanary")));
        }

        if (argc < 2) {
                /* self-test mode */
                say_count("before");
                {
                        long i;

                        for (i = 0; i < 20; i++)
                                payload[i] = 0;
                }
                sc_once(CMD_SUSFS_SHOW_VERSION, 20, "show_version");
                {
                        long i;

                        for (i = 0; i < 20; i++)
                                payload[i] = 0;
                }
                sc_once(CMD_SUSFS_SHOW_VARIANT, 20, "show_variant");
                {
                        /* v53: the feature-rung readback (8196B answer,
                         * err seeded at +8192 like every sc_once call) */
                        long i;

                        for (i = 0; i < PAYLOAD_MAX; i++)
                                payload[i] = 0;
                }
                sc_once(CMD_SUSFS_V53_DEBUG_LIST, PAYLOAD_MAX,
                        "v53_feature_readback");
                say_count("after");
                say("interpretation: count moved => the patched dispatcher arm intercepted\n");
                say("  the call (transport LIVE); err=0 + answer => channel answering end to end;\n");
                say("  count unchanged + negative rc => this call hit the real ioperm(2)\n");
                say("  (arm not live this boot, or the caller is not on syscall 173).\n");
                return 0;
        }

        cmd = parse_cmd(argv[1]);
        if (cmd < 0) {
                say("sc_probe: bad command number\n");
                return 2;
        }
        len = 0;
        if (argc > 2) {
                len = parse_hex(argv[2], payload, PAYLOAD_MAX);
                if (len < 0) {
                        say("sc_probe: bad or oversized payload hex\n");
                        return 2;
                }
        }
        say_count("before");
        sc_once((unsigned long)cmd, len, "raw");
        if (len > 0) {
                say("   payload after call:\n");
                dump_payload(len);
        }
        say_count("after");
        return 0;
}

__asm__(
".text\n"
".global _start\n"
".type _start,@function\n"
"_start:\n"
"       xor     %rbp, %rbp\n"
"       movq    (%rsp), %rdi\n"
"       leaq    8(%rsp), %rsi\n"
"       call    probe_main\n"
"       movl    %eax, %edi\n"
"       movl    $60, %eax\n"
"       syscall\n"
);
