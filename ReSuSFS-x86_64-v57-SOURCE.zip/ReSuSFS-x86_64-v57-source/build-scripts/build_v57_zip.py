#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.57.zip from work/pkg57 (pkg56 tree + v54.3 edits).

v54.3 = THE UID-READ FIX (first kernel-side change since v54.1):
- the uid was read at cred+8 = GID on 5.15 (atomic_t usage@+0, kuid_t
  uid@+4, kgid_t gid@+8 - header-verified); both uid==0 gates passed for
  every root:root field caller BY COINCIDENCE and the uid-drop test
  (uid 101234, gid 0) was never filtered -> the v54.1/v54.2 field disables
- both .kos REBUILT with the cred+4 read; change set vs the field-run
  v26.11.55/.56 object proven by reference-diff disassembly to be exactly
  the two gate reads + the calibrate window; imports still 15, zero ud2
- sc_probe gd64_test runs a GID CANARY first (root, gid 54321: show_version
  must still answer) - the receipt proves which word the gate reads
- module.prop v26.11.57 / versionCode 136 re-bases the ladders on flash

Verifies: entry list identical to v56, change set exactly the 6 expected
entries, both .kos sha256-locked to this build, v54.3 receipts + the
cred+4 gate bytes + wire-dispatch lock on the shipped .ko, the new
sc_probe canary strings, exec bits, stock CLI untouched.
"""
import zipfile, os, hashlib, re, subprocess, tempfile

SRC = '/home/z/my-project/work/pkg57'
PREV = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.56.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.57.zip'

prev_names = zipfile.ZipFile(PREV).namelist()

file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
prev_dir_set = set(n for n in prev_names if n.endswith('/'))

missing_dirs = prev_dir_set - dir_set
extra_dirs = dir_set - prev_dir_set
missing_files = set(prev_names) - set(file_paths) - prev_dir_set
extra_files = set(file_paths) - set(prev_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v55'

file_set = set(file_paths)
ordered = [n for n in prev_names if n in dir_set or n in file_set]
assert len(ordered) == len(prev_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
zp, z56 = zipfile.ZipFile(PREV), zipfile.ZipFile(OUT)
np_, n56 = zp.namelist(), z56.namelist()
assert n56 == np_, 'entry list mismatch vs v56'

changed = []
for n in n56:
    if zp.read(n) != z56.read(n):
        changed.append(n)
print('changed vs v56:', sorted(changed))
assert set(changed) == {
    'module.prop', 'boot-completed.sh', 'bin/x86_64/sc_probe',
    'lkm/x86_64/.payload_stamp',
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
}, f'unexpected change set: {sorted(changed)}'

mp = z56.read('module.prop').decode()
assert 'version=v26.11.57-x86_64' in mp and 'versionCode=136' in mp, 'module.prop version'
assert 'v54.3 THE UID-READ FIX' in mp, 'module.prop headline'
assert 'uid@cred+4' in mp or 'cred+4' in mp, 'module.prop names the fix'
stamp = z56.read('lkm/x86_64/.payload_stamp').decode()
assert 'v26.11.57' in stamp, 'payload stamp'
bc = z56.read('boot-completed.sh').decode()
assert 'gd64_receipt_${CUR_BOOT}.txt' in bc, 'the receipt archive lines present'
assert bc.count('cp "$SC_TEST_LOG" "$PERSISTENT_DIR/logs/gd64_receipt_') == 2, \
    'both archive points (post-arm + post-test)'
assert 'v54_test: PASS' in bc, 'the PASS grep intact'
assert 'v54 gd64 ladder' in bc and 'stale' in bc and 'disabled' in bc, 'ladder discipline intact'
assert 'v26.11.57 (v54.3): THE UID-READ FIX' in bc, 'the v54.3 comment present'
# non-comment lines IDENTICAL to v56 (comments only - the ladder logic is
# the field-proven v54.2 logic)
import subprocess as _sp
same = _sp.run(['bash', '-c',
    "diff <(grep -v '^[[:space:]]*#' %s) <(grep -v '^[[:space:]]*#' %s) >/dev/null"
    % ('/home/z/my-project/work/pkg56/boot-completed.sh', '/home/z/my-project/work/pkg57/boot-completed.sh')])
assert same.returncode == 0, 'boot-completed.sh non-comment lines must be identical to v56'

# ---- BOTH .kos sha256-LOCKED to the v54.3 build (and differ from v56) ----
WANT = {
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko':
        'f36353425e345eaa2053d76a4548058e84539a13d13a61fb99f4ba9f20357f71',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko':
        '9d3106915da841e70fb59bdcd8c6f987806b6f9e3512035b9beb3de8ef238d0e',
}
for name, want in WANT.items():
    b = hashlib.sha256(z56.read(name)).hexdigest()
    a = hashlib.sha256(zp.read(name)).hexdigest()
    assert b == want, f'{name} sha256 {b[:12]}.. != built {want[:12]}..'
    assert a != b, f'{name} UNCHANGED from v56 - v54.3 must ship the fixed .ko'
    print(f'  .ko v54.3 build locked: {name.split("/")[-1]} sha256={b[:16]}.. (v56 was {a[:16]}..)')
# byte-identical to the port-v57 build outputs
for name, src in (('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                   '/home/z/my-project/port-v57/susfs_guard_lkm-x86_64-android13-5.15-v57.ko'),
                  ('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
                   '/home/z/my-project/port-v57/susfs_guard_lkm-x86_64-vanilla-5.15-v57.ko')):
    assert z56.read(name) == open(src, 'rb').read(), f'{name} != {src}'

ym = z56.read('lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')
assert hashlib.sha256(ym).hexdigest() == hashlib.sha256(zp.read(
    'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')).hexdigest(), \
    'reference payload must stay byte-identical'

# ---- receipts + THE WIRE-DISPATCH LOCK on the shipped .ko (re-check) ----
def wire_lock(ko_bytes, label):
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko_bytes)
        path = tf.name
    try:
        asm = subprocess.run(['objdump', '-d', '--no-show-raw-insn',
                              '--disassemble=susfs_sc_entry', path],
                             capture_output=True, text=True, check=True).stdout
    finally:
        os.unlink(path)
    ilist = []
    for l in asm.splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+(.+?)\s*$', l)
        if m:
            ilist.append((int(m.group(1), 16), m.group(2)))
    def builder_for(cmd):
        found = set()
        for i, (a, ins) in enumerate(ilist):
            if not re.match(rf'cmp\s+\$0x{cmd:x},%eax', ins):
                continue
            if i + 1 >= len(ilist):
                continue
            nxt = ilist[i + 1][1]
            for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+|sc_v54_\w+)>', nxt):
                found.add(mb.group(1))
            mj = re.match(r'je\s+([0-9a-f]+)', nxt)
            if mj:
                tgt = int(mj.group(1), 16)
                seq = [x[1] for x in ilist if tgt <= x[0] < tgt + 48]
            else:
                mn = re.match(r'jne\s+([0-9a-f]+)', nxt)
                if mn:
                    seq = [x[1] for x in ilist[i + 2:i + 8]]
                else:
                    continue        # range check
            for s in seq:
                for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+|sc_v54_\w+)>', s):
                    found.add(mb.group(1))
                if re.match(r'(jmp|ret)', s):
                    break
        return found
    assert builder_for(0x555e1) == {'sc_v51_answer_str'}, f'{label}: 0x555e1 must answer version (20B)'
    assert builder_for(0x555e2) == {'sc_v51_answer_features'}, f'{label}: 0x555e2 must answer enabled_features (8196B)'
    assert builder_for(0x555e3) == {'sc_v51_answer_str'}, f'{label}: 0x555e3 must answer variant (20B)'
    assert builder_for(0x55550) == {'sc_v53_add_sus_path'}, f'{label}: 0x55550 must accept add_sus_path (260B)'
    assert builder_for(0x55553) == {'sc_v53_add_sus_path'}, f'{label}: 0x55553 must accept add_sus_path_loop (260B)'
    assert builder_for(0x55561) == {'sc_v53_hide_mnts'}, f'{label}: 0x55561 must accept hide_sus_mnts (8B)'
    assert builder_for(0x55f53) == {'sc_v53_answer_debug_list'}, f'{label}: 0x55f53 must answer the private readback (8196B)'
    assert builder_for(0x55f54) == {'sc_v54_gd64_arm'}, f'{label}: 0x55f54 must run the gd64 arm (8B)'
    assert builder_for(0x55f55) == {'sc_v54_add_resolved'}, f'{label}: 0x55f55 must accept add_resolved (268B)'
    assert not builder_for(0x55590), f'{label}: set_uname must stay not-handled this rung'
    assert not builder_for(0x555b0), f'{label}: set_cmdline must stay not-handled this rung'
    print(f'  wire lock OK ({label}): e1/e2/e3 SHOW + 55550/55553/55561 FEATURE + 55f53/55f54/55f55 private; 55590/555b0 out')

van = z56.read('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
a13 = z56.read('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
for label, ko in (('vanilla', van), ('android13', a13)):
    assert b'v53 clang accept-path init' in ko, f'{label}: v53 init receipt'
    assert b'v54.3 ENFORCEMENT RUNG loaded' in ko, f'{label}: v54.3 loaded receipt (the uid-fix graft)'
    assert b'v54.3 ENFORCEMENT LIVE' in ko, f'{label}: v54.3 arm receipt'
    assert b'uid at cred+4' in ko, f'{label}: the calibrate receipt names the fixed offset'
    assert b'---- v54 enforcement rung ----' in ko, f'{label}: v54 readback section'
    assert b'__x64_sys_getdents64' in ko, f'{label}: the 217 handler name string'
    assert b'v2.3.0\x00' in ko, f'{label}: SUSFS_VERSION_STR'
    assert b'GKI-LKM\x00' in ko, f'{label}: SUSFS_VARIANT_STR'
    wire_lock(ko, label)
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko)
        path = tf.name
    try:
        gd_dis = subprocess.run(['objdump', '-d', '--no-show-raw-insn',
                                 '--disassemble=susfs_gd64_entry', path],
                                capture_output=True, text=True).stdout
        ent_dis = subprocess.run(['objdump', '-d', '--no-show-raw-insn',
                                  '--disassemble=susfs_sc_entry', path],
                                 capture_output=True, text=True).stdout
        assert '0x4(%rax),%eax' in gd_dis.replace('  ', ' '), \
            f'{label}: gd64 filter gate reads cred+4 (uid)'
        assert '0x8(%rax),%eax' not in gd_dis.replace('  ', ' '), \
            f'{label}: gd64 filter gate must NOT read cred+8 (gid)'
        import re as _re
        assert _re.search(r'cmpl?\s+\$0x0,0x4\(%rcx\)', ent_dis), \
            f'{label}: transport root gate reads cred+4 (uid)'
        assert not _re.search(r'cmpl?\s+\$0x0,0x8\(%rcx\)', ent_dis), \
            f'{label}: transport root gate must NOT read cred+8 (gid)'
        print(f'  v54.3 gate bytes re-checked ({label}): both gates read uid@cred+4')
        imp = subprocess.run(['nm', '-u', path], capture_output=True, text=True).stdout
    finally:
        os.unlink(path)
    names = sorted(set(l.split()[1] for l in imp.splitlines() if l.strip()))
    assert '__kmalloc' in names and 'kfree' in names, f'{label}: the two filter imports present'
    assert not any('__x86_indirect_thunk' in n for n in names), f'{label}: no thunk imports'
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko)
        path = tf.name
    try:
        # the v54.1 zero-ud2 guarantee is scoped to THE GRAFT'S OWN PATHS
        # (susfs_gd64_entry + sc_v54_fwd inside the merged .ko) - the base
        # module has always shipped ud2 sites in BUG()/assert paths that
        # are not on our code paths (build_v55_verify.py's scope, and the
        # field run proved this exact image)
        ent = subprocess.run(['objdump', '-d', '--disassemble=susfs_gd64_entry', path],
                             capture_output=True, text=True).stdout
        fwd = subprocess.run(['objdump', '-d', '--disassemble=sc_v54_fwd', path],
                             capture_output=True, text=True).stdout
    finally:
        os.unlink(path)
    assert 'ud2' not in ent, f'{label}: susfs_gd64_entry must carry NO ud2 (the v54 killer)'
    assert 'sc_v54_fwd' in ent, f'{label}: the entry forwards via sc_v54_fwd'
    assert 'call' in ent or 'jmp' in ent, f'{label}: entry disassembly present'
    assert 'ud2' not in fwd and ('*%rax' in fwd), \
        f'{label}: sc_v54_fwd is an unchecked trampoline (no hash check, tail-jmp/call *%rax)'
    print(f'  v54.1 forward guarantee re-checked ({label}): entry zero-ud2, helper unchecked')

# ---- the new sc_probe ----
sp = z56.read('bin/x86_64/sc_probe')
assert b'root walk entries=' in sp, 'sc_probe: the v54.2 full-walk receipt (unchanged)'
assert b'app-uid view entries=' in sp, 'sc_probe: the app-view entry count'
assert b'FAIL marker not present in the root listing (full walk)' in sp, 'sc_probe: the walk-aware failure string'
assert b'v54_test: PASS (enforcement end-to-end)' in sp, 'sc_probe: the PASS string the script greps'
assert b'gd64_test' in sp and b'gd64_arm' in sp, 'sc_probe: the v54 modes present'
assert b'gid canary OK' in sp and b'FAIL gid canary' in sp, 'sc_probe: the v54.3 canary verdicts'
assert b'the transport gate still reads GID at cred+8' in sp, 'sc_probe: the canary fail reason'
assert hashlib.sha256(sp).hexdigest() == '6f70ad6c33b2c0858cc26953a452e05539a7c01e56ceb1fe5520169653c58236', \
    'sc_probe sha256 locked to the v54.3 build'
info = z56.getinfo('bin/x86_64/sc_probe')
assert (info.external_attr >> 16) & 0o111, 'sc_probe must carry exec bits in the zip'
print('sc_probe zip mode:', oct((info.external_attr >> 16) & 0o777))

# ---- the stock CLI must be byte-identical to v56 (and thus to v52) ----
cli = z56.read('bin/x86_64/ksu_susfs')
assert hashlib.sha256(cli).hexdigest() == hashlib.sha256(zp.read('bin/x86_64/ksu_susfs')).hexdigest(), \
    'the stock CLI binary must never change'
sites = sum(1 for m in re.finditer(b'\xb8\xad\x00\x00\x00', cli)
            if cli.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert sites == 9, f'CLI 173 sites: {sites}'
print('CLI 173-riding sites:', sites)

print('zip size:', os.path.getsize(OUT))
print('sha256:', hashlib.sha256(open(OUT, 'rb').read()).hexdigest())
print('V57 ZIP OK')
