#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.56.zip from work/pkg56 (pkg55 tree + v54.2 edits).

v54.2 = THE TEST FIX + RECEIPT PERSISTENCE (userspace only):
- both .kos BYTE-IDENTICAL to the field-run v26.11.55 (kernel side proven:
  arm OK, no panic, filter harmless with a live rule)
- sc_probe gd64_test walks the WHOLE directory (the v54.1 single-batch read
  was the reproduced root cause of the field disable)
- boot-completed.sh archives arm/test receipts to logs/gd64_receipt_<boot>.txt
- module.prop v26.11.56 / versionCode 135 re-bases the ladders on flash

Verifies: entry list identical to v55, change set exactly as expected,
both .kos sha256-identical to v55's, v54.1 receipts + wire-dispatch lock on
the shipped .ko, the new sc_probe strings, exec bits, stock CLI untouched.
"""
import zipfile, os, hashlib, re, subprocess, tempfile

SRC = '/home/z/my-project/work/pkg56'
PREV = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.55.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.56.zip'

prev_names = zipfile.ZipFile(PREV).namelist()

file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
prev_dir_set = set(n for n in prev_names if n.endswith('/'))

missing_dirs = prev_dir_set - dir_set
extra_dirs = dir_set - prev_dir_set
missing_files = set(prev_names) - set(file_paths) - prev_dir_set
extra_files = set(file_paths) - set(prev_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v55'

file_set = set(file_paths)
ordered = [n for n in prev_names if n in dir_set or n in file_set]
assert len(ordered) == len(prev_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
zp, z56 = zipfile.ZipFile(PREV), zipfile.ZipFile(OUT)
np_, n56 = zp.namelist(), z56.namelist()
assert n56 == np_, 'entry list mismatch vs v55'

changed = []
for n in n56:
    if zp.read(n) != z56.read(n):
        changed.append(n)
print('changed vs v55:', sorted(changed))
assert set(changed) == {
    'module.prop', 'boot-completed.sh', 'bin/x86_64/sc_probe',
    'lkm/x86_64/.payload_stamp',
}, f'unexpected change set: {sorted(changed)}'

mp = z56.read('module.prop').decode()
assert 'version=v26.11.56-x86_64' in mp and 'versionCode=135' in mp, 'module.prop version'
assert 'v54.2 THE TEST FIX + RECEIPT PERSISTENCE' in mp, 'module.prop headline'
assert 'BYTE-IDENTICAL to v54.1' in mp, 'module.prop kernel-side guarantee stated'
stamp = z56.read('lkm/x86_64/.payload_stamp').decode()
assert 'v26.11.56' in stamp, 'payload stamp'
bc = z56.read('boot-completed.sh').decode()
assert 'gd64_receipt_${CUR_BOOT}.txt' in bc, 'the receipt archive lines present'
assert bc.count('cp "$SC_TEST_LOG" "$PERSISTENT_DIR/logs/gd64_receipt_') == 2, \
    'both archive points (post-arm + post-test)'
assert 'v54_test: PASS' in bc, 'the PASS grep intact'
assert 'v54 gd64 ladder' in bc and 'stale' in bc and 'disabled' in bc, 'ladder discipline intact'

# ---- BOTH .kos BYTE-IDENTICAL to the field-run v55 (the core guarantee) ----
for name in ('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
             'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko'):
    a = hashlib.sha256(zp.read(name)).hexdigest()
    b = hashlib.sha256(z56.read(name)).hexdigest()
    assert a == b, f'{name} DRIFTED - v54.2 must ship the field-proven .ko byte-identical'
    print(f'  .ko byte-identical to v55: {name.split("/")[-1]} sha256={a[:16]}..')

ym = z56.read('lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')
assert hashlib.sha256(ym).hexdigest() == hashlib.sha256(zp.read(
    'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')).hexdigest(), \
    'reference payload must stay byte-identical'

# ---- receipts + THE WIRE-DISPATCH LOCK on the shipped .ko (re-check) ----
def wire_lock(ko_bytes, label):
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko_bytes)
        path = tf.name
    try:
        asm = subprocess.run(['objdump', '-d', '--no-show-raw-insn',
                              '--disassemble=susfs_sc_entry', path],
                             capture_output=True, text=True, check=True).stdout
    finally:
        os.unlink(path)
    ilist = []
    for l in asm.splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+(.+?)\s*$', l)
        if m:
            ilist.append((int(m.group(1), 16), m.group(2)))
    def builder_for(cmd):
        found = set()
        for i, (a, ins) in enumerate(ilist):
            if not re.match(rf'cmp\s+\$0x{cmd:x},%eax', ins):
                continue
            if i + 1 >= len(ilist):
                continue
            nxt = ilist[i + 1][1]
            for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+|sc_v54_\w+)>', nxt):
                found.add(mb.group(1))
            mj = re.match(r'je\s+([0-9a-f]+)', nxt)
            if mj:
                tgt = int(mj.group(1), 16)
                seq = [x[1] for x in ilist if tgt <= x[0] < tgt + 48]
            else:
                mn = re.match(r'jne\s+([0-9a-f]+)', nxt)
                if mn:
                    seq = [x[1] for x in ilist[i + 2:i + 8]]
                else:
                    continue        # range check
            for s in seq:
                for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+|sc_v54_\w+)>', s):
                    found.add(mb.group(1))
                if re.match(r'(jmp|ret)', s):
                    break
        return found
    assert builder_for(0x555e1) == {'sc_v51_answer_str'}, f'{label}: 0x555e1 must answer version (20B)'
    assert builder_for(0x555e2) == {'sc_v51_answer_features'}, f'{label}: 0x555e2 must answer enabled_features (8196B)'
    assert builder_for(0x555e3) == {'sc_v51_answer_str'}, f'{label}: 0x555e3 must answer variant (20B)'
    assert builder_for(0x55550) == {'sc_v53_add_sus_path'}, f'{label}: 0x55550 must accept add_sus_path (260B)'
    assert builder_for(0x55553) == {'sc_v53_add_sus_path'}, f'{label}: 0x55553 must accept add_sus_path_loop (260B)'
    assert builder_for(0x55561) == {'sc_v53_hide_mnts'}, f'{label}: 0x55561 must accept hide_sus_mnts (8B)'
    assert builder_for(0x55f53) == {'sc_v53_answer_debug_list'}, f'{label}: 0x55f53 must answer the private readback (8196B)'
    assert builder_for(0x55f54) == {'sc_v54_gd64_arm'}, f'{label}: 0x55f54 must run the gd64 arm (8B)'
    assert builder_for(0x55f55) == {'sc_v54_add_resolved'}, f'{label}: 0x55f55 must accept add_resolved (268B)'
    assert not builder_for(0x55590), f'{label}: set_uname must stay not-handled this rung'
    assert not builder_for(0x555b0), f'{label}: set_cmdline must stay not-handled this rung'
    print(f'  wire lock OK ({label}): e1/e2/e3 SHOW + 55550/55553/55561 FEATURE + 55f53/55f54/55f55 private; 55590/555b0 out')

van = z56.read('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
a13 = z56.read('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
for label, ko in (('vanilla', van), ('android13', a13)):
    assert b'v53 clang accept-path init' in ko, f'{label}: v53 init receipt'
    assert b'v54.1 ENFORCEMENT RUNG loaded' in ko, f'{label}: v54.1 loaded receipt (the field-proven graft)'
    assert b'---- v54 enforcement rung ----' in ko, f'{label}: v54 readback section'
    assert b'__x64_sys_getdents64' in ko, f'{label}: the 217 handler name string'
    assert b'v2.3.0\x00' in ko, f'{label}: SUSFS_VERSION_STR'
    assert b'GKI-LKM\x00' in ko, f'{label}: SUSFS_VARIANT_STR'
    wire_lock(ko, label)
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko)
        path = tf.name
    try:
        imp = subprocess.run(['nm', '-u', path], capture_output=True, text=True).stdout
    finally:
        os.unlink(path)
    names = sorted(set(l.split()[1] for l in imp.splitlines() if l.strip()))
    assert '__kmalloc' in names and 'kfree' in names, f'{label}: the two filter imports present'
    assert not any('__x86_indirect_thunk' in n for n in names), f'{label}: no thunk imports'
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko)
        path = tf.name
    try:
        # the v54.1 zero-ud2 guarantee is scoped to THE GRAFT'S OWN PATHS
        # (susfs_gd64_entry + sc_v54_fwd inside the merged .ko) - the base
        # module has always shipped ud2 sites in BUG()/assert paths that
        # are not on our code paths (build_v55_verify.py's scope, and the
        # field run proved this exact image)
        ent = subprocess.run(['objdump', '-d', '--disassemble=susfs_gd64_entry', path],
                             capture_output=True, text=True).stdout
        fwd = subprocess.run(['objdump', '-d', '--disassemble=sc_v54_fwd', path],
                             capture_output=True, text=True).stdout
    finally:
        os.unlink(path)
    assert 'ud2' not in ent, f'{label}: susfs_gd64_entry must carry NO ud2 (the v54 killer)'
    assert 'sc_v54_fwd' in ent, f'{label}: the entry forwards via sc_v54_fwd'
    assert 'call' in ent or 'jmp' in ent, f'{label}: entry disassembly present'
    assert 'ud2' not in fwd and ('*%rax' in fwd), \
        f'{label}: sc_v54_fwd is an unchecked trampoline (no hash check, tail-jmp/call *%rax)'
    print(f'  v54.1 forward guarantee re-checked ({label}): entry zero-ud2, helper unchecked')

# ---- the new sc_probe ----
sp = z56.read('bin/x86_64/sc_probe')
assert b'root walk entries=' in sp, 'sc_probe: the v54.2 full-walk receipt'
assert b'app-uid view entries=' in sp, 'sc_probe: the app-view entry count'
assert b'FAIL marker not present in the root listing (full walk)' in sp, 'sc_probe: the walk-aware failure string'
assert b'v54_test: PASS (enforcement end-to-end)' in sp, 'sc_probe: the PASS string the script greps'
assert b'gd64_test' in sp and b'gd64_arm' in sp, 'sc_probe: the v54 modes present'
info = z56.getinfo('bin/x86_64/sc_probe')
assert (info.external_attr >> 16) & 0o111, 'sc_probe must carry exec bits in the zip'
print('sc_probe zip mode:', oct((info.external_attr >> 16) & 0o777))

# ---- the stock CLI must be byte-identical to v55 (and thus to v52) ----
cli = z56.read('bin/x86_64/ksu_susfs')
assert hashlib.sha256(cli).hexdigest() == hashlib.sha256(zp.read('bin/x86_64/ksu_susfs')).hexdigest(), \
    'the stock CLI binary must never change'
sites = sum(1 for m in re.finditer(b'\xb8\xad\x00\x00\x00', cli)
            if cli.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert sites == 9, f'CLI 173 sites: {sites}'
print('CLI 173-riding sites:', sites)

print('zip size:', os.path.getsize(OUT))
print('sha256:', hashlib.sha256(open(OUT, 'rb').read()).hexdigest())
print('V56 ZIP OK')
