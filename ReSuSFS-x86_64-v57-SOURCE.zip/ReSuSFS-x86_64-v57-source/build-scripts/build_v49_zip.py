#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.49.zip from work/pkg49 (v48 tree + v49 edits).

- Reproduces the v48 zip layout EXACTLY (same entries - v49 adds no files).
- The two module .kos are new (the v49 kCFI-preamble rebuild); the CLI and
  susfs_insmod are rebuilt from the same sources and land byte-identical.
- Verifies: entry set identical to v48, both real .kos changed, ymuuu
  reference identical, v49 markers present (deferred confirmation, re-base,
  kCFI preamble strings in module.prop/scripts), CLI still patched 173.
"""
import zipfile, os, hashlib

SRC = '/home/z/my-project/work/pkg49'
V48 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.48.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.49.zip'

v48_names = zipfile.ZipFile(V48).namelist()

# collect files + directories in pkg49
file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
v48_dir_set = set(n for n in v48_names if n.endswith('/'))

missing_dirs = v48_dir_set - dir_set
extra_dirs = dir_set - v48_dir_set
missing_files = set(v48_names) - set(file_paths) - v48_dir_set
extra_files = set(file_paths) - set(v48_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v48'

# order entries exactly like v48
file_set = set(file_paths)
ordered = [n for n in v48_names if n in dir_set or n in file_set]
assert len(ordered) == len(v48_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
z48, z49 = zipfile.ZipFile(V48), zipfile.ZipFile(OUT)
n48, n49 = z48.namelist(), z49.namelist()
assert n49 == n48, 'entry list mismatch vs v48'

ko_changed = []
for n in n49:
    if n.endswith('.ko'):
        c48 = hashlib.sha256(z48.read(n)).hexdigest()
        c49 = hashlib.sha256(z49.read(n)).hexdigest()
        if c48 != c49:
            ko_changed.append((n, 'changed' if 'ymuuu' not in n else 'UNEXPECTED'))
print('ko changed vs v48:', [c[0] for c in ko_changed])
changed_names = {c[0] for c in ko_changed}
assert 'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko' in changed_names, 'vanilla .ko must be new'
assert 'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko' in changed_names, 'android13 .ko must be new'
assert 'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko' not in changed_names, 'reference payload must stay byte-identical'

changed = []
for n in n49:
    if z48.read(n) != z49.read(n):
        changed.append(n)
print('changed vs v48:', sorted(changed))
assert set(changed) == {
    'README-DIAGNOSTIC.md', 'boot-completed.sh', 'customize.sh', 'module.prop', 'post-fs-data.sh', 'utils.sh',
    'lkm/x86_64/.payload_stamp',
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
}, f'unexpected change set: {sorted(changed)}'

mp = z49.read('module.prop').decode()
pfd = z49.read('post-fs-data.sh').decode()
bc = z49.read('boot-completed.sh').decode()
assert 'version=v26.11.49-x86_64' in mp and 'versionCode=127' in mp, 'module.prop version'
assert 'THE kCFI PREAMBLE FIX' in mp, 'module.prop headline'
assert 'kcfi preamble replicated' in pfd or True  # kernel string, sanity below via .ko
assert 'SC_DEFER_ADVANCE' in bc, 'boot-completed carries the deferred confirmation'
assert 'DEFERRED until the supercall self-test survives' in bc, 'deferred-confirmation log line'
assert 're-basing the stage ladder' in pfd, 'post-fs-data re-base receipt'
assert 'v26.11.49' in z49.read('lkm/x86_64/.payload_stamp').decode(), 'payload stamp'
van = z49.read('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
a13 = z49.read('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
for label, ko in (('vanilla', van), ('android13', a13)):
    assert b'susfs_sc_kcfi_preamble' in ko, f'{label}: preamble symbol name present'
    assert b'v49 table transport' in ko, f'{label}: v49 transport receipt string'
    assert b'kcfi preamble replicated' in ko, f'{label}: preamble replication receipt'
    assert b'is_cfi_preamble_symbol' in ko, f'{label}: kcfi detection string'
    assert b'v48 table transport' not in ko, f'{label}: old v48 receipt string gone'
cli = z49.read('bin/x86_64/ksu_susfs')
import re
sites = sum(1 for m in re.finditer(b'\xb8\xad\x00\x00\x00', cli)
            if cli.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert sites == 9, f'CLI 173 sites: {sites}'
print('CLI 173-riding sites:', sites)
print('zip size:', os.path.getsize(OUT))
print('V49 ZIP OK')
