#!/bin/bash
# kcfi_probe.sh - determine clang-17's kCFI preamble layout on x86_64
# for the exact syscall-table prototype: long (const struct pt_regs *)
set -e
CC=/home/z/clang17/usr/lib/llvm-17/bin/clang
export LD_LIBRARY_PATH=/home/z/clang17/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
D=$(dirname "$0")
[ -x "$CC" ] || { echo "clang missing"; exit 1; }

cat > /tmp/kcfi_probe.c <<'EOF'
struct pt_regs;
extern long ext_wrapper(const struct pt_regs *regs);
typedef long (*sc_fn_t)(const struct pt_regs *);

__attribute__((used, noinline))
long probe_entry(const struct pt_regs *regs)
{
        return ext_wrapper(regs);
}

sc_fn_t take_addr = probe_entry;   /* force address-taken -> preamble */
EOF

# kernel-style codegen flags for x86_64 + kcfi instrumentation
$CC -target x86_64-linux-gnu -c /tmp/kcfi_probe.c -o /tmp/kcfi_probe.o \
    -O2 -fsanitize=kcfi -fno-stack-protector -fno-pic -mno-red-zone \
    -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 \
    -fcf-protection=branch -ffreestanding -nostdinc 2>&1 || {
    echo "compile failed - trying without -fcf-protection";
    $CC -target x86_64-linux-gnu -c /tmp/kcfi_probe.c -o /tmp/kcfi_probe.o \
        -O2 -fsanitize=kcfi -fno-stack-protector -fno-pic -mno-red-zone \
        -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 -ffreestanding -nostdinc
}

echo "=== nm ==="
nm -S /tmp/kcfi_probe.o | sort
echo
echo "=== disassembly around probe_entry ==="
objdump -d --disassemble=probe_entry /tmp/kcfi_probe.o
echo
echo "=== raw .text bytes (see hash before entry) ==="
objdump -s -j .text /tmp/kcfi_probe.o
echo
echo "=== section headers ==="
readelf -SW /tmp/kcfi_probe.o | grep -E 'text|data|Name|kcfi' | head
echo
echo "=== relocations ==="
readelf -rW /tmp/kcfi_probe.o
