#!/bin/bash
# build_v57_ko.sh - v26.11.57 (v54.3 THE UID-READ FIX) kernel-side build.
#
# v54.3 change vs the field-run v26.11.55/.56 (sc_v55.c graft):
#   1. sc_v51_current_uid(): cred+8 -> cred+4.  5.15 struct cred is
#      { atomic_t usage@+0 (4B), kuid_t uid@+4, kgid_t gid@+8 } - verified
#      against torvalds v5.15 AND aosp android13-5.15 include/linux/cred.h.
#      The old +8 read returned the GID; every root:root field caller
#      passed the uid==0 gates by coincidence and the uid-drop test
#      (uid 101234, gid 0) was never filtered -> the v54.1/v54.2 field
#      disables with "app-uid view marker=present, filtered=0".
#   2. sc_v51_calibrate(): the honest init_cred window (usage as the u32
#      it is; id words checked from +4, not +8 - the old window skipped
#      the REAL uid slot entirely and proved nothing).
#   3. Banners name the fix; the probe's gid canary proves the word
#      on-box before the walk verdict.
# NOTHING else changes: same 15 imports, same wire ids, same arm
# discipline, same filter logic.  The base .kos stay the FROZEN v49
# images - never rebuilt.
set -e
BASE=/home/z/my-project
PORT=$BASE/port-v57
CC=$BASE/toolchain/clang17/usr/lib/llvm-17/bin/clang
GRAFT_SRC=$PORT/sc_v56.c
GRAFT_OBJ=$PORT/sc_v56.o
MOD=$PORT/ReSuFS/module
V=26.11.57

export LD_LIBRARY_PATH=$BASE/toolchain/clang17/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
[ -x "$CC" ] || { echo "[!] clang-17 missing at $CC"; exit 1; }

echo "[*] v54.3: compiling the clang-17 graft object (entry + accept path + enforcement rung + uid fix)"
"$CC" -target x86_64-linux-gnu -c "$GRAFT_SRC" -o "$GRAFT_OBJ" \
        -O2 -fsanitize=kcfi -fcf-protection=branch \
        -fno-stack-protector -fno-pic -mno-red-zone \
        -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 \
        -ffreestanding -nostdinc -fno-builtin -std=gnu11 -Wall
echo "[+] graft object: $GRAFT_OBJ ($(stat -c%s "$GRAFT_OBJ") bytes)"

echo "[*] graft object self-checks"
nm -u "$GRAFT_OBJ" | awk '{print $2}' | sort > /tmp/v57_graft_u.txt
cat /tmp/v57_graft_u.txt
# UNCHANGED from v54/v54.1: the v51 13-symbol set + __kmalloc + kfree.
cat > /tmp/v57_graft_expected.txt <<'EOF'
__kmalloc
_copy_from_user
_copy_to_user
kfree
ksu_kallsyms_lookup_name
ksu_patch_text
sc_full_mode
sc_installed
sc_orig
susfs_armed_features
susfs_current_arm_stage
susfs_current_task_gs_off
susfs_diag_logf
susfs_fp_syscall_table
susfs_sc_entry_count
EOF
diff -u /tmp/v57_graft_expected.txt /tmp/v57_graft_u.txt
echo "[+] undefined set exact (15 symbols = v51 13 + __kmalloc + kfree - UNCHANGED by the uid fix)"

# THE v54.3 CHECK: the uid read must be the u32 at cred+4 (movl 0x4 off
# the cred pointer), and the object must contain NO +8 uid read.  The
# helper is sc_v51_current_uid; verify its load displacement.
echo "[*] v54.3 THE UID-READ PROOF: build the pristine v55 reference and diff the disassembly"
REF_SRC=$PORT/sc_v55.c
REF_OBJ=/tmp/sc_v55_ref.o
"$CC" -target x86_64-linux-gnu -c "$REF_SRC" -o "$REF_OBJ" \
        -O2 -fsanitize=kcfi -fcf-protection=branch \
        -fno-stack-protector -fno-pic -mno-red-zone \
        -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 \
        -ffreestanding -nostdinc -fno-builtin -std=gnu11 -Wall
objdump -d "$REF_OBJ" > /tmp/v55_ref.asm
objdump -d "$GRAFT_OBJ" > /tmp/v56_new.asm
diff /tmp/v55_ref.asm /tmp/v56_new.asm > /tmp/v57_delta.txt || true
DELTA=$(wc -l < /tmp/v57_delta.txt)
echo "[*] disasm delta lines vs the field-run v55 graft: $DELTA"
# the two GATE SITES (sc_v51_current_uid is inlined at both callers):
#   susfs_gd64_entry filter gate:  mov 0x8(%rax),%eax  -> mov 0x4(%rax),%eax
#   susfs_sc_entry transport gate: cmpl $0x0,0x8(%rcx) -> cmpl $0x0,0x4(%rcx)
for want in 'mov    0x4(%rax),%eax' 'cmpl   $0x0,0x4(%rcx)'; do
        rg -qF "$want" /tmp/v56_new.asm || { echo "[!] FATAL: fixed gate site missing: $want"; exit 1; }
done
for stale in 'mov    0x8(%rax),%eax' 'cmpl   $0x0,0x8(%rcx)'; do
        rg -qF "$stale" /tmp/v56_new.asm && { echo "[!] FATAL: stale gid read still present: $stale"; exit 1; }
done
# calibrate window: the unrolled id compare chain now spans 0x4..0x2c (u32 usage)
rg -qF "mov    0x4(%rax),%r8d" /tmp/v56_new.asm || { echo "[!] FATAL: calibrate window does not start at +4"; exit 1; }
# symbol surface unchanged: same functions, same order
nm "$REF_OBJ" | awk "{print \$2, \$3}" | sort > /tmp/v55_syms.txt
nm "$GRAFT_OBJ" | awk "{print \$2, \$3}" | sort > /tmp/v56_syms.txt
diff /tmp/v55_syms.txt /tmp/v56_syms.txt && echo "[+] symbol surface identical to v55"
# function entry points identical (no code moved between functions)
diff <(rg "^0000" /tmp/v55_ref.asm) <(rg "^0000" /tmp/v56_new.asm) \
        && echo "[+] function layout identical to v55"
echo "[+] v54.3 change set verified: the ONLY code deltas are the two gate reads (+8 gid -> +4 uid) and the calibrate window (receipt: /tmp/v57_delta.txt)"

# layout contract: zero .bss; v54 storage rides in .data (unchanged)
if nm "$GRAFT_OBJ" | grep -qE ' [bB] '; then
        echo "[!] FATAL: graft object carries .bss symbols:"
        nm "$GRAFT_OBJ" | grep -E ' [bB] '
        exit 1
fi
echo "[+] zero .bss in the graft object (storage rides in .data)"
for v in sc_v54_res sc_v54_next_slot sc_v54_res_adds sc_v54_res_dups \
         sc_v54_res_rejects sc_v54_gd64_calls sc_v54_gd64_filtered \
         sc_v54_gd64_hidden sc_v54_gd64_alloc_fail sc_v54_gd64_copy_fail \
         sc_v54_gd64_installed sc_v54_gd64_orig; do
        nm "$GRAFT_OBJ" | grep -q " d $v\$" || { echo "[!] FATAL: $v not in .data"; exit 1; }
done
echo "[+] all v54 storage in .data (48-slot resolved table + counters + arm state)"

nm "$GRAFT_OBJ" | grep -E ' T (susfs_sc_entry|susfs_gd64_entry|susfs_supercall_init|susfs_supercall_exit)$'
echo "[*] gd64 entry disassembly (must start: endbr64, then lock incl)"
objdump -d --disassemble=susfs_gd64_entry "$GRAFT_OBJ" | head -8
if objdump -dr "$GRAFT_OBJ" | grep -q 'susfs_sc_wrapper'; then
        echo "[!] FATAL: the graft references susfs_sc_wrapper - the v51 contract is that the v49 GCC wrapper is NEVER called"
        exit 1
fi
echo "[+] the v49 GCC wrapper is not referenced anywhere in the graft"
for id in 55550 55553 55561 55f53 55f54 55f55; do
        objdump -d --disassemble=susfs_sc_entry "$GRAFT_OBJ" | grep -q "cmp.*\$0x$id" \
                || { echo "[!] FATAL: entry does not dispatch cmd 0x$id"; exit 1; }
done
echo "[+] entry dispatches the six wire ids (55550/55553/55561/55f53/55f54/55f55)"
# v54.3: the banners must name the fix (receipt strings for the field log)
for s in "v54.3 ENFORCEMENT RUNG loaded" "v54.3 ENFORCEMENT LIVE" "uid at cred+4"; do
        strings "$GRAFT_OBJ" | grep -q "$s" \
                || { echo "[!] FATAL: banner string missing: $s"; exit 1; }
done
echo "[+] v54.3 banners present"
# zero ud2 anywhere (the v54.1 discipline)
if objdump -d "$GRAFT_OBJ" | grep -q "ud2"; then
        echo "[!] FATAL: ud2 site found in the graft object (the v54 death)"
        objdump -d "$GRAFT_OBJ" | grep -n "ud2"
        exit 1
fi
echo "[+] zero ud2 sites in the whole graft object"
if objdump -dr "$GRAFT_OBJ" | grep -qE '__x86_indirect_thunk'; then
        echo "[!] FATAL: thunk import found (the kernel is RETPOLINE=n)"
        exit 1
fi
echo "[+] no __x86_indirect_thunk imports (RETPOLINE=n kernel)"

graft_ko() {      # $1 = base .ko, $2 = output name
        local SRC_KO=$1 NAME=$2
        local WEAK=$(mktemp /tmp/v57_weak_XXXX.ko)
        echo "[*] v54.3: grafting $NAME <- $SRC_KO"
        objcopy \
                --weaken-symbol=susfs_supercall_init \
                --weaken-symbol=susfs_supercall_exit \
                --weaken-symbol=susfs_sc_entry \
                --globalize-symbol=sc_orig \
                --globalize-symbol=sc_installed \
                --globalize-symbol=sc_full_mode \
                --globalize-symbol=susfs_sc_entry_count \
                --globalize-symbol=susfs_armed_features \
                "$SRC_KO" "$WEAK"
        ld -r -o "$PORT/$NAME" "$GRAFT_OBJ" "$WEAK"
        rm -f "$WEAK"
        echo "[+] merged: $PORT/$NAME ($(stat -c%s "$PORT/$NAME") bytes)"
}

graft_ko "$PORT/susfs_guard_lkm-x86_64-android13-5.15.ko" \
         "susfs_guard_lkm-x86_64-android13-5.15-v57.ko"
graft_ko "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15.ko" \
         "susfs_guard_lkm-x86_64-vanilla-5.15-v57.ko"

echo "[*] v54.3: installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$PORT/susfs_guard_lkm-x86_64-android13-5.15-v57.ko" \
      "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15-v57.ko" \
      "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v$V" > "$MOD/lkm/x86_64/.payload_stamp"
ls -la "$MOD/lkm/x86_64" "$MOD/lkm/x86_64/candidates"
echo "[+] v54.3 graft done (verify: python3 $BASE/scripts/build_v57_verify.py)"
