#!/bin/bash
# build_v42_ko.sh - reproducible v26.11.42 x86_64 LKM dual-candidate build.
#
# v42 is the ABI-correct + proven-profile build pair (see the v26.11.42 header
# comment in kernel/susfs_main.c for the full rationale):
#
#   android13 -> susfs_guard_lkm-x86_64-android13-5.15.ko
#                AOSP android13-5.15 ASB-2025-03-05 (a13-full/), HOST GCC.
#                struct module = the RUNNING kernel's (0x340: scmversion +
#                4 ANDROID_KABI_RESERVEs) - the kernel's load-time struct
#                initialization writes land INSIDE the section instead of
#                0x40 bytes past it (what every kernel.org-built image since
#                v26.11.26 actually shipped).
#   vanilla   -> susfs_guard_lkm-x86_64-vanilla-5.15.ko
#                kernel.org linux-5.15.178 (linux-5.15.178/), HOST GCC.
#                The EXACT toolchain+tree profile of v26.11.34..37 - the only
#                images whose module code verifiably EXECUTED in the field
#                (gcc fingerprints: .text.unlikely + .rodata.str1.8).
#                0x300-byte this_module: field-proven benign overflow.
#
# Both built with HOST GCC (gcc 14.2 here); no clang anywhere in v42 - the
# clang-built v40/v41 images froze at the first module-code call while every
# gcc-built image ran.  RETPOLINE/RETHUNK stay at defconfig defaults (the
# v37 profile): 5.15 stable backported CONFIG_RETHUNK, and defconfig leaves
# both ON for gcc, matching the v33-v37 field-proven images (their import
# sets included __x86_return_thunk? NO - verified: v37's imports carry
# neither panic nor __x86_return_thunk; gcc 14 on this tree emits plain ret
# unless -mfunction-return=thunk-extern is passed - checked in step 5).
#
# Expected output properties (verified by step 5 + build_v42_verify.py):
#   vermagic:     5.15.178+ SMP preempt modversions   (byte-identical, both)
#   this_module:  android13=0x340  vanilla=0x300       (the ABI difference)
#   imports:      ~123, all present in the field kernel's kallsyms
#   setter:       susfs_param_set_force_init = bare schedule_work + ret
#   kworker:      susfs_deferred_init_fn first instruction = the -50 store
set -e
BASE=/home/z/my-project
A13=$BASE/a13-full
KORG=$BASE/linux-5.15.178
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
OUT=$BASE/ReSuSFS-x86_64-port

prepare_tree() {          # $1 = tree root, $2 = label
        local TREE=$1 LABEL=$2
        echo "[*] preparing $LABEL tree ($TREE)"

        # current.h override (identical for both trees - the LDPlayer kernel
        # trimmed EXPORT_PER_CPU_SYMBOL(current_task); see restore_build_env.sh)
        CURH="$TREE/arch/x86/include/asm/current.h"
        if ! grep -q susfs_current_task_gs_off "$CURH" 2>/dev/null; then
                cp "$BASE/scripts/current.h.override" "$CURH"
        fi

        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                if [ ! -f .config ]; then
                        make defconfig >/dev/null
                        ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                                --enable PREEMPT --enable SMP \
                                --disable MODULE_UNLOAD --disable X86_5LEVEL \
                                --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY
                fi
                # v42: RETPOLINE/RETHUNK OFF.  The field kernel's kallsyms has NO
                # __x86_indirect_thunk_* symbols (LDPlayer built RETPOLINE=n) - a
                # module importing them resolves them to garbage and its very
                # first indirect call jumps into the void.  This also restores the
                # exact v26.11.26-37 profile (their imports carried no thunk at
                # all) that the field proved live.
                ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                        --enable PREEMPT --enable SMP \
                        --disable MODULE_UNLOAD --disable X86_5LEVEL \
                        --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY \
                        --disable RETPOLINE --disable RETHUNK
                make olddefconfig >/dev/null
                # AOSP's setlocalversion appends a '+' for a no-git tree; the
                # kernel.org one does not.  LOCALVERSION= (set, empty) suppresses
                # it ("If the variable LOCALVERSION is set (including empty)...")
                # so BOTH trees end up at exactly "5.15.178+".
                make LOCALVERSION= modules_prepare >/dev/null
        )
        echo "[+] $LABEL tree ready (this_module will be $(grep -q ANDROID_KABI_RESERVE "$TREE/include/linux/module.h" && echo 0x340 || echo 0x300))"
}

build_tree() {             # $1 = tree root, $2 = output name
        local TREE=$1 NAME=$2
        echo "[*] building $NAME from $TREE"
        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                make M="$LKM" clean >/dev/null 2>&1 || true
                make LOCALVERSION= M="$LKM" CC=gcc modules 2>&1 | tail -5
                cp -f "$LKM/susfs_guard_lkm.ko" "$OUT/$NAME"
        )
        echo "[+] built: $OUT/$NAME ($(stat -c%s "$OUT/$NAME") bytes)"
}

# 1. trees (kernel.org was re-extracted by restore_build_env.sh; a13-full is
#    the full ASB-2025-03-05 mirror extraction)
[ -f "$KORG/Makefile" ] || { echo "[!] kernel.org tree missing"; exit 1; }
[ -f "$A13/Makefile" ] || { echo "[!] a13 tree missing"; exit 1; }

# 2. current.h override source file (kept as a file so both trees get the
#    identical bytes)
if [ ! -f "$BASE/scripts/current.h.override" ]; then
        cp "$KORG/arch/x86/include/asm/current.h" "$BASE/scripts/current.h.override"
fi

prepare_tree "$A13"    "a13-ASB-2025-03"
build_tree   "$A13"    "susfs_guard_lkm-x86_64-android13-5.15.ko"
prepare_tree "$KORG"   "kernel.org-5.15.178"
build_tree   "$KORG"   "susfs_guard_lkm-x86_64-vanilla-5.15.ko"

# 3. verification
python3 "$BASE/scripts/build_v42_verify.py"
