#!/usr/bin/env python3
"""build_v42_verify.py - fail the v42 build on any regression.

Checks BOTH candidates for:
  vermagic byte-exact ("5.15.178+ SMP preempt modversions")
  this_module section size (a13=0x340 ABI-correct / korg=0x300 proven)
  imports: every one present in the uploaded field kernel_kallsyms.txt
  setter minimal: susfs_param_set_force_init contains ONLY the queue_work
     family call and a ret (no stores/calls to DIAG)
  kworker: susfs_deferred_init_fn's first instruction stores -50 (0xffffffce)
  body: susfs_init_body's first instruction stores 0
  probe: the probe/probe_arm params exist in __param
  no return thunks, no panic import (the v41 profile)
"""
import subprocess, sys, re

A13 = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15.ko'
KORG = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
KALL = '/home/z/my-project/upload/kernel_kallsyms.txt'

fails = []

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True)

def symbols(ko):
    out = sh(f"nm -S --defined-only {ko}")
    syms = {}
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 4:
            try:
                syms[p[3]] = (int(p[0], 16), p[1], p[2])
            except ValueError:
                pass
    return syms

def check(label, cond, msg):
    print(f"  [{'OK' if cond else 'FAIL'}] {label}: {msg}")
    if not cond:
        fails.append(f"{label}: {msg}")

for name, ko, want_tm in (('android13', A13, 0x340), ('vanilla', KORG, 0x300)):
    print(f"### {name}: {ko}")
    d = open(ko, 'rb').read()
    i = d.find(b'vermagic=')
    vm = d[i:i+80].split(b'\x00')[0].decode()
    check(name, vm.startswith('vermagic=5.15.178+ SMP preempt modversions'), f"vermagic {vm!r}")

    tm = sh(f"readelf -SW {ko} | awk '/gnu.linkonce.this_module/ {{print strtonum(\"0x\" $7)}}' 2>/dev/null || true")
    # awk strtonum may be mawk; use readelf parse in python instead
    secs = sh(f"readelf -SW {ko}")
    size = None
    for line in secs.splitlines():
        m = re.search(r'\.gnu\.linkonce\.this_module\s+PROGBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
        if m:
            size = int(m.group(1), 16)
    check(name, size == want_tm, f"this_module section size 0x{size:x} (want 0x{want_tm:x})")

    imports = sorted(set(l.split()[1] for l in sh(f"nm -u {ko}").splitlines() if l.strip()))
    print(f"  imports: {len(imports)}")
    kall = open(KALL).read()
    missing = [s for s in imports if f" {s}\n" not in kall]
    check(name, not missing, f"imports all in field kallsyms (missing: {missing})")
    for bad in ('panic', '__x86_return_thunk') + tuple(f'__x86_indirect_thunk_{r}' for r in ('rax','rbp','rdx','rsi','rdi','rcx','r8','r9','r10','r11','r12','r13')):
        check(name, bad not in imports, f"{bad} not imported")

    dis = sh(f"objdump -d --disassemble=susfs_param_set_force_init {ko}")
    n_calls = dis.count('\tcall')
    check(name, n_calls <= 1, f"setter has {n_calls} call(s) (want <=1: the queue_work dispatch)")
    check(name, re.search(r'\tret', dis) is not None, "setter ends with plain ret")
    check(name, 'ffffff9c' not in dis and 'ffffff9b' not in dis, "setter carries no sentinel stores")

    kw = sh(f"objdump -d --disassemble=susfs_deferred_init_fn {ko}")
    kw_body = kw.split('susfs_deferred_init_fn>:', 1)[1] if 'susfs_deferred_init_fn>:' in kw else kw
    first_insns = '\n'.join(kw_body.split('\n')[:3])
    check(name, 'ffffffce' in first_insns, "kworker first instruction stores -50 (0xffffffce)")
    check(name, 'cs jmp' not in kw, 'kworker has no return-thunk jumps')

    bod = sh(f"objdump -d --disassemble=susfs_init_body {ko}")
    check(name, 'c7 05' in bod or 'movl' in bod, "init_body contains stores")

    pr = sh(f"readelf -r {ko}")
    have_param_str = '__param_str_probe' in sh(f"nm {ko}")
    have_probe_arm = '__param_probe_arm' in sh(f"nm {ko}")
    have_probe_get = 'susfs_param_get_probe' in sh(f"nm {ko}")
    check(name, have_param_str and have_probe_arm and have_probe_get,
          "probe/probe_arm params + custom .get present")

    syms = symbols(ko)
    check(name, 'susfs_init_work' in syms, "susfs_init_work present")

print()
if fails:
    print("FAILURES:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("ALL CHECKS PASSED")
