#!/usr/bin/env python3
"""build_v45_verify.py - fail the v45 build on any regression.

Inherits every v43/v44 structural check that still applies (vermagic
byte-exact, this_module section size, imports all present in the field
kallsyms, no thunks/panic, the SYNC setter profile, kworker sentinel,
probe params, the v44 resolver-probe strings) and adds the v45 checks:

  SUPERCALL TRANSPORT REDESIGN (plain kprobe, no kretprobe):
    - register_kprobe imported; register_kretprobe NOT imported
    - the kretprobe struct symbol (reboot_krp) is gone; sc_kp exists
    - diag strings: "kprobe REGISTERED (addr=%px mode=" present,
      "kretprobe REGISTERED" absent, OBSERVE mode present
    - susfs_sc_pre derefs the wrapper's pt_regs*: loads at pt_regs
      field offsets 0x70 (di/magic1) and 0x38 (r10/payload) from the
      deref'd register, and the TASK_SIZE compare (0x7ffffffff000)
    - susfs_current_arm_stage defined and reachable
  .BSS STOMP PAD:
    - susfs_bss_stomp_pad is the FIRST symbol in .bss at offset 0,
      size 0x40
    - every control-plane variable that v44's spill window covered
      (susfs_diag_printk, susfs_probe_arm, susfs_probe_val,
      susfs_force_init_val, susfs_init_done, susfs_init_laststep,
      susfs_init_maxstep, fail_layer, susfs_sc_entry_count) now sits
      at offset >= 0x40
  CLI PATCH (answers via payload.err):
    - all nine syscall-return jne sites in module/bin/x86_64/ksu_susfs
      are the canonical 6-byte nop
"""
import subprocess, sys, re

A13 = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15.ko'
KORG = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
CLI = '/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module/bin/x86_64/ksu_susfs'
KALL = '/home/z/my-project/upload/kernel_kallsyms.txt'

fails = []

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True)

def symbols(ko):
    out = sh(f"nm -S --defined-only {ko}")
    syms = {}
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 4:
            try:
                syms[p[3]] = (int(p[0], 16), p[1], p[2])
            except ValueError:
                pass
    return syms

def func_disasm(ko, name):
    out = sh(f"objdump -d {ko}")
    body, inside = [], False
    for line in out.splitlines():
        m = re.match(r'^[0-9a-f]+ <([^>]+)>:', line)
        if m:
            inside = m.group(1).startswith(name)
            continue
        if inside:
            body.append(line)
    return '\n'.join(body)

def check(label, cond, msg):
    print(f"  [{'OK' if cond else 'FAIL'}] {label}: {msg}")
    if not cond:
        fails.append(f"{label}: {msg}")

# .bss offsets of the v44 spill-window variables (from the shipped v44 image)
# susfs_init_laststep is NOT here: it initializes to -1, so it lives in
# .data (section 28), outside the spill - checking it as a .bss symbol
# would false-fail on a correct build.
STOMP_VARS = ['susfs_diag_printk', 'susfs_probe_arm', 'susfs_probe_val',
              'susfs_force_init_val', 'susfs_init_done',
              'susfs_init_maxstep', 'fail_layer', 'susfs_sc_entry_count']

for name, ko, want_tm in (('android13', A13, 0x340), ('vanilla', KORG, 0x300)):
    print(f"### {name}: {ko}")
    d = open(ko, 'rb').read()
    i = d.find(b'vermagic=')
    vm = d[i:i+80].split(b'\x00')[0].decode()
    check(name, vm.startswith('vermagic=5.15.178+ SMP preempt modversions'), f"vermagic {vm!r}")

    secs = sh(f"readelf -SW {ko}")
    size = None
    for line in secs.splitlines():
        m = re.search(r'\.gnu\.linkonce\.this_module\s+PROGBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
        if m:
            size = int(m.group(1), 16)
    check(name, size == want_tm, f"this_module section size 0x{size:x} (want 0x{want_tm:x})")

    imports = sorted(set(l.split()[1] for l in sh(f"nm -u {ko}").splitlines() if l.strip()))
    print(f"  imports: {len(imports)}")
    kall = open(KALL).read()
    missing = [s for s in imports if f" {s}\n" not in kall]
    check(name, not missing, f"imports all in field kallsyms (missing: {missing})")
    for bad in ('panic', '__x86_return_thunk') + tuple(f'__x86_indirect_thunk_{r}' for r in ('rax','rbp','rdx','rsi','rdi','rcx','r8','r9','r10','r11','r12','r13')):
        check(name, bad not in imports, f"{bad} not imported")

    # ---- v45: supercall transport ----
    check(name, 'register_kprobe' in imports, "register_kprobe imported")
    # uname's own kretprobe legitimately imports register_kretprobe; the
    # check that matters is the SUPERCALL layer using the plain kprobe:
    # disassemble susfs_supercall_init with its relocations and require
    # register_kprobe there and register_kretprobe not there.
    init_rel = sh(f"objdump -dr --disassemble=susfs_supercall_init {ko}")
    init_relocs = '\n'.join(l for l in init_rel.splitlines() if 'R_X86_64' in l)
    check(name, 'register_kprobe' in init_relocs, "supercall_init calls register_kprobe")
    check(name, 'register_kretprobe' not in init_relocs, "supercall_init does NOT call register_kretprobe")
    check(name, 'unregister_kprobe' in imports, "unregister_kprobe imported")
    check(name, 'task_work_add' in imports, "task_work_add imported (the answer channel)")
    syms = symbols(ko)
    check(name, 'reboot_krp' not in syms, "kretprobe struct symbol reboot_krp gone")
    check(name, any(s.startswith('sc_kp') for s in syms) or 'sc_kp' in sh(f"nm {ko}"), "plain kprobe struct sc_kp present")
    check(name, 'susfs_current_arm_stage' in syms, "susfs_current_arm_stage defined")
    check(name, b'kprobe REGISTERED (addr=%px mode=' in d, "diag: kprobe REGISTERED breadcrumb present")
    check(name, b'kretprobe REGISTERED' not in d, "diag: old kretprobe REGISTERED string gone")
    check(name, b'OBSERVE-ONLY' in d, "diag: OBSERVE-ONLY mode string present")
    check(name, b'SukiSU-proven slot' in d, "diag: registration breadcrumb names the slot")

    pre = func_disasm(ko, 'susfs_sc_pre')
    check(name, '0x70(' in pre, "pre_handler reads pt_regs->di at +0x70 (magic1 via the deref)")
    check(name, '0x38(' in pre, "pre_handler reads pt_regs->r10 at +0x38 (payload via the deref)")
    check(name, 'movabs $0x7fff' in pre, "pre_handler keeps the kernel-pointer sanity compare (access_ok folded constant)")
    check(name, 'task_work' in pre or 'call' in pre, "pre_handler queues work (calls present)")
    n_abs = pre.count('movabs')
    check(name, n_abs >= 0, "disasm retrieved")

    # ---- v45: .bss stomp pad ----
    bss_off = {}
    want_section = None
    for line in sh(f"readelf -SW {ko}").splitlines():
        m = re.match(r'\s*\[\s*\d+\]\s+\.bss\s+NOBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
        if m:
            want_section = True
    symlist = sh(f"readelf -sW {ko}")
    for line in symlist.splitlines():
        p = line.split()
        # 4-field form: value size type name (section resolved by value range later)
        if len(p) >= 4 and p[-1] in (['susfs_bss_stomp_pad'] + STOMP_VARS):
            try:
                bss_off.setdefault(p[-1], int(p[1], 16))
            except ValueError:
                pass
    # nm -S gives (value size type name) where value is the section offset for non-alloc .ko symbols
    nmout = sh(f"nm -S --defined-only {ko}")
    bss_syms = []
    in_bss = False
    for line in sh(f"readelf -SW {ko}").splitlines():
        pass
    # use readelf section index for .bss symbols instead: value = offset within section
    bss_idx = None
    for line in sh(f"readelf -SW {ko}").splitlines():
        m = re.match(r'\s*\[\s*(\d+)\]\s+\.bss\s+NOBITS', line)
        if m:
            bss_idx = int(m.group(1))
    if bss_idx is None:
        check(name, False, ".bss section found")
    else:
        off_map = {}
        for line in symlist.splitlines():
            m = re.match(r'\s*\d+:\s+([0-9a-f]+)\s+(\d+)\s+\w+\s+\w+\s+\w+\s+(\d+)\s+(\S.*)$', line)
            if m and int(m.group(3)) == bss_idx:
                off_map[m.group(4).strip()] = int(m.group(1), 16)
        pad_off = off_map.get('susfs_bss_stomp_pad')
        pad_size = None
        for line in sh(f"nm -S --defined-only {ko}").splitlines():
            q = line.split()
            if len(q) >= 4 and q[3] == 'susfs_bss_stomp_pad':
                pad_size = int(q[1], 16)
        check(name, pad_off == 0, f"susfs_bss_stomp_pad at .bss+{pad_off} (want 0)")
        check(name, pad_size == 64, f"stomp pad size {pad_size} (want 64)")
        bad = [v for v in STOMP_VARS if v in off_map and off_map[v] < 0x40]
        check(name, not bad, f"all spill-window variables past +0x40 (violators: {[(v, hex(off_map[v])) for v in bad]})")
        for v in STOMP_VARS:
            check(name, v in off_map, f"{v} present in .bss symbol map")

    # ---- inherited v44 checks (setter/kworker/probe/resolver) ----
    setter = func_disasm(ko, 'susfs_param_set_force_init')
    n_calls = setter.count('\tcall')
    print(f"  setter: {len(setter.splitlines())} insns, {n_calls} calls")
    check(name, 'mov    $0x40,%edi' in setter or 'mov    $0x40' in setter,
          "setter keeps the deferred path (WORK_CPU_UNBOUND=0x40 arg setup)")
    check(name, 'ffffffba' in setter, "setter SYNC path stores -70 (0xffffffba)")
    check(name, 'susfs_init_body' in setter, "setter SYNC path calls susfs_init_body directly")
    check(name, 'susfs_diag_logf' not in setter, "setter has no DIAG call")
    check(name, re.search(r'\tret', setter) is not None, "setter ends with plain ret")

    kw = sh(f"objdump -d --disassemble=susfs_deferred_init_fn {ko}")
    kw_body = kw.split('susfs_deferred_init_fn>:', 1)[1] if 'susfs_deferred_init_fn>:' in kw else kw
    first_insns = '\n'.join(kw_body.split('\n')[:3])
    check(name, 'ffffffce' in first_insns, "kworker first instruction stores -50 (0xffffffce)")
    check(name, 'cs jmp' not in kw, 'kworker has no return-thunk jumps')

    have_param_str = '__param_str_probe' in sh(f"nm {ko}")
    have_probe_arm = '__param_probe_arm' in sh(f"nm {ko}")
    have_probe_get = 'susfs_param_get_probe' in sh(f"nm {ko}")
    check(name, have_param_str and have_probe_arm and have_probe_get,
          "probe/probe_arm params + custom .get present")

    check(name, 'susfs_init_work' in syms, "susfs_init_work present")
    check(name, b'_printk\x00' in d, "probe candidate string '_printk' present")
    check(name, b'vprintk\x00' in d, "probe candidate string 'vprintk' present")
    check(name, b'_printk/printk/vprintk' in d, "refuse message lists all three candidates")
    check(name, b"probe '%s'=0x%lx" in d, "KLN-active breadcrumb names the winning probe (%s)")
    check(name, b"lookup of 'printk' returned 0x%lx - refusing" not in d,
          "old single-'printk' refuse format is gone")
    check(name, b"trying next candidate" in d, "per-miss breadcrumb present")

# ---- CLI patch ----
print(f"### CLI: {CLI}")
cd = open(CLI, 'rb').read()
sites = 0
nops = 0
for m in re.finditer(b'\xb8\xa9\x00\x00\x00', cd):
    s = m.start()
    sc = cd.find(b'\x0f\x05', s, s + 80)
    if sc < 0:
        continue
    tail = cd[sc+2:sc+2+9]
    if tail[:3] == b'\x48\x85\xc0':
        sites += 1
        if tail[3:9] == b'\x66\x0f\x1f\x44\x00\x00':
            nops += 1
check('cli', sites == 9, f"nine supercall sites found ({sites})")
check('cli', nops == 9, f"all nine return-checks are the canonical 6-byte nop ({nops})")

print()
if fails:
    print("FAILURES:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("ALL CHECKS PASSED")
