#!/usr/bin/env python3
"""check_pkg51_vs_zip.py - byte-compare work/pkg51 against the v51 flashable
zip entries (path set + content), without extracting (zip stores odd modes)."""
import hashlib
import os
import stat
import zipfile

BASE = '/home/z/my-project'
ZIP = f'{BASE}/download/ReSuSFS-x86_64-v26.11.51.zip'
DIR = f'{BASE}/work/pkg51'

zf = zipfile.ZipFile(ZIP)
zip_files = {}
for info in zf.infolist():
    name = info.filename
    if name.endswith('/'):
        continue
    zip_files[name] = zf.read(name)

disk_files = {}
for root, _dirs, files in os.walk(DIR):
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), DIR).replace(os.sep, '/')
        disk_files[rel] = open(os.path.join(root, f), 'rb').read()

only_zip = sorted(set(zip_files) - set(disk_files))
only_disk = sorted(set(disk_files) - set(zip_files))
differs = [n for n in sorted(set(zip_files) & set(disk_files))
           if hashlib.sha256(zip_files[n]).digest() != hashlib.sha256(disk_files[n]).digest()]

print(f'zip entries:  {len(zip_files)}')
print(f'disk files:   {len(disk_files)}')
print(f'only in zip:  {only_zip or "none"}')
print(f'only on disk: {only_disk or "none"}')
print(f'content differs: {differs or "none"}')

# Also report the odd modes stored in the zip (informational)
odd = {}
for info in zf.infolist():
    mode = (info.external_attr >> 16) & 0o7777
    if info.filename.endswith('/'):
        continue
    odd.setdefault(oct(mode), []).append(info.filename)
for m, names in sorted(odd.items()):
    print(f'zip mode {m}: {len(names)} files (e.g. {names[0]})')

ok = not only_zip and not only_disk and not differs
print('RESULT:', 'IDENTICAL' if ok else 'MISMATCH - bundle pkg51 dir separately')
raise SystemExit(0 if ok else 1)
