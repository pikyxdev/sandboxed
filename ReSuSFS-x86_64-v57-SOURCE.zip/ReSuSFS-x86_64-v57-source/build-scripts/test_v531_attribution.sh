#!/bin/sh
# Offline test of the v53.1 honest-wedge-attribution block (extracted verbatim
# from work/pkg531/post-fs-data.sh) against the REAL v53 field init_trace.txt.
set -u
SCRIPT=/home/z/my-project/work/pkg531/post-fs-data.sh
FIELD_LOGS=/home/z/my-project/upload/v53-field
PASS=0; FAIL=0

run_case() {
    # $1 = name, $2 = init_trace path, $3 = marker, $4 = arm_stage, $5 = retries file content or NONE
    NAME="$1"; TRACE="$2"; MARKER="$3"; ARM_STAGE="$4"
    T=$(mktemp -d)
    mkdir -p "$T/persist" "$T/logs"
    cp "$TRACE" "$T/logs/init_trace.txt"
    [ "$5" != "NONE" ] && echo "$5" > "$T/persist/freeze_retries"
    echo 3 > "$T/stage_max"; echo "$ARM_STAGE" > "$T/stage"
    MARKER_BOOT=$(echo "$MARKER" | awk '{print $3}')
    LOG_DIR="$T/logs"
    STAGE_MAX_FILE="$T/stage_max"; STAGE_FILE="$T/stage"
    log_boot() { echo "LOG: $*"; }
    # extract the real block (WEDGE_SECTION .. the closing fi of the else) and
    # redirect the persist path into the test dir
    awk '/^                        WEDGE_SECTION=""/,/^                        fi$/' "$SCRIPT" \
      | sed "s|/data/adb/ReSuSFS/freeze_retries|$T/persist/freeze_retries|g" > "$T/block.sh"
    ( . "$T/block.sh" ) > "$T/out" 2>&1
    echo "== $NAME"
    cat "$T/out"
    echo "   state: INIT_TRIGGERED=$(grep -c x /dev/null; echo 0) stage_max=$(cat $T/stage_max) stage=$(cat $T/stage) retries=$(cat $T/persist/freeze_retries 2>/dev/null || echo none)"
    rm -rf "$T"
}

MARKER_V53="try 1 aab0e48978df43ba8f1d538d92292f8e"
echo "################ CASE 1: the REAL v53 field freeze (no force_init receipt) -> expect RETRY, no demote"
run_case "v53-field-freeze" "$FIELD_LOGS/init_trace.txt" "$MARKER_V53" 1 NONE

echo
echo "################ CASE 2: real init wedge (section contains writing force_init) -> expect DEMOTE 3->... wait stage_max untouched, ARM 1 -> NEW_MAX 0"
# manufacture: append a boot section that DID write force_init
T2=$(mktemp); cp "$FIELD_LOGS/init_trace.txt" "$T2"
printf '%s\n' \
 "---- boot deadbeefdeadbeefdeadbeefdeadbeef begin (v42 substep ladder; trigger_mode=sync) ----" \
 "[x] boot=deadbeefdeadbeefdeadbeefdeadbeef writing arm_stage=1 (layer gate)" \
 "[x] boot=deadbeefdeadbeefdeadbeefdeadbeef trigger_mode=sync: writing force_init=2 (v43 SYNC path)" \
 "---- boot 00000000000000000000000000000000 begin ----" >> "$T2"
run_case "real-init-wedge" "$T2" "try 1 deadbeefdeadbeefdeadbeefdeadbeef" 1 NONE
rm -f "$T2"

echo
echo "################ CASE 3: SECOND consecutive freeze -> expect DEMOTE (stage 1 -> NEW_MAX 0) + stage reset"
run_case "second-consecutive-freeze" "$FIELD_LOGS/init_trace.txt" "$MARKER_V53" 1 1
