#!/bin/sh
# test_ladder_v37.sh - state-machine test of the v26.11.37 bring-up ladder.
#
# Extracts the REAL ladder logic blocks from the packaged post-fs-data.sh
# and service.sh (paths substituted into a sandbox, sleep stubbed), then
# simulates boots and asserts the resulting ladder state:
#   A) healthy climb 0 -> 1 -> 2 -> 3 (one rung per boot)
#   B) wedge at stage 3 (init_done=1, boot never completes) -> demote + cap
#   C) re-climb to the capped max and hold there
#   D) stage-0 wedge -> enable_lkm auto-removed, marker cleared
#   E) same-boot double-run of post-fs-data -> NO spurious demote
#   F) same-boot double-run of service -> rung not skipped
#   G) pfd -> svc -> pfd -> svc same-boot reorder -> rung not skipped
#   H) stage above stage_max -> clamped for this boot
#   I) garbage arm_stage file -> floor (0)
set -e

PKG=/home/z/my-project/work/pkg37
BASE=$(mktemp -d)
trap 'rm -rf "$BASE"' EXIT
fails=0

check() {   # check <desc> <expected> <actual>
        if [ "$2" = "$3" ]; then
                echo "  ok: $1"
        else
                echo "  FAIL: $1: expected [$2] got [$3]"
                fails=$((fails+1))
        fi
}

# gen <phase> : build sandbox $BASE/<phase> with pfd.sh/svc.sh generated from
# the REAL scripts with that sandbox's paths baked in.
gen() {
        local_d="$BASE/$1"
        mkdir -p "$local_d/ReSuSFS/logs" "$local_d/sysparams"
        for f in arm_stage init_done diag_log force_init; do : > "$local_d/sysparams/$f"; done
        sed -e "s#/data/adb/ReSuSFS#$local_d/ReSuSFS#g" \
            -e "s#/sys/module/susfs_guard_lkm/parameters#$local_d/sysparams#g" \
            -e "s#/proc/sys/kernel/random/boot_id#$local_d/boot_id#g" \
            "$PKG/post-fs-data.sh" | \
            awk '/^        STAGE_FILE=/{flag=1} /capture_lkm_live_evidence/{flag=0} flag' > "$local_d/pfd.block"
        sed -e "s#/data/adb/ReSuSFS#$local_d/ReSuSFS#g" \
            -e "s#/sys/module/susfs_guard_lkm/parameters#$local_d/sysparams#g" \
            -e "s#/proc/sys/kernel/random/boot_id#$local_d/boot_id#g" \
            "$PKG/service.sh" | \
            awk '/^# v26\.11\.37 auto-escalation/{flag=1} flag && /^fi$/{print; exit} flag' > "$local_d/svc.block"
        {
                echo 'log_boot() { echo "  [boot] $*" >> "$BOOT_LOG"; }'
                echo "BOOT_LOG=\"$local_d/boot.log\""
                echo 'sleep() { :; }'
                cat "$local_d/pfd.block"
        } > "$local_d/pfd.sh"
        {
                echo 'log_boot() { echo "  [boot] $*" >> "$BOOT_LOG"; }'
                echo "BOOT_LOG=\"$local_d/boot.log\""
                echo 'sleep() { :; }'
                cat "$local_d/svc.block"
        } > "$local_d/svc.sh"
        echo "DIAG step 1: susfs_init ENTERED" > "$local_d/sysparams/diag_log"
}

# boot <dir> <id> <init_done> : switch the simulated kernel to a new boot.
# A real boot gets a FRESH module image, so its sysfs params start at their
# defaults again - the fake param files must be reset the same way (except
# init_done/diag_log, which the module fills in as init progresses).
boot() {
        printf '%s-0000-0000-0000-000000000000\n' "$2" > "$1/boot_id"
        : > "$1/sysparams/arm_stage"
        : > "$1/sysparams/force_init"
        printf '%s' "$3" > "$1/sysparams/init_done"
}

ST() { d="$1"; [ -f "$d/ReSuSFS/arm_stage" ] && cat "$d/ReSuSFS/arm_stage" || echo "(absent)"; }
SM() { d="$1"; [ -f "$d/ReSuSFS/stage_max" ] && cat "$d/ReSuSFS/stage_max" || echo "(absent)"; }
SB() { d="$1"; [ -f "$d/ReSuSFS/stage_boot" ] && cat "$d/ReSuSFS/stage_boot" || echo "(absent)"; }
PRM() { cat "$1/sysparams/arm_stage" 2>/dev/null || echo "(none)"; }

echo "== A) healthy climb 0 -> 1 -> 2 -> 3 (one rung per boot)"
D="$BASE/a"; gen a; boot "$D" a1 1; sh "$D/pfd.sh"
check "A1 try marker"   "try 0 a1000000000000000000000000" "$(SB "$D")"
check "A1 param written" "0" "$(PRM "$D")"
sh "$D/svc.sh"
check "A1 raised to 1"  "1" "$(ST "$D")"
boot "$D" a2 1; sh "$D/pfd.sh"; sh "$D/svc.sh"
check "A2 raised to 2"  "2" "$(ST "$D")"
boot "$D" a3 1; sh "$D/pfd.sh"; sh "$D/svc.sh"
check "A3 raised to 3"  "3" "$(ST "$D")"
check "A3 ok marker (rung that ran)" "ok 2 a3000000000000000000000000" "$(SB "$D")"
check "A3 max default"  "(absent)" "$(SM "$D")"

echo "== B) wedge at stage 3: init done but the boot never completes -> demote"
boot "$D" b1 1; sh "$D/pfd.sh"            # init reports done, then the boot wedges: NO service run
check "B1 try marker left" "try 3 b1000000000000000000000000" "$(SB "$D")"
boot "$D" b2 1; sh "$D/pfd.sh"            # next boot sees the stale try from the previous boot
check "B2 demoted stage"  "0" "$(ST "$D")"
check "B2 max capped 2"   "2" "$(SM "$D")"
check "B2 try marker"     "try 0 b2000000000000000000000000" "$(SB "$D")"
sh "$D/svc.sh"
check "B2 raised to 1"    "1" "$(ST "$D")"

echo "== C) re-climb to the cap and hold"
boot "$D" c1 1; sh "$D/pfd.sh"; sh "$D/svc.sh"
check "C1 raised to 2"   "2" "$(ST "$D")"
boot "$D" c2 1; sh "$D/pfd.sh"; sh "$D/svc.sh"
check "C2 holds at max"  "2" "$(ST "$D")"
check "C2 ok marker"     "ok 2 c2000000000000000000000000" "$(SB "$D")"

echo "== D) stage-0 wedge -> enable_lkm auto-removed, marker cleared"
D="$BASE/d"; gen d; touch "$D/ReSuSFS/enable_lkm"
boot "$D" d1 1; sh "$D/pfd.sh"            # boots at stage 0, then wedges: no service run
boot "$D" d2 1; sh "$D/pfd.sh"            # next boot: the stage-0 attempt never completed
check "D2 enable_lkm removed" "gone" "$([ -e "$D/ReSuSFS/enable_lkm" ] && echo present || echo gone)"
check "D2 marker cleared"     "(absent)" "$(SB "$D")"
check "D2 stage floor"        "0" "$(ST "$D")"
check "D2 force_init NOT triggered" "" "$(cat "$D/sysparams/force_init" 2>/dev/null)"

echo "== E) same-boot double-run of post-fs-data -> NO spurious demote"
D="$BASE/e"; gen e; touch "$D/ReSuSFS/enable_lkm"
boot "$D" e1 1; sh "$D/pfd.sh"; sh "$D/pfd.sh"
check "E2 enable_lkm intact" "present" "$([ -e "$D/ReSuSFS/enable_lkm" ] && echo present || echo gone)"
check "E2 no demote (stage file untouched)" "(absent)" "$(ST "$D")"
check "E2 max untouched"     "(absent)" "$(SM "$D")"
check "E2 marker current"    "try 0 e1000000000000000000000000" "$(SB "$D")"

echo "== F) same-boot double-run of service -> rung not skipped"
sh "$D/svc.sh"                              # absent marker -> ok 0 + raise to 1
check "F1 raised to 1"        "1" "$(ST "$D")"
sh "$D/svc.sh"                              # same boot again -> must NOT raise to 2
check "F2 still 1"            "1" "$(ST "$D")"

echo "== G) pfd -> svc -> pfd -> svc same-boot reorder -> rung not skipped"
D="$BASE/g"; gen g
boot "$D" g1 1
sh "$D/pfd.sh"                              # try 0
sh "$D/svc.sh"                               # ok 0 + raise to 1
sh "$D/pfd.sh"                              # re-run after svc: must keep the ok marker
check "G1 ok marker kept"     "ok 0 g1000000000000000000000000" "$(SB "$D")"
sh "$D/svc.sh"                               # re-run: marker ok+this boot -> skip
check "G2 still 1"            "1" "$(ST "$D")"

echo "== H) stage above stage_max -> clamped for this boot"
D="$BASE/h"; gen h
echo 4 > "$D/ReSuSFS/arm_stage"; echo 2 > "$D/ReSuSFS/stage_max"
boot "$D" h1 1; sh "$D/pfd.sh"
check "H1 param clamped"      "2" "$(PRM "$D")"

echo "== I) garbage arm_stage file -> floor"
D="$BASE/i"; gen i
echo "9x" > "$D/ReSuSFS/arm_stage"
boot "$D" i1 1; sh "$D/pfd.sh"
check "I1 param floor"        "0" "$(PRM "$D")"

echo "== J) boot completes but init incomplete -> nok marker, retry same rung (no demote)"
D="$BASE/j"; gen j
boot "$D" j1 1; sh "$D/pfd.sh"; sh "$D/svc.sh"
check "J1 raised to 1"        "1" "$(ST "$D")"
boot "$D" j2 0; sh "$D/pfd.sh"; sh "$D/svc.sh"      # init incomplete, boot completes
check "J2 nok marker"        "nok 1 j2000000000000000000000000" "$(SB "$D")"
check "J2 no raise"          "1" "$(ST "$D")"
boot "$D" j3 1; sh "$D/pfd.sh"                       # next boot: same rung, NOT demoted
check "J3 rung retried"      "1" "$(ST "$D")"
check "J3 max not capped"    "(absent)" "$(SM "$D")"
check "J3 try marker"        "try 1 j3000000000000000000000000" "$(SB "$D")"

echo
if [ "$fails" -eq 0 ]; then
        echo "LADDER STATE MACHINE: ALL SCENARIOS PASSED"
else
        echo "LADDER STATE MACHINE: $fails FAILURE(S)"
        exit 1
fi
