#!/bin/bash
# Deep harness for update_susfs / download_susfs_guard_lkm / load_susfs_lkm.
#
# utils.sh hardcodes /data/adb/ksu/bin, /data/adb/ReSuSFS_LKM and
# /data/local/tmp. To exercise the real functions without root, this harness
# copies utils.sh into a sandbox dir and rewrites those three prefixes, then
# runs the functions with fake getprop / uname / busybox / ksud on PATH.
set -u
PORT=/home/z/my-project/ReSuSFS-x86_64
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=$(mktemp -d /tmp/resusfs_deep.XXXXXX)
FAKEBIN="$ROOT/fakebin"
BIN="$ROOT/data/adb/ksu/bin"        # fake /data/adb/ksu/bin
LKMDIR="$ROOT/data/adb/ReSuSFS_LKM"
TMPDIR_="$ROOT/data/local/tmp"
mkdir -p "$FAKEBIN" "$BIN" "$LKMDIR" "$TMPDIR_"

pass=0; fail=0
ok()  { echo "PASS: $1"; pass=$((pass+1)); }
bad() { echo "FAIL: $1"; fail=$((fail+1)); }

cleanup() { rm -rf "$ROOT"; }
trap cleanup EXIT

# ---------- fixtures ----------
FIX="$ROOT/fixtures"; mkdir -p "$FIX"
# fake x64 LKM module zip containing all 8 KMIs (mirrors ymuuu release layout)
X64ZIP="$FIX/susfs_lkm_x64.zip"
pushd "$FIX" >/dev/null
for k in android12-5.10 android13-5.10 android13-5.15 android14-5.15 \
         android14-6.1 android15-6.6 android16-6.12 android17-6.18; do
    printf '# fake x64 ko %s\n' "$k" > "${k}_susfs_guard_lkm.ko"
done
printf 'id=susfs_lkm_x64\n' > module.prop
printf '#!/system/bin/sh\n' > post-fs-data.sh
zip -q -X "$X64ZIP" ./*_susfs_guard_lkm.ko module.prop post-fs-data.sh
rm -f ./*_susfs_guard_lkm.ko module.prop post-fs-data.sh
popd >/dev/null
printf '# fake arm64 ko\n'    > "$FIX/susfs_guard_lkm-android15-6.6.ko"
printf '# fake insmod\n'      > "$FIX/susfs_insmod"
printf '# fake arm64 cli\n'   > "$FIX/ksu_susfs_arm64"

# ---------- fakes ----------
make_getprop() {
    printf '#!/bin/sh\n[ "$1" = ro.product.cpu.abi ] && echo "%s"\nexit 0\n' "$1" > "$FAKEBIN/getprop"
    chmod +x "$FAKEBIN/getprop"
}
make_uname() {
    printf '#!/bin/sh\n[ "$1" = -m ] && echo "%s"\n[ "$1" = -r ] && echo "%s"\nexit 0\n' "$1" "$2" > "$FAKEBIN/uname"
    chmod +x "$FAKEBIN/uname"
}
# fake busybox: wget maps URLs to fixtures; sleep/rmmod are no-ops; rest delegate
cat > "$FAKEBIN/busybox" <<'EOF'
#!/bin/bash
cmd="$1"; shift
case "$cmd" in
    wget)
        out=""; url=""; prev=""
        for a in "$@"; do
            [ "$prev" = "-O" ] && out="$a"
            case "$a" in -*) ;; *) [ "$prev" = "-O" ] || url="$a" ;; esac
            prev="$a"
        done
        case "$url" in
            */susfs_lkm_x64.zip) cp "$FIXTURES/susfs_lkm_x64.zip" "$out" ;;
            */susfs_guard_lkm-*.ko) cp "$FIXTURES/susfs_guard_lkm-android15-6.6.ko" "$out" ;;
            */susfs_insmod) cp "$FIXTURES/susfs_insmod" "$out" ;;
            */ksu_susfs_arm64*) cp "$FIXTURES/ksu_susfs_arm64" "$out" ;;
            *) exit 1 ;;
        esac
        exit $?
        ;;
    sleep) exit 0 ;;
    rmmod) exit 0 ;;
    zcat) exit 1 ;;   # pretend CONFIG_KSU_SUSFS is absent (forces LKM path)
    *)
        if command -v "$cmd" >/dev/null 2>&1; then exec "$cmd" "$@"; else exit 0; fi
        ;;
esac
EOF
chmod +x "$FAKEBIN/busybox"
# fake ksud: record insmod calls, always succeed
cat > "$FAKEBIN/ksud" <<EOF
#!/bin/bash
echo "ksud \$*" >> "$ROOT/ksud.log"
exit 0
EOF
chmod +x "$FAKEBIN/ksud"

# ---------- patched copy of utils.sh ----------
UTILS_TEST="$ROOT/utils_test.sh"
sed -e "s|/data/adb/ksu/bin|$BIN|g" \
    -e "s|/data/adb/ReSuSFS_LKM|$LKMDIR|g" \
    -e "s|/data/local/tmp|$TMPDIR_|g" \
    "$PORT/module/utils.sh" > "$UTILS_TEST"

run_f() {  # run_f <sh-code>  — run code with utils.sh sourced, fakes on PATH
    FIXTURES="$FIX" PATH="$FAKEBIN:$PATH" MODDIR="$PORT/module" sh -c "
        . '$UTILS_TEST' >/dev/null 2>&1
        $1
    "
}

# ---------- update_susfs: x86_64 installs the bundled binary ----------
make_getprop x86_64; make_uname x86_64 "6.6.66-android15-8"
out=$(run_f 'MODPATH="'"$PORT"'/module" update_susfs 2>&1'); rc=$?
echo "$out" | grep -q "Installing bundled x86_64 ksu_susfs CLI" \
  && echo "$out" | grep -q "SUSFS updated successfully" && [ $rc = 0 ] \
  && ok "update_susfs x86_64: installs bundled binary" \
  || bad "update_susfs x86_64 (rc=$rc out: $(echo "$out"|head -2|tr '\n' '|'))"
cmp -s "$BIN/ksu_susfs" "$PORT/module/bin/x86_64/ksu_susfs" \
  && ok "update_susfs x86_64: installed file is byte-identical to bundled ELF" \
  || bad "update_susfs x86_64: installed file differs"
[ -x "$BIN/ksu_susfs" ] && ok "update_susfs x86_64: installed file is executable" || bad "not +x"

# ---------- update_susfs: x86_64 keeps the LKM-provided symlink ----------
rm -f "$BIN/ksu_susfs"; ln -s /data/adb/ksu/bin/susfs "$BIN/ksu_susfs"
out=$(run_f 'MODPATH="'"$PORT"'/module" update_susfs 2>&1'); rc=$?
echo "$out" | grep -q "provided by the x86_64 susfs LKM, keeping it" && [ $rc = 0 ] \
  && [ -L "$BIN/ksu_susfs" ] \
  && ok "update_susfs x86_64: LKM symlink preserved" \
  || bad "update_susfs x86_64 symlink guard (rc=$rc out: $(echo "$out"|head -1))"
rm -f "$BIN/ksu_susfs"

# ---------- update_susfs: x86_64 with missing bundled binary ----------
mkdir -p "$ROOT/badmod"
out=$(run_f 'MODPATH="'"$ROOT"'/badmod" update_susfs 2>&1'); rc=$?
echo "$out" | grep -q "Bundled x86_64 ksu_susfs binary not found" && [ $rc != 0 ] \
  && ok "update_susfs x86_64: missing bundled binary fails cleanly" \
  || bad "update_susfs x86_64 missing bundle (rc=$rc)"

# ---------- update_susfs: arm64 flow preserved (download via fake wget) ----------
make_getprop arm64-v8a; make_uname aarch64 "6.6.66-android15-8"
rm -f "$BIN/ksu_susfs"
out=$(run_f 'MODPATH="'"$ROOT"'/badmod" update_susfs 2>&1'); rc=$?
echo "$out" | grep -q "Installing ksu_susfs binary for arm64" \
  && echo "$out" | grep -q "SUSFS updated successfully" && [ $rc = 0 ] \
  && cmp -s "$BIN/ksu_susfs" "$FIX/ksu_susfs_arm64" \
  && ok "update_susfs arm64: upstream download flow intact" \
  || bad "update_susfs arm64 (rc=$rc out: $(echo "$out"|head -2|tr '\n' '|'))"

# ---------- update_susfs: unsupported ABI ----------
make_getprop x86; make_uname i686 "5.10.0"
out=$(run_f 'update_susfs 2>&1'); rc=$?
echo "$out" | grep -q "Only arm64-v8a and x86_64 are supported" && [ $rc != 0 ] \
  && ok "update_susfs: unsupported ABI rejected" \
  || bad "update_susfs unsupported ABI (rc=$rc out: $(echo "$out"|head -1))"

# ---------- download_susfs_guard_lkm: x86_64 fetch + extract ----------
make_getprop x86_64; make_uname x86_64 "6.6.66-android15-8"
rm -f "$LKMDIR"/*
out=$(run_f 'download_susfs_guard_lkm 2>&1'); rc=$?
echo "$out" | grep -q "Downloading susfs_lkm_x64.zip" \
  && [ -f "$LKMDIR/android15-6.6_susfs_guard_lkm.ko" ] && [ $rc = 0 ] \
  && ok "download x64: zip fetched, matching .ko extracted to LKM dir" \
  || bad "download x64 (rc=$rc files: $(ls "$LKMDIR" 2>/dev/null | tr '\n' ' '))"
[ ! -f "$LKMDIR/susfs_insmod" ] \
  && ok "download x64: no susfs_insmod fetched (arm64-only tool)" \
  || bad "download x64 fetched susfs_insmod unexpectedly"

# ---------- load_susfs_lkm: x86_64 loads via ksud ----------
: > "$ROOT/ksud.log"
out=$(run_f 'load_susfs_lkm 2>&1'); rc=$?
echo "$out" | grep -q "LKM loaded successfully (ksud)" && [ $rc = 0 ] \
  && grep -q "insmod $LKMDIR/android15-6.6_susfs_guard_lkm.ko" "$ROOT/ksud.log" \
  && ok "load x64: ksud insmod called with the right .ko" \
  || bad "load x64 (rc=$rc out: $(echo "$out"|head -2|tr '\n' '|'))"

# ---------- download_susfs_guard_lkm: arm64 fetch (.ko + susfs_insmod) ----------
make_getprop arm64-v8a; make_uname aarch64 "6.6.66-android15-8"
rm -f "$LKMDIR"/*
out=$(run_f 'download_susfs_guard_lkm 2>&1'); rc=$?
[ -f "$LKMDIR/susfs_guard_lkm-android15-6.6.ko" ] && [ -f "$LKMDIR/susfs_insmod" ] \
  && echo "$out" | grep -q "susfs_insmod" \
  && ok "download arm64: .ko + susfs_insmod flow intact" \
  || bad "download arm64 (files: $(ls "$LKMDIR" 2>/dev/null | tr '\n' ' '))"

# ---------- download x64: custom kernel without a bundled LKM -> clean refusal ----------
make_getprop x86_64; make_uname x86_64 "5.10.134-013.15.kangaroo.al8.x86_64"
rm -f "$LKMDIR"/*
out=$(run_f 'download_susfs_guard_lkm 2>&1'); rc=$?
echo "$out" | grep -q "No x86_64 LKM available for this kernel" && [ $rc != 0 ] \
  && ok "download x64: unsupported custom kernel refused cleanly (non-fatal to install)" \
  || bad "download x64 custom kernel (rc=$rc out: $(echo "$out" | head -1))"

# ---------- download x64: custom kernel with bundled LKM (LDPlayer 14 case) ----------
make_getprop x86_64; make_uname x86_64 "5.15.178+"
rm -f "$LKMDIR"/*
# stage a module root with the bundled payload, like KernelSU does at install time
mkdir -p "$ROOT/modstage/lkm/x86_64" "$ROOT/modstage/bin/x86_64"
cp "$FIX/susfs_insmod" "$ROOT/modstage/bin/x86_64/susfs_insmod"
printf '# fake bundled ko\n' > "$ROOT/modstage/lkm/x86_64/susfs_guard_lkm-x86_64-5.15.ko"
out=$(run_f 'MODPATH="'"$ROOT"'/modstage" download_susfs_guard_lkm 2>&1'); rc=$?
[ -f "$LKMDIR/susfs_guard_lkm-x86_64-5.15.ko" ] && [ -f "$LKMDIR/susfs_insmod" ] && [ $rc = 0 ] \
  && echo "$out" | grep -q "Installing bundled susfs_guard_lkm-x86_64-5.15.ko" \
  && ok "download x64: LDPlayer 14 staging path installs bundled .ko + loader" \
  || bad "download x64 ldplayer bundled (rc=$rc files: $(ls "$LKMDIR" 2>/dev/null | tr '\n' ' '))"

# ---------- download x64: user-supplied LKM in $SUSFS_LKM wins over bundled ----------
printf '# user rebuilt ko\n' > "$LKMDIR/susfs_guard_lkm-x86_64-5.15.ko"
out=$(run_f 'MODPATH="'"$ROOT"'/modstage" download_susfs_guard_lkm 2>&1'); rc=$?
grep -q "# user rebuilt ko" "$LKMDIR/susfs_guard_lkm-x86_64-5.15.ko" && [ $rc = 0 ] \
  && echo "$out" | grep -q "Using existing susfs_guard_lkm-x86_64-5.15.ko" \
  && ok "download x64: user-supplied LKM wins over the bundled one" \
  || bad "download x64 user LKM precedence (rc=$rc)"
rm -f "$LKMDIR"/*

echo
echo "RESULT: pass=$pass fail=$fail"
[ "$fail" = 0 ]
