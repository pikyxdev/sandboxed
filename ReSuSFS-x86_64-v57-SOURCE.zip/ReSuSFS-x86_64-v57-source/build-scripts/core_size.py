#!/usr/bin/env python3
"""Compute Linux 5.15 module core_layout.size (what /proc/modules prints)
from a .ko ELF: text / ro / ro_after_init / data+bss regions, each page-aligned."""
import subprocess, sys, re

def regions(path):
    out = subprocess.check_output(["readelf", "-SW", path]).decode()
    groups = {"text": 0, "ro": 0, "ro_after_init": 0, "data": 0}
    for line in out.splitlines():
        m = re.match(r"\s*\[\s*\d+\]\s+(\S+)\s+(\S+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+(\S*)\s*(\S*)\s*", line)
        if not m:
            continue
        name, shtype, addr, off, size, es, flags = m.groups()
        if shtype == "NULL":
            continue
        flags = flags.upper()
        if "A" not in flags:  # SHF_ALLOC only
            continue
        sz = int(size, 16)
        if "I" in flags:  # SHT_INIT_ARRAY etc still alloc; keep
            pass
        if name.startswith(".init"):  # init sections live in init_layout, not core
            continue
        if name in (".note.gnu.property", ".note.Linux"):  # notes not in core layout
            # .note sections: kernel 5.15 keeps some notes; module_layout skips non-alloc;
            # notes ARE alloc. Include them (small).
            pass
        if "X" in flags:
            groups["text"] += sz
        elif "W" in flags:
            if name in (".data..ro_after_init",) or "ro_after_init" in name:
                groups["ro_after_init"] += sz
            else:
                groups["data"] += sz
        else:
            groups["ro"] += sz
    return groups

def core_size(path):
    g = regions(path)
    page = 4096
    total = 0
    for k in ("text", "ro", "ro_after_init", "data"):
        total += (g[k] + page - 1) // page * page
    return total, g

for p in sys.argv[1:]:
    t, g = core_size(p)
    print(f"{p.split('/')[-1]:55s} core={t:8d}  (text={g['text']} ro={g['ro']} rai={g['ro_after_init']} data={g['data']})")
