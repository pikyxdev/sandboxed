/* test_sc_v51_host.c - sandbox unit test for the v51 graft logic.
 *
 * Compiles sc_v51.c with -DSC_V51_HOSTTEST on the host and exercises:
 *   1. the cred-offset calibration: success at a NON-vanilla offset (0x790,
 *      deliberately different from the v49 hardcoded 0x788), success at
 *      exactly 0x788, refusal on zero pairs, refusal on two pairs,
 *      refusal on failed init_cred sanity;
 *   2. the SHOW_VERSION / SHOW_VARIANT 20-byte answer layout (string
 *      zero-padded, err=0 at +16);
 *   3. the SHOW_ENABLED_FEATURES 8196-byte answer for several bitmaps,
 *      including the all-armed case whose names straddle the 256-byte
 *      chunk boundary - compared against a reference builder;
 *   4. the entry's gating: observe mode, magic mismatch, uncalibrated uid
 *      gate, non-root uid, root uid + each command, feature command
 *      fallthrough (-22), counter increments;
 *   5. the installer's early refusal gates (entry/handler mismatch,
 *      dispatcher absent) - the patch_text happy path is NOT run on the
 *      host (it would write into the host's own text pages).
 *
 * The host provides same-named definitions for every symbol the graft
 * imports; only the %gs current read is #ifdef'd (sc_v51_host_current).
 */
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>

/* ---- forward declarations of the hosted knobs --------------------------- */
static int g_stage = 3;
static uint64_t g_dispatcher = 0;
static int g_handler_valid = 1, g_have_init_cred = 1, g_fault_uaccess = 0;

/* ---- the kernel surface, hosted ---------------------------------------- */
static unsigned char fake_kernel[0x100000];        /* "kernel" memory blob */
#define FAKE_INIT_TASK   ((uint64_t)(uintptr_t)(fake_kernel + 0x1000))
#define FAKE_INIT_CRED   ((uint64_t)(uintptr_t)(fake_kernel + 0x8000))
#define FAKE_TABLE       ((uint64_t)(uintptr_t)(fake_kernel + 0x10000))
#define FAKE_HANDLER     ((uint64_t)(uintptr_t)(fake_kernel + 0x20000))
static uint64_t fake_task_area[0x10000];           /* current task_structs */
static uint64_t fake_cred_area[0x1000];

void susfs_diag_logf(const char *fmt, ...)
{
        va_list ap;

        va_start(ap, fmt);
        vprintf(fmt, ap);
        va_end(ap);
}

int susfs_current_arm_stage(void) { return g_stage; }

uint64_t ksu_kallsyms_lookup_name(const char *name)
{
        if (!strcmp(name, "init_task"))       return FAKE_INIT_TASK;
        if (!strcmp(name, "init_cred"))       return g_have_init_cred ? FAKE_INIT_CRED : 0;
        if (!strcmp(name, "sys_call_table"))  return FAKE_TABLE;
        if (!strcmp(name, "ksu_syscall_dispatcher")) return g_dispatcher;
        if (!strcmp(name, "__x64_sys_ioperm")) return g_handler_valid ? FAKE_HANDLER : 0;
        return 0;
}

uint64_t susfs_fp_syscall_table(void) { return FAKE_TABLE; }

int ksu_patch_text(void *dst, void *src, uint64_t len, int flags)
{
        memcpy(dst, src, len);
        return 0;
}

uint64_t _copy_from_user(void *to, const void *from, uint64_t n)
{
        if (g_fault_uaccess) return n;
        memcpy(to, from, n);
        return 0;
}

uint64_t _copy_to_user(void *to, const void *from, uint64_t n)
{
        if (g_fault_uaccess) return n;
        memcpy(to, from, n);
        return 0;
}

volatile int susfs_sc_entry_count;
unsigned char sc_full_mode, sc_installed;
uint64_t sc_orig;
unsigned long susfs_current_task_gs_off;
unsigned long susfs_armed_features;
unsigned char *sc_v51_host_current;

/* pull in the graft (statics become same-TU visible) */
#include "../ReSuSFS-x86_64-port/sc_v51.c"

/* ---- helpers ------------------------------------------------------------ */
static int fails = 0;

static void check(const char *label, int cond, const char *detail)
{
        printf("  [%s] %s%s%s\n", cond ? "OK" : "FAIL", label,
               detail && detail[0] ? ": " : "", detail ? detail : "");
        if (!cond) fails++;
}

static void put_pair(uint64_t task, uint32_t off)
{
        *(uint64_t *)(uintptr_t)(task + off) = FAKE_INIT_CRED;
        *(uint64_t *)(uintptr_t)(task + off + 8) = FAKE_INIT_CRED;
}

/* reference features-string builder (straightforward, no chunking) */
static void ref_features(uint64_t feats, char *out)
{
        size_t o = 0;
        size_t i;

        for (i = 0; i < sizeof(sc_v51_feats) / sizeof(sc_v51_feats[0]); i++) {
                size_t l;

                if (sc_v51_feats[i].bit >= 0 && !((feats >> sc_v51_feats[i].bit) & 1))
                        continue;
                l = strlen(sc_v51_feats[i].name);
                memcpy(out + o, sc_v51_feats[i].name, l);
                o += l;
        }
}

/* ---- the tests ---------------------------------------------------------- */
int main(void)
{
        long rc;
        struct sc_v51_regs regs;
        char payload[8196];
        int i;

        memset(fake_kernel, 0, sizeof(fake_kernel));
        memset(fake_task_area, 0, sizeof(fake_task_area));
        memset(fake_cred_area, 0, sizeof(fake_cred_area));
        memset(&regs, 0, sizeof(regs));

        printf("== 1. calibration ==\n");
        *(uint64_t *)(uintptr_t)FAKE_INIT_CRED = 4;   /* usage refcount */

        /* success at a NON-vanilla offset: real_cred@0x788, cred@0x790 */
        put_pair(FAKE_INIT_TASK, 0x788);
        sc_v51_calibrate();
        check("calibrate finds cred at +0x790 (non-vanilla)",
              sc_v51_uid_ok == 1 && sc_v51_cred_off == 0x790, "");

        /* success at exactly the vanilla offset: real_cred@0x780, cred@0x788 */
        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x780);
        sc_v51_calibrate();
        check("calibrate finds cred at +0x788 (vanilla)",
              sc_v51_uid_ok == 1 && sc_v51_cred_off == 0x788, "");

        /* refusal: no adjacent pair */
        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        *(uint64_t *)(uintptr_t)FAKE_INIT_TASK = FAKE_INIT_CRED;
        sc_v51_calibrate();
        check("calibrate refuses with no pair",
              sc_v51_uid_ok == 0 && sc_v51_cred_off == 0, "");

        /* refusal: two pairs (ambiguous) */
        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x100);
        put_pair(FAKE_INIT_TASK, 0x500);
        sc_v51_calibrate();
        check("calibrate refuses with two pairs", sc_v51_uid_ok == 0, "");

        /* refusal: init_cred usage == 0 */
        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x788);
        *(uint64_t *)(uintptr_t)FAKE_INIT_CRED = 0;
        sc_v51_calibrate();
        check("calibrate refuses on usage==0", sc_v51_uid_ok == 0, "");
        *(uint64_t *)(uintptr_t)FAKE_INIT_CRED = 4;

        /* refusal: nonzero gid word inside the uid window */
        *(uint32_t *)(uintptr_t)(FAKE_INIT_CRED + 12) = 1000;
        sc_v51_calibrate();
        check("calibrate refuses on nonzero gid", sc_v51_uid_ok == 0, "");
        *(uint32_t *)(uintptr_t)(FAKE_INIT_CRED + 12) = 0;

        /* restore the good state */
        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x788);
        sc_v51_calibrate();
        check("calibrate re-arms after good state",
              sc_v51_uid_ok == 1 && sc_v51_cred_off == 0x790, "");

        printf("== 2. SHOW_VERSION / SHOW_VARIANT layout ==\n");
        {
                uint64_t task = (uint64_t)(uintptr_t)fake_task_area;
                uint64_t cred = (uint64_t)(uintptr_t)fake_cred_area;

                *(uint64_t *)(uintptr_t)(task + sc_v51_cred_off) = cred;
                *(uint64_t *)(uintptr_t)cred = 2;          /* usage */
                *(uint32_t *)(uintptr_t)(cred + 8) = 0;    /* uid 0 = root */
                sc_v51_host_current = (unsigned char *)(uintptr_t)task;
        }

        memset(payload, 0xAA, sizeof(payload));
        rc = sc_v51_answer_str((uint64_t)(uintptr_t)payload, sc_v51_version);
        check("answer_str rc=0", rc == 0, "");
        check("answer_str payload starts 'v2.3.0'",
              memcmp(payload, "v2.3.0", 6) == 0, "");
        {
                int zero_ok = 1;

                for (i = 6; i < 16; i++)
                        if (payload[i]) zero_ok = 0;
                check("answer_str string zero-padded to 16", zero_ok, "");
        }
        check("answer_str err==0 at +16", *(int *)(uintptr_t)(payload + 16) == 0, "");

        memset(payload, 0xAA, sizeof(payload));
        rc = sc_v51_answer_str((uint64_t)(uintptr_t)payload, sc_v51_variant);
        check("variant rc=0 and 'GKI-LKM'",
              rc == 0 && memcmp(payload, "GKI-LKM", 7) == 0, "");

        rc = sc_v51_answer_str(0, sc_v51_version);
        check("answer_str refuses null payload", rc == -22, "");
        rc = sc_v51_answer_str(0x10, sc_v51_version);
        check("answer_str refuses low payload", rc == -22, "");
        g_fault_uaccess = 1;
        rc = sc_v51_answer_str(0x100000, sc_v51_version);
        check("answer_str -EFAULT on bad pointer", rc == -14, "");
        g_fault_uaccess = 0;

        printf("== 3. SHOW_ENABLED_FEATURES ==\n");
        {
                char want[8196];
                uint64_t bitmaps[] = { 0, 1u << 8, 0x1FD, 0x1FF };
                unsigned t;

                for (t = 0; t < sizeof(bitmaps) / sizeof(bitmaps[0]); t++) {
                        char dbuf[96];

                        memset(want, 0, sizeof(want));
                        ref_features(bitmaps[t], want);
                        memset(payload, 0x55, sizeof(payload));
                        susfs_armed_features = bitmaps[t];
                        rc = sc_v51_answer_features((uint64_t)(uintptr_t)payload);
                        snprintf(dbuf, sizeof(dbuf), "bitmap=0x%lx rc=%ld %s",
                                 (unsigned long)bitmaps[t], rc,
                                 rc == 0 && memcmp(payload, want, 8192) == 0 &&
                                 *(int *)(uintptr_t)(payload + 8192) == 0 ?
                                 "bytes match" : "MISMATCH");
                        check("features answer matches reference (straddles chunks)",
                              rc == 0 && memcmp(payload, want, 8192) == 0 &&
                              *(int *)(uintptr_t)(payload + 8192) == 0, dbuf);
                }
        }
        susfs_armed_features = 0x1FD;

        printf("== 4. entry gating ==\n");
        susfs_sc_entry_count = 0;
        sc_full_mode = 0;
        regs.di = 0xDEADBEEF; regs.si = 0xFAFAFAFA; regs.dx = CMD_SUSFS_SHOW_VERSION;
        regs.r10 = (uint64_t)(uintptr_t)payload;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("observe mode: -22 and counter++",
              rc == -22 && susfs_sc_entry_count == 1, "");

        sc_full_mode = 1;
        regs.di = 0x1234;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("bad magic1: -22", rc == -22, "");
        regs.di = 0xDEADBEEF; regs.si = 0x9999;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("bad magic2: -22", rc == -22, "");
        regs.si = 0xFAFAFAFA;

        *(uint32_t *)(uintptr_t)((uint64_t)(uintptr_t)fake_cred_area + 8) = 10075;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("non-root uid: -22", rc == -22, "");
        *(uint32_t *)(uintptr_t)((uint64_t)(uintptr_t)fake_cred_area + 8) = 0;

        sc_v51_uid_ok = 0;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("uncalibrated uid gate: -22", rc == -22, "");
        sc_v51_uid_ok = 1;

        memset(payload, 0, sizeof(payload));
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("entry SHOW_VERSION answers",
              rc == 0 && memcmp(payload, "v2.3.0", 6) == 0 &&
              *(int *)(uintptr_t)(payload + 16) == 0, "");

        regs.dx = CMD_SUSFS_SHOW_VARIANT;
        memset(payload, 0, sizeof(payload));
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("entry SHOW_VARIANT answers",
              rc == 0 && memcmp(payload, "GKI-LKM", 7) == 0, "");

        regs.dx = CMD_SUSFS_SHOW_ENABLED_FEATURES;
        memset(payload, 0x66, sizeof(payload));
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        {
                char want[8196];

                memset(want, 0, sizeof(want));
                ref_features(0x1FD, want);
                check("entry SHOW_FEATURES answers",
                      rc == 0 && memcmp(payload, want, 8192) == 0 &&
                      *(int *)(uintptr_t)(payload + 8192) == 0, "");
        }

        regs.dx = 0x555e4;   /* a feature command: not handled at this rung */
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("feature command: -22 (CLI keeps 126)", rc == -22, "");
        check("counter counted every entry (9 calls)", susfs_sc_entry_count == 9, "");

        printf("== 4b. wire ABI: literal cmd ids decoded from the stock CLI ==\n");
        /* The v52 lesson: constants can drift from the CLI wire ABI while
         * every constant-based test stays green (internal consistency is
         * not ABI conformance - v51 shipped variant/features swapped and
         * every host test passed).  These use the LITERAL ids from the
         * stock ksu_susfs binary's own dispatch sites, each tied to its
         * payload shape and fail string:
         *   0x555e1  show version           20-byte   (str[16]+err@16)
         *   0x555e2  show enabled_features  8196-byte (str[8192]+err@8192)
         *   0x555e3  show variant           20-byte   (str[16]+err@16) */
        memset(payload, 0x66, sizeof(payload));
        regs.dx = 0x555e2;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        {
                char want[8196];

                memset(want, 0, sizeof(want));
                ref_features(0x1FD, want);
                check("literal 0x555e2 answers enabled_features (8196B)",
                      rc == 0 && memcmp(payload, want, 8192) == 0 &&
                      *(int *)(uintptr_t)(payload + 8192) == 0, "");
        }
        memset(payload, 0x66, sizeof(payload));
        regs.dx = 0x555e3;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("literal 0x555e3 answers variant (20B)",
              rc == 0 && memcmp(payload, "GKI-LKM", 7) == 0 &&
              *(int *)(uintptr_t)(payload + 16) == 0, "");
        memset(payload, 0, sizeof(payload));
        regs.dx = 0x555e1;
        rc = susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
        check("literal 0x555e1 answers version (20B)",
              rc == 0 && memcmp(payload, "v2.3.0", 6) == 0 &&
              *(int *)(uintptr_t)(payload + 16) == 0, "");

        printf("== 5. installer early gates (patch path not host-runnable) ==\n");
        ((uint64_t *)(uintptr_t)FAKE_TABLE)[173] = 0xdeadbeefdeadbeef;
        g_dispatcher = (uint64_t)(uintptr_t)(fake_kernel + 0x40000);
        ((uint64_t *)(uintptr_t)FAKE_TABLE)[134] = g_dispatcher;
        sc_installed = 0;
        rc = susfs_supercall_init();
        check("init refuses on entry/handler mismatch",
              rc == 0 && sc_installed == 0, "");

        ((uint64_t *)(uintptr_t)FAKE_TABLE)[173] = FAKE_HANDLER;
        g_dispatcher = 0;
        rc = susfs_supercall_init();
        check("init refuses when dispatcher not in table",
              rc == 0 && sc_installed == 0, "");

        printf("\n%s (%d failure(s))\n",
               fails ? "SOME CHECKS FAILED" : "ALL HOST CHECKS PASSED", fails);
        return fails ? 1 : 0;
}
