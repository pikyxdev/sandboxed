#!/bin/bash
# End-to-end install simulation of the ReSuSFS x86_64 module zip.
#
# It reproduces, on the build host, exactly what KernelSU does when the zip
# is flashed on LDPlayer 14 (x86_64, kernel 5.15.178+):
#   - the module is extracted to the staging dir /data/adb/modules_update/ReSuSFS
#     and customize.sh runs with MODPATH exported and ui_print() defined;
#   - uname reports "5.15.178+" / x86_64, getprop reports ro.product.cpu.abi=x86_64;
#   - /proc/config.gz, /proc/susfs_path and /sys/module/susfs_guard_lkm are absent
#     (no built-in susfs), so the bundled LKM path must be taken.
# All /data/adb and /data/local/tmp paths are redirected into a throwaway
# sandbox root by textual rewrite, so the real host /data is never touched.
#
# This is the scenario that aborted with
#   "[!] No bundled x86_64 LKM for this kernel (5.15.178+)"
#   "[!] bundled ksu_susfs binary missing from module (...)"
#   "Error: Failed to install module script"
# on v26.10.23-x86_64; it must now install cleanly.
#
# Usage: test_module_install.sh [module_dir]   (default: ../ReSuSFS-x86_64/module)
set -u

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
MODULE="${1:-}"
# works from the workspace (../ReSuSFS-x86_64/module) and from inside the
# port package (../ReSuSFS/module)
[ -z "$MODULE" ] && for cand in "$HERE/../ReSuSFS/module" "$HERE/../ReSuSFS-x86_64/module"; do
        [ -f "$cand/customize.sh" ] && MODULE="$cand" && break
done
[ -n "$MODULE" ] && [ -f "$MODULE/customize.sh" ] || { echo "FATAL: module dir not found (pass it as \$1)"; exit 1; }
MODULE=$(cd "$MODULE" && pwd) || exit 1

ROOT=$(mktemp -d /tmp/resusfs_e2e.XXXXXX)
FAKEBIN="$ROOT/fakebin"
ADB="$ROOT/data/adb"
KSU_BIN="$ADB/ksu/bin"                 # fake /data/adb/ksu/bin
LKMDIR="$ADB/ReSuSFS_LKM"              # fake /data/adb/ReSuSFS_LKM
PERSIST="$ADB/ReSuSFS"                 # fake /data/adb/ReSuSFS (configs)
STAGE="$ADB/modules_update/ReSuSFS"    # fake staging dir (KernelSU extracts here)
MODULES="$ADB/modules/ReSuSFS"        # fake installed module (runtime)
mkdir -p "$FAKEBIN" "$KSU_BIN" "$LKMDIR" "$STAGE" "$MODULES"

pass=0; fail=0
ok()  { echo "PASS: $1"; pass=$((pass+1)); }
bad() { echo "FAIL: $1"; fail=$((fail+1)); }
cleanup() { rm -rf "$ROOT"; }
trap cleanup EXIT

# ---------------------------------------------------------------- fakes -----
printf '#!/bin/sh\n[ "$1" = ro.product.cpu.abi ] && echo x86_64\nexit 0\n' > "$FAKEBIN/getprop"
printf '#!/bin/sh\ncase "$1" in -m) echo x86_64 ;; -r) echo "5.15.178+" ;; *) echo "Linux localhost 5.15.178+ x86_64" ;; esac\n' > "$FAKEBIN/uname"
chmod +x "$FAKEBIN/getprop" "$FAKEBIN/uname"

# fake busybox: delegates to host tools; zcat always "fails" (no CONFIG_KSU_SUSFS
# on the fake device); rmmod is a no-op; wget maps URLs to fixture files.
cat > "$FAKEBIN/busybox" <<'EOF'
#!/bin/bash
cmd="$1"; shift
case "$cmd" in
        zcat)  exit 1 ;;
        rmmod) exit 0 ;;
        wget)
                out=""; url=""; prev=""
                for a in "$@"; do
                        [ "$prev" = "-O" ] && out="$a"
                        [ "$a" = "$out" ] || url="$a"
                        prev="$a"
                done
                echo "fake-wget: $url -> $out" >&2
                exit 1
                ;;
        *)
                if command -v "$cmd" >/dev/null 2>&1; then exec "$cmd" "$@"; else exit 0; fi
                ;;
esac
EOF
chmod +x "$FAKEBIN/busybox"

# fake ksud: records invocations, always succeeds
cat > "$FAKEBIN/ksud" <<EOF
#!/bin/bash
echo "ksud \$*" >> "$ROOT/ksud.log"
exit 0
EOF
chmod +x "$FAKEBIN/ksud"

# ------------------------------------------------------ staging + patching --
# The manager extracts the zip payload into the staging dir; the scripts
# inside it are then patched so the /data/adb tree they hard-code points at
# the sandbox root instead of the host /data.
cp -a "$MODULE/." "$STAGE/"
patch_script() {  # patch_script <file>
        sed -e "s|/data/adb|$ADB|g" -e "s|/data/local/tmp|$ROOT/data/local/tmp|g" "$1"
}
for f in customize.sh utils.sh service.sh post-fs-data.sh late-load.sh \
         action.sh boot-completed.sh uninstall.sh ReSuSFS.sh; do
        patch_script "$STAGE/$f" > "$STAGE/$f.new" && mv "$STAGE/$f.new" "$STAGE/$f"
done

# The manager's install wrapper: ui_print() + sourced customize.sh.
# Run under bash: the harness host has no KernelSU busybox/mksh, and dash
# cannot even PARSE upstream's own process-substitution bashism in
# detect_key_press (never executed on x86_64, and parsed fine by the
# device shell - the on-device log proves it). bash is the local superset.
cat > "$ROOT/installer.sh" <<EOF
#!/bin/bash
ui_print() { echo "\$1"; }
MODPATH="$STAGE"
export MODPATH
. "\$MODPATH/customize.sh"
EOF
chmod +x "$ROOT/installer.sh"

# ------------------------------------------------- test 1: first install ----
echo "=== test 1: first install on LDPlayer-14-like device (5.15.178+, x86_64) ==="
out=$(PATH="$FAKEBIN:$PATH" bash "$ROOT/installer.sh" 2>&1); rc=$?
echo "$out" | sed 's/^/    | /'

[ "$rc" = 0 ] && ok "customize.sh exits 0 (manager installs the module)" \
        || bad "customize.sh rc=$rc (manager reports 'Failed to install module script')"

echo "$out" | grep -q "Installing bundled susfs_guard_lkm-x86_64-5.15.ko" \
        && ok "bundled x86_64 LKM recognized for kernel 5.15.178+" \
        || bad "bundled LKM not installed (out: $(echo "$out" | grep -m1 '\[!\]'))"
echo "$out" | grep -q "Installing bundled susfs_insmod loader" \
        && ok "bundled susfs_insmod loader installed" \
        || bad "susfs_insmod loader missing from install"
echo "$out" | grep -q "Installing bundled x86_64 ksu_susfs CLI" \
        && echo "$out" | grep -q "SUSFS updated successfully" \
        && ok "bundled x86_64 ksu_susfs CLI installed" \
        || bad "ksu_susfs CLI not installed"
echo "$out" | grep -q "creating symlink in" \
        && ok "ReSuSFS command symlink created in ksu/bin" \
        || bad "ksu/bin symlink not created"

echo "$out" | grep -q "No bundled x86_64 LKM" \
        && bad "REGRESSION: 'No bundled x86_64 LKM' still printed" \
        || ok "no 'No bundled x86_64 LKM' failure"
echo "$out" | grep -qi "binary missing\|binary not found" \
        && bad "REGRESSION: ksu_susfs 'missing' failure still printed" \
        || ok "no ksu_susfs 'missing' failure"

# artifacts on the fake device
cmp -s "$LKMDIR/susfs_guard_lkm-x86_64-5.15.ko" "$MODULE/lkm/x86_64/susfs_guard_lkm-x86_64-5.15.ko" \
        && ok "installed .ko is byte-identical to the bundled build" \
        || bad "installed .ko differs from the bundled build"
cmp -s "$LKMDIR/susfs_insmod" "$MODULE/bin/x86_64/susfs_insmod" \
        && [ -x "$LKMDIR/susfs_insmod" ] \
        && ok "installed susfs_insmod is byte-identical + executable" \
        || bad "installed susfs_insmod wrong or not +x"
cmp -s "$KSU_BIN/ksu_susfs" "$MODULE/bin/x86_64/ksu_susfs" \
        && [ -x "$KSU_BIN/ksu_susfs" ] \
        && ok "installed ksu_susfs is byte-identical + executable" \
        || bad "installed ksu_susfs wrong or not +x"
[ "$(readlink "$KSU_BIN/susfs")" = "ksu_susfs" ] && [ "$(readlink "$KSU_BIN/sus")" = "ksu_susfs" ] \
        && ok "susfs/sus convenience symlinks point at ksu_susfs" \
        || bad "susfs/sus symlinks wrong"
[ -f "$PERSIST/config.txt" ] && [ -f "$PERSIST/sus_paths.txt" ] && [ -d "$PERSIST/scripts" ] \
        && ok "persistent config dir populated" \
        || bad "persistent configs missing"
[ -f "$PERSIST/.webui_config/custom.css" ] \
        && ok "webui custom.css moved to persistent dir" \
        || bad "webui custom.css not persisted"
[ "$(readlink "$KSU_BIN/ReSuSFS")" = "$ADB/modules/ReSuSFS/ReSuSFS.sh" ] \
        && ok "ReSuSFS command symlink targets the runtime module path" \
        || bad "ReSuSFS symlink target wrong: $(readlink "$KSU_BIN/ReSuSFS" 2>/dev/null)"

# ------------------------------------------------- test 2: upgrade flash ----
echo "=== test 2: re-flash over an existing install (configs must survive) ==="
echo "# user-edited marker" >> "$PERSIST/config.txt"
marker="HIDE_SUS_MNTS_NON_SU=1 # keep-me"
sed -i "s/^HIDE_SUS_MNTS_NON_SU=.*/$marker/" "$PERSIST/config.txt"
rm -rf "$STAGE"; mkdir -p "$STAGE"; cp -a "$MODULE/." "$STAGE/"
for f in customize.sh utils.sh service.sh post-fs-data.sh late-load.sh \
         action.sh boot-completed.sh uninstall.sh ReSuSFS.sh; do
        patch_script "$STAGE/$f" > "$STAGE/$f.new" && mv "$STAGE/$f.new" "$STAGE/$f"
done
out2=$(PATH="$FAKEBIN:$PATH" bash "$ROOT/installer.sh" 2>&1); rc2=$?
echo "$out2" | sed 's/^/    | /' | head -12

[ "$rc2" = 0 ] && ok "re-flash exits 0" || bad "re-flash rc=$rc2"
grep -q "keep-me" "$PERSIST/config.txt" \
        && ok "user's existing config.txt kept (x86_64 auto-answer = keep)" \
        || bad "user config.txt clobbered on re-flash"
cmp -s "$LKMDIR/susfs_guard_lkm-x86_64-5.15.ko" "$MODULE/lkm/x86_64/susfs_guard_lkm-x86_64-5.15.ko" \
        && ok "LKM still installed after re-flash" || bad "LKM lost on re-flash"

# ------------------------------------------------- test 3: runtime load -----
echo "=== test 3: opt-in custom-kernel load (enable_lkm, tool-first) ==="
rm -rf "$MODULES"; cp -a "$MODULE/." "$MODULES/"
for f in utils.sh service.sh post-fs-data.sh late-load.sh action.sh \
         boot-completed.sh uninstall.sh ReSuSFS.sh; do
        patch_script "$MODULES/$f" > "$MODULES/$f.new" && mv "$MODULES/$f.new" "$MODULES/$f"
done
: > "$ROOT/ksud.log"; : > "$ROOT/insmod.log"
touch "$PERSIST/enable_lkm"      # v26.11.23+ safeguard: custom-kernel load is opt-in
# stub loader: records argv, succeeds. NEVER let the test execute the real
# freestanding loader binary on the host - it would call init_module for real.
cat > "$LKMDIR/susfs_insmod" <<EOF
#!/bin/bash
echo "susfs_insmod \$*" >> "$ROOT/insmod.log"
exit 0
EOF
chmod +x "$LKMDIR/susfs_insmod"
out3=$(FIXTURES="" PATH="$FAKEBIN:$PATH" sh -c "
        MODDIR='$MODULES'
        . '$MODULES/utils.sh' >/dev/null 2>&1
        load_susfs_lkm
" 2>&1); rc3=$?
echo "$out3" | sed 's/^/    | /' | head -8
echo "$out3" | grep -q "LKM loaded successfully (susfs_insmod, custom-kernel path)" && [ "$rc3" = 0 ] \
        && grep -q -- "-v $LKMDIR/susfs_guard_lkm-x86_64-5.15.ko" "$ROOT/insmod.log" \
        && [ ! -s "$ROOT/ksud.log" ] \
        && ok "opt-in load goes through susfs_insmod first (with -v), ksud not even tried" \
        || bad "custom-kernel opt-in load (rc=$rc3 out: $(echo "$out3" | head -1))"

echo "=== test 3b: loader fails -> ksud fallback still reached ==="
cat > "$LKMDIR/susfs_insmod" <<EOF
#!/bin/bash
echo "susfs_insmod \$*" >> "$ROOT/insmod.log"
exit 1
EOF
chmod +x "$LKMDIR/susfs_insmod"
out3b=$(FIXTURES="" PATH="$FAKEBIN:$PATH" sh -c "
        MODDIR='$MODULES'
        . '$MODULES/utils.sh' >/dev/null 2>&1
        load_susfs_lkm
" 2>&1); rc3b=$?
echo "$out3b" | sed 's/^/    | /' | head -8
echo "$out3b" | grep -q "LKM loaded successfully (ksud)" && [ "$rc3b" = 0 ] \
        && grep -q "insmod $LKMDIR/susfs_guard_lkm-x86_64-5.15.ko" "$ROOT/ksud.log" \
        && ok "ksud fallback reached when the absolutizing loader fails" \
        || bad "ksud fallback broken (rc=$rc3b)"

echo "=== test 4: no ksud at all, loader fails -> evidence + clean failure ==="
PATH_NOKSUD="$ROOT/noksud"; mkdir -p "$PATH_NOKSUD"
cp "$FAKEBIN/getprop" "$FAKEBIN/uname" "$FAKEBIN/busybox" "$PATH_NOKSUD/"
out4=$(PATH="$PATH_NOKSUD:$PATH" sh -c "
        MODDIR='$MODULES'
        . '$MODULES/utils.sh' >/dev/null 2>&1
        load_susfs_lkm
" 2>&1); rc4=$?
echo "$out4" | sed 's/^/    | /' | head -8
echo "$out4" | grep -q "\[!\] Failed to load LKM" && [ "$rc4" = 1 ] \
        && echo "$out4" | grep -q "LKM load failure evidence" \
        && ok "failed load reports cleanly + dumps evidence (v26.11.24)" \
        || bad "failed-load path wrong (rc=$rc4)"

echo "=== test 5: real bundled loader smoke-runs on x86_64 host ==="
"$MODULE/bin/x86_64/susfs_insmod" --help >/dev/null 2>&1; rcs=$?
if [ "$rcs" -lt 126 ]; then
        ok "real susfs_insmod executes (rc=$rcs, no signal death)"
else
        bad "real susfs_insmod crashed (rc=$rcs)"
fi
"$MODULE/bin/x86_64/ksu_susfs" show version >/dev/null 2>&1; rck=$?
if [ "$rck" -lt 126 ]; then
        ok "real ksu_susfs executes gracefully without the LKM (rc=$rck)"
else
        bad "real ksu_susfs crashed (rc=$rck)"
fi

echo
echo "RESULT: pass=$pass fail=$fail"
[ "$fail" = 0 ]
