#!/bin/bash
# build_v49_ko.sh - reproducible v26.11.49 x86_64 LKM dual-candidate build.
#
# v49 is THE kCFI PREAMBLE FIX (see kernel/susfs_supercall.c header):
# the five v48 boots (2026-11-24 11:00-11:11) all died 2-5s after init
# returned 0 - always at the FIRST syscall(173) dispatched through the
# patched sys_call_table[173] (the last boot.log line: "supercall self-test
# starting").  Root cause: this clang-17 LTO kernel enforces kCFI, and the
# LIVE dispatch path (KernelSU-Next's my_x64_sys_call, which is NOT __nocfi)
# type-checks the indirect ksu_syscall_table[nr](regs) call: every real
# entry carries the 4-byte type hash immediately before its address, and
# v48's raw-asm thunk had none.  v49 gives the thunk a preamble slot
# (susfs_sc_kcfi_preamble) and replicates the ORIGINAL entry's hash into it
# before the table write.  Wrapper + ABI + CLI (173) all unchanged.
#
# Pipeline identical to build_v48_ko.sh (that one produced the field-proven
# v48 artifacts): a13-ASB + kernel.org in-tree builds, current.h override,
# RETPOLINE/RETHUNK off, MODVERSIONS with the normalized dummy entry,
# payload install into ReSuSFS-x86_64-port/ReSuSFS/module + stamp, CLI
# rebuilt fresh from source and patched 169 -> 173, then build_v49_verify.
set -e
BASE=/home/z/my-project
A13=$BASE/a13-full
KORG=$BASE/linux-5.15.178
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
OUT=$BASE/ReSuSFS-x86_64-port
MOD=$BASE/ReSuSFS-x86_64-port/ReSuSFS/module
V=26.11.49

# 0. tree restore (recycle-proof): re-extract from the kept tarballs
restore_tree() {            # $1 = tarball, $2 = expected dir, $3 = inner name
        local TB=$1 DIR=$2 INNER=$3
        if [ ! -f "$DIR/Makefile" ]; then
                echo "[*] restoring $DIR from $TB"
                rm -rf "$DIR"
                tar -xf "$TB" -C "$BASE"
                if [ "$DIR" != "$BASE/$INNER" ]; then
                        mv "$BASE/$INNER" "$DIR"
                fi
        fi
}
restore_tree "$BASE/linux-5.15.178.tar.xz" "$KORG" "linux-5.15.178"
restore_tree "$BASE/a13-mirror.tar.gz"     "$A13"  "kernel_common-ASB-2025-03-05_13-5.15"

prepare_tree() {          # $1 = tree root, $2 = label
        local TREE=$1 LABEL=$2
        echo "[*] preparing $LABEL tree ($TREE)"

        # current.h override (identical for both trees - the LDPlayer kernel
        # trimmed EXPORT_PER_CPU_SYMBOL(current_task); see restore_build_env.sh)
        CURH="$TREE/arch/x86/include/asm/current.h"
        if ! grep -q susfs_current_task_gs_off "$CURH" 2>/dev/null; then
                cp "$BASE/scripts/current.h.override" "$CURH"
        fi

        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                if [ ! -f .config ]; then
                        make defconfig >/dev/null
                        ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                                --enable PREEMPT --enable SMP \
                                --disable MODULE_UNLOAD --disable X86_5LEVEL \
                                --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY
                fi
                # RETPOLINE/RETHUNK OFF (the v42 profile): the field kernel's
                # kallsyms has NO __x86_indirect_thunk_* symbols - a module
                # importing them resolves them to garbage and its very first
                # indirect call jumps into the void.
                ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                        --enable PREEMPT --enable SMP \
                        --disable MODULE_UNLOAD --disable X86_5LEVEL \
                        --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY \
                        --disable RETPOLINE --disable RETHUNK
                make olddefconfig >/dev/null
                make LOCALVERSION= modules_prepare >/dev/null
        )
        echo "[+] $LABEL tree ready"
}

build_tree() {             # $1 = tree root, $2 = output name
        local TREE=$1 NAME=$2
        echo "[*] building $NAME from $TREE"
        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                make M="$LKM" clean >/dev/null 2>&1 || true
                make LOCALVERSION= M="$LKM" CC=gcc modules 2>&1 | tail -5
                cp -f "$LKM/susfs_guard_lkm.ko" "$OUT/$NAME"
        )
        echo "[+] built: $OUT/$NAME ($(stat -c%s "$OUT/$NAME") bytes)"
}

# 1. trees
[ -f "$BASE/linux-5.15.178.tar.xz" ] || { echo "[!] kernel.org tarball missing"; exit 1; }
[ -f "$BASE/a13-mirror.tar.gz" ] || { echo "[!] a13 tarball missing"; exit 1; }

# 2. current.h override source file (kept as a file so both trees get the
# identical bytes)
if [ ! -f "$BASE/scripts/current.h.override" ]; then
        cp "$KORG/arch/x86/include/asm/current.h" "$BASE/scripts/current.h.override"
fi

prepare_tree "$A13"    "a13-ASB-2025-03"
build_tree   "$A13"    "susfs_guard_lkm-x86_64-android13-5.15.ko"
prepare_tree "$KORG"   "kernel.org-5.15.178"
build_tree   "$KORG"   "susfs_guard_lkm-x86_64-vanilla-5.15.ko"

# 3. payload install + stamp
echo "[*] installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$OUT/susfs_guard_lkm-x86_64-android13-5.15.ko" "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$OUT/susfs_guard_lkm-x86_64-vanilla-5.15.ko"   "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v$V" > "$MOD/lkm/x86_64/.payload_stamp"

# 3b. v49: fresh freestanding userspace (same sources as v48 - the CLI is
# rebuilt so the shipped bytes always match the tree, then patched below;
# susfs_insmod is unchanged and rebuilt from the same source)
gcc -O2 -nostdlib -static-pie -fno-stack-protector -fno-builtin -Wl,-e,_start \
        -o "$MOD/bin/x86_64/ksu_susfs" \
        "$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/tools/susfs_cli_x64.c"
gcc -O2 -nostdlib -static-pie -fno-stack-protector -fno-builtin -Wl,-e,_start \
        -o "$MOD/bin/x86_64/susfs_insmod" \
        "$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/tools/susfs_insmod_x64.c"
chmod 755 "$MOD/bin/x86_64/ksu_susfs" "$MOD/bin/x86_64/susfs_insmod"

# 4. CLI patches (v45 payload.err contract FIRST - it nops the nine
#    `syscall; test rax,rax; jne fail` return-checks so the CLI reads the
#    answer from payload.err - THEN the v47 syscall number 169 -> 173;
#    both unchanged in v49)
echo "[*] patching the CLI return-checks (v45 payload.err contract)"
python3 "$BASE/scripts/patch_ksu_cli_v45.py" "$MOD/bin/x86_64/ksu_susfs"
echo "[*] patching the CLI supercall sites (169 -> 173)"
python3 "$BASE/scripts/patch_ksu_cli_v47.py" "$MOD/bin/x86_64/ksu_susfs"

# 5. verification (after the CLI patch: the verifier checks the patched sites)
python3 "$BASE/scripts/build_v49_verify.py"

echo "[+] v49 module build complete (payload staged in $MOD)"
