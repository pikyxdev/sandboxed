#!/bin/bash
# Unit tests for the arch-aware logic added to module/utils.sh.
# Uses fake `uname`/`getprop` in PATH to simulate devices without touching
# the real system.
set -u
PORT=/home/z/my-project/ReSuSFS-x86_64
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
FAKEBIN="$HERE/fakebin"
mkdir -p "$FAKEBIN"

pass=0; fail=0
ok()  { echo "PASS: $1"; pass=$((pass+1)); }
bad() { echo "FAIL: $1"; fail=$((fail+1)); }

make_uname() {  # make_uname <machine> <release>
    printf '#!/bin/sh\n[ "$1" = -m ] && echo "%s"\n[ "$1" = -r ] && echo "%s"\nexit 0\n' "$1" "$2" > "$FAKEBIN/uname"
    chmod +x "$FAKEBIN/uname"
}
make_getprop() {  # make_getprop <abi|none>
    if [ "$1" = none ]; then rm -f "$FAKEBIN/getprop"; else
        printf '#!/bin/sh\n[ "$1" = ro.product.cpu.abi ] && echo "%s"\nexit 0\n' "$1" > "$FAKEBIN/getprop"
        chmod +x "$FAKEBIN/getprop"
    fi
}

run_utils() {  # evaluate functions from utils.sh in a subshell with fake PATH
    PATH="$FAKEBIN:$PATH" sh -c '
        MODDIR="'"$PORT"'/module"
        . "'"$PORT"'/module/utils.sh" >/dev/null 2>&1
        '"$1"'
    '
}

# ---- get_device_abi ----
make_uname x86_64 "5.10.134-x"
make_getprop none
out=$(run_utils 'get_device_abi'); rc=$?
[ "$out" = "x86_64" ] && [ $rc = 0 ] && ok "abi: uname fallback x86_64" || bad "abi uname fallback (got '$out' rc=$rc)"

make_uname aarch64 "5.10.134-x"
out=$(run_utils 'get_device_abi'); rc=$?
[ "$out" = "arm64-v8a" ] && [ $rc = 0 ] && ok "abi: uname fallback aarch64" || bad "abi uname aarch64 (got '$out' rc=$rc)"

make_uname x86_64 "5.10.134-x"   # getprop wins over lying uname (arm translation)
make_getprop arm64-v8a
out=$(run_utils 'get_device_abi'); rc=$?
[ "$out" = "arm64-v8a" ] && ok "abi: getprop authoritative over uname" || bad "abi getprop authority (got '$out')"

make_getprop x86_64
out=$(run_utils 'get_device_abi'); rc=$?
[ "$out" = "x86_64" ] && ok "abi: getprop x86_64" || bad "abi getprop x86_64 (got '$out')"

# ---- get_susfs_guard_lkm (x86_64 KMI mapping; patch level dropped, as upstream) ----
make_getprop x86_64
for rel in "5.10.101-android12-9" "5.10.168-android13-8" "5.15.123-android13-24" \
           "5.15.149-android14-6" "6.1.99-android14-13" "6.6.66-android15-8" \
           "6.12.10-android16-7" "6.18.1-android17-1"; do
    ver=$(echo "$rel" | cut -d- -f1 | cut -d. -f1,2)
    and=$(echo "$rel" | sed -n 's/.*-\(android[0-9]*\)-.*/\1/p')
    exp="${and}-${ver}_susfs_guard_lkm.ko"
    make_uname x86_64 "$rel"
    out=$(run_utils 'get_susfs_guard_lkm'); rc=$?
    [ "$out" = "$exp" ] && [ $rc = 0 ] && ok "lkm x64: $rel -> $exp" || bad "lkm x64 $rel (got '$out' rc=$rc)"
done

# ---- get_susfs_guard_lkm (arm64 KMI mapping preserved) ----
make_getprop arm64-v8a
make_uname aarch64 "6.6.66-android15-8"
out=$(run_utils 'get_susfs_guard_lkm'); rc=$?
[ "$out" = "susfs_guard_lkm-android15-6.6.ko" ] && [ $rc = 0 ] && ok "lkm arm64: naming preserved" || bad "lkm arm64 (got '$out' rc=$rc)"

# ---- custom (non-GKI) x86_64 kernel -> bundled-series name resolution ----
make_getprop x86_64
make_uname x86_64 "5.10.134-013.15.kangaroo.al8.x86_64"
out=$(run_utils 'get_susfs_guard_lkm'); rc=$?
[ "$out" = "susfs_guard_lkm-x86_64-5.10.ko" ] && [ $rc = 0 ] && ok "lkm x64: custom kernel -> bundled-series name" || bad "lkm custom x64 (got '$out' rc=$rc)"

# ---- LDPlayer 14 exact release -> bundled 5.15 build ----
make_uname x86_64 "5.15.178+"
out=$(run_utils 'get_susfs_guard_lkm'); rc=$?
[ "$out" = "susfs_guard_lkm-x86_64-5.15.ko" ] && [ $rc = 0 ] && ok "lkm x64: LDPlayer 14 '5.15.178+' -> bundled 5.15 ko" || bad "lkm ldplayer (got '$out' rc=$rc)"

# ---- update_susfs: unsupported ABI rejected once DEST exists (deep harness covers it) ----
# (sandbox has no /data/adb/ksu/bin, so the DEST check fires first here — same as upstream order)
make_uname x86_64 "5.10.134-x"
make_getprop x86_64
out=$(run_utils 'update_susfs 2>&1 | head -2')
echo "$out" | grep -q "not existed, installation aborted" && ok "update_susfs: missing ksu bin dir aborted (upstream order)" || bad "update_susfs dest dir (got '$out')"

echo
echo "RESULT: pass=$pass fail=$fail"
[ "$fail" = 0 ]
