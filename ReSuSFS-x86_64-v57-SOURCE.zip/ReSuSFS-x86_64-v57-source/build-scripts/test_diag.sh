#!/bin/sh
# Functional dry-run of the v26.11.23 safe-diagnostic layer.
# Simulates the module environment with fake dirs + a stub ksu_susfs and
# exercises: log_boot, run_gated receipts/watchdog, run_stage_scripts
# (commented lists -> no-op), apply_cmdline_bootconfig hardening, and the
# stage wrappers' skip-recovery path.
# (no set -u: module scripts run under plain sh, where unset vars are empty)

FAKE=/tmp/resusfs_dryrun
rm -rf "$FAKE"
mkdir -p "$FAKE/modules/ReSuSFS" "$FAKE/persistent" "$FAKE/ksu_bin" "$FAKE/bin"

# fake module tree: utils.sh + ReSuSFS.sh from the build dir
cp /home/z/my-project/build-v26.11.23/utils.sh    "$FAKE/modules/ReSuSFS/"
cp /home/z/my-project/build-v26.11.23/ReSuSFS.sh  "$FAKE/modules/ReSuSFS/"
cp /home/z/my-project/build-v26.11.23/module.prop "$FAKE/modules/ReSuSFS/"
# fake persistent config (what handle_files installs from configs/)
cp /home/z/my-project/build-v26.11.23/configs/scripts_bootcompleted.txt "$FAKE/persistent/"
cp /home/z/my-project/build-v26.11.23/configs/scripts_postfs.txt         "$FAKE/persistent/"
cp /home/z/my-project/build-v26.11.23/configs/config.txt                "$FAKE/persistent/"
cp /home/z/my-project/build-v26.11.23/configs/cmdline_or_bootconfig.txt "$FAKE/persistent/"
mkdir -p "$FAKE/persistent/scripts"
cp /home/z/my-project/build-v26.11.23/configs/scripts/*.sh "$FAKE/persistent/scripts/"
touch "$FAKE/persistent/scripts_cron.txt"

# stub ksu_susfs that records every call and answers like a live LKM
cat > "$FAKE/ksu_bin/ksu_susfs" <<'EOF'
#!/bin/sh
echo "ksu_susfs-stub: $*" >> /tmp/resusfs_dryrun/super_calls.log
case "$1" in
  show) case "$2" in
          version) echo "v1.4.x-LKM";;
          variant) echo "LKM";;
          enabled_features) echo "sus_path"; echo "sus_map"; echo "kstat";;
        esac ;;
  *) exit 0 ;;
esac
EOF
chmod +x "$FAKE/ksu_bin/ksu_susfs"

# date/sync/getprop stubs
mkdir -p "$FAKE/bin"
cat > "$FAKE/bin/getprop" <<'EOF'
#!/bin/sh
[ "$1" = "sys.boot_completed" ] && echo 1 && exit 0
echo ""
EOF
chmod +x "$FAKE/bin/getprop"

# fake boot id (different from the "current" one to simulate a previous boot)
echo "aaaa1111bbbb2222cccc3333dddd4444" > "$FAKE/prev_boot_id"
echo "eeee5555ffff6666aaaa7777bbbb8888" > "$FAKE/cur_boot_id"

# sourced environment mirroring the real scripts
MODDIR="$FAKE/modules/ReSuSFS"
. "$MODDIR/utils.sh"

# redirect the diagnostic paths to the fake persistent dir
PERSISTENT_DIR="$FAKE/persistent"
LOG_DIR="$PERSISTENT_DIR/logs"
BOOT_LOG="$LOG_DIR/boot.log"
DIAG_LOG="$LOG_DIR/diagnose.log"
RECEIPT_DIR="$LOG_DIR/receipts"
mkdir -p "$RECEIPT_DIR"

PATH="$FAKE/bin:$PATH"

pass=0; fail=0
check() {
  if [ "$2" = "$3" ]; then pass=$((pass+1)); echo "PASS: $1"
  else fail=$((fail+1)); echo "FAIL: $1 (expected [$3] got [$2])"; fi
}

echo "== T1: log_boot writes file + kmsg-safe =="
log_boot "hello log"
check "boot.log line count" "$(wc -l < "$BOOT_LOG")" "1"
check "boot.log content" "$(sed 's/^\[[^]]*\] //' "$BOOT_LOG")" "hello log"

echo "== T2: run_gated happy path =="
run_gated t2 5 /bin/echo hi > /dev/null 2>&1
check "t2 rc" "$?" "0"
check "t2 receipt removed" "$([ -f "$RECEIPT_DIR/t2.open" ] && echo present || echo gone)" "gone"

echo "== T3: run_gated skip-on-open-receipt (previous boot) =="
echo "2026-11-22 04:34:00 boot=aaaa1111" > "$RECEIPT_DIR/t3.open"
run_gated t3 5 /bin/echo hi > /dev/null 2>&1
check "t3 skipped rc" "$?" "0"
check "t3 skips counter" "$(cat "$RECEIPT_DIR/t3.skips")" "1"
check "t3 open receipt cleared" "$([ -f "$RECEIPT_DIR/t3.open" ] && echo present || echo gone)" "gone"
grep -q "WATCHDOG: 't3' never finished" "$BOOT_LOG"
check "t3 watchdog log line" "$?" "0"

echo "== T4: run_gated quarantine after second skip =="
echo "2026-11-22 04:34:00 boot=aaaa1111" > "$RECEIPT_DIR/t4.open"
echo 1 > "$RECEIPT_DIR/t4.skips"
run_gated t4 5 /bin/echo hi > /dev/null 2>&1
check "t4 second skip counter" "$(cat "$RECEIPT_DIR/t4.skips" 2>/dev/null || echo none)" "2"
# now simulate a third boot: open receipt from prev boot + skips=2 -> quarantined
echo "2026-11-22 04:34:00 boot=aaaa1111" > "$RECEIPT_DIR/t5.open"
echo 2 > "$RECEIPT_DIR/t5.skips"
run_gated t5 5 /bin/echo hi > /dev/null 2>&1
grep -q "quarantined" "$BOOT_LOG"
check "t5 quarantine logged" "$?" "0"

echo "== T5: run_gated success resets skips =="
echo 1 > "$RECEIPT_DIR/t2.skips"
run_gated t2 5 /bin/echo again > /dev/null 2>&1
check "t2 skips cleared" "$([ -f "$RECEIPT_DIR/t2.skips" ] && echo present || echo gone)" "gone"

echo "== T6: scripts lists are inert (comments only) =="
USER_SCRIPTS_DIR="$PERSISTENT_DIR/scripts"
out="$(sed 's/#.*//' "$PERSISTENT_DIR/scripts_bootcompleted.txt" | grep -v '^[[:space:]]*$')"
check "bootcompleted list empty" "$out" ""
out="$(sed 's/#.*//' "$PERSISTENT_DIR/scripts_postfs.txt" | grep -v '^[[:space:]]*$')"
check "postfs list empty" "$out" ""

echo "== T7: apply_cmdline_bootconfig refuses comment-only file =="
SUSFS_BIN="$FAKE/ksu_bin/ksu_susfs"
: > "$FAKE/super_calls.log"
# emulate the function body from ReSuSFS.sh (persistence paths redirected)
file="$PERSISTENT_DIR/cmdline_or_bootconfig.txt"
list=$(sed 's/#.*//' "$file" | grep -v '^[[:space:]]*$')
if [ -z "$list" ]; then echo "[*] cmdline/bootconfig list empty, skipping"; else
  "$SUSFS_BIN" set_cmdline_or_bootconfig "$file"; fi
check "no set_cmdline supercall fired" "$(grep -c set_cmdline "$FAKE/super_calls.log")" "0"

echo "== T8: stage wrappers skip-recovery flow (boot-completed.sh logic) =="
# simulate: stage-late hung on previous boot -> receipt open
echo "2026-11-22 04:34:00 boot=aaaa1111" > "$RECEIPT_DIR/stage-late.open"
run_gated stage-late 5 /bin/echo stage-late-work > /dev/null 2>&1
check "stage-late skipped" "$?" "0"
grep -q "WATCHDOG: 'stage-late' never finished" "$BOOT_LOG"
check "stage-late watchdog line" "$?" "0"

echo
echo "== summary: $pass pass, $fail fail =="
[ "$fail" -eq 0 ]
