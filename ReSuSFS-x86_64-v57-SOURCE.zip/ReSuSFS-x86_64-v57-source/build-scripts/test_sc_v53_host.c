/* test_sc_v53_host.c - sandbox unit test for the v53 graft (feature rung).
 *
 * Compiles sc_v53.c with -DSC_V51_HOSTTEST on the host.  Inherits the
 * v51/v52 coverage (calibration, SHOW layouts, entry gating, installer
 * gates) and adds the v53 FEATURE RUNG cases:
 *   6.  add_sus_path via the entry with the LITERAL wire id 0x55550:
 *       err=0 at +256, rc=0, silent-success shape (the stock CLI reads
 *       only payload.err); path stored in slot 0;
 *   7.  add_sus_path_loop via 0x55553: stored with the loop flag;
 *   8.  dedupe: same path again (either flavor) -> err=0, no new slot,
 *       dups counter++;
 *   9.  validation: no leading '/' -> err=-22; empty -> -22; path with
 *       no NUL in 256 bytes (255 chars + 1 more) -> err=-36;
 *  10.  capacity: fill the table to 32, the 33rd distinct path -> -28
 *       (-ENOSPC); the readback still answers;
 *  11.  hide_sus_mnts_for_non_su_procs via 0x55561: byte 0/1 recorded,
 *       err=0 at +4;
 *  12.  the private readback 0x55f53: 8196-byte answer, err=0 at +8192,
 *       dump text contains the counters and every stored path, ends with
 *       the slots_used summary; a table overflowing the 8192-byte dump
 *       truncates with the truncated= marker and never overflows;
 *  13.  EFAULT shapes: bad payload pointer -> rc=-14 for every handler;
 *  14.  regression: after all feature calls, the three SHOW commands
 *       still answer (the transport is unchanged), and set_uname
 *       (0x55590) stays not-handled (-22).
 *
 * Build: gcc -DSC_V51_HOSTTEST -O1 -o /tmp/test_sc_v53_host scripts/test_sc_v53_host.c
 */
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>

/* ---- forward declarations of the hosted knobs --------------------------- */
static int g_stage = 3;
static uint64_t g_dispatcher = 0;
static int g_handler_valid = 1, g_have_init_cred = 1, g_fault_uaccess = 0;

/* ---- the kernel surface, hosted ---------------------------------------- */
static unsigned char fake_kernel[0x100000];        /* "kernel" memory blob */
#define FAKE_INIT_TASK   ((uint64_t)(uintptr_t)(fake_kernel + 0x1000))
#define FAKE_INIT_CRED   ((uint64_t)(uintptr_t)(fake_kernel + 0x8000))
#define FAKE_TABLE       ((uint64_t)(uintptr_t)(fake_kernel + 0x10000))
#define FAKE_HANDLER     ((uint64_t)(uintptr_t)(fake_kernel + 0x20000))
static uint64_t fake_task_area[0x10000];           /* current task_structs */
static uint64_t fake_cred_area[0x1000];

void susfs_diag_logf(const char *fmt, ...)
{
        va_list ap;

        va_start(ap, fmt);
        vprintf(fmt, ap);
        va_end(ap);
}

int susfs_current_arm_stage(void) { return g_stage; }

uint64_t ksu_kallsyms_lookup_name(const char *name)
{
        if (!strcmp(name, "init_task"))       return FAKE_INIT_TASK;
        if (!strcmp(name, "init_cred"))       return g_have_init_cred ? FAKE_INIT_CRED : 0;
        if (!strcmp(name, "sys_call_table"))  return FAKE_TABLE;
        if (!strcmp(name, "ksu_syscall_dispatcher")) return g_dispatcher;
        if (!strcmp(name, "__x64_sys_ioperm")) return g_handler_valid ? FAKE_HANDLER : 0;
        return 0;
}

uint64_t susfs_fp_syscall_table(void) { return FAKE_TABLE; }

int ksu_patch_text(void *dst, void *src, uint64_t len, int flags)
{
        memcpy(dst, src, len);
        return 0;
}

uint64_t _copy_from_user(void *to, const void *from, uint64_t n)
{
        if (g_fault_uaccess) return n;
        memcpy(to, from, n);
        return 0;
}

uint64_t _copy_to_user(void *to, const void *from, uint64_t n)
{
        if (g_fault_uaccess) return n;
        memcpy(to, from, n);
        return 0;
}

volatile int susfs_sc_entry_count;
unsigned char sc_full_mode, sc_installed;
uint64_t sc_orig;
unsigned long susfs_current_task_gs_off;
unsigned long susfs_armed_features;
unsigned char *sc_v51_host_current;

/* pull in the graft (statics become same-TU visible) */
#include "../ReSuSFS-x86_64-port/sc_v53.c"

/* ---- helpers ------------------------------------------------------------ */
static int fails = 0;

static void check(const char *label, int cond, const char *detail)
{
        printf("  [%s] %s%s%s\n", cond ? "OK" : "FAIL", label,
               detail && detail[0] ? ": " : "", detail ? detail : "");
        if (!cond) fails++;
}

static void put_pair(uint64_t task, uint32_t off)
{
        *(uint64_t *)(uintptr_t)(task + off) = FAKE_INIT_CRED;
        *(uint64_t *)(uintptr_t)(task + off + 8) = FAKE_INIT_CRED;
}

/* reference features-string builder (straightforward, no chunking) */
static void ref_features(uint64_t feats, char *out)
{
        size_t o = 0;
        size_t i;

        for (i = 0; i < sizeof(sc_v51_feats) / sizeof(sc_v51_feats[0]); i++) {
                size_t l;

                if (sc_v51_feats[i].bit >= 0 && !((feats >> sc_v51_feats[i].bit) & 1))
                        continue;
                l = strlen(sc_v51_feats[i].name);
                memcpy(out + o, sc_v51_feats[i].name, l);
                o += l;
        }
}

/* one supercall through the REAL entry, with a fresh payload buffer */
static char sc_payload[8196];
static long entry_call(uint32_t cmd, void *payload)
{
        struct sc_v51_regs regs;

        memset(&regs, 0, sizeof(regs));
        regs.di = 0xDEADBEEF;
        regs.si = 0xFAFAFAFA;
        regs.dx = cmd;
        regs.r10 = (uint64_t)(uintptr_t)payload;
        return susfs_sc_entry((const struct pt_regs *)(uintptr_t)&regs);
}

/* fill an add_sus_path-shaped payload: path + err seed 126 at +256 */
static void fill_path_payload(char *p, const char *path)
{
        memset(p, 0, 260);
        if (path)
                snprintf(p, 256, "%s", path);
        *(int *)(uintptr_t)(p + 256) = 126;
}

/* ---- the tests ---------------------------------------------------------- */
int main(void)
{
        long rc;
        char payload[8196];
        int i;

        memset(fake_kernel, 0, sizeof(fake_kernel));
        memset(fake_task_area, 0, sizeof(fake_task_area));
        memset(fake_cred_area, 0, sizeof(fake_cred_area));
        memset(&sc_v53_paths, 0, sizeof(sc_v53_paths));
        sc_v53_next_slot = 0;
        sc_v53_add_calls = 0;
        sc_v53_dups_skipped = 0;
        sc_v53_toggle_calls = 0;
        sc_v53_hide_mnts_on = 0;

        printf("== 1. calibration (inherited v51 coverage) ==\n");
        *(uint64_t *)(uintptr_t)FAKE_INIT_CRED = 4;   /* usage refcount */

        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x788);
        sc_v51_calibrate();
        check("calibrate finds cred at +0x790 (non-vanilla)",
              sc_v51_uid_ok == 1 && sc_v51_cred_off == 0x790, "");

        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x780);
        sc_v51_calibrate();
        check("calibrate finds cred at +0x788 (vanilla)",
              sc_v51_uid_ok == 1 && sc_v51_cred_off == 0x788, "");

        /* restore the good state for the rest of the run */
        memset((void *)(uintptr_t)FAKE_INIT_TASK, 0, SC_V51_TASK_SCAN);
        put_pair(FAKE_INIT_TASK, 0x788);
        sc_v51_calibrate();
        check("calibrate armed",
              sc_v51_uid_ok == 1 && sc_v51_cred_off == 0x790, "");

        printf("== 2. SHOW layouts (inherited) ==\n");
        {
                uint64_t task = (uint64_t)(uintptr_t)fake_task_area;
                uint64_t cred = (uint64_t)(uintptr_t)fake_cred_area;

                *(uint64_t *)(uintptr_t)(task + sc_v51_cred_off) = cred;
                *(uint64_t *)(uintptr_t)cred = 2;          /* usage */
                *(uint32_t *)(uintptr_t)(cred + 8) = 0;    /* uid 0 = root */
                sc_v51_host_current = (unsigned char *)(uintptr_t)task;
        }
        sc_full_mode = 1;

        memset(payload, 0, sizeof(payload));
        rc = entry_call(CMD_SUSFS_SHOW_VERSION, payload);
        check("SHOW_VERSION answers v2.3.0",
              rc == 0 && memcmp(payload, "v2.3.0", 6) == 0 &&
              *(int *)(uintptr_t)(payload + 16) == 0, "");

        susfs_armed_features = 0x1FD;
        memset(payload, 0x66, sizeof(payload));
        rc = entry_call(CMD_SUSFS_SHOW_ENABLED_FEATURES, payload);
        {
                char want[8196];

                memset(want, 0, sizeof(want));
                ref_features(0x1FD, want);
                check("SHOW_ENABLED_FEATURES matches reference",
                      rc == 0 && memcmp(payload, want, 8192) == 0 &&
                      *(int *)(uintptr_t)(payload + 8192) == 0, "");
        }

        memset(payload, 0, sizeof(payload));
        rc = entry_call(CMD_SUSFS_SHOW_VARIANT, payload);
        check("SHOW_VARIANT answers GKI-LKM",
              rc == 0 && memcmp(payload, "GKI-LKM", 7) == 0, "");

        printf("== 3. v53 feature rung: add_sus_path (literal 0x55550) ==\n");
        fill_path_payload(sc_payload, "/data/local/tmp/.resusfs_v53_selftest");
        rc = entry_call(0x55550, sc_payload);
        check("add_sus_path rc=0 (silent success shape)",
              rc == 0, "");
        check("add_sus_path err=0 at +256 (the CLI's only read)",
              *(int *)(uintptr_t)(sc_payload + 256) == 0, "");
        check("path stored in slot 0",
              sc_v53_paths[0][SC_V53_USED_OFF] == 1 &&
              memcmp(sc_v53_paths[0], "/data/local/tmp/.resusfs_v53_selftest",
                     sizeof("/data/local/tmp/.resusfs_v53_selftest") - 1) == 0, "");
        check("slot 0 not loop flavor",
              sc_v53_paths[0][SC_V53_LOOP_OFF] == 0, "");
        check("add_calls counted", sc_v53_add_calls == 1, "");

        printf("== 4. add_sus_path_loop (literal 0x55553) ==\n");
        fill_path_payload(sc_payload, "/data/local/tmp/.resusfs_v53_selftest_loop");
        rc = entry_call(0x55553, sc_payload);
        check("add_sus_path_loop rc=0 err=0",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == 0, "");
        check("path stored in slot 1 with loop flag",
              sc_v53_paths[1][SC_V53_USED_OFF] == 1 &&
              sc_v53_paths[1][SC_V53_LOOP_OFF] == 1, "");

        printf("== 5. dedupe (both orders) ==\n");
        fill_path_payload(sc_payload, "/data/local/tmp/.resusfs_v53_selftest");
        rc = entry_call(0x55550, sc_payload);
        check("dup via add_sus_path: rc=0 err=0, no new slot",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == 0 &&
              sc_v53_paths[2][SC_V53_USED_OFF] == 0, "");
        fill_path_payload(sc_payload, "/data/local/tmp/.resusfs_v53_selftest_loop");
        rc = entry_call(0x55550, sc_payload);   /* loop path via the OTHER flavor */
        check("dup across flavors: rc=0 err=0",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == 0 &&
              sc_v53_paths[2][SC_V53_USED_OFF] == 0, "");
        check("dups counter == 2", sc_v53_dups_skipped == 2, "");

        printf("== 6. validation ==\n");
        fill_path_payload(sc_payload, "relative/path");
        rc = entry_call(0x55550, sc_payload);
        check("no leading '/': err=-22",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == -22, "");
        fill_path_payload(sc_payload, NULL);   /* empty path */
        rc = entry_call(0x55550, sc_payload);
        check("empty path: err=-22",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == -22, "");
        {
                /* no NUL anywhere in path[256]: 256 non-zero bytes */
                u32 before_slot = sc_v53_next_slot;

                memset(sc_payload, 'a', 256);
                *(int *)(uintptr_t)(sc_payload + 256) = 126;
                rc = entry_call(0x55550, sc_payload);
                check("path with no NUL in 256 bytes: err=-36, not stored",
                      rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == -36 &&
                      sc_v53_next_slot == before_slot, "");
                /* exactly 255 chars + NUL is legal */
                fill_path_payload(sc_payload, "/255chars is fine when NUL lands at [255]");
                memset(sc_payload, 'a', 255);
                sc_payload[0] = '/';
                sc_payload[255] = 0;
                *(int *)(uintptr_t)(sc_payload + 256) = 126;
                rc = entry_call(0x55550, sc_payload);
                check("exactly-255-char path accepted (err=0)",
                      rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == 0, "");
        }

        printf("== 7. hide_sus_mnts (literal 0x55561) ==\n");
        memset(sc_payload, 0, 8);
        sc_payload[0] = 1;
        *(int *)(uintptr_t)(sc_payload + 4) = 126;
        rc = entry_call(0x55561, sc_payload);
        check("hide_mnts on: rc=0 err=0 at +4",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 4) == 0, "");
        check("toggle recorded (1)", sc_v53_hide_mnts_on == 1, "");
        sc_payload[0] = 0;
        *(int *)(uintptr_t)(sc_payload + 4) = 126;
        rc = entry_call(0x55561, sc_payload);
        check("hide_mnts off: rc=0 err=0, recorded (0)",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 4) == 0 &&
              sc_v53_hide_mnts_on == 0, "");
        check("toggle_calls counted", sc_v53_toggle_calls == 2, "");

        printf("== 8. readback (private 0x55f53) ==\n");
        memset(sc_payload, 0x44, sizeof(sc_payload));
        *(int *)(uintptr_t)(sc_payload + 8192) = 126;
        rc = entry_call(0x55f53, sc_payload);
        check("readback rc=0 err=0 at +8192",
              rc == 0 && *(int *)(uintptr_t)(sc_payload + 8192) == 0, "");
        check("readback marker present",
              strncmp(sc_payload, "v53-feature-rung", 16) == 0, "");
        check("readback lists the stored paths",
              strstr(sc_payload, "/data/local/tmp/.resusfs_v53_selftest") != NULL &&
              strstr(sc_payload, "/data/local/tmp/.resusfs_v53_selftest_loop") != NULL, "");
        check("readback counts add_calls and dups",
              strstr(sc_payload, "add_calls=") != NULL &&
              strstr(sc_payload, "dups=2") != NULL, "");
        check("readback ends with the slots_used summary",
              strstr(sc_payload, "slots_used=") != NULL &&
              strstr(sc_payload, "loops=1") != NULL, "");
        printf("    dump: %.700s\n", sc_payload);

        printf("== 9. capacity: fill to 32, next distinct -> ENOSPC ==\n");
        {
                char big[64];
                int n = 0, guard = 0;

                /* fill with distinct paths until the allocator hits 32
                 * (dynamic: earlier tests already consumed slots) */
                while (sc_v53_next_slot < 32 && guard++ < 64) {
                        snprintf(big, sizeof(big), "/data/local/tmp/cap/%d", n++);
                        fill_path_payload(sc_payload, big);
                        rc = entry_call(0x55550, sc_payload);
                        if (rc != 0 || *(int *)(uintptr_t)(sc_payload + 256) != 0) {
                                check("capacity fill", 0, "unexpected err mid-fill");
                                break;
                        }
                }
                check("all 32 slots allocated (next_slot==32)",
                      sc_v53_next_slot == 32, "");
                {
                        u32 used = 0;

                        for (i = 0; i < 32; i++)
                                used += sc_v53_paths[i][SC_V53_USED_OFF] ? 1 : 0;
                        check("every allocated slot is used", used == 32, "");
                }
                fill_path_payload(sc_payload, "/data/local/tmp/one/too/many");
                rc = entry_call(0x55550, sc_payload);
                check("next distinct path with full table: err=-28 (ENOSPC)",
                      rc == 0 && *(int *)(uintptr_t)(sc_payload + 256) == -28, "");
                memset(sc_payload, 0x44, sizeof(sc_payload));
                *(int *)(uintptr_t)(sc_payload + 8192) = 126;
                rc = entry_call(0x55f53, sc_payload);
                check("readback still answers with a full table",
                      rc == 0 && *(int *)(uintptr_t)(sc_payload + 8192) == 0, "");
                check("readback reports slots_used=32/32",
                      strstr(sc_payload, "slots_used=32/32") != NULL, "");
        }

        printf("== 10. EFAULT shapes ==\n");
        g_fault_uaccess = 1;
        rc = entry_call(0x55550, (void *)(uintptr_t)0x100000);
        check("add_sus_path bad pointer: rc=-14", rc == -14, "");
        rc = entry_call(0x55561, (void *)(uintptr_t)0x100000);
        check("hide_mnts bad pointer: rc=-14", rc == -14, "");
        rc = entry_call(0x55f53, (void *)(uintptr_t)0x100000);
        check("readback bad pointer: rc=-14", rc == -14, "");
        rc = entry_call(0x55550, NULL);
        check("null payload: -22 (low pointer gate)", rc == -22, "");
        g_fault_uaccess = 0;

        printf("== 11. regression: SHOW still answers; set_uname stays out ==\n");
        memset(payload, 0, sizeof(payload));
        rc = entry_call(0x555e1, payload);
        check("SHOW_VERSION still answers after feature traffic",
              rc == 0 && memcmp(payload, "v2.3.0", 6) == 0, "");
        memset(payload, 0, sizeof(payload));
        rc = entry_call(0x55590, payload);   /* set_uname: next rung */
        check("set_uname (0x55590) stays not-handled (-22)",
              rc == -22, "");
        rc = entry_call(0x555b0, payload);   /* set_cmdline: next rung */
        check("set_cmdline (0x555b0) stays not-handled (-22)",
              rc == -22, "");

        printf("== 12. observe mode: feature commands answer nothing ==\n");
        {
                u32 slot_before = sc_v53_next_slot;
                u32 adds_before = sc_v53_add_calls;

                sc_full_mode = 0;
                fill_path_payload(sc_payload, "/should/not/be/stored");
                rc = entry_call(0x55550, sc_payload);
                check("observe mode add_sus_path: -22, nothing stored, not counted",
                      rc == -22 && sc_v53_next_slot == slot_before &&
                      sc_v53_add_calls == adds_before, "");
                sc_full_mode = 1;
        }

        printf("== 13. installer early gates (inherited) ==\n");
        ((uint64_t *)(uintptr_t)FAKE_TABLE)[173] = 0xdeadbeefdeadbeef;
        g_dispatcher = (uint64_t)(uintptr_t)(fake_kernel + 0x40000);
        ((uint64_t *)(uintptr_t)FAKE_TABLE)[134] = g_dispatcher;
        sc_installed = 0;
        rc = susfs_supercall_init();
        check("init refuses on entry/handler mismatch",
              rc == 0 && sc_installed == 0, "");

        ((uint64_t *)(uintptr_t)FAKE_TABLE)[173] = FAKE_HANDLER;
        g_dispatcher = 0;
        rc = susfs_supercall_init();
        check("init refuses when dispatcher not in table",
              rc == 0 && sc_installed == 0, "");

        printf("\n%s (%d failure(s))\n",
               fails ? "SOME CHECKS FAILED" : "ALL HOST CHECKS PASSED", fails);
        return fails ? 1 : 0;
}
