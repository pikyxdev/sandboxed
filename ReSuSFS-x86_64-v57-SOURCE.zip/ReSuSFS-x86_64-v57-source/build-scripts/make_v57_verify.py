#!/usr/bin/env python3
"""Create build_v57_verify.py from build_v55_verify.py, matching lines by
prefix (robust against any invisible-character mismatch)."""
import sys, re

SRC = '/home/z/my-project/scripts/build_v55_verify.py'
DST = '/home/z/my-project/scripts/build_v57_verify.py'

lines = open(SRC).read().split('\n')
out = []
swapped = {}

def swap_line(prefix, newtext, key):
    for i, l in enumerate(lines):
        if l.startswith(prefix):
            lines[i] = newtext
            swapped[key] = True
            return
    print('PREFIX NOT FOUND: %r' % prefix)
    sys.exit(1)

swap_line("A13 = ", "A13 = '/home/z/my-project/port-v57/susfs_guard_lkm-x86_64-android13-5.15-v57.ko'", 'a13')
swap_line("KORG = ", "KORG = '/home/z/my-project/port-v57/susfs_guard_lkm-x86_64-vanilla-5.15-v57.ko'", 'korg')
swap_line("A13_BASE = ", "A13_BASE = '/home/z/my-project/port-v57/susfs_guard_lkm-x86_64-android13-5.15.ko'", 'a13b')
swap_line("KORG_BASE = ", "KORG_BASE = '/home/z/my-project/port-v57/susfs_guard_lkm-x86_64-vanilla-5.15.ko'", 'korgb')
swap_line("CLI = ", "CLI = '/home/z/my-project/port-v57/ReSuFS/module/bin/x86_64/ksu_susfs'", 'cli')
swap_line("GRAFT_OBJ = ", "GRAFT_OBJ = '/home/z/my-project/port-v57/sc_v56.o'", 'graft')

s = '\n'.join(lines)

def rep(old, new, n=1):
    global s
    c = s.count(old)
    if c != n:
        print('MISMATCH (%d): %r' % (c, old[:70]))
        sys.exit(1)
    s = s.replace(old, new)

# docstring header
rep('build_v55_verify.py - fail the v54 build on any regression (derived from build_v53_verify.py).',
    'build_v57_verify.py - fail the v54.3 build on any regression (derived from build_v55_verify.py).\n'
    '\n'
    'v54.3 = THE UID-READ FIX.  Inherited v55 invariants verbatim; new checks:\n'
    '  - both uid gates (gd64 filter + transport root) read cred+4 (kuid_t uid),\n'
    '    not cred+8 (kgid_t gid) - instruction bytes verified per function in\n'
    '    the MERGED .ko disassembly\n'
    '  - the calibrate id-window starts at +4 (u32 usage at +0)\n'
    '  - the v54.3 banners name the fix; .ko sha256 + size locked\n')

# the v55 .bss-map syntax repair (CONDITIONAL: an earlier read of this
# file showed a stale 'off_map.group(4)...' artifact of the flaky overlay;
# the disk content is already correct - repair only if actually present)
if 'off_map.group(4).strip()] = int(m.group(1), 16)' in s:
    rep('off_map.group(4).strip()] = int(m.group(1), 16)',
        'off_map[m.group(4).strip()] = int(m.group(1), 16)')
else:
    assert 'off_map[m.group(4).strip()] = int(m.group(1), 16)' in s, 'off_map line not found in either form'

rep('print("### v54.1 HOTFIX: the UNCHECKED FORWARD (v54 field root cause)")',
    'print("### v54.3: THE UID-READ FIX (both gates read cred+4 = uid, not cred+8 = gid)")')

# insert the per-ko v54.3 checks right after the vermagic check
anchor = None
for l in lines:
    if "vm.startswith('vermagic=5.15.178+" in l:
        anchor = l
        break
assert anchor, 'vermagic check line not found'
block = anchor + """

    # ---- V54.3: both uid gates read cred+4, in the MERGED bytes --------
    gd_dis = sh(f"objdump -d --no-show-raw-insn --disassemble=susfs_gd64_entry {ko}")
    ent_dis = sh(f"objdump -d --no-show-raw-insn --disassemble=susfs_sc_entry {ko}")
    init_dis = sh(f"objdump -d --no-show-raw-insn --disassemble=susfs_supercall_init {ko}")
    check(name, '0x4(%rax),%eax' in gd_dis.replace('  ', ' '),
          "gd64 filter gate reads the u32 at cred+4 (kuid_t uid)")
    check(name, '0x8(%rax),%eax' not in gd_dis.replace('  ', ' '),
          "gd64 filter gate does NOT read cred+8 (kgid_t gid) - the v54.1/v54.2 field bug")
    check(name, re.search(r'cmpl?\\s+\\$0x0,0x4\\(%rcx\\)', ent_dis) is not None,
          "transport root gate reads the u32 at cred+4 (kuid_t uid)")
    check(name, re.search(r'cmpl?\\s+\\$0x0,0x8\\(%rcx\\)', ent_dis) is None,
          "transport root gate does NOT read cred+8 (kgid_t gid)")
    check(name, re.search(r'0x4\\(%rax\\),%r8d', init_dis) is not None,
          "calibrate id-window starts at +4 (u32 usage at +0, ids +4..+0x2c)")
    check(name, re.search(r'0xc\\(%rax\\),%r8d', init_dis) is not None,
          "calibrate id-window still spans through +0xc (uid,gid,suid,sgid)")
    for bs in (b'v54.3 ENFORCEMENT RUNG loaded', b'v54.3 ENFORCEMENT LIVE',
               b'uid at cred+4'):
        check(name, bs in d, f"v54.3 banner present: {bs.decode()[:40]}")
    import hashlib
    ko_sha = hashlib.sha256(d).hexdigest()
    want_sha = ('f36353425e345eaa2053d76a4548058e84539a13d13a61fb99f4ba9f20357f71'
                if name == 'android13' else
                '9d3106915da841e70fb59bdcd8c6f987806b6f9e3512035b9beb3de8ef238d0e')
    check(name, ko_sha == want_sha, f".ko sha256 locked ({ko_sha[:12]}..)")
    want_sz = 685112 if name == 'android13' else 685048
    check(name, len(d) == want_sz, f".ko size locked ({len(d)} bytes)")
"""
rep(anchor, block)

rep('print("ALL V55 CHECKS PASSED")', 'print("ALL V57 CHECKS PASSED")')

open(DST, 'w').write(s)
print('build_v57_verify.py written (%d bytes); lines swapped: %s' % (len(s), sorted(swapped)))
