#!/bin/bash
# Driver for the ReSuSFS x86_64 v26.11.23 safeguard test suite (tier-2:
# path-rewritten copies + command stubs; runs entirely in the sandbox).

set -u

PORT="${PORT_OVERRIDE:-/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module}"
WORK=/home/z/my-project/work/t2tree
FAKE="$WORK/fake"

rm -rf "$WORK"
mkdir -p "$FAKE/data/adb/ksu/bin" \
         "$FAKE/data/adb/ReSuSFS_LKM" \
         "$FAKE/data/adb/modules" \
         "$FAKE/data/adb/modules_update" \
         "$FAKE/data/local/tmp" \
         "$FAKE/data/adb/ReSuSFS/logs" \
         "$WORK/stubbin"

# 1) copy the module tree and rewrite /data/* to the fake root
cp -a "$PORT" "$FAKE/data/adb/modules_update/ReSuSFS"
find "$FAKE/data/adb/modules_update" -name '*.sh' -type f -print0 |
        xargs -0 sed -i "s|/data/|$FAKE/data/|g"

# 2) command stubs ------------------------------------------------------

cat > "$WORK/stubbin/uname" <<'EOF'
#!/bin/sh
case "${1:-}" in
        -r) echo "5.15.178+" ;;
        -m) echo "x86_64" ;;
        -v) echo "#1 SMP PREEMPT" ;;
        -a|""|--all) echo "Linux localhost 5.15.178+ #1 SMP PREEMPT x86_64" ;;
        *) echo "5.15.178+" ;;
esac
EOF

cat > "$WORK/stubbin/getprop" <<'EOF'
#!/bin/sh
case "$1" in
        ro.product.cpu.abi) echo "x86_64" ;;
        sys.boot_completed) echo "1" ;;
        ro.build.version.release) echo "14" ;;
        *) echo "" ;;
esac
EOF

cat > "$WORK/stubbin/ksud" <<'EOF'
#!/bin/sh
LOG="${FAKE}/data/adb/ReSuSFS/logs/ksud_calls.log"
mkdir -p "${FAKE}/data/adb/ReSuSFS/logs" 2>/dev/null
echo "ksud $*" >> "$LOG" 2>/dev/null
[ "$1" = "insmod" ] && exit 0
exit 1
EOF
sed -i "s|\${FAKE}|$FAKE|g" "$WORK/stubbin/ksud"

# busybox shim: delegate the applets the module actually uses to the
# real binaries; fail fast on anything network/lkm related.
cat > "$WORK/stubbin/busybox" <<'EOF'
#!/bin/sh
app="${1:-}"; shift || true
case "$app" in
        rmmod) exit 0 ;;
        cp|mv|chmod|sleep|rm|mkdir|ln|cat|grep|sed|awk|sort|find|cut|wc|touch)
                command "$app" "$@" ;;
        *) echo "busybox-stub: unhandled applet '$app' (fail)" >&2; exit 1 ;;
esac
EOF

chmod 755 "$WORK/stubbin/"*

# 3) run the suite -------------------------------------------------------
echo "Running tier-2 safeguard test suite (fake root: $FAKE)"
echo
PATH="$WORK/stubbin:/usr/bin:/bin" FAKE="$FAKE" sh /home/z/my-project/scripts/test_inner.sh
rc=$?

echo
if [ $rc -eq 0 ]; then
        echo "ALL SAFEGUARD TESTS PASSED"
else
        echo "SAFEGUARD TESTS FAILED - inspect $FAKE/data/adb/ReSuSFS/logs/"
fi
exit $rc
