#!/bin/bash
# kcfi_caller_probe.sh + ld -r weak/strong test
set -e
CC=/home/z/clang17/usr/lib/llvm-17/bin/clang
export LD_LIBRARY_PATH=/home/z/clang17/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH

echo "=========== PART 1: caller-side kCFI check emission ==========="
cat > /tmp/kcfi_caller.c <<'EOF'
struct pt_regs;
typedef long (*sc_fn_t)(const struct pt_regs *);
extern long callee(const struct pt_regs *r);
long indirect_caller(sc_fn_t fp, const struct pt_regs *r)
{
        return fp(r);          /* the indirect call the kernel's dispatch makes */
}
long direct_user(void)
{
        return indirect_caller(callee, 0);
}
EOF
$CC -target x86_64-linux-gnu -c /tmp/kcfi_caller.c -o /tmp/kcfi_caller.o \
    -O2 -fsanitize=kcfi -fno-stack-protector -fno-pic -mno-red-zone \
    -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 -fcf-protection=branch \
    -ffreestanding -nostdinc
objdump -d --disassemble=indirect_caller /tmp/kcfi_caller.o

echo
echo "=========== PART 2: ld -r weak/strong resolution test ==========="
mkdir -p /tmp/ldtest && cd /tmp/ldtest
cat > base.c <<'EOF'
extern void my_init(void);
void old_init(void) { }
void caller(void)   { my_init(); }   /* reloc against my_init */
EOF
cat > graft.c <<'EOF'
void my_init(void) { }               /* strong def */
void other(void)   { }
EOF
gcc -c base.c -o base.o
gcc -c graft.c -o graft.o
# make base's my_init... base has no def of my_init; instead test duplicate-def path:
cat > base2.c <<'EOF'
void my_init(void) { }               /* will be weakened - old definition */
void caller(void)   { my_init(); }
EOF
gcc -c base2.c -o base2.o
objcopy --weaken-symbol=my_init base2.o
echo "--- weak base2.o + strong graft.o, ld -r graft FIRST then base:"
ld -r -o merged1.o graft.o base2.o && nm merged1.o | grep -E 'my_init|caller'
echo "--- weak base2.o + strong graft.o, ld -r base FIRST then graft:"
ld -r -o merged2.o base2.o graft.o && nm merged2.o | grep -E 'my_init|caller'
echo "--- check reloc binding: disassemble caller in merged2"
objdump -dr --disassemble=caller merged2.o
echo "--- and merged1:"
objdump -dr --disassemble=caller merged1.o
