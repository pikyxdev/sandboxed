#!/bin/bash
# build_v40_ko.sh - reproducible v26.11.40 x86_64 LKM rebuild recipe.
#
# Reconstructs the exact build environment used for the v40 image after a
# sandbox recycle: kernel.org linux-5.15.178 tarball, current.h override,
# three local clang-compat build-tree patches, defconfig-derived .config
# (MODULE_UNLOAD=n / X86_5LEVEL=n / RANDOMIZE_BASE=n reproduce the v39
# import set), host tools via tools/env.sh, NDK r28c clang as CC (no LLVM=1:
# GNU ld/binutils link the module; clang-compiled objects link fine there).
#
# Verified output properties (compare before shipping a rebuild):
#   vermagic:  5.15.178+ SMP preempt modversions   (byte-identical to v39)
#   imports:   v39 set + panic + __x86_return_thunk + bcmp
#              - memcmp - __warn_printk            (all listed in the field
#                                                    kernel's kallsyms)
set -e
BASE=/home/z/my-project
KSRC=$BASE/linux-5.15.178
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
NDKB=$BASE/ndk/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin

# 1. kernel source (restore_build_env.sh also rewrites the current.h override)
if [ ! -f "$KSRC/Makefile" ]; then
        [ -f "$BASE/linux-5.15.178.tar.xz" ] || {
                echo "[!] $BASE/linux-5.15.178.tar.xz missing - download it from kernel.org first"; exit 1; }
        tar -xf "$BASE/linux-5.15.178.tar.xz" -C "$BASE"
fi
bash "$BASE/scripts/restore_build_env.sh" >/dev/null 2>&1 || true
grep -q susfs_current_task_gs_off "$KSRC/arch/x86/include/asm/current.h" || {
        echo "[!] current.h override missing - restore_build_env.sh failed"; exit 1; }

# 2. the three local clang-compat patches on the build tree (idempotent)
python3 - <<'PY'
import os
ksrc = os.environ.get('KSRC', '/home/z/my-project/linux-5.15.178')
def patch(path, old, new):
    p = os.path.join(ksrc, path)
    s = open(p).read()
    if old in s and new not in s:
        s = s.replace(old, new, 1)
        open(p, 'w').write(s)
        print('patched', path)
    elif new in s:
        print('already', path)
    else:
        print('SKIP (anchor missing)', path)
patch('Makefile', 'KBUILD_CFLAGS   += -fconserve-stack',
      '# v40 local build-tree patch: -fconserve-stack is gcc-only (clang rejects it)\n# KBUILD_CFLAGS   += -fconserve-stack')
patch('Makefile', 'KBUILD_CFLAGS += -Wno-maybe-uninitialized',
      '# v40 local build-tree patch: gcc-only warning flag (clang rejects it)\n# KBUILD_CFLAGS += -Wno-maybe-uninitialized')
patch('Makefile', 'KBUILD_CFLAGS += $(call cc-ifversion, -ge, 0901, -Wno-alloc-size-larger-than)',
      '# v40 local build-tree patch: gcc-only warning flag (clang rejects it)\n# KBUILD_CFLAGS += $(call cc-ifversion, -ge, 0901, -Wno-alloc-size-larger-than)')
PY

# 3. config (idempotent: only when .config is absent)
if [ ! -f "$KSRC/.config" ]; then
        ( cd "$KSRC" && . "$BASE/tools/env.sh" && make defconfig >/dev/null && \
          ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                --enable PREEMPT --enable SMP \
                --disable MODULE_UNLOAD --disable X86_5LEVEL \
                --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY && \
          make olddefconfig >/dev/null && make modules_prepare >/dev/null )
        echo "[+] config prepared"
fi

# 4. build the module (clang CC, GNU ld/binutils)
cd "$KSRC"
. "$BASE/tools/env.sh"
export PATH="$NDKB:$PATH"
make M="$LKM" CC=clang modules
echo "[+] built: $LKM/susfs_guard_lkm.ko"
python3 - <<'PY'
d = open('/home/z/my-project/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel/susfs_guard_lkm.ko','rb').read()
i = d.find(b'vermagic=')
print('vermagic:', d[i:i+80].split(b'\x00')[0].decode())
PY
echo "[i] verify imports vs the shipped v40 image before shipping:"
echo "    readelf -sW $LKM/susfs_guard_lkm.ko | awk '\$7==\"UND\" && \$8!=\"\" {print \$8}' | sort -u"
