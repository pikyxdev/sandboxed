#!/usr/bin/env python3
"""patch_ksu_cli_v45.py - ksu_susfs x86_64 CLI: read the answer from payload.err.

The v45 supercall transport is a plain kprobe on __x64_sys_reboot (the SukiSU
slot).  The original __se_sys_reboot still runs and returns -EINVAL for the
susfs magic pair (harmless - the kernel never acts on bad magics), while the
ANSWER is written into payload.err by task_work BEFORE the syscall returns to
userspace.  The shipped CLI pre-seeds payload.err=126 (ERR_CMD_NOT_SUPPORTED)
and already reads it back after the syscall - but it ALSO branches to its fail
path when the syscall's RETURN VALUE is nonzero, which is now every time.

This patch neutralizes exactly those nine `syscall; test rax,rax; jne <fail>`
branches (the jne becomes 6 NOP bytes, same length, so no other offset moves).
The subsequent payload.err check is untouched: err==0 -> success path,
err!=0 -> the CLI's own "no answer" error, which is the upstream contract.

Each site is verified contextually before patching: a mov eax,0xa9 (SYS_reboot)
within 80 bytes before the syscall.  Idempotent: already-patched sites
(jne replaced by nops) are skipped.
"""
import re
import sys

SITES_EXPECTED = 9

def patch(path):
    data = bytearray(open(path, 'rb').read())
    movs = [m.start() for m in re.finditer(b'\xb8\xa9\x00\x00\x00', bytes(data))]
    patched = skipped = 0
    for s in movs:
        sc = bytes(data).find(b'\x0f\x05', s, s + 80)
        if sc < 0:
            continue
        tail = bytes(data[sc+2:sc+2+9])
        if tail[:3] != b'\x48\x85\xc0':
            print(f"  mov@{s:#x}: syscall not followed by test rax,rax ({tail[:6].hex()}) - left alone")
            continue
        jne = tail[3:]
        if jne[:2] == b'\x0f\x85':
            off = sc + 2 + 3
            rel = int.from_bytes(bytes(data[off+2:off+6]), 'little', signed=True)
            tgt = off + 6 + rel
            # canonical 6-byte nop (66 0f 1f 44 00 00) - same length as the jne,
            # and unlike 0f 1f 44 00 00 00 it decodes as exactly six bytes, so
            # the following movslq err-load stays aligned.
            data[off:off+6] = b'\x66\x0f\x1f\x44\x00\x00'
            patched += 1
            print(f"  patched syscall@{sc:#x}: jne -> {tgt:#x} neutralized")
        elif jne[:6] == b'\x66\x0f\x1f\x44\x00\x00':
            skipped += 1
            print(f"  already patched syscall@{sc:#x}")
        elif jne[:5] == b'\x0f\x1f\x44\x00\x00':
            # earlier revision of this script wrote the 5-byte nop + stray 00:
            # repair it in place to the canonical 6-byte form.
            off = sc + 2 + 3
            data[off:off+6] = b'\x66\x0f\x1f\x44\x00\x00'
            patched += 1
            print(f"  repaired broken 5-byte-nop patch at syscall@{sc:#x}")
        else:
            print(f"  mov@{s:#x}: test followed by unexpected branch {jne[:6].hex()} - left alone")
    open(path, 'wb').write(bytes(data))
    print(f"{path}: {patched} patched, {skipped} already done, {len(movs)} mov sites seen")
    return patched + skipped

if __name__ == '__main__':
    total = 0
    for p in sys.argv[1:]:
        total += patch(p)
    if total != SITES_EXPECTED:
        print(f"WARNING: expected {SITES_EXPECTED} sites, handled {total}")
        sys.exit(1)
    print("all sites handled")
