#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.52.zip from work/pkg52 (pkg51 tree + v52 edits).

- Reproduces the v51 zip layout EXACTLY (same entries - v52 adds no files).
- The two module .kos are the rebuilt clang grafts with the CMD-TABLE FIX.
- Verifies: entry list identical to v51, change set exactly as expected,
  v52 receipts present, THE WIRE-DISPATCH LOCK on the zip's own .kos
  (0x555e2 -> answer_features, 0x555e3 -> answer_str - the stock CLI's
  literal cmd ids), the sc_probe field fixes present, CLI still riding
  syscall 173.
"""
import zipfile, os, hashlib, re, subprocess, tempfile

SRC = '/home/z/my-project/work/pkg52'
V51 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.51.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.52.zip'

v51_names = zipfile.ZipFile(V51).namelist()

file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
v51_dir_set = set(n for n in v51_names if n.endswith('/'))

missing_dirs = v51_dir_set - dir_set
extra_dirs = dir_set - v51_dir_set
missing_files = set(v51_names) - set(file_paths) - v51_dir_set
extra_files = set(file_paths) - set(v51_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v51'

file_set = set(file_paths)
ordered = [n for n in v51_names if n in dir_set or n in file_set]
assert len(ordered) == len(v51_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
z51, z52 = zipfile.ZipFile(V51), zipfile.ZipFile(OUT)
n51, n52 = z51.namelist(), z52.namelist()
assert n52 == n51, 'entry list mismatch vs v51'

changed = []
for n in n52:
    if z51.read(n) != z52.read(n):
        changed.append(n)
print('changed vs v51:', sorted(changed))
assert set(changed) == {
    'README-DIAGNOSTIC.md', 'boot-completed.sh', 'customize.sh', 'module.prop',
    'post-fs-data.sh',
    'lkm/x86_64/.payload_stamp',
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
}, f'unexpected change set: {sorted(changed)}'

mp = z52.read('module.prop').decode()
assert 'version=v26.11.52-x86_64' in mp and 'versionCode=130' in mp, 'module.prop version'
assert 'THE CMD-TABLE FIX' in mp, 'module.prop headline'
stamp = z52.read('lkm/x86_64/.payload_stamp').decode()
assert 'v26.11.52' in stamp, 'payload stamp'
bc = z52.read('boot-completed.sh').decode()
assert 'v52 CLANG ACCEPT PATH + CLI WIRE ABI' in bc, 'self-test names the v52 transport'
assert '0x555e1=version 20B, 0x555e2=enabled_features 8196B, 0x555e3=variant 20B' in bc, 'self-test documents the wire ABI'
assert 'for p in /data/adb/ksu/bin/sc_probe' in bc, 'sc_probe lookup fix present'
pfd = z52.read('post-fs-data.sh').decode()
assert 'PROBE_DST=/data/adb/ksu/bin/sc_probe' in pfd, 'sc_probe self-heal install present'
assert 're-basing the stage ladder' in pfd, 'post-fs-data re-base receipt kept'

# ---- THE WIRE-DISPATCH LOCK on the zip's own .kos ----
def wire_lock(ko_bytes, label):
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko_bytes)
        path = tf.name
    try:
        asm = subprocess.run(['objdump', '-d', '--no-show-raw-insn',
                              '--disassemble=susfs_sc_entry', path],
                             capture_output=True, text=True, check=True).stdout
    finally:
        os.unlink(path)
    ilist = []
    for l in asm.splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+(.+?)\s*$', l)
        if m:
            ilist.append((int(m.group(1), 16), m.group(2)))
    def builder_for(cmd):
        for i, (a, ins) in enumerate(ilist):
            if re.match(rf'cmp\s+\$0x{cmd:x},%eax', ins):
                if i + 1 >= len(ilist):
                    return None
                nxt = ilist[i + 1][1]
                mb0 = re.search(r'<(sc_v51_answer_\w+)>', nxt)
                if mb0:
                    return mb0.group(1)
                mj = re.match(r'j(e|ne)\s+([0-9a-f]+)', nxt)
                if not mj:
                    return None
                if mj.group(1) == 'ne':
                    seq = [x[1] for x in ilist[i + 2:i + 6]]
                else:
                    tgt = int(mj.group(2), 16)
                    seq = [x[1] for x in ilist if tgt <= x[0] < tgt + 32][:4]
                for s in seq:
                    mb = re.search(r'<(sc_v51_answer_\w+)>', s)
                    if mb:
                        return mb.group(1)
                return None
        return None
    assert builder_for(0x555e1) == 'sc_v51_answer_str', f'{label}: 0x555e1 must answer version (20B)'
    assert builder_for(0x555e2) == 'sc_v51_answer_features', f'{label}: 0x555e2 must answer enabled_features (8196B)'
    assert builder_for(0x555e3) == 'sc_v51_answer_str', f'{label}: 0x555e3 must answer variant (20B)'
    print(f'  wire lock OK ({label}): e1=version, e2=enabled_features, e3=variant')

van = z52.read('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
a13 = z52.read('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
for label, ko in (('vanilla', van), ('android13', a13)):
    assert b'v52 clang accept-path init' in ko, f'{label}: v52 init receipt'
    assert b'v52 calibrate' in ko, f'{label}: calibration receipt'
    assert b'v52 transport LIVE' in ko, f'{label}: v52 LIVE receipt'
    assert b'v51 clang accept-path init' not in ko, f'{label}: stale v51 receipt must not survive'
    # the ABI answers
    assert b'v2.3.0\x00' in ko, f'{label}: SUSFS_VERSION_STR'
    assert b'GKI-LKM\x00' in ko, f'{label}: SUSFS_VARIANT_STR'
    wire_lock(ko, label)
ym = z52.read('lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')
assert hashlib.sha256(ym).hexdigest() == hashlib.sha256(z51.read(
    'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')).hexdigest(), \
    'reference payload must stay byte-identical'

cli = z52.read('bin/x86_64/ksu_susfs')
sites = sum(1 for m in re.finditer(b'\xb8\xad\x00\x00\x00', cli)
            if cli.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert sites == 9, f'CLI 173 sites: {sites}'
# sc_probe must be executable in the zip (the v51 field lesson)
info = z52.getinfo('bin/x86_64/sc_probe')
assert (info.external_attr >> 16) & 0o111, 'sc_probe must carry exec bits in the zip'
print('CLI 173-riding sites:', sites)
print('sc_probe zip mode:', oct((info.external_attr >> 16) & 0o777))
print('zip size:', os.path.getsize(OUT))
print('sha256:', hashlib.sha256(open(OUT, 'rb').read()).hexdigest())
print('V52 ZIP OK')
