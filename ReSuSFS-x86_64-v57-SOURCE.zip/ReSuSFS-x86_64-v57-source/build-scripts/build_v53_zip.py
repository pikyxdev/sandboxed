#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.53.zip from work/pkg53 (pkg52 tree + v53 edits).

- Reproduces the v52 zip layout EXACTLY (same entries - v53 adds no files).
- The two module .kos are the rebuilt clang grafts with THE FIRST FEATURE
  RUNG; sc_probe carries the private readback (0x55f53).
- Verifies: entry list identical to v52, change set exactly as expected,
  v53 receipts present, THE WIRE-DISPATCH LOCK (v52 SHOW ids + v53 FEATURE
  ids) on the zip's own .kos, the stock CLI still riding syscall 173.
"""
import zipfile, os, hashlib, re, subprocess, tempfile

SRC = '/home/z/my-project/work/pkg53'
V52 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.52.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.53.zip'

v52_names = zipfile.ZipFile(V52).namelist()

file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
v52_dir_set = set(n for n in v52_names if n.endswith('/'))

missing_dirs = v52_dir_set - dir_set
extra_dirs = dir_set - v52_dir_set
missing_files = set(v52_names) - set(file_paths) - v52_dir_set
extra_files = set(file_paths) - set(v52_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v52'

file_set = set(file_paths)
ordered = [n for n in v52_names if n in dir_set or n in file_set]
assert len(ordered) == len(v52_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
z52, z53 = zipfile.ZipFile(V52), zipfile.ZipFile(OUT)
n52, n53 = z52.namelist(), z53.namelist()
assert n53 == n52, 'entry list mismatch vs v52'

changed = []
for n in n53:
    if z52.read(n) != z53.read(n):
        changed.append(n)
print('changed vs v52:', sorted(changed))
assert set(changed) == {
    'README-DIAGNOSTIC.md', 'boot-completed.sh', 'customize.sh', 'module.prop',
    'lkm/x86_64/.payload_stamp',
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
    'bin/x86_64/sc_probe',
}, f'unexpected change set: {sorted(changed)}'

mp = z53.read('module.prop').decode()
assert 'version=v26.11.53-x86_64' in mp and 'versionCode=131' in mp, 'module.prop version'
assert 'THE FIRST FEATURE RUNG' in mp, 'module.prop headline'
stamp = z53.read('lkm/x86_64/.payload_stamp').decode()
assert 'v26.11.53' in stamp, 'payload stamp'
bc = z53.read('boot-completed.sh').decode()
assert 'v53 CLANG ACCEPT PATH + CLI WIRE ABI + THE FIRST FEATURE RUNG' in bc, 'self-test names the v53 transport'
assert '---- v53 FEATURE RUNG @' in bc, 'the feature rung block present'
assert 'add_sus_path /data/local/tmp/.resusfs_v53_selftest' in bc, 'live add_sus_path call present'
assert 'hide_sus_mnts_for_non_su_procs 1' in bc, 'live toggle call present'
assert '0x55550=add_sus_path and 0x55553=add_sus_path_loop' in bc, 'self-test documents the feature wire'
assert 'for p in /data/adb/ksu/bin/sc_probe' in bc, 'sc_probe lookup fix kept'

# ---- THE WIRE-DISPATCH LOCK on the zip's own .kos (v52 SHOW + v53 FEATURE) ----
def wire_lock(ko_bytes, label):
    with tempfile.NamedTemporaryFile(suffix='.ko', delete=False) as tf:
        tf.write(ko_bytes)
        path = tf.name
    try:
        asm = subprocess.run(['objdump', '-d', '--no-show-raw-insn',
                              '--disassemble=susfs_sc_entry', path],
                             capture_output=True, text=True, check=True).stdout
    finally:
        os.unlink(path)
    ilist = []
    for l in asm.splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+(.+?)\s*$', l)
        if m:
            ilist.append((int(m.group(1), 16), m.group(2)))
    def builder_for(cmd):
        """Eq-path builders of any cmp $cmd,%eax (range-check cmps skipped,
        eq basic blocks only - see build_v53_verify.py for the rationale)."""
        found = set()
        for i, (a, ins) in enumerate(ilist):
            if not re.match(rf'cmp\s+\$0x{cmd:x},%eax', ins):
                continue
            if i + 1 >= len(ilist):
                continue
            nxt = ilist[i + 1][1]
            for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+)>', nxt):
                found.add(mb.group(1))
            mj = re.match(r'je\s+([0-9a-f]+)', nxt)
            if mj:
                tgt = int(mj.group(1), 16)
                seq = [x[1] for x in ilist if tgt <= x[0] < tgt + 48]
            else:
                mn = re.match(r'jne\s+([0-9a-f]+)', nxt)
                if mn:
                    seq = [x[1] for x in ilist[i + 2:i + 8]]
                else:
                    continue        # range check
            for s in seq:
                for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+)>', s):
                    found.add(mb.group(1))
                if re.match(r'(jmp|ret)', s):
                    break
        return found
    assert builder_for(0x555e1) == {'sc_v51_answer_str'}, f'{label}: 0x555e1 must answer version (20B)'
    assert builder_for(0x555e2) == {'sc_v51_answer_features'}, f'{label}: 0x555e2 must answer enabled_features (8196B)'
    assert builder_for(0x555e3) == {'sc_v51_answer_str'}, f'{label}: 0x555e3 must answer variant (20B)'
    assert builder_for(0x55550) == {'sc_v53_add_sus_path'}, f'{label}: 0x55550 must accept add_sus_path (260B)'
    assert builder_for(0x55553) == {'sc_v53_add_sus_path'}, f'{label}: 0x55553 must accept add_sus_path_loop (260B)'
    assert builder_for(0x55561) == {'sc_v53_hide_mnts'}, f'{label}: 0x55561 must accept hide_sus_mnts (8B)'
    assert builder_for(0x55f53) == {'sc_v53_answer_debug_list'}, f'{label}: 0x55f53 must answer the private readback (8196B)'
    assert not builder_for(0x55590), f'{label}: set_uname must stay not-handled this rung'
    assert not builder_for(0x555b0), f'{label}: set_cmdline_or_bootconfig must stay not-handled this rung'
    print(f'  wire lock OK ({label}): e1/e2/e3 SHOW + 55550/55553/55561 FEATURE + 55f53 readback; 55590/555b0 out')

van = z53.read('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
a13 = z53.read('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
for label, ko in (('vanilla', van), ('android13', a13)):
    assert b'v53 clang accept-path init' in ko, f'{label}: v53 init receipt'
    assert b'v53 calibrate' in ko, f'{label}: calibration receipt'
    assert b'v53 transport LIVE' in ko, f'{label}: v53 LIVE receipt'
    assert b'v53 feature rung' in ko, f'{label}: feature-rung receipt'
    assert b'v52 clang accept-path init' not in ko, f'{label}: stale v52 receipt must not survive'
    # the ABI answers
    assert b'v2.3.0\x00' in ko, f'{label}: SUSFS_VERSION_STR'
    assert b'GKI-LKM\x00' in ko, f'{label}: SUSFS_VARIANT_STR'
    wire_lock(ko, label)
ym = z53.read('lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')
assert hashlib.sha256(ym).hexdigest() == hashlib.sha256(z52.read(
    'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')).hexdigest(), \
    'reference payload must stay byte-identical'

cli = z53.read('bin/x86_64/ksu_susfs')
sites = sum(1 for m in re.finditer(b'\xb8\xad\x00\x00\x00', cli)
            if cli.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert sites == 9, f'CLI 173 sites: {sites}'
# sc_probe must be executable in the zip (the v51 field lesson)
info = z53.getinfo('bin/x86_64/sc_probe')
assert (info.external_attr >> 16) & 0o111, 'sc_probe must carry exec bits in the zip'
# the stock CLI must be byte-identical to the v52 zip (it is the ABI authority)
assert hashlib.sha256(cli).hexdigest() == hashlib.sha256(z52.read('bin/x86_64/ksu_susfs')).hexdigest(), \
    'the stock CLI binary must never change'
print('CLI 173-riding sites:', sites)
print('sc_probe zip mode:', oct((info.external_attr >> 16) & 0o777))
print('zip size:', os.path.getsize(OUT))
print('sha256:', hashlib.sha256(open(OUT, 'rb').read()).hexdigest())
print('V53 ZIP OK')
