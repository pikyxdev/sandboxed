#!/usr/bin/env python3
"""Dump the __versions (modversions) table of each bundled x86_64 candidate .ko.

Decodes what the kernel sees at load time:
  - entry per imported symbol: name + crc
  - presence/absence of the "module_layout" gate entry
  - whether real CRCs are present (ymuuuu GKI prebuilt) vs the port's
    neutralized single-dummy-entry build (android13/vanilla)
"""
import struct
import sys

ENTRY_SIZE = 64          # unsigned long crc + char name[56]
NAME_OFF = 8
NAME_LEN = 56

KOS = [
    "/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko",
    "/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko",
    "/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module/lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko",
]


def parse(path):
    with open(path, "rb") as f:
        img = f.read()

    assert img[:4] == b"\x7fELF" and img[4] == 2, path
    e_shoff, = struct.unpack_from("<Q", img, 0x28)
    e_shentsize, = struct.unpack_from("<H", img, 0x3A)
    e_shnum, = struct.unpack_from("<H", img, 0x3C)
    e_shstrndx, = struct.unpack_from("<H", img, 0x3E)

    shdrs = [e_shoff + i * e_shentsize for i in range(e_shnum)]
    st = shdrs[e_shstrndx]
    st_off, st_size = struct.unpack_from("<QQ", img, st + 0x18)
    names = img[st_off:st_off + st_size]

    def secname(i):
        o, = struct.unpack_from("<I", img, shdrs[i])
        end = names.find(b"\0", o)
        end = st_size if end < 0 else end
        return names[o:end].decode("latin1")

    for i in range(e_shnum):
        if secname(i) == "__versions":
            off, size = struct.unpack_from("<QQ", img, shdrs[i] + 0x18)
            n = size // ENTRY_SIZE
            entries = []
            for k in range(n):
                base = off + k * ENTRY_SIZE
                crc, = struct.unpack_from("<Q", img, base)
                raw = img[base + NAME_OFF:base + NAME_OFF + NAME_LEN]
                nm = raw.split(b"\0", 1)[0].decode("latin1")
                entries.append((nm, crc))
            return entries
    return None


def main():
    for path in KOS:
        print("=" * 72)
        print(path.split("/")[-1])
        entries = parse(path)
        if entries is None:
            print("  NO __versions section at all")
            continue
        print("  %d entr%s in __versions" % (len(entries), "y" if len(entries) == 1 else "ies"))
        has_layout = any(nm == "module_layout" for nm, _ in entries)
        print("  module_layout entry: %s" % ("PRESENT" if has_layout else "ABSENT"))
        for nm, crc in entries:
            tag = ""
            if nm == "module_layout":
                tag = "   <-- the struct-module ABI gate"
            elif nm in ("try_module_get", "module_put"):
                tag = "   <-- seen in your boot-4 dmesg"
            print("    %-52s crc=0x%016x%s" % (nm, crc, tag))


if __name__ == "__main__":
    main()
