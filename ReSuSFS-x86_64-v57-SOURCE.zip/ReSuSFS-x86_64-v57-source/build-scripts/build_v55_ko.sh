#!/bin/bash
# build_v55_ko.sh - v26.11.55 THE ENFORCEMENT BRIDGE v54.1 hotfix (graft onto the v49 .ko).
#
# v54 = the v53 accept path (field-proven by the v53.1 4-boot run: transport
# live at stage 3, SHOW answering, feature rung storing) + the enforcement
# rung:
#   private 0x55f54  gd64_arm      { u32 flags(0=arm); s32 err@4 } 8B
#   private 0x55f55  add_resolved  { char name[256]; u64 ino@256; s32 err@264 } 268B
# The filter: sys_call_table[217] (getdents64) -> susfs_gd64_entry (cloned
# 16-byte kCFI preamble, the v49/v53 recipe, second application); registered
# (name, ino) rules are removed from listings for app-range uids (>= 10000);
# every anomaly fails OPEN (unfiltered).  Matching is upstream susfs4ksu's
# own (name, ino) rule (decoded from its android13-5.15 LKM); the ino is
# resolved USERSPACE-side (stat) so the kernel touches no struct offset.
#
# Build chain: clang-17 compiles sc_v55.c freestanding (same flags as v53),
# the undefined-symbol set is asserted EXACT (15 = the v51 13 + __kmalloc +
# kfree, both verified in the box's kallsyms snapshot), and the object is
# grafted onto the FROZEN v49 base .ko (objcopy weaken + ld -r).  The base
# .ko is bit-exact the field-proven v49 image - it is NEVER rebuilt.
set -e
BASE=/home/z/my-project
PORT=$BASE/ReSuSFS-x86_64-port
CC=$BASE/toolchain/clang17/usr/lib/llvm-17/bin/clang
GRAFT_SRC=$PORT/sc_v55.c
GRAFT_OBJ=$PORT/sc_v55.o
MOD=$PORT/ReSuSFS/module
V=26.11.55

export LD_LIBRARY_PATH=$BASE/toolchain/clang17/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
[ -x "$CC" ] || { echo "[!] clang-17 missing at $CC (bash scripts/fetch_clang17.sh)"; exit 1; }

echo "[*] v54.1: compiling the clang-17 graft object (entry + accept path + enforcement rung)"
"$CC" -target x86_64-linux-gnu -c "$GRAFT_SRC" -o "$GRAFT_OBJ" \
        -O2 -fsanitize=kcfi -fcf-protection=branch \
        -fno-stack-protector -fno-pic -mno-red-zone \
        -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 \
        -ffreestanding -nostdinc -fno-builtin -std=gnu11 -Wall
echo "[+] graft object: $GRAFT_OBJ ($(stat -c%s "$GRAFT_OBJ") bytes)"

echo "[*] graft object self-checks"
nm -u "$GRAFT_OBJ" | awk '{print $2}' | sort > /tmp/v55_graft_u.txt
cat /tmp/v55_graft_u.txt
# v54.1: the v51 13-symbol set + __kmalloc + kfree = EXACTLY 15.  The two new
# imports are the filter's staging buffer (called DIRECTLY, the same
# resolution path _copy_from_user rides); everything else stays open-coded.
cat > /tmp/v55_graft_expected.txt <<'EOF'
__kmalloc
_copy_from_user
_copy_to_user
kfree
ksu_kallsyms_lookup_name
ksu_patch_text
sc_full_mode
sc_installed
sc_orig
susfs_armed_features
susfs_current_arm_stage
susfs_current_task_gs_off
susfs_diag_logf
susfs_fp_syscall_table
susfs_sc_entry_count
EOF
diff -u /tmp/v55_graft_expected.txt /tmp/v55_graft_u.txt
echo "[+] undefined set exact (15 symbols = v51 13 + __kmalloc + kfree)"

# layout contract: the graft contributes ZERO .bss (merged .bss must stay
# byte-identical to the field-proven v49..v53 image; the graft object is
# FIRST in the ld -r merge).  All v54 storage must show up as 'd' (.data).
if nm "$GRAFT_OBJ" | grep -qE ' [bB] '; then
        echo "[!] FATAL: graft object carries .bss symbols:"
        nm "$GRAFT_OBJ" | grep -E ' [bB] '
        exit 1
fi
echo "[+] zero .bss in the graft object (storage rides in .data)"
for v in sc_v54_res sc_v54_next_slot sc_v54_res_adds sc_v54_res_dups \
         sc_v54_res_rejects sc_v54_gd64_calls sc_v54_gd64_filtered \
         sc_v54_gd64_hidden sc_v54_gd64_alloc_fail sc_v54_gd64_copy_fail \
         sc_v54_gd64_installed sc_v54_gd64_orig; do
        nm "$GRAFT_OBJ" | grep -q " d $v\$" || { echo "[!] FATAL: $v not in .data"; exit 1; }
done
echo "[+] all v54 storage in .data (48-slot resolved table + counters + arm state)"

nm "$GRAFT_OBJ" | grep -E ' T (susfs_sc_entry|susfs_gd64_entry|susfs_supercall_init|susfs_supercall_exit)$'
echo "[*] gd64 entry disassembly (must start: endbr64, then lock incl)"
objdump -d --disassemble=susfs_gd64_entry "$GRAFT_OBJ" | head -8
if objdump -dr "$GRAFT_OBJ" | grep -q 'susfs_sc_wrapper'; then
        echo "[!] FATAL: the graft references susfs_sc_wrapper - the v51 contract is that the v49 GCC wrapper is NEVER called"
        exit 1
fi
echo "[+] the v49 GCC wrapper is not referenced anywhere in the graft"
# the wire ids must appear in the entry's dispatch
for id in 55550 55553 55561 55f53 55f54 55f55; do
        objdump -d --disassemble=susfs_sc_entry "$GRAFT_OBJ" | grep -q "cmp.*\$0x$id" \
                || { echo "[!] FATAL: entry does not dispatch cmd 0x$id"; exit 1; }
done
echo "[+] entry dispatches the six wire ids (55550/55553/55561/55f53/55f54/55f55)"
# the filter must call the saved orig through ONE kCFI-checked indirect call
# shape and import exactly the two allocation symbols
if objdump -dr "$GRAFT_OBJ" | grep -qE '__x86_indirect_thunk'; then
        echo "[!] FATAL: thunk import found (the kernel is RETPOLINE=n)"
        exit 1
fi
echo "[+] no __x86_indirect_thunk imports (RETPOLINE=n kernel)"

graft_ko() {      # $1 = base .ko, $2 = output name
        local SRC_KO=$1 NAME=$2
        local WEAK=$(mktemp /tmp/v54_weak_XXXX.ko)
        echo "[*] v54.1: grafting $NAME <- $SRC_KO"
        objcopy \
                --weaken-symbol=susfs_supercall_init \
                --weaken-symbol=susfs_supercall_exit \
                --weaken-symbol=susfs_sc_entry \
                --globalize-symbol=sc_orig \
                --globalize-symbol=sc_installed \
                --globalize-symbol=sc_full_mode \
                --globalize-symbol=susfs_sc_entry_count \
                --globalize-symbol=susfs_armed_features \
                "$SRC_KO" "$WEAK"
        # graft FIRST: ld -r keeps the first definition of each symbol; the
        # weakened v49 defs of the three overridden symbols are dropped and
        # all references bind to the clang graft.
        ld -r -o "$PORT/$NAME" "$GRAFT_OBJ" "$WEAK"
        rm -f "$WEAK"
        echo "[+] merged: $PORT/$NAME ($(stat -c%s "$PORT/$NAME") bytes)"
}

graft_ko "$PORT/susfs_guard_lkm-x86_64-android13-5.15.ko" \
         "susfs_guard_lkm-x86_64-android13-5.15-v55.ko"
graft_ko "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15.ko" \
         "susfs_guard_lkm-x86_64-vanilla-5.15-v55.ko"

echo "[*] v54.1: installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$PORT/susfs_guard_lkm-x86_64-android13-5.15-v55.ko" \
      "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15-v55.ko" \
      "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v$V" > "$MOD/lkm/x86_64/.payload_stamp"
ls -la "$MOD/lkm/x86_64" "$MOD/lkm/x86_64/candidates"
echo "[+] v54 graft done (verify: python3 $BASE/scripts/build_v55_verify.py)"
