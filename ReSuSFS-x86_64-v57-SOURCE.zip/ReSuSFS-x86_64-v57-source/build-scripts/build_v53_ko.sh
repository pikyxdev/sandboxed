#!/bin/bash
# build_v53_ko.sh - v26.11.53 THE FIRST FEATURE RUNG (graft onto the v49 .ko).
#
# v53 = the v52 accept path (field-proven by TWO consecutive clean-room
# 10-boot runs: transport live at stage 2/3, SHOW channel answering at
# stage 3) + the first FEATURE commands:
#   0x55550 add_sus_path / 0x55553 add_sus_path_loop (accept+store, 32-slot
#   .data table, dedupe, ENOSPC-capped) and 0x55561 hide_sus_mnts (recorded),
#   plus the private readback 0x55f53 for sc_probe.  The wire ids come from
#   the stock CLI binary's own dispatch sites (sha256 7a30fa74...); the
#   WIRE-DISPATCH LOCK in build_v53_verify.py machine-checks the merged .ko
#   against them.
#
# Build chain unchanged from v51/v52: clang-17 compiles sc_v53.c freestanding
# (same flags), the 13-symbol undefined set is asserted EXACT (no new
# imports: storage is .data, zeroing is open-coded), and the object is
# grafted onto the FROZEN v49 base .ko (objcopy weaken + ld -r).  The base
# .ko is bit-exact the field-proven v49 image (1b94cdf2... android13 /
# 6de75b79... vanilla) - it is NEVER rebuilt.
set -e
BASE=/home/z/my-project
PORT=$BASE/ReSuSFS-x86_64-port
CC=$BASE/toolchain/clang17/usr/lib/llvm-17/bin/clang
GRAFT_SRC=$PORT/sc_v53.c
GRAFT_OBJ=$PORT/sc_v53.o
MOD=$PORT/ReSuSFS/module
V=26.11.53

export LD_LIBRARY_PATH=$BASE/toolchain/clang17/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
[ -x "$CC" ] || { echo "[!] clang-17 missing at $CC (bash scripts/fetch_clang17.sh)"; exit 1; }

echo "[*] v53: compiling the clang-17 graft object (entry + accept path + FEATURE RUNG)"
"$CC" -target x86_64-linux-gnu -c "$GRAFT_SRC" -o "$GRAFT_OBJ" \
        -O2 -fsanitize=kcfi -fcf-protection=branch \
        -fno-stack-protector -fno-pic -mno-red-zone \
        -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 \
        -ffreestanding -nostdinc -fno-builtin -std=gnu11 -Wall
echo "[+] graft object: $GRAFT_OBJ ($(stat -c%s "$GRAFT_OBJ") bytes)"

echo "[*] graft object self-checks"
nm -u "$GRAFT_OBJ" | awk '{print $2}' | sort > /tmp/v53_graft_u.txt
cat /tmp/v53_graft_u.txt
# the v53 graft may reference NOTHING outside the v51 13-symbol set: 4 base
# functions + the resolver + patch primitive + the kernel uaccess pair + the
# globalized/known base globals, exact set, no libcalls (open-coded loops
# only - a memset sneaking in would show up here and must be fixed in the
# source, not linked away).  v53 adds ZERO imports: its storage rides in
# .data and every zero/copy is an open-coded loop.
cat > /tmp/v53_graft_expected.txt <<'EOF'
_copy_from_user
_copy_to_user
ksu_kallsyms_lookup_name
ksu_patch_text
sc_full_mode
sc_installed
sc_orig
susfs_armed_features
susfs_current_arm_stage
susfs_current_task_gs_off
susfs_diag_logf
susfs_fp_syscall_table
susfs_sc_entry_count
EOF
diff -u /tmp/v53_graft_expected.txt /tmp/v53_graft_u.txt
echo "[+] undefined set exact (13 symbols, unchanged from v51/v52 - the feature rung imports NOTHING new)"

# v53 layout contract: the graft contributes ZERO .bss (merged .bss must
# stay byte-identical to the field-proven v49/v50/v51/v52 image; the graft
# object is FIRST in the ld -r merge, so graft .bss would land in the
# android struct-module spill window .bss[0..0x40)).  All v53 storage must
# show up as 'd' (.data) symbols.
if nm "$GRAFT_OBJ" | grep -qE ' [bB] '; then
        echo "[!] FATAL: graft object carries .bss symbols:"
        nm "$GRAFT_OBJ" | grep -E ' [bB] '
        exit 1
fi
echo "[+] zero .bss in the graft object (storage rides in .data)"
for v in sc_v53_paths sc_v53_next_slot sc_v53_add_calls sc_v53_dups_skipped \
         sc_v53_toggle_calls sc_v53_hide_mnts_on sc_v53_dump \
         sc_v51_cred_off sc_v51_uid_ok; do
        nm "$GRAFT_OBJ" | grep -q " d $v\$" || { echo "[!] FATAL: $v not in .data"; exit 1; }
done
echo "[+] all v53 storage in .data (32-slot table + counters + dump buffer)"

nm "$GRAFT_OBJ" | grep -E ' T (susfs_sc_entry|susfs_supercall_init|susfs_supercall_exit)$'
echo "[*] entry disassembly (must be: endbr64 ... lock incl ... no susfs_sc_wrapper reference)"
objdump -d --disassemble=susfs_sc_entry "$GRAFT_OBJ" | head -30
if objdump -dr "$GRAFT_OBJ" | grep -q 'susfs_sc_wrapper'; then
        echo "[!] FATAL: the graft references susfs_sc_wrapper - the v51 contract is that the v49 GCC wrapper is NEVER called"
        exit 1
fi
echo "[+] the v49 GCC wrapper is not referenced anywhere in the graft"
# the feature commands must appear in the entry's dispatch (the wire ids)
for id in 55550 55553 55561 55f53; do
        objdump -d --disassemble=susfs_sc_entry "$GRAFT_OBJ" | grep -q "cmp.*\$0x$id" \
                || { echo "[!] FATAL: entry does not dispatch cmd 0x$id"; exit 1; }
done
echo "[+] entry dispatches the four v53 wire ids (55550/55553/55561/55f53)"

graft_ko() {      # $1 = base .ko, $2 = output name
        local SRC_KO=$1 NAME=$2
        local WEAK=$(mktemp /tmp/v53_weak_XXXX.ko)
        echo "[*] v53: grafting $NAME <- $SRC_KO"
        objcopy \
                --weaken-symbol=susfs_supercall_init \
                --weaken-symbol=susfs_supercall_exit \
                --weaken-symbol=susfs_sc_entry \
                --globalize-symbol=sc_orig \
                --globalize-symbol=sc_installed \
                --globalize-symbol=sc_full_mode \
                --globalize-symbol=susfs_sc_entry_count \
                --globalize-symbol=susfs_armed_features \
                "$SRC_KO" "$WEAK"
        # graft FIRST: ld -r keeps the first definition of each symbol; the
        # weakened v49 defs of the three overridden symbols are dropped and
        # all references (susfs_layers[].init/.exit, the old dead init's
        # own code) bind to the clang graft.
        ld -r -o "$PORT/$NAME" "$GRAFT_OBJ" "$WEAK"
        rm -f "$WEAK"
        echo "[+] merged: $PORT/$NAME ($(stat -c%s "$PORT/$NAME") bytes)"
}

graft_ko "$PORT/susfs_guard_lkm-x86_64-android13-5.15.ko" \
         "susfs_guard_lkm-x86_64-android13-5.15-v53.ko"
graft_ko "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15.ko" \
         "susfs_guard_lkm-x86_64-vanilla-5.15-v53.ko"

echo "[*] v53: installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$PORT/susfs_guard_lkm-x86_64-android13-5.15-v53.ko" \
      "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15-v53.ko" \
      "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v$V" > "$MOD/lkm/x86_64/.payload_stamp"
ls -la "$MOD/lkm/x86_64" "$MOD/lkm/x86_64/candidates"
echo "[+] v53 graft done (verify: python3 $BASE/scripts/build_v53_verify.py)"
