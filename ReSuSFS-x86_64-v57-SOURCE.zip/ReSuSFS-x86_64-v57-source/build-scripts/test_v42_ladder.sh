#!/bin/sh
# ============================================================================
# v26.11.42 substep-ladder regression test (host).
#
# v42 semantics under test:
#   - fake module surface adds probe / probe_arm params
#   - module sim walks the v42 sentinel ladder: -1 -> -50 (kworker entered)
#     -> 0..maxstep -> init_done=1; probe .get writes -60
#   - trigger_mode=set (default): force_init WRITE channel + receipts
#   - trigger_mode=get: probe_arm=1 write + probe read dispatch
#   - trigger_mode=early: post-fs-data writes force_init; boot-completed
#     polls only (no second write)
#   - heartbeat receipts land in init_trace.txt
#   - tread: a hung param read is KILLed by timeout and receipted as
#     PARAM READ TIMEOUT (the v41 blind spot)
#   - the witness/bg + ladder advance + stand-down still work
#
# All hardcoded /data paths are substituted into scratch copies of utils.sh /
# boot-completed.sh / post-fs-data.sh; nothing on the host is touched.
# ============================================================================
SRC=/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module
T=/tmp/v42test
FB=$T/fakebin
FAIL=0

ok()   { echo "  [PASS] $1"; }
bad()  { echo "  [FAIL] $1"; FAIL=$((FAIL+1)); }
has()  { grep -qF "$2" "$1" 2>/dev/null && ok "$3" || bad "$3"; }
lacks(){ { ! grep -qF "$2" "$1" 2>/dev/null; } && ok "$3" || bad "$3"; }

rm -rf "$T"; mkdir -p "$T/adb/ReSuSFS_LKM" "$T/adb/ReSuSFS/logs" \
                "$T/adb/modules/ReSuSFS" "$T/out" "$FB" "$T/kasym" "$T/proc/sys/kernel/random"

cat > "$T/kasym/current" <<'EOF'
000000000001bc40 A current_task
ffffffff810fd360 t kallsyms_lookup_name
ffffffff810fd840 t kallsyms_lookup
ffffffff810fdce0 t sprint_symbol
EOF
echo "0123456789abcdef0123456789abcdef" > "$T/proc/sys/kernel/random/boot_id"
echo 2 > "$T/proc/sys/kernel/kptr_restrict"

MODP="$T/sys/module/susfs_guard_lkm"
make_params() {
        rm -rf "$MODP"; mkdir -p "$MODP/parameters"
        for p in arm_stage force_init init_done init_maxstep init_laststep \
                 diag_log kr_seed kr_scan sc_entry_count diag_printk probe probe_arm; do
                : > "$MODP/parameters/$p"
        done
        echo "-1" > "$MODP/parameters/init_laststep"
        echo "0"  > "$MODP/parameters/init_done"
}

cat > "$FB/ksud" <<EOF
#!/bin/sh
[ "\$1" = "insmod" ] && exit 0
exit 1
EOF
cat > "$FB/uname" <<'EOF'
#!/bin/sh
case "$1" in
  -m) echo "x86_64" ;;
  -r) echo "5.15.178+" ;;
  *)  echo "Linux (none) 5.15.178+ #1 SMP PREEMPT x86_64 Android" ;;
esac
EOF
cat > "$FB/getprop" <<'EOF'
#!/bin/sh
case "$1" in
  ro.product.cpu.abi) echo "x86_64" ;;
  *) : ;;
esac
EOF
cat > "$FB/busybox" <<'EOF'
#!/bin/sh
a="$1"; shift
case "$a" in
  dmesg) echo "" ;;
  sleep) /bin/sleep "$@" ;;
  cp)    /bin/cp "$@" ;;
  chmod) /bin/chmod "$@" ;;
  rmmod) exit 1 ;;
  *)     command "$a" "$@" ;;
esac
EOF
chmod +x "$FB/ksud" "$FB/uname" "$FB/getprop" "$FB/busybox"

MODDIR="$T/adb/modules/ReSuSFS"
mkdir -p "$MODDIR/lkm/x86_64/candidates" "$MODDIR/bin/x86_64" "$MODDIR/logs"
cp "$SRC/module.prop" "$MODDIR/module.prop"
sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS_LKM|$T/adb/ReSuSFS_LKM|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/proc/kallsyms|$T/kasym/current|g" \
    -e "s|/proc/sys/kernel|$T/proc/sys/kernel|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/utils.sh" > "$MODDIR/utils.sh"
sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/boot-completed.sh" > "$T/out/boot-completed.sh"
sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/post-fs-data.sh" > "$T/out/post-fs-data.sh"
for f in "$MODDIR/utils.sh" "$T/out/boot-completed.sh" "$T/out/post-fs-data.sh"; do
        sed -i "s|^PATH=.*|PATH=$FB:\$PATH|" "$f"
done
cp "$MODDIR/utils.sh" "$T/out/utils.keep"

PERSIST="$T/adb/ReSuSFS"
BOOTLOG="$PERSIST/logs/boot.log"
INITTRACE="$PERSIST/logs/init_trace.txt"
mkdir -p "$PERSIST/logs"

# ---- module sim: v42 sentinel ladder, fired from each `sleep 1` tick ------
cat > "$T/out/simfn.sh" <<EOF
sim_stage() {
        st="\$(cat "$T/out/simstate" 2>/dev/null)"
        case "\$st" in
        ""|1)
                echo "-50" > "$MODP/parameters/init_laststep"
                echo 2 > "$T/out/simstate" ;;
        2)
                maxstep="\$(cat "$MODP/parameters/init_maxstep" 2>/dev/null)"
                case "\$maxstep" in ''|*[!0-9]*) maxstep=0 ;; esac
                laststep=\$maxstep
                {
                        echo "force_init(deferred): running susfs_init_body in kworker context"
                        echo "DIAG step 1: susfs_init ENTERED (maxstep=\$maxstep arm_stage=0)"
                        echo "DIAG step 9: susfs_init_body RETURNING 0 (laststep=\$laststep init_done=1)"
                } > "$MODP/parameters/diag_log"
                echo "\$laststep" > "$MODP/parameters/init_laststep"
                echo 1 > "$MODP/parameters/init_done"
                echo done > "$T/out/simstate" ;;
        esac
}
EOF
cat > "$FB/simhook" <<EOF
#!/bin/sh
. "$T/out/simfn.sh"
sim_stage
EOF
chmod +x "$FB/simhook"

reset_boot() {
        pkill -f "$T/out/boot-completed.sh" 2>/dev/null
        pkill -f "$FB/simhook" 2>/dev/null
        sleep 0.3
        rm -rf "$PERSIST" "$T/adb/ReSuSFS_LKM"
        mkdir -p "$PERSIST/logs" "$T/adb/ReSuSFS_LKM"
        : > "$BOOTLOG"
        rm -f "$T/out/simstate"
        make_params
        cp "$T/out/utils.keep" "$MODDIR/utils.sh"
}
arm_simhook() { sed -i "0,/sleep 1/s|sleep 1|sleep 1; $FB/simhook|" "$T/out/boot-completed.sh"; }
wait_pfd() {
        n=0
        while [ "$n" -lt 30 ] && { ! grep -q "=== post-fs-data DONE ===" "$BOOTLOG" 2>/dev/null; }; do
                sleep 0.5
                n=$((n+1))
        done
        pkill -f "$T/out/post-fs-data.sh" 2>/dev/null
        sleep 0.3
}
disarm_simhook() { sed -i "s|; $FB/simhook||g" "$T/out/boot-completed.sh"; }
run_bc() {
        sh "$T/out/boot-completed.sh" >/dev/null 2>&1
        pkill -f "$T/out/boot-completed.sh" 2>/dev/null
        pkill -f "$FB/simhook" 2>/dev/null
        sleep 0.3
}

# ============================================================================
echo "== T1: trigger_mode default (set): WRITE channel, v42 sentinel ladder =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
arm_simhook
sh "$T/out/boot-completed.sh" >/dev/null 2>&1 &
BSPID=$!
# tick 1 (embedded in the witness sleep): sim writes -50; wait for the read
sleep 1.6; $FB/simhook >/dev/null 2>&1
# let the witness read -50 BEFORE advancing the sim to done
sleep 1.6; $FB/simhook >/dev/null 2>&1
# let the poll loop see done + heartbeats (first beat at 5s) land
sleep 5
pkill -f "$T/out/boot-completed.sh" 2>/dev/null; pkill -f "$FB/simhook" 2>/dev/null
sleep 0.3
has "$INITTRACE" "writing force_init=1 (minimal setter" "T1a minimal-setter receipt"
has "$INITTRACE" "force_init write returned" "T1b write-returned receipt"
has "$INITTRACE" "heartbeat @" "T1c heartbeat receipt present"
has "$INITTRACE" "witness(bg): laststep=-50" "T1d kworker -50 sentinel seen"
has "$INITTRACE" "init_done=1" "T1e done receipt"
has "$INITTRACE" "STEP 0 COMPLETE" "T1f ladder COMPLETE receipt"
[ "$(cat "$PERSIST/init_seq" 2>/dev/null)" = "1" ] && ok "T1g init_seq advanced to 1" || bad "T1g init_seq=$(cat "$PERSIST/init_seq" 2>/dev/null)"
lacks "$INITTRACE" "PARAM READ TIMEOUT" "T1h no spurious TIMEOUT on healthy reads"

echo "== T2: trigger_mode=get: probe_arm write + probe READ dispatch =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo get > "$PERSIST/trigger_mode"
arm_simhook
# probe .get simulation: reading probe sets -60 then arms the work
sed -i "s|cur=\"\$(tread \$LASTSTEP_PARAM)\"|cur=\"\$(tread \$LASTSTEP_PARAM)\"|" "$T/out/boot-completed.sh" >/dev/null 2>&1
cat > "$FB/cat" <<EOF
#!/bin/sh
# fake cat: reading 'probe' simulates the module .get (writes -60, returns 0)
for a in "\$@"; do
        case "\$a" in
        */probe)
                echo "-60" > "$MODP/parameters/init_laststep"
                echo "0" ;;
        *) /bin/cat "\$@" ;;
        esac
done
EOF
chmod +x "$FB/cat"
sh "$T/out/boot-completed.sh" >/dev/null 2>&1 &
BSPID=$!
sleep 1.2; $FB/simhook >/dev/null 2>&1; sleep 0.5; $FB/simhook >/dev/null 2>&1
sleep 2
pkill -f "$T/out/boot-completed.sh" 2>/dev/null; pkill -f "$FB/simhook" 2>/dev/null
rm -f "$FB/cat"
sleep 0.3
has "$INITTRACE" "trigger_mode=get: writing probe_arm=1" "T2a get-mode receipt"
has "$INITTRACE" "probe_arm=1 written" "T2b probe_arm receipt"
has "$INITTRACE" "probe read returned" "T2c probe-read receipt"
has "$INITTRACE" "witness(bg): laststep=-60" "T2d probe .get -60 sentinel"
lacks "$INITTRACE" "writing force_init=1" "T2e force_init NOT written in get mode"

echo "== T3: hung param read -> PARAM READ TIMEOUT receipt (the v41 blind spot) =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
cat > "$FB/cat" <<EOF
#!/bin/sh
for a in "\$@"; do
        case "\$a" in
        */init_laststep) /bin/sleep 60 ;;
        *) /bin/cat "\$@" ;;
        esac
done
EOF
chmod +x "$FB/cat"
( sh "$T/out/boot-completed.sh" >/dev/null 2>&1 & ) ; sleep 4
pkill -f "$T/out/boot-completed.sh" 2>/dev/null
rm -f "$FB/cat"
sleep 0.3
has "$INITTRACE" "PARAM READ TIMEOUT" "T3a TIMEOUT receipt on hung param read"
has "$INITTRACE" "dmesg_freeze.txt" "T3b dmesg-capture instructions receipted"

echo "== T4: trigger_mode=early: post-fs-data writes, boot-completed only polls =="
reset_boot
echo early > "$PERSIST/trigger_mode"
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
sh "$T/out/post-fs-data.sh" >/dev/null 2>&1 &
wait_pfd
has "$BOOTLOG" "trigger_mode=early - writing force_init NOW" "T4a early write receipt"
has "$BOOTLOG" "early force_init write returned" "T4b early write returned"
disarm_simhook
sh "$T/out/boot-completed.sh" >/dev/null 2>&1
pkill -f "$T/out/boot-completed.sh" 2>/dev/null
sleep 0.3
has "$BOOTLOG" "trigger_mode=early - the dispatch already happened" "T4c boot-completed skips its own write"
lacks "$INITTRACE" "writing force_init=1 (minimal setter" "T4d no second force_init write at boot-completed"

echo "== T5: stale try marker from a previous boot -> stand-down + dossier =="
reset_boot
echo "try 0 deadbeefdeadbeefdeadbeefdeadbeef" > "$PERSIST/stage_boot"
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 0 > "$PERSIST/arm_stage"
sh "$T/out/post-fs-data.sh" >/dev/null 2>&1 &
wait_pfd
has "$BOOTLOG" "WEDGE DOSSIER" "T5a dossier printed"
has "$BOOTLOG" "stage-0/substep boot itself never completed" "T5b stand-down receipt"
[ ! -f "$PERSIST/enable_lkm" ] && ok "T5c enable_lkm removed" || bad "T5c enable_lkm still present"
[ ! -f "$PERSIST/enable_force_init" ] && ok "T5d enable_force_init removed" || bad "T5d enable_force_init still present"
[ -f "$PERSIST/no_init_this_boot" ] && ok "T5e no_init_this_boot set" || bad "T5e no_init_this_boot missing"

echo
if [ "$FAIL" -eq 0 ]; then
        echo "v42 ladder regression: ALL PASS"
else
        echo "v42 ladder regression: $FAIL FAILURES"
fi
exit $FAIL
