#!/bin/bash
# build_v43_ko.sh - reproducible v26.11.43 x86_64 LKM dual-candidate build.
#
# v43 is the TRI-CHANNEL TRIGGER + CONSOLE BREADCRUMBS build (see the
# v26.11.43 header comment in kernel/susfs_main.c for the full rationale):
#
#   android13 -> susfs_guard_lkm-x86_64-android13-5.15.ko
#                AOSP android13-5.15 ASB-2025-03-05 (a13-full/), HOST GCC.
#                NOT the default candidate (the v42 image fails init_module
#                with ENOEXEC on the box; kept shippable for re-testing).
#   vanilla   -> susfs_guard_lkm-x86_64-vanilla-5.15.ko
#                kernel.org linux-5.15.178 (linux-5.15.178/), HOST GCC.
#                THE DEFAULT since v43 - loads CLEAN in the field (all
#                relocations applied, zero kernel warnings) and carries the
#                v26.11.26-37 build profile whose module code verifiably
#                EXECUTED on the box.
#
# Module changes in v43 (kernel/susfs_main.c):
#   - force_init .set: "2" = SYNC dispatch (susfs_init_body called DIRECTLY
#     from the .set - no workqueue at all; substep 0 = pure stores), "1" =
#     the v42 deferred path (bare schedule_work) kept byte-for-byte.
#   - Both paths hit a diag_printk-gated raw printk(KERN_EMERG
#     "XYZDIAG2: ...") FIRST: printk takes no param_lock and reaches the
#     ring AND the console (tty0), so the breadcrumb survives a dead box.
#   - Sync sentinels -70 (entered) / -71 (already-done).
#
# Trees may be pruned by a sandbox recycle: this script re-extracts them
# from the kept tarballs (linux-5.15.178.tar.xz / a13-mirror.tar.gz) when
# their Makefile is missing, then re-applies the current.h override.
set -e
BASE=/home/z/my-project
A13=$BASE/a13-full
KORG=$BASE/linux-5.15.178
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
OUT=$BASE/ReSuSFS-x86_64-port
MOD=$BASE/ReSuSFS-x86_64-port/ReSuSFS/module

# 0. tree restore (recycle-proof): re-extract from the kept tarballs
restore_tree() {            # $1 = tarball, $2 = expected dir, $3 = inner name
        local TB=$1 DIR=$2 INNER=$3
        if [ ! -f "$DIR/Makefile" ]; then
                echo "[*] restoring $DIR from $TB"
                rm -rf "$DIR"
                tar -xf "$TB" -C "$BASE"
                [ "$DIR" != "$BASE/$INNER" ] && mv "$BASE/$INNER" "$DIR"
        fi
}
restore_tree "$BASE/linux-5.15.178.tar.xz" "$KORG" "linux-5.15.178"
restore_tree "$BASE/a13-mirror.tar.gz"     "$A13"  "kernel_common-ASB-2025-03-05_13-5.15"

prepare_tree() {          # $1 = tree root, $2 = label
        local TREE=$1 LABEL=$2
        echo "[*] preparing $LABEL tree ($TREE)"

        # current.h override (identical for both trees - the LDPlayer kernel
        # trimmed EXPORT_PER_CPU_SYMBOL(current_task); see restore_build_env.sh)
        CURH="$TREE/arch/x86/include/asm/current.h"
        if ! grep -q susfs_current_task_gs_off "$CURH" 2>/dev/null; then
                cp "$BASE/scripts/current.h.override" "$CURH"
        fi

        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                if [ ! -f .config ]; then
                        make defconfig >/dev/null
                        ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                                --enable PREEMPT --enable SMP \
                                --disable MODULE_UNLOAD --disable X86_5LEVEL \
                                --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY
                fi
                # RETPOLINE/RETHUNK OFF (the v42 profile): the field kernel's
                # kallsyms has NO __x86_indirect_thunk_* symbols - a module
                # importing them resolves them to garbage and its very first
                # indirect call jumps into the void.
                ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                        --enable PREEMPT --enable SMP \
                        --disable MODULE_UNLOAD --disable X86_5LEVEL \
                        --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY \
                        --disable RETPOLINE --disable RETHUNK
                make olddefconfig >/dev/null
                make LOCALVERSION= modules_prepare >/dev/null
        )
        echo "[+] $LABEL tree ready (this_module will be $(grep -q ANDROID_KABI_RESERVE "$TREE/include/linux/module.h" && echo 0x340 || echo 0x300))"
}

build_tree() {             # $1 = tree root, $2 = output name
        local TREE=$1 NAME=$2
        echo "[*] building $NAME from $TREE"
        (
                cd "$TREE"
                . "$BASE/tools/env.sh"
                make M="$LKM" clean >/dev/null 2>&1 || true
                make LOCALVERSION= M="$LKM" CC=gcc modules 2>&1 | tail -5
                cp -f "$LKM/susfs_guard_lkm.ko" "$OUT/$NAME"
        )
        echo "[+] built: $OUT/$NAME ($(stat -c%s "$OUT/$NAME") bytes)"
}

# 1. trees
[ -f "$KORG/Makefile" ] || { echo "[!] kernel.org tree missing"; exit 1; }
[ -f "$A13/Makefile" ] || { echo "[!] a13 tree missing"; exit 1; }

# 2. current.h override source file (kept as a file so both trees get the
# identical bytes)
if [ ! -f "$BASE/scripts/current.h.override" ]; then
        cp "$KORG/arch/x86/include/asm/current.h" "$BASE/scripts/current.h.override"
fi

prepare_tree "$A13"    "a13-ASB-2025-03"
build_tree   "$A13"    "susfs_guard_lkm-x86_64-android13-5.15.ko"
prepare_tree "$KORG"   "kernel.org-5.15.178"
build_tree   "$KORG"   "susfs_guard_lkm-x86_64-vanilla-5.15.ko"

# 3. verification
python3 "$BASE/scripts/build_v43_verify.py"

# 4. payload install + stamp + module zip
echo "[*] installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$OUT/susfs_guard_lkm-x86_64-android13-5.15.ko" "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$OUT/susfs_guard_lkm-x86_64-vanilla-5.15.ko"   "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v26.11.43" > "$MOD/lkm/x86_64/.payload_stamp"

echo "[*] zipping ReSuSFS-x86_64-v26.11.43.zip"
(
        cd "$MOD"
        rm -f "$OUT/ReSuSFS-x86_64-v26.11.43.zip" "$BASE/download/ReSuSFS-x86_64-v26.11.43.zip"
        zip -9 -r "$OUT/ReSuSFS-x86_64-v26.11.43.zip" . -x 'webroot/CNAME' > /dev/null
)
mkdir -p "$BASE/download"
cp -f "$OUT/ReSuSFS-x86_64-v26.11.43.zip" "$BASE/download/ReSuSFS-x86_64-v26.11.43.zip"
echo "[+] shipped: $BASE/download/ReSuSFS-x86_64-v26.11.43.zip ($(stat -c%s "$BASE/download/ReSuSFS-x86_64-v26.11.43.zip") bytes)"
