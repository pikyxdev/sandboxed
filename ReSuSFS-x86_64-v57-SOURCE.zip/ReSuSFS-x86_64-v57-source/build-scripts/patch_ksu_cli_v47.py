#!/usr/bin/env python3
"""patch_ksu_cli_v47.py - ksu_susfs x86_64 CLI: move the supercall to ioperm(2).

The v47 transport redirects the hardened syscall dispatcher's COLD ioperm arm
(nr 173) to the module wrapper; the v45 transport rode reboot(2) (nr 169, the
slot KernelSU's own kprobe hot-occupies).  The CLI's supercall sites must
therefore issue syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload).

This patch rewrites the nine `mov eax,0xa9` (169) immediates to `0xad` (173) -
same instruction length, no other offset moves.  Context is verified before
each patch: a syscall (0f 05) within 80 bytes after the mov.  The v45 payload.err
contract is untouched: the sites keep their neutralized jne (answer read from
payload.err), and v47's wrapper also returns 0 for handled commands, so both
conventions hold.

Idempotent: mov sites already carrying 0xad are skipped.  Expected: 9 sites
(the same nine the v45 patch verified).
"""
import re
import sys

SITES_EXPECTED = 9
SYS_OLD = 0xa9   # __NR_reboot, x86_64
SYS_NEW = 0xad   # __NR_ioperm, x86_64


def patch(path):
    data = bytearray(open(path, 'rb').read())
    # count already-done sites FIRST (mov eax,0xad followed by a syscall):
    # they must not be counted again after this run's own patches land.
    skipped = 0
    for m in re.finditer(b'\xb8\xad\x00\x00\x00', bytes(data)):
        s = m.start()
        if bytes(data).find(b'\x0f\x05', s, s + 80) >= 0:
            skipped += 1
            print(f"  already patched mov@{s:#x}")
    movs = [m.start() for m in re.finditer(b'\xb8\xa9\x00\x00\x00', bytes(data))]
    patched = 0
    for s in movs:
        sc = bytes(data).find(b'\x0f\x05', s, s + 80)
        if sc < 0:
            print(f"  mov@{s:#x}: no syscall within 80 bytes - left alone")
            continue
        data[s + 1] = SYS_NEW
        patched += 1
        print(f"  patched mov@{s:#x}: eax {SYS_OLD:#x} -> {SYS_NEW:#x} (syscall@{sc:#x})")
    open(path, 'wb').write(bytes(data))
    print(f"{path}: {patched} patched, {skipped} already done, {len(movs)} old sites seen")
    return patched + skipped


if __name__ == '__main__':
    total = 0
    for p in sys.argv[1:]:
        total += patch(p)
    if total != SITES_EXPECTED:
        print(f"WARNING: expected {SITES_EXPECTED} sites, handled {total}")
        sys.exit(1)
    print("all sites handled")
