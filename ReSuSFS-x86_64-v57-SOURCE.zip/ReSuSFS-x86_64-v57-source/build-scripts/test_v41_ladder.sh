#!/bin/sh
# ============================================================================
# v26.11.41 substep-ladder regression test (host).
#
# Adapted from the v40 harness for the v41 semantics:
#   - the fake module has NO wd_timeout_s param (v41 removed the watchdog)
#   - the module sim walks the v41 sentinel ladder: -1 -> -100 (setter
#     entered) -> -101 (work queued) -> 0 (kworker in body) -> done=1
#   - T4 asserts the SENTINEL receipts and the post-echo receipt land in
#     init_trace.txt (the v40 field box died at the echo with neither)
#   - T11/T12 use the v26.11.41 payload stamp
#   - T14 checks the collector's fixed force_init readout (0200 present)
#
# T1..T3 seed v2 (unchanged from v40), T4..T7 ladder, T8..T10 stand-down,
# T11/T12 payload stamp + self-heal, T13 sentinel receipts, T14 collector.
#
# All hardcoded /data paths are substituted into scratch copies of utils.sh
# / boot-completed.sh / post-fs-data.sh; nothing on the host is touched.
# ============================================================================
SRC=/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module
T=/tmp/v41test
FB=$T/fakebin
FAIL=0

ok()   { echo "  [PASS] $1"; }
bad()  { echo "  [FAIL] $1"; FAIL=$((FAIL+1)); }
has()  { grep -qF "$2" "$1" 2>/dev/null && ok "$3" || bad "$3"; }
lacks(){ { ! grep -qF "$2" "$1" 2>/dev/null; } && ok "$3" || bad "$3"; }

rm -rf "$T"; mkdir -p "$T/adb/ReSuSFS_LKM" "$T/adb/ReSuSFS/logs" \
                "$T/adb/modules/ReSuSFS" "$T/persist" "$T/out" "$FB" "$T/kasym"

# ---- fake /proc/kallsyms: the FIELD shape (v40 field log) ----------------
cat > "$T/kasym/field" <<'EOF'
000000000001bc40 A current_task
ffffffff810fd360 t kallsyms_lookup_name
ffffffff810fd840 t kallsyms_lookup
ffffffff810fdce0 t sprint_symbol
ffffffff81067820 t panic
ffffffff81476500 t bcmp
EOF
cat > "$T/kasym/tables" <<'EOF'
000000000001bc40 A current_task
ffffffff810fd360 t kallsyms_lookup_name
ffffffff82074a60 d kallsyms_names
ffffffff82074b00 d kallsyms_offsets
ffffffff81000000 d kallsyms_relative_base
ffffffff82074b40 d kallsyms_num_syms
ffffffff82074c00 d kallsyms_markers
ffffffff82074c40 d kallsyms_token_table
ffffffff82074c80 d kallsyms_token_index
EOF
cat > "$T/kasym/empty" <<'EOF'
000000000001bc40 A current_task
ffffffff81067820 t panic
EOF

# ---- fake /proc / /sys trees ----------------------------------------------
mkdir -p "$T/proc/sys/kernel/random" "$T/proc/sys/kernel"
echo "0123456789abcdef0123456789abcdef" > "$T/proc/sys/kernel/random/boot_id"
echo 2 > "$T/proc/sys/kernel/kptr_restrict"

MODP="$T/sys/module/susfs_guard_lkm"
make_params() {
        rm -rf "$MODP"; mkdir -p "$MODP/parameters"
        # v41 param surface: NO wd_timeout_s
        for p in arm_stage force_init init_done init_maxstep init_laststep \
                 diag_log kr_seed kr_scan sc_entry_count diag_printk; do
                : > "$MODP/parameters/$p"
        done
}

V41_SYS="$T/sys"
export V41_SYS
cat > "$FB/ksud" <<'EOF'
#!/bin/sh
echo "ksud $*" >> "$V41_SIM_DIR/ksud.log"
if [ "$1" = "insmod" ]; then
        mkdir -p "$V41_SYS/module/susfs_guard_lkm/parameters"
        for p in arm_stage force_init init_done init_maxstep init_laststep \
                 diag_log kr_seed kr_scan sc_entry_count diag_printk; do
                [ -f "$V41_SYS/module/susfs_guard_lkm/parameters/$p" ] || : > "$V41_SYS/module/susfs_guard_lkm/parameters/$p"
        done
        exit 0
fi
exit 1
EOF
chmod +x "$FB/ksud"

cat > "$FB/uname" <<'EOF'
#!/bin/sh
case "$1" in
  -m) echo "x86_64" ;;
  -r) echo "5.15.178+" ;;
  *)  echo "Linux (none) 5.15.178+ #1 SMP PREEMPT x86_64 Android" ;;
esac
EOF
cat > "$FB/getprop" <<'EOF'
#!/bin/sh
case "$1" in
  ro.product.cpu.abi) echo "x86_64" ;;
  *) : ;;
esac
EOF
cat > "$FB/busybox" <<'EOF'
#!/bin/sh
a="$1"; shift
case "$a" in
  dmesg) echo "" ;;
  sleep) /bin/sleep "$@" ;;
  cp)    /bin/cp "$@" ;;
  chmod) /bin/chmod "$@" ;;
  rmmod) exit 1 ;;
  *)     command "$a" "$@" ;;
esac
EOF
chmod +x "$FB/uname" "$FB/getprop" "$FB/busybox"

# ---- module tree + path substitution --------------------------------------
MODDIR="$T/adb/modules/ReSuSFS"
mkdir -p "$MODDIR/lkm/x86_64/candidates" "$MODDIR/bin/x86_64" "$MODDIR/logs"
cp "$SRC/module.prop" "$MODDIR/module.prop"
sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS_LKM|$T/adb/ReSuSFS_LKM|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/proc/kallsyms|$T/kasym/current|g" \
    -e "s|/proc/sys/kernel|$T/proc/sys/kernel|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/utils.sh" > "$MODDIR/utils.sh"

sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/boot-completed.sh" > "$T/out/boot-completed.sh"
sed -e "s|/data/adb/modules/ReSuSFS|$MODDIR|g" \
    -e "s|/data/adb/ReSuSFS|$T/adb/ReSuSFS|g" \
    -e "s|/sys/module/susfs_guard_lkm|$MODP|g" \
    "$SRC/post-fs-data.sh" > "$T/out/post-fs-data.sh"
for f in "$MODDIR/utils.sh" "$T/out/boot-completed.sh" "$T/out/post-fs-data.sh"; do
        sed -i "s|^PATH=.*|PATH=$FB:\$PATH|" "$f"
done

# payload: a fake .ko + the v41 stamp
echo "V41KO-ANDROID13" > "$MODDIR/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
echo "V39KO-VANILLA"    > "$MODDIR/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "YMUUU"            > "$MODDIR/lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko"
echo "v26.11.41"        > "$MODDIR/lkm/x86_64/.payload_stamp"
cp "$MODDIR/utils.sh" "$T/out/utils.keep"

PERSIST="$T/adb/ReSuSFS"
BOOTLOG="$PERSIST/logs/boot.log"
INITTRACE="$PERSIST/logs/init_trace.txt"
mkdir -p "$PERSIST/logs"

# ---- the fake module "firmware": v41 sentinel ladder ----------------------
# sim_stage fires once per sleep tick (patched into every `sleep 1` of the
# scratch boot-completed.sh copy); the state machine walks the v41 module's
# own boundary sequence: setter entered (-100) -> work queued (-101) ->
# kworker in body + substeps (0..maxstep) -> init_done=1.
cat > "$T/out/simfn.sh" <<EOF
sim_stage() {
        st="\$(cat "$T/out/simstate" 2>/dev/null)"
        case "\$st" in
        ""|1)
                echo "-100" > "$MODP/parameters/init_laststep"
                echo 2 > "$T/out/simstate" ;;
        2)
                echo "-101" > "$MODP/parameters/init_laststep"
                echo 3 > "$T/out/simstate" ;;
        3)
                maxstep="\$(cat "$MODP/parameters/init_maxstep" 2>/dev/null)"
                case "\$maxstep" in ''|*[!0-9]*) maxstep=0 ;; esac
                laststep=\$maxstep
                {
                        echo "DIAG step 1: susfs_init ENTERED (maxstep=\$maxstep arm_stage=0)"
                        [ "\$maxstep" -ge 1 ] && { echo "DIAG step 2: imports_guard ok"; laststep=1; }
                        [ "\$maxstep" -ge 2 ] && { echo "resolver: KLN mode ACTIVE"; laststep=2; }
                        [ "\$maxstep" -ge 3 ] && { echo "current_task: gs_off=0x1bc40"; laststep=3; }
                        [ "\$maxstep" -ge 4 ] && { echo "DIAG step 4b: deadman ok"; laststep=4; }
                        [ "\$maxstep" -ge 5 ] && { echo "DIAG step 5: crosscheck ok"; laststep=5; }
                        [ "\$maxstep" -ge 6 ] && { echo "DIAG step 5a: patch ok"; laststep=6; }
                        [ "\$maxstep" -ge 7 ] && { echo "DIAG step 6: layer loop ok"; laststep=7; }
                        echo "DIAG step 9: susfs_init_body RETURNING 0 (laststep=\$laststep init_done=1)"
                } > "$MODP/parameters/diag_log"
                echo "\$laststep" > "$MODP/parameters/init_laststep"
                echo 1 > "$MODP/parameters/init_done"
                echo done > "$T/out/simstate" ;;
        esac
}
EOF
cat > "$FB/simhook" <<EOF
#!/bin/sh
. "$T/out/simfn.sh"
sim_stage
EOF
chmod +x "$FB/simhook"

reset_boot() {
        # kill any orphaned background witness (its baked-in sleep hook
        # would keep firing the module sim into the NEXT test's fake tree)
        pkill -f "$T/out/boot-completed.sh" 2>/dev/null
        pkill -f "$FB/simhook" 2>/dev/null
        sleep 0.3
        rm -rf "$PERSIST" "$T/adb/ReSuSFS_LKM"
        mkdir -p "$PERSIST/logs" "$T/adb/ReSuSFS_LKM"
        : > "$BOOTLOG"
        rm -f "$T/out/simstate"
        make_params
        cp "$T/out/utils.keep" "$MODDIR/utils.sh"
}

arm_simhook() { sed -i "s|sleep 1|sleep 1; $FB/simhook|" "$T/out/boot-completed.sh"; }
disarm_simhook() { sed -i "s|; $FB/simhook||" "$T/out/boot-completed.sh"; }

run_bc() {
        sh "$T/out/boot-completed.sh" >/dev/null 2>&1
        # the background witness outlives the script by design (30s window):
        # reap it here so it cannot fire the sleep-hook sim into later tests
        pkill -f "$T/out/boot-completed.sh" 2>/dev/null
        pkill -f "$FB/simhook" 2>/dev/null
        sleep 0.3
}

echo "== T1: seed v2 emits kln=+gsoff= from the field-shaped kallsyms =="
cp "$T/kasym/field" "$T/kasym/current"
reset_boot
. "$MODDIR/utils.sh"
S="$(seed_kallsyms_resolver_v2)"
case "$S" in
        kln=ffffffff810fd360* ) ok "seed v2 kln/gsoff: $S" ;;
        * ) bad "seed v2 kln/gsoff: got '$S'" ;;
esac
echo "kln=ffffffff810fd360 gsoff=0x1bc40" > "$MODP/parameters/kr_seed"
has "$MODP/parameters/kr_seed" "kln=ffffffff810fd360 gsoff=0x1bc40" "T1b kr_seed param written"

echo "== T2: seed v2 falls back to the table form =="
cp "$T/kasym/tables" "$T/kasym/current"
S="$(seed_kallsyms_resolver_v2)"
case "$S" in
        *"kln=ffffffff810fd360"*"offsets=ffffffff82074b00"* ) ok "T2 table form present with kln: $S" ;;
        * ) bad "T2 table form: got '$S'" ;;
esac

echo "== T3: seed v2 refuses when neither is visible =="
cp "$T/kasym/empty" "$T/kasym/current"
S="$(seed_kallsyms_resolver_v2 2>/dev/null)"
rc=$?
if [ "$rc" = "1" ] && [ -z "$S" ]; then ok "T3 refused (rc=1, no seed written)"
else bad "T3: rc=$rc seed='$S'"; fi
cp "$T/kasym/field" "$T/kasym/current"

echo "== T4: substep 0 dispatch + sentinel receipts + advance on ok =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 0 > "$PERSIST/init_seq"
arm_simhook
run_bc
seq="$(cat "$PERSIST/init_seq" 2>/dev/null)"
[ "$seq" = "1" ] && ok "T4 init_seq advanced 0 -> 1" || bad "T4 init_seq=$seq (want 1)"
[ -f "$INITTRACE" ] && ok "T4b init_trace.txt exists" || bad "T4b init_trace.txt missing"
has "$INITTRACE" "STEP 0/7 DISPATCHING" "T4c receipt BEFORE dispatch"
has "$INITTRACE" "module=v26.11.41-x86_64" "T4c2 module.prop version carried into the trace"
has "$INITTRACE" "writing force_init=1" "T4d receipt before the trigger"
has "$INITTRACE" "force_init write returned" "T4d2 post-echo receipt (the v40 field box never wrote this)"
has "$INITTRACE" "witness(bg): laststep=-1" "T4e witness saw the fresh module"
has "$INITTRACE" "laststep=-100" "T4f sentinel -100 receipt (setter entered)"
has "$INITTRACE" "laststep=-101" "T4g sentinel -101 receipt (work queued)"
has "$INITTRACE" "laststep=0 init_done=1" "T4h kworker-in-body receipt (dispatch proof complete)"
lacks "$INITTRACE" "watchdog" "T4i no watchdog receipts (v41 removed it)"
has "$PERSIST/stage_boot" "ok 0 " "T4j ok marker written"
has "$PERSIST/logs/diag_last.txt" "DIAG step 1" "T4k diag snapshot salvaged"
disarm_simhook

echo "== T5: nok leaves init_seq untouched =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 3 > "$PERSIST/init_seq"
run_bc
seq="$(cat "$PERSIST/init_seq" 2>/dev/null)"
[ "$seq" = "3" ] && ok "T5 nok kept seq=3 (same-rung retry)" || bad "T5 seq=$seq"
has "$PERSIST/stage_boot" "nok 0 " "T5b nok marker written"

echo "== T6: seq 6 ok -> seq 7 + arm_stage 1 =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 6 > "$PERSIST/init_seq"
arm_simhook
run_bc
seq="$(cat "$PERSIST/init_seq" 2>/dev/null)"
arm="$(cat "$PERSIST/arm_stage" 2>/dev/null)"
[ "$seq" = "7" ] && ok "T6 seq 6->7" || bad "T6 seq=$seq"
[ "$arm" = "1" ] && ok "T6b arm_stage raised to 1" || bad "T6b arm=$arm"
disarm_simhook

echo "== T7: seq 7 ok at arm 1 -> arm_stage 2 (cap respected) =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo 7 > "$PERSIST/init_seq"
echo 1 > "$PERSIST/arm_stage"
arm_simhook
run_bc
arm="$(cat "$PERSIST/arm_stage" 2>/dev/null)"
[ "$arm" = "2" ] && ok "T7 arm_stage 1->2" || bad "T7 arm=$arm"
disarm_simhook

echo "== T8: stale try + stage 0 -> stand-down dossier + flags removed =="
reset_boot
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
echo "try 0 deadbeefdeadbeefdeadbeefdeadbeef" > "$PERSIST/stage_boot"
echo 0 > "$PERSIST/arm_stage"
echo "[receipt] STEP 2/7 DISPATCHING (resolver)" > "$INITTRACE"
echo "resolver: KLN mode ACTIVE" > "$PERSIST/logs/diag_last.txt"
mkdir -p "$MODP/parameters"
sh "$T/out/post-fs-data.sh" >/dev/null 2>&1
[ ! -f "$PERSIST/enable_lkm" ] && ok "T8 enable_lkm removed" || bad "T8 enable_lkm still present"
[ ! -f "$PERSIST/enable_force_init" ] && ok "T8b enable_force_init removed" || bad "T8b still present"
[ -f "$PERSIST/no_init_this_boot" ] && ok "T8c no_init_this_boot sentinel written" || bad "T8c sentinel missing"
has "$BOOTLOG" "WEDGE DOSSIER" "T8d dossier in boot.log"
has "$BOOTLOG" "STEP 2/7 DISPATCHING" "T8e dossier carries the receipt line"
has "$BOOTLOG" "resolver: KLN mode ACTIVE" "T8f dossier carries diag_last content"

echo "== T9: stale try at stage 2 -> demote to 0 + cap stage_max =="
reset_boot
echo "try 2 deadbeefdeadbeefdeadbeefdeadbeef" > "$PERSIST/stage_boot"
echo 2 > "$PERSIST/arm_stage"
sh "$T/out/post-fs-data.sh" >/dev/null 2>&1
arm="$(cat "$PERSIST/arm_stage" 2>/dev/null)"
max="$(cat "$PERSIST/stage_max" 2>/dev/null)"
[ "$arm" = "0" ] && ok "T9 demoted to 0" || bad "T9 arm=$arm"
[ "$max" = "1" ] && ok "T9b stage_max capped at 1" || bad "T9b max=$max"

echo "== T10: suppression branch consumes no_init_this_boot =="
reset_boot
echo 1 > "$PERSIST/no_init_this_boot"
touch "$PERSIST/enable_lkm" "$PERSIST/enable_force_init"
run_bc
has "$BOOTLOG" "init suppressed this boot" "T10 suppression logged"
[ ! -f "$PERSIST/no_init_this_boot" ] && ok "T10b sentinel consumed" || bad "T10b sentinel left behind"

echo "== T11: payload stamp refresh in the install gate =="
reset_boot
echo "V40KO-OLD" > "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko"
. "$MODDIR/utils.sh" >/dev/null 2>&1
install_susfs_guard_lkm_x86_64 > "$T/out/inst.log" 2>&1
inst="$(cat "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" 2>/dev/null)"
[ "$inst" = "V41KO-ANDROID13" ] && ok "T11 v41 ko refreshed over v40" || bad "T11 ko='$inst'"
[ "$(cat "$T/adb/ReSuSFS_LKM/.payload_stamp" 2>/dev/null)" = "v26.11.41" ] && ok "T11b stamp written" || bad "T11b stamp missing"
echo "USERKO" > "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko"
install_susfs_guard_lkm_x86_64 > "$T/out/inst2.log" 2>&1
inst="$(cat "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" 2>/dev/null)"
[ "$inst" = "USERKO" ] && ok "T11c same-stamp keeps user file" || bad "T11c ko='$inst'"

echo "== T12: self-heal fires on stamp mismatch =="
reset_boot
echo "V40KO-OLD" > "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko"
rm -f "$T/adb/ReSuSFS_LKM/.payload_stamp"
touch "$PERSIST/enable_lkm"
rm -rf "$MODP"
V41_SYS="$T/sys"; export V41_SYS
sh -c ". $MODDIR/utils.sh; V41_SYS='$T/sys'; load_susfs_lkm" > "$T/out/heal.log" 2>&1
[ "$(head -n 1 "$T/adb/ReSuSFS_LKM/.payload_stamp" 2>/dev/null)" = "v26.11.41" ] && ok "T12 stamp written by self-heal" || bad "T12 stamp missing"
inst="$(cat "$T/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-android13-5.15.ko" 2>/dev/null)"
[ "$inst" = "V41KO-ANDROID13" ] && ok "T12b v41 ko in place after heal" || bad "T12b ko='$inst'"
has "$T/out/heal.log" "LKM loaded successfully" "T12c fake ksud load succeeded"

echo "== T13: sentinel receipts survive in the wedge dossier =="
reset_boot
echo "[receipt] witness(bg): laststep=-101 init_done=0 @2s" > "$INITTRACE"
echo "try 0 deadbeefdeadbeefdeadbeefdeadbeef" > "$PERSIST/stage_boot"
mkdir -p "$MODP/parameters"
sh "$T/out/post-fs-data.sh" >/dev/null 2>&1
has "$BOOTLOG" "witness(bg): laststep=-101" "T13 the next boot's dossier carries the sentinel receipt"

echo "== T14: collector's v41 param readout (force_init 0200 present) =="
reset_boot
make_params
. "$MODDIR/utils.sh" >/dev/null 2>&1
capture_lkm_live_evidence > "$T/out/coll.log" 2>&1
has "$T/out/coll.log" "v41 substep ladder" "T14a collector prints the v41 ladder header"
has "$T/out/coll.log" "force_init = present (0200 write-only by design" "T14b force_init presence via -e (v40 misread fixed)"
has "$T/out/coll.log" "wd_timeout_s = <removed in v41" "T14c watchdog removal reported"
lacks "$T/out/coll.log" "param not exposed - fallback image, no v40 experiment>" "T14d no stale v40 fallback line for present params"

echo
if [ "$FAIL" = "0" ]; then
        echo "v26.11.41 regression suite: ALL PASS"
else
        echo "v26.11.41 regression suite: $FAIL FAILURE(S)"
fi
exit $FAIL
