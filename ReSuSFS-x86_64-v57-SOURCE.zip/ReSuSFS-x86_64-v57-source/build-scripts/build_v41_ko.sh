#!/bin/bash
# build_v41_ko.sh - reproducible v26.11.41 x86_64 LKM rebuild recipe.
#
# Same environment as v40 (kernel.org linux-5.15.178 tarball, current.h
# override, three clang-compat build-tree patches, defconfig-derived
# .config, host tools via tools/env.sh, NDK r28c clang as CC, GNU
# ld/binutils link) with ONE codegen-level change:
#
#   RETPOLINE=n RETHUNK=n  ->  the module compiles with PLAIN `ret`
#   returns again (the v26.11.26-37 image profile that executed module code
#   live in the field at the v35 trigger).  The v40 image was built with
#   RETHUNK=y: 446 function returns as `cs jmp __x86_return_thunk` through
#   a loader-absolutized import, and the v40 field box froze at the
#   force_init write - the FIRST module code the whole boot executes.  With
#   the watchdog also gone from the source, panic/__x86_return_thunk drop
#   out of the import set entirely.
#
# Expected output properties (verified by the tail of this script):
#   vermagic:  5.15.178+ SMP preempt modversions   (byte-identical to v39/v40)
#   imports:   the v26.11.26-37 proven set + bcmp, - panic - __x86_return_thunk
#   codegen:   zero "cs jmp" return thunks
set -e
BASE=/home/z/my-project
KSRC=$BASE/linux-5.15.178
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
NDKB=$BASE/ndk/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin

# 1. kernel source (restore_build_env.sh also rewrites the current.h override)
if [ ! -f "$KSRC/Makefile" ]; then
        [ -f "$BASE/linux-5.15.178.tar.xz" ] || {
                echo "[!] $BASE/linux-5.15.178.tar.xz missing - download it from kernel.org first"; exit 1; }
        tar -xf "$BASE/linux-5.15.178.tar.xz" -C "$BASE"
fi
bash "$BASE/scripts/restore_build_env.sh" >/dev/null 2>&1 || true
grep -q susfs_current_task_gs_off "$KSRC/arch/x86/include/asm/current.h" || {
        echo "[!] current.h override missing - restore_build_env.sh failed"; exit 1; }

# 2. the three local clang-compat patches on the build tree (idempotent)
python3 - <<'PY'
import os
ksrc = os.environ.get('KSRC', '/home/z/my-project/linux-5.15.178')
def patch(path, old, new):
    p = os.path.join(ksrc, path)
    s = open(p).read()
    if old in s and new not in s:
        s = s.replace(old, new, 1)
        open(p, 'w').write(s)
        print('patched', path)
    elif new in s:
        print('already', path)
    else:
        print('SKIP (anchor missing)', path)
patch('Makefile', 'KBUILD_CFLAGS   += -fconserve-stack',
      '# v40 local build-tree patch: -fconserve-stack is gcc-only (clang rejects it)\n# KBUILD_CFLAGS   += -fconserve-stack')
patch('Makefile', 'KBUILD_CFLAGS += -Wno-maybe-uninitialized',
      '# v40 local build-tree patch: gcc-only warning flag (clang rejects it)\n# KBUILD_CFLAGS += -Wno-maybe-uninitialized')
patch('Makefile', 'KBUILD_CFLAGS += $(call cc-ifversion, -ge, 0901, -Wno-alloc-size-larger-than)',
      '# v40 local build-tree patch: gcc-only warning flag (clang rejects it)\n# KBUILD_CFLAGS += $(call cc-ifversion, -ge, 0901, -Wno-alloc-size-larger-than)')
PY

# 3. config: the v40 options PLUS the v41 codegen reversion.
#    Applied to an existing .config too (RETPOLINE/RETHUNK were ON in the
#    v40 build tree) - the change must land regardless of whether the
#    config was prepared fresh or inherited from the v40 build.
if [ ! -f "$KSRC/.config" ]; then
        ( cd "$KSRC" && . "$BASE/tools/env.sh" && make defconfig >/dev/null && \
          ./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
                --enable PREEMPT --enable SMP \
                --disable MODULE_UNLOAD --disable X86_5LEVEL \
                --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY && \
          make olddefconfig >/dev/null && make modules_prepare >/dev/null )
        echo "[+] config prepared"
fi
( cd "$KSRC" && . "$BASE/tools/env.sh" && \
  ./scripts/config -d RETPOLINE -d RETHUNK && \
  make olddefconfig >/dev/null && make modules_prepare >/dev/null ) || true
echo "[*] v41 codegen profile: RETPOLINE/RETHUNK -> $(grep -cE '^CONFIG_RETPOLINE=y|^CONFIG_RETHUNK=y' "$KSRC/.config" || true) enabled (want 0)"

# 4. clean rebuild of the module (the .cmd flag change detection handles
#    it, but a clean tree cannot carry stale v40 objects either)
cd "$KSRC"
. "$BASE/tools/env.sh"
export PATH="$NDKB:$PATH"
make M="$LKM" clean >/dev/null 2>&1 || true
make M="$LKM" CC=clang modules
echo "[+] built: $LKM/susfs_guard_lkm.ko"

# 5. verification (fail the build on any regression)
python3 - <<'PY'
import subprocess, sys
KO = '/home/z/my-project/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel/susfs_guard_lkm.ko'
d = open(KO, 'rb').read()
i = d.find(b'vermagic=')
vm = d[i:i+80].split(b'\x00')[0].decode()
print('vermagic:', vm)
assert vm.startswith('vermagic=5.15.178+ SMP preempt modversions'), 'vermagic regression'

imports = sorted(set(l.split()[1] for l in subprocess.check_output(['nm', '-u', KO], text=True).splitlines() if l.strip()))
print(f'imports: {len(imports)}')
for bad in ('panic', '__x86_return_thunk'):
    assert bad not in imports, f'{bad} still imported (watchdog/thunk removal failed)'
print('panic / __x86_return_thunk absent: OK')

dis = subprocess.check_output(['objdump', '-d', KO], text=True)
thunks = dis.count('cs jmp')
print(f'return thunks (cs jmp): {thunks} (want 0)')
assert thunks == 0, 'return-thunk codegen still present (RETPOLINE/RETHUNK not disabled)'

for sym in ('susfs_param_set_force_init', 'susfs_deferred_init_fn', 'susfs_init_body', 'susfs_init_work'):
    assert sym in dis, f'{sym} missing from the image'
assert 'susfs_wd_fire' not in dis and 'susfs_wd_work' not in dis, 'watchdog still present'
print('sentinel setter/work/body present, watchdog gone: OK')
PY
echo "[i] verify imports vs the field kernel kallsyms:"
python3 "$BASE/scripts/verify_imports_field_kallsyms.py" | head -n 20
