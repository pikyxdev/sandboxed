#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.46.zip from work/pkg46 (v45 tree + v46 edits).

- Reproduces the v45 zip layout exactly (same entries, incl. dir entries).
- Module binaries (.ko) are carried over byte-identical.
- Verifies: entry sets match v45, .ko CRCs identical, v46 markers present.
"""
import zipfile, os, hashlib

SRC = '/home/z/my-project/work/pkg46'
V45 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.45.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.46.zip'

v45_names = zipfile.ZipFile(V45).namelist()

# collect files + directories in pkg46
file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
v45_dir_set = set(n for n in v45_names if n.endswith('/'))

missing_dirs = v45_dir_set - dir_set
extra_dirs = dir_set - v45_dir_set
missing_files = set(v45_names) - set(file_paths) - v45_dir_set
extra_files = set(file_paths) - set(v45_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v45'

# order entries exactly like v45 (same positions, dirs and files interleaved)
file_set = set(file_paths)
ordered = [n for n in v45_names if n in dir_set or n in file_set]
assert len(ordered) == len(v45_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
z45, z46 = zipfile.ZipFile(V45), zipfile.ZipFile(OUT)
n45, n46 = z45.namelist(), z46.namelist()
assert n46 == n45, 'entry list mismatch'
ko_diff = []
for n in n46:
    if n.endswith('.ko'):
        c45 = hashlib.sha256(z45.read(n)).hexdigest()
        c46 = hashlib.sha256(z46.read(n)).hexdigest()
        if c45 != c46:
            ko_diff.append(n)
print('.ko byte-identical:', 'YES' if not ko_diff else ko_diff)
assert not ko_diff

changed = []
for n in n46:
    if z45.read(n) != z46.read(n):
        changed.append(n)
print('changed vs v45:', changed)

pfd = z46.read('post-fs-data.sh').decode()
bc = z46.read('boot-completed.sh').decode()
mp = z46.read('module.prop').decode()
for marker in ('v26.11.46 HARD CAP', 'enable_sc_probe', 'echo 1 > "$STAGE_MAX_FILE"'):
    assert marker in pfd, marker
for marker in ('enable_sc_probe', 'DEFUSED BY DEFAULT', 'v46 ceiling'):
    assert marker in bc, marker
assert 'version=v26.11.46-x86_64' in mp and 'versionCode=124' in mp
print('v46 markers: OK')
print('zip size:', os.path.getsize(OUT))
