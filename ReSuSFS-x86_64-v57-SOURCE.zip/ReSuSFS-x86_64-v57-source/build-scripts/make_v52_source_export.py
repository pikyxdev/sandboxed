#!/usr/bin/env python3
"""make_v52_source_export.py - complete v52 source export for download.

Builds TWO archives in download/:
  1. ReSuSFS-x86_64-v52-SOURCE.zip   - every source/build input of v26.11.52
  2. ReSuSFS-x86_64-ALL-BUILDS-v22-v52.zip - all 31 flashable zips + port.zip

Everything the campaign produced that is NOT re-downloadable from public
sources is inside archive 1. The big public inputs (kernel tarball, a13
mirror, clang-17 debs) are documented in README-BUILD-V52.md instead.
"""
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile

BASE = '/home/z/my-project'
STAGE = '/tmp/v52src'
TOP = f'{STAGE}/ReSuSFS-x86_64-v52-source'
OUT_SRC = f'{BASE}/download/ReSuSFS-x86_64-v52-SOURCE.zip'
OUT_ALL = f'{BASE}/download/ReSuSFS-x86_64-ALL-BUILDS-v22-v52.zip'


def sh(cmd, **kw):
    print(f'[cmd] {cmd}')
    return subprocess.run(cmd, shell=True, check=True, **kw)


def copy_rel(src, dst_rel):
    """Copy file or tree into TOP/dst_rel."""
    dst = os.path.join(TOP, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_stats(path):
    n, total = 0, 0
    for root, _d, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            if os.path.islink(fp):
                continue
            n += 1
            total += os.path.getsize(fp)
    return n, total


# ---------------------------------------------------------------- stage tree
print('== staging ==', flush=True)
shutil.rmtree(STAGE, ignore_errors=True)
os.makedirs(TOP)

P = f'{BASE}/ReSuSFS-x86_64-port'
S = f'{BASE}/scripts'
W = f'{BASE}/work'
D = f'{BASE}/download'

# 1. LKM sources (the kernel-module heart of the port)
copy_rel(f'{P}/susfs4ksu-lkm-x64-5.15', 'lkm-source/susfs4ksu-lkm-x64-5.15')
for f in ('sc_v50.c', 'sc_v50.o', 'sc_v51.c', 'sc_v51.o'):
    copy_rel(f'{P}/{f}', f'lkm-source/{f}')
for f in ('sc_probe.c', 'sc_probe', 'test_sc_v51_host.c', 'test_sc_v51_host'):
    copy_rel(f'{S}/{f}', f'lkm-source/{f}')

# 2. Userspace sources
copy_rel(f'{BASE}/ksu_susfs.c', 'userspace-src/ksu_susfs.c')
copy_rel(f'{S}/libredir.c', 'userspace-src/libredir.c')
copy_rel(f'{S}/port_insmod_x64.py', 'userspace-src/port_insmod_x64.py')
copy_rel(f'{BASE}/testbuild', 'userspace-src/testbuild')

# 3. Module template (staging tree the flashable is built from)
copy_rel(f'{P}/ReSuSFS', 'module-template/ReSuSFS')

# 4. Exact v52 package staging
copy_rel(f'{W}/pkg52', 'package-v52')

# 5. Build scripts - the whole campaign lineage + port-level scripts
copy_rel(S, 'build-scripts')
copy_rel(f'{P}/scripts', 'build-scripts/port-scripts')
copy_rel(f'{P}/bin', 'build-scripts/port-bin')

# 6. Bit-exact build outputs (reference binaries)
for f in ('susfs_guard_lkm-x86_64-android13-5.15.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v51.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v51.ko'):
    copy_rel(f'{P}/{f}', f'binaries/{f}')

# 7. Kernel fragments (current.h override etc. - tiny, part of build inputs)
copy_rel(f'{BASE}/linux-5.15.178', 'kernel-fragments/linux-5.15.178')
copy_rel(f'{BASE}/a13', 'kernel-fragments/a13')
copy_rel(f'{BASE}/a13-full', 'kernel-fragments/a13-full')

# 8. Upstream references
copy_rel(f'{BASE}/ReSuSFS-x86_64', 'upstream-refs/ReSuSFS-x86_64')
copy_rel(f'{BASE}/susfs_lkm_x64.zip', 'upstream-refs/susfs_lkm_x64.zip')
copy_rel(f'{BASE}/susfs4ksu_LICENSE', 'upstream-refs/susfs4ksu_LICENSE')
for f in ('kp.json', 'branches.json', 'tree.json', 'lkm_release.json', 'test.tab.c'):
    copy_rel(f'{BASE}/{f}', f'upstream-refs/{f}')

# 9. Docs
copy_rel(f'{P}/README-x86_64-PORT.md', 'docs/README-x86_64-PORT.md')
copy_rel(f'{P}/ReSuSFS/docs/PORTING_x86_64.md', 'docs/PORTING_x86_64.md')
copy_rel(f'{P}/ReSuSFS/CHANGELOG.md', 'docs/CHANGELOG.md')
copy_rel(f'{P}/ReSuSFS/update.json', 'docs/update.json')
for v in (47, 48, 49, 50, 51, 52):
    copy_rel(f'{D}/ReSuSFS-v{v}-TESTPLAN.md', f'docs/test-plans/ReSuSFS-v{v}-TESTPLAN.md')
copy_rel(f'{D}/ReSuSFS-v47-Field-Validation-Report.docx',
         'docs/ReSuSFS-v47-Field-Validation-Report.docx')
copy_rel(f'{D}/ReSuSFS-v47-Field-Validation-Report.pdf',
         'docs/ReSuSFS-v47-Field-Validation-Report.pdf')
copy_rel(f'{BASE}/logs', 'docs/build-logs')

# 10. Field logs (user's device evidence - irreplaceable)
copy_rel(f'{BASE}/upload', 'field-logs')

# 11. The exact flashable artifact
copy_rel(f'{D}/ReSuSFS-x86_64-v26.11.52.zip', 'flashable/ReSuSFS-x86_64-v26.11.52.zip')

# 12. Git provenance
prov = []
for cmd in ('git log --oneline --all --date=short --pretty=format:%h %ad %s',
            'git ls-files'):
    r = subprocess.run(f'git -C {BASE} {cmd}', shell=True,
                       capture_output=True, text=True)
    prov.append(f'$ {cmd}\n{r.stdout.strip()}\n')
open(f'{TOP}/git-provenance.txt', 'w').write(
    'ReSuSFS x86_64 port campaign - git provenance snapshot (2026-11-25)\n'
    '=' * 70 + '\n\n' + '\n'.join(prov))
print('[ok] tree staged')

# ------------------------------------------------------------- checksums
KEY = {
    'flashable/ReSuSFS-x86_64-v26.11.52.zip':
        f'{D}/ReSuSFS-x86_64-v26.11.52.zip',
    'package-v52/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko':
        f'{W}/pkg52/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'package-v52/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko':
        f'{W}/pkg52/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
    'lkm-source/sc_v51.c (THE v52 graft source)': f'{P}/sc_v51.c',
    'lkm-source/sc_v51.o': f'{P}/sc_v51.o',
    'lkm-source/sc_probe.c': f'{S}/sc_probe.c',
    'package-v52/bin/x86_64/ksu_susfs (stock CLI)': f'{W}/pkg52/bin/x86_64/ksu_susfs',
    'package-v52/bin/x86_64/susfs_insmod': f'{W}/pkg52/bin/x86_64/susfs_insmod',
    'binaries/susfs_guard_lkm-x86_64-android13-5.15.ko (v49 base)':
        f'{P}/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'binaries/susfs_guard_lkm-x86_64-android13-5.15-v51.ko (v52 payload)':
        f'{P}/susfs_guard_lkm-x86_64-android13-5.15-v51.ko',
}
cksum_lines = []
for label, path in KEY.items():
    try:
        cksum_lines.append(f'{sha256(path)}  {label}')
    except FileNotFoundError:
        cksum_lines.append(f'MISSING  {label}')
cksum = '\n'.join(cksum_lines)
open(f'{TOP}/SHA256SUMS.key', 'w').write(cksum + '\n')
print('[ok] checksums:\n' + cksum)

# ------------------------------------------------- ALL-BUILDS archive first
print('== ALL-BUILDS archive ==', flush=True)
if os.path.exists(OUT_ALL):
    os.remove(OUT_ALL)
builds = sorted(
    f for f in os.listdir(D)
    if f.startswith('ReSuSFS-x86_64-v26.11.') and f.endswith('.zip'))
expected = [f'ReSuSFS-x86_64-v26.11.{n}.zip' for n in range(22, 53)]
missing = [b for b in expected if b not in builds]
assert not missing, f'missing flashable zips: {missing}'
sh(f'cd {D} && zip -0 -q -r {OUT_ALL} ' + ' '.join(expected)
   + ' ReSuSFS-x86_64-port.zip')
sha_all = sha256(OUT_ALL)
print(f'[ok] {OUT_ALL} ({len(expected)+1} zips, {os.path.getsize(OUT_ALL)} bytes)')

# ------------------------------------------------------------- README-BUILD
readme = '''# ReSuSFS x86_64 port - v26.11.52 (v52) COMPLETE SOURCE EXPORT

Exported 2026-11-25 from the build sandbox, so the campaign survives a
sandbox recycle. This archive contains every source file, build script,
kernel-module input and document that is NOT re-downloadable from public
sources. Together with `ReSuSFS-x86_64-ALL-BUILDS-v22-v52.zip` (all 31
flashable builds + the first port snapshot) it can rebuild v52 bit-for-bit.

## 1. What v52 is (one paragraph)

THE CMD-TABLE FIX. The v51 field run (2026-11-25, fresh instance, full
10-boot ladder: substeps 0-7 then arm_stage 1-3, every rung healthy, no
wedge) proved the transport end-to-end and, for the first time,
`ksu_susfs show version` ANSWERED (v2.3.0). But `show variant` and
`show enabled_features` failed: the graft had the two wire cmd ids
swapped versus the stock CLI's dispatch (CLI wire ABI: 0x555e1=version,
20B answer; 0x555e2=enabled_features, 8196B; 0x555e3=variant, 20B).
v52 corrects the two constants in `sc_v51.c`, adds a WIRE-DISPATCH LOCK
that machine-checks the shipped .ko against the CLI's literal cmd ids at
build time, and installs sc_probe to /data/adb/ksu/bin so the self-test
actually runs it in the field. 51->52 re-bases the ladder automatically
(in-place flash-over = 4 reboots; fresh instance = full 10-boot climb).

## 2. Build chain (what produces what)

    lkm-source/susfs4ksu-lkm-x64-5.15/kernel/*.c   (LKM sources)
      + linux-5.15.178.tar.xz        (kernel.org 5.15.178 - NOT bundled)
      + a13-mirror.tar.gz            (android13-5.15 ASB-2025-03-05 - NOT bundled)
      |-- scripts/build_v49_ko.sh --> base .ko (android13 + vanilla variants,
      |                                  in-tree build, syscall 169->173 patch)
      |-- scripts/build_v51_ko.sh --> compiles lkm-source/sc_v51.c with
      |       (clang-17)               clang-17 and grafts it onto the base
      |                                .ko (weak-symbol rebind) -> *-v51.ko
      |                                = THE v52 payload (sc_v51.c carries
      |                                the cmd-table fix)
      |-- scripts/build_v52_verify.py -> WIRE-DISPATCH LOCK + graft symbol
      |                                   and calibration checks (must PASS)
      |-- scripts/make_pkg52.py ----> work/pkg52 (from work/pkg51; pkg51 is
      |                                   byte-identical to the v51 flashable)
      |-- scripts/build_v52_zip.py -> ReSuSFS-x86_64-v26.11.52.zip
          (asserts layout identical to the v51 zip: keep
           download/ReSuSFS-x86_64-v26.11.51.zip in place, from ALL-BUILDS)

## 3. Restoring the sandbox layout

All scripts hardcode BASE=/home/z/my-project. Either recreate that exact
path or `sed -i s#/home/z/my-project#<your-base>#` every script.

| archive path                       | sandbox path                             |
|------------------------------------|------------------------------------------|
| lkm-source/susfs4ksu-lkm-x64-5.15  | ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15 |
| lkm-source/sc_v50.c, sc_v51.c, *.o, sc_probe* , test_sc_v51_host* | ReSuSFS-x86_64-port/ and scripts/ (see file names; sc_v51.* + sc_v50.* go to ReSuSFS-x86_64-port/, sc_probe*/test_* go to scripts/) |
| userspace-src/*                    | ksu_susfs.c, scripts/libredir.c, scripts/port_insmod_x64.py, testbuild/ |
| module-template/ReSuSFS            | ReSuSFS-x86_64-port/ReSuSFS (module staging tree) |
| package-v52                        | work/pkg52 |
| build-scripts/* (top level)        | scripts/* |
| build-scripts/port-scripts/*       | ReSuSFS-x86_64-port/scripts/* |
| build-scripts/port-bin/*           | ReSuSFS-x86_64-port/bin/* |
| binaries/*.ko                      | ReSuSFS-x86_64-port/ (reference outputs) |
| kernel-fragments/*                 | linux-5.15.178/, a13/, a13-full/ (tiny overrides; regenerated by build_v49_ko.sh anyway) |
| upstream-refs/*                    | repo root (ReSuSFS-x86_64/, susfs_lkm_x64.zip, *.json, ...) |
| flashable/ReSuSFS-x86_64-v26.11.52.zip | download/ (the artifact to flash) |

Then, from ALL-BUILDS:
    mkdir -p download work
    unzip ReSuSFS-x86_64-ALL-BUILDS-v22-v52.zip -d download
    # pkg51 (input of make_pkg52.py) = the v51 flashable contents:
    mkdir -p work/pkg51
    unzip download/ReSuSFS-x86_64-v26.11.51.zip -d work/pkg51
    # (verified 2026-11-25: work/pkg51 was byte-identical to the v51 zip)

## 4. Big public inputs NOT bundled (re-fetch)

| input | size | where |
|-------|------|-------|
| linux-5.15.178.tar.xz | 126 MB | https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.15.178.tar.xz |
| a13-mirror.tar.gz | 201 MB | git clone --depth 1 https://android.googlesource.com/kernel/common -b android13-5.15 (ASB-2025-03-05 state; the original tarball's inner dir is kernel_common-ASB-2025-03-05_13-5.15; if you re-clone, repack with that inner name or edit build_v49_ko.sh restore_tree) |
| clang-17 (Debian, 17.0.6-22+b2) | 35 MB debs | 4 debs, exact filenames below; extract ALL with `dpkg-deb -x` into toolchain/clang17/ so that toolchain/clang17/usr/lib/llvm-17/bin/clang exists |
| host toolchain (flex bison bc libelf zlib zstd) | small | scripts/restore_build_env.sh downloads these automatically |
| tools/root fake-root (host CLI tests) | 11 MB | rebuild per tools/env.sh: a Debian usr tree (libc etc.) used via LD_PRELOAD=libredir.so; source userspace-src/libredir.c |

Exact clang-17 debs used (from Debian 12/bookworm pool):
    clang-17_1%3a17.0.6-22+b2_amd64.deb
    libclang-common-17-dev_1%3a17.0.6-22+b2_amd64.deb
    libclang-cpp17t64_1%3a17.0.6-22+b2_amd64.deb
    libllvm17t64_1%3a17.0.6-22+b2_amd64.deb

## 5. Rebuild v52 from scratch (commands)

    export BASE=/home/z/my-project          # or your rebased path
    # 0. restore layout per section 3 + re-fetch section 4 inputs
    # 1. kernel trees + current.h override + host debs (idempotent):
    bash $BASE/scripts/restore_build_env.sh
    # 2. base .ko (in-tree builds against both kernel trees):
    bash $BASE/scripts/build_v49_ko.sh
    # 3. clang-17 graft with the CMD-TABLE FIX (= v52 payload):
    bash $BASE/scripts/build_v51_ko.sh      # compiles sc_v51.c fresh
    # 4. machine verification (wire-dispatch lock MUST pass):
    python3 $BASE/scripts/build_v52_verify.py
    # 5. package staging:
    python3 $BASE/scripts/make_pkg52.py     # work/pkg51 -> work/pkg52
    # 6. final zip (layout-asserted against the v51 zip):
    python3 $BASE/scripts/build_v52_zip.py
    # 7. compare with the shipped artifact:
    sha256sum $BASE/download/ReSuSFS-x86_64-v26.11.52.zip

Note: step 6 writes the zip deterministically (same entries, order and
modes as v51); timestamps follow the files, so a byte-identical result is
expected only if file mtimes match. Content identity is what matters -
compare the SHA256SUMS.key entries.

## 6. Host tests (optional, no device needed)

    gcc -o /tmp/test_sc_v51_host scripts/test_sc_v51_host.c && /tmp/test_sc_v51_host
    # KCFI probes used during v50 diagnosis:
    bash scripts/kcfi_probe.sh; bash scripts/kcfi_caller_probe.sh

## 7. Field flash - what to expect from v52

Flash `flashable/ReSuSFS-x86_64-v26.11.52.zip` in KernelSU (or Magisk;
see docs/test-plans/ReSuSFS-v52-TESTPLAN.md). In-place 51->52 flash-over
re-bases the ladder: 4 reboots (stage 0, 1, 2=OBSERVE, 3=FULL). At stage
3 expect: `ksu_susfs show version` -> v2.3.0, `show variant` -> GKI-LKM,
`show enabled_features` -> the armed feature list (SUSFS_LKM_MODULES +
sus_mount/enable_log/spoof_cmdline/open_redirect/sus_map). Feature
commands still answer not-handled this rung; the susfs list application
lights up rung by rung from v53. After any wedge send back the five
logs: logs/init_trace.txt, logs/diag_last.txt, logs/boot.log,
logs/kernel_facts.txt, logs/sc_selftest.txt.

## 8. If the sandbox died with this archive in hand

Everything unique is here. Historical flashables: ALL-BUILDS zip.
Campaign history: docs/test-plans/ (v47-v52), docs/build-logs/,
field-logs/ (your device evidence), git-provenance.txt, and the
per-version story embedded in each build script header and
README-DIAGNOSTIC.md inside package-v52/.
'''
open(f'{TOP}/README-BUILD-V52.md', 'w').write(readme)

# ----------------------------------------------------------------- MANIFEST
print('== manifest ==', flush=True)
sections = [
    ('lkm-source', 'LKM sources: susfs4ksu-lkm-x64-5.15 tree, sc_v50/v51 graft sources + objects, sc_probe, host test'),
    ('userspace-src', 'userspace sources: ksu_susfs.c, libredir.c, port_insmod_x64.py, testbuild/'),
    ('module-template', 'ReSuSFS module staging tree (scripts, configs, bin, staged lkm payload)'),
    ('package-v52', 'EXACT staging tree of the v52 flashable (what the zip contains)'),
    ('build-scripts', 'full campaign build/verify/zip/test script lineage + port-level scripts'),
    ('binaries', 'bit-exact build outputs: v49 base, v50, v51 graft .ko (= v52 payload), port bin/'),
    ('kernel-fragments', 'current.h override + tiny kernel tree fragments used by host builds'),
    ('upstream-refs', 'upstream ReSuSFS module template, upstream susfs LKM zip, repo metadata, license'),
    ('docs', 'port docs, porting guide, changelog, test plans v47-v52, v47 field report, build logs'),
    ('field-logs', 'YOUR device evidence (upload/): boot logs, pasted diagnostics, LDPlayer guide'),
    ('flashable', 'the exact v26.11.52 flashable zip'),
]
lines = [
    '# MANIFEST - ReSuSFS x86_64 v26.11.52 source export',
    '',
    f'Exported: 2026-11-25 (Asia/Jakarta). Sandbox: /home/z/my-project',
    f'Flashable v52 SHA256: {sha256(f"{D}/ReSuSFS-x86_64-v26.11.52.zip")}',
    f'ALL-BUILDS zip SHA256: {sha_all}',
    '',
    'See README-BUILD-V52.md for the rebuild guide and the list of big',
    're-downloadable inputs (kernel tarball, a13 mirror, clang-17 debs).',
    'Key artifact checksums: SHA256SUMS.key. Git snapshot: git-provenance.txt.',
    '',
    '| directory | files | bytes | contents |',
    '|-----------|-------|-------|----------|',
]
for name, desc in sections:
    p = os.path.join(TOP, name)
    n, total = tree_stats(p)
    lines.append(f'| {name}/ | {n} | {total} | {desc} |')
lines += [
    '',
    'NOT included (re-downloadable, see README-BUILD-V52.md section 4):',
    'linux-5.15.178.tar.xz (kernel.org), a13-mirror.tar.gz (googlesource',
    'android13-5.15), clang-17 debs (Debian), tools/root fake-root (11 MB,',
    'rebuilt from system packages), historical work/ staging dirs (their',
    'outputs are the flashables in ALL-BUILDS), .env (sandbox boilerplate).',
    'work/pkg51 is NOT included: byte-identical to the v51 flashable',
    '(verified 2026-11-25), extract it from ALL-BUILDS when rebuilding.',
]
open(f'{TOP}/MANIFEST.md', 'w').write('\n'.join(lines) + '\n')
print('[ok] MANIFEST.md + README-BUILD-V52.md written')

# ------------------------------------------------------------- source zip
print('== source zip ==', flush=True)
if os.path.exists(OUT_SRC):
    os.remove(OUT_SRC)
sh(f'cd {STAGE} && zip -q -r -9 {OUT_SRC} ReSuSFS-x86_64-v52-source')

# ------------------------------------------------------------- verification
print('== verify ==', flush=True)
for z in (OUT_SRC, OUT_ALL):
    sh(f'unzip -t -qq {z}')
    with zipfile.ZipFile(z) as zf:
        n = len(zf.namelist())
    print(f'[PASS] {z}: {n} entries, {os.path.getsize(z):,} bytes, sha256={sha256(z)}')

# sanity: key files present in the source zip
must = ['ReSuSFS-x86_64-v52-source/README-BUILD-V52.md',
        'ReSuSFS-x86_64-v52-source/MANIFEST.md',
        'ReSuSFS-x86_64-v52-source/SHA256SUMS.key',
        'ReSuSFS-x86_64-v52-source/lkm-source/sc_v51.c',
        'ReSuSFS-x86_64-v52-source/lkm-source/susfs4ksu-lkm-x64-5.15/kernel/susfs_main.c',
        'ReSuSFS-x86_64-v52-source/package-v52/customize.sh',
        'ReSuSFS-x86_64-v52-source/package-v52/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
        'ReSuSFS-x86_64-v52-source/build-scripts/build_v51_ko.sh',
        'ReSuSFS-x86_64-v52-source/build-scripts/build_v52_verify.py',
        'ReSuSFS-x86_64-v52-source/build-scripts/make_pkg52.py',
        'ReSuSFS-x86_64-v52-source/build-scripts/build_v52_zip.py',
        'ReSuSFS-x86_64-v52-source/flashable/ReSuSFS-x86_64-v26.11.52.zip',
        'ReSuSFS-x86_64-v52-source/field-logs/boot.log',
        ]
names = set(zipfile.ZipFile(OUT_SRC).namelist())
miss = [m for m in must if m not in names]
assert not miss, f'missing from source zip: {miss}'
print(f'[PASS] all {len(must)} key entries present')
print('DONE')
