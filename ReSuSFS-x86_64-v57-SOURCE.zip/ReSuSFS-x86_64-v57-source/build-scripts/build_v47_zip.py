#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.47.zip from work/pkg47 (v46 tree + v47 edits).

- Reproduces the v46 zip layout exactly (same entries, incl. dir entries).
- This build's .ko binaries ARE new (the v47 transport rebuild); the CLI is
  the v45-patched binary with the v47 syscall-number patch (169 -> 173).
- Verifies: entry sets match v46, .ko differ from v46 (module changed),
  v47 markers present, CLI patched, payload stamp bumped.
"""
import zipfile, os, hashlib, re

SRC = '/home/z/my-project/work/pkg47'
V46 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.46.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.47.zip'

v46_names = zipfile.ZipFile(V46).namelist()

# collect files + directories in pkg47
file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
v46_dir_set = set(n for n in v46_names if n.endswith('/'))

missing_dirs = v46_dir_set - dir_set
extra_dirs = dir_set - v46_dir_set
missing_files = set(v46_names) - set(file_paths) - v46_dir_set
extra_files = set(file_paths) - set(v46_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v46'

# order entries exactly like v46
file_set = set(file_paths)
ordered = [n for n in v46_names if n in dir_set or n in file_set]
assert len(ordered) == len(v46_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
z46, z47 = zipfile.ZipFile(V46), zipfile.ZipFile(OUT)
n46, n47 = z46.namelist(), z47.namelist()
assert n47 == n46, 'entry list mismatch'

ko_changed = []
for n in n47:
    if n.endswith('.ko'):
        c46 = hashlib.sha256(z46.read(n)).hexdigest()
        c47 = hashlib.sha256(z47.read(n)).hexdigest()
        if c46 != c47:
            ko_changed.append((n, 'changed' if 'ymuuu' not in n else 'UNEXPECTED'))
print('ko changed vs v46:', [c[0] for c in ko_changed])
# the two REAL v47 builds must change; the ymuuu reference payload must NOT
changed_names = {c[0] for c in ko_changed}
assert 'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko' in changed_names, 'vanilla .ko must be new'
assert 'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko' in changed_names, 'android13 .ko must be new'
assert 'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko' not in changed_names, 'reference payload must stay byte-identical'

changed = []
for n in n47:
    if z46.read(n) != z47.read(n):
        changed.append(n)
print('changed vs v46:', sorted(changed))
assert set(changed) == {
    'README-DIAGNOSTIC.md', 'boot-completed.sh', 'customize.sh', 'module.prop', 'post-fs-data.sh',
    'bin/x86_64/ksu_susfs', 'lkm/x86_64/.payload_stamp',
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
}, f'unexpected change set: {sorted(changed)}'

pfd = z47.read('post-fs-data.sh').decode()
bc = z47.read('boot-completed.sh').decode()
mp = z47.read('module.prop').decode()
rd = z47.read('README-DIAGNOSTIC.md').decode()

# v47 shell markers
for marker in ('v26.11.47 ceiling', 'stage_max=3 - the v47 ceiling'):
    assert marker in pfd, marker
assert 'echo 3 > "$STAGE_MAX_FILE"' in pfd
assert 'enable_sc_probe' not in pfd, 'the v46 opt-in gate must be gone from post-fs-data'
for marker in ('RE-ENABLED BY DEFAULT', 'cold-arm redirect, nr 173', 'v47 ceiling'):
    assert marker in bc, marker
assert 'enable_sc_probe' not in bc, 'the v46 opt-in gate must be gone from boot-completed'
assert 'show enabled_features' in bc, 'the self-test now covers enabled_features'
assert 'version=v26.11.47-x86_64' in mp and 'versionCode=125' in mp
assert 'THE TRANSPORT BUILD' in mp and 'KSU_X86_PATCH_SYSCALL_DISPATCHER' in mp
assert 'v26.11.47' in rd and 'THE TRANSPORT BUILD' in rd

# payload stamp
assert z47.read('lkm/x86_64/.payload_stamp').decode().strip() == 'v26.11.47'

# CLI: the v47 syscall number
cd = z47.read('bin/x86_64/ksu_susfs')
new_sites = old_sites = 0
for m in re.finditer(b'\xb8\xad\x00\x00\x00', cd):
    s = m.start()
    if cd.find(b'\x0f\x05', s, s + 80) >= 0:
        new_sites += 1
for m in re.finditer(b'\xb8\xa9\x00\x00\x00', cd):
    s = m.start()
    if cd.find(b'\x0f\x05', s, s + 80) >= 0:
        old_sites += 1
assert new_sites == 9, f'CLI 173 sites: {new_sites}'
assert old_sites == 0, f'CLI 169 sites remain: {old_sites}'
print('CLI: 9 sites carry syscall 173, none carry 169 - OK')

# module markers inside the shipped .ko files
for n in ('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
          'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko'):
    d = z47.read(n)
    for marker in (b'__x64_sys_ioperm', b'transport LIVE', b'OBSERVE-ONLY',
                   b'susfs_sc_wrapper', b'no kprobe is registered anywhere'):
        assert marker in d, f'{n}: {marker}'
    assert b'kprobe REGISTERED (addr=%px mode=' not in d, f'{n}: old kprobe receipt'
    assert b'susfs_supercall_kprobe_active' not in d, f'{n}: old symbol name'
print('both .ko files carry the v47 transport - OK')

print('v47 markers: OK')
print('zip size:', os.path.getsize(OUT))
