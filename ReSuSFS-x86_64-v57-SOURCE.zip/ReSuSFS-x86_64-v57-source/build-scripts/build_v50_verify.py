#!/usr/bin/env python3
"""build_v50_verify.py - fail the v50 build on any regression.

The v50 module is the v49 field object with a clang-17 grafted entry +
installer.  This verifier proves BOTH halves of that claim on BOTH
candidates:

  V49 BASE INVARIANTS (must be untouched by the graft):
    - vermagic byte-exact '5.15.178+ SMP preempt modversions'
    - .gnu.linkonce.this_module size unchanged (0x300 vanilla / 0x340 a13)
    - undefined imports EXACTLY the v49 set (124, name-for-name)
    - .bss stomp pad at .bss+0 size 64; spill-window vars past +0x40
    - the v49 wrapper body still present (susfs_sc_wrapper, sc_call_orig)
    - inherited strings: transport LIVE / OBSERVE-ONLY receipts

  V50 GRAFT PROPERTIES (the new clang half):
    - susfs_sc_entry: single STRONG def (the v49 def is gone - dropped by
      ld -r), starts with endbr64, lock-increments susfs_sc_entry_count,
      observe path returns -22, full path tail-jumps susfs_sc_wrapper
    - genuine clang kCFI preamble: 16-byte window at [entry-16..entry-1)
      ending in 'b8 <typeid>' (movl opcode at -5, nonzero typeid at -4)
    - susfs_supercall_init: single STRONG def; references &susfs_sc_entry
      (32S relocs), calls ksu_patch_text (twice: 16-byte clone + 8-byte
      table write), calls ksu_kallsyms_lookup_name / susfs_fp_syscall_table
      / susfs_current_arm_stage / susfs_diag_logf
    - the susfs_layers[] wiring: .data R_X86_64_64 relocs against
      susfs_supercall_init and susfs_supercall_exit resolve to the GRAFT
      addresses (not the old v49 ones)
    - the four globalized state vars are B (global .bss), same .bss
      addresses as the base object
    - v50 receipt strings present ('v50 clang transport init', 'preamble
      window cloned + verified', 'v50 transport LIVE', refusal receipts)
    - NO weak duplicates of the overridden symbols survive

  CLI (carried over from the v49 payload): nine syscall-173 sites with the
  v45 nop'd return-checks, zero 169 sites.
"""
import subprocess, sys, re

A13 = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15-v50.ko'
KORG = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15-v50.ko'
A13_BASE = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15.ko'
KORG_BASE = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
CLI = '/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module/bin/x86_64/ksu_susfs'

fails = []

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True)

def symbols(ko):
    syms = {}
    for line in sh(f"nm -S --defined-only {ko}").splitlines():
        p = line.split()
        if len(p) >= 4:
            try:
                syms.setdefault(p[3], []).append((int(p[0], 16), p[2], p[1]))
            except ValueError:
                pass
    return syms

def check(label, cond, msg):
    print(f"  [{'OK' if cond else 'FAIL'}] {label}: {msg}")
    if not cond:
        fails.append(f"{label}: {msg}")

STOMP_VARS = ['susfs_diag_printk', 'susfs_probe_arm', 'susfs_probe_val',
              'susfs_force_init_val', 'susfs_init_done',
              'susfs_init_maxstep', 'fail_layer', 'susfs_sc_entry_count']

for name, ko, base, want_tm in (('android13', A13, A13_BASE, 0x340),
                                ('vanilla', KORG, KORG_BASE, 0x300)):
    print(f"### {name}: {ko}")
    d = open(ko, 'rb').read()
    i = d.find(b'vermagic=')
    vm = d[i:i+80].split(b'\x00')[0].decode()
    check(name, vm.startswith('vermagic=5.15.178+ SMP preempt modversions'), f"vermagic {vm!r}")

    # this_module size unchanged
    size = None
    for line in sh(f"readelf -SW {ko}").splitlines():
        m = re.search(r'\.gnu\.linkonce\.this_module\s+PROGBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
        if m:
            size = int(m.group(1), 16)
    check(name, size == want_tm, f"this_module size 0x{size:x} (want 0x{want_tm:x})")

    # imports EXACTLY the base set
    imports = sorted(set(l.split()[1] for l in sh(f"nm -u {ko}").splitlines() if l.strip()))
    base_imports = sorted(set(l.split()[1] for l in sh(f"nm -u {base}").splitlines() if l.strip()))
    check(name, imports == base_imports,
          f"imports identical to v49 base ({len(imports)}; extra={set(imports)-set(base_imports)}, missing={set(base_imports)-set(imports)})")

    syms = symbols(ko)

    # ---- the three overridden symbols: ONE strong def each, no weak dup ----
    for s in ('susfs_sc_entry', 'susfs_supercall_init', 'susfs_supercall_exit'):
        defs = syms.get(s, [])
        weak = [l for l in sh(f"nm {ko}").splitlines() if l.endswith(f' W {s}')]
        check(name, len(defs) == 1 and defs[0][1] == 'T',
              f"{s}: single strong T def at 0x{defs[0][0]:x}" if len(defs) == 1 else f"{s}: defs={defs}")
        check(name, not weak, f"{s}: no weak duplicate survives")

    # ---- the entry: endbr64 + lock incl + observe -22 + full tail-jump ----
    ent = sh(f"objdump -dr --disassemble=susfs_sc_entry {ko}")
    check(name, 'endbr64' in ent, "entry starts with endbr64")
    check(name, 'lock incl' in ent, "entry lock-increments the counter")
    check(name, re.search(r'mov\s+\$0xffffffffffffffea,%rax', ent) is not None,
          "observe path returns -22 (-EINVAL)")
    check(name, re.search(r'susfs_sc_entry_count', ent) is not None,
          "counter reloc present")
    check(name, re.search(r'R_X86_64_PLT32\s+susfs_sc_wrapper', ent) is not None,
          "full path tail-jumps susfs_sc_wrapper")

    # ---- genuine clang kCFI preamble in the 16-byte window ----
    ent_addr = syms['susfs_sc_entry'][0][0]
    cfi = syms.get('__cfi_susfs_sc_entry', [])
    check(name, len(cfi) == 1 and cfi[0][0] == ent_addr - 16 and int(cfi[0][2], 16) == 16,
          f"__cfi_susfs_sc_entry: 16-byte preamble block at entry-16 (0x{cfi[0][0]:x})" if cfi else "__cfi block missing")
    check(name, ent_addr % 16 == 0, f"entry 16-byte aligned (0x{ent_addr:x})")
    win = sh(f"objdump -s -j .text --start-address={ent_addr-16} --stop-address={ent_addr} {ko}")
    wbytes = None
    for l in win.splitlines():
        parts = l.split()
        if parts and parts[0].lower() == 'contents':
            continue
        try:
            if parts and int(parts[0], 16) == ent_addr - 16:
                wbytes = bytes.fromhex(''.join(parts[1:5]))[:16]
                break
        except ValueError:
            continue
    if wbytes is None:
        check(name, False, "preamble window bytes readable")
    else:
        check(name, wbytes[11] == 0xb8, f"movl opcode 0xb8 at [entry-5] (got 0x{wbytes[11]:02x})")
        typeid = int.from_bytes(wbytes[12:16], 'little')
        check(name, typeid == 0xb02b34d9,
              f"genuine clang typeid at [entry-4]: 0x{typeid:08x} (clang-17 for 'long (const struct pt_regs *)')")
        check(name, all(b == 0x90 for b in wbytes[0:11]), "nop padding fills [entry-16..-6)")

    # ---- the installer: relocs prove the clone + table write + gates ----
    init_rel = sh(f"objdump -dr --disassemble=susfs_supercall_init {ko}")
    relocs = []
    for l in init_rel.splitlines():
        if 'R_X86_64' not in l:
            continue
        m = re.search(r'R_X86_64_\w+\s+([^\s+-]+)', l)
        if m:
            relocs.append(m.group(1))
    check(name, 'susfs_sc_entry' in relocs, "init takes &susfs_sc_entry")
    n_patch = sum(1 for l in init_rel.splitlines() if re.search(r'R_X86_64_PLT32\s+ksu_patch_text', l))
    check(name, n_patch == 2, f"init calls ksu_patch_text twice (clone 16B + table 8B): {n_patch}")
    check(name, 'ksu_kallsyms_lookup_name' in relocs, "init resolves symbols")
    check(name, 'susfs_fp_syscall_table' in relocs, "init uses the fp-layer table cache")
    check(name, 'susfs_current_arm_stage' in relocs, "init reads the ladder rung")
    check(name, 'susfs_diag_logf' in relocs, "init writes receipts")
    check(name, 'sc_orig' in relocs or 'sc_installed' in relocs, "init wires the v49 state")

    # ---- the layers[] wiring binds to the GRAFT addresses ----
    rel_all = sh(f"readelf -rW {ko}")
    graft_init = syms['susfs_supercall_init'][0][0]
    graft_exit = syms['susfs_supercall_exit'][0][0]
    m_init = re.search(r'R_X86_64_64\s+([0-9a-f]+) susfs_supercall_init \+ 0', rel_all)
    m_exit = re.search(r'R_X86_64_64\s+([0-9a-f]+) susfs_supercall_exit \+ 0', rel_all)
    check(name, m_init is not None and int(m_init.group(1), 16) == graft_init,
          "susfs_layers[].init binds to the graft init" if m_init else "layers[] init reloc missing")
    check(name, m_exit is not None and int(m_exit.group(1), 16) == graft_exit,
          "susfs_layers[].exit binds to the graft exit" if m_exit else "layers[] exit reloc missing")

    # ---- the v49 wrapper still present and referenced ----
    check(name, 'susfs_sc_wrapper' in syms, "v49 wrapper body present")
    check(name, 'sc_call_orig' in syms, "v19 orig-forwarder present")

    # ---- globalized state vars: global B, same .bss layout as base ----
    base_syms = symbols(base)
    for v in ('sc_orig', 'sc_installed', 'sc_full_mode', 'susfs_sc_entry_count'):
        check(name, v in syms and syms[v][0][1] == 'B', f"{v} globalized (B)")
        check(name, v in base_syms and syms[v][0][0] == base_syms[v][0][0],
              f"{v} at the same .bss offset as base (0x{syms[v][0][0]:x})")

    # ---- v50 receipt strings ----
    for s in (b'v50 clang transport init', b'preamble window cloned + verified',
              b'v50 transport LIVE', b'preamble clone write FAILED',
              b'preamble clone did not stick', b'v50: preamble window',
              b'refusing (loaded, not installed)'):
        check(name, s in d, f"diag receipt present: {s.decode()[:44]}")

    # ---- inherited v49 strings still present (dead code keeps them) ----
    for s in (b'transport LIVE', b'OBSERVE-ONLY', b'__x64_sys_ioperm'):
        check(name, s in d, f"inherited string present: {s.decode()}")

    # ---- .bss stomp pad + spill window (inherited) ----
    bss_idx = None
    for line in sh(f"readelf -SW {ko}").splitlines():
        m = re.match(r'\s*\[\s*(\d+)\]\s+\.bss\s+NOBITS', line)
        if m:
            bss_idx = int(m.group(1))
    off_map = {}
    for line in sh(f"readelf -sW {ko}").splitlines():
        m = re.match(r'\s*\d+:\s+([0-9a-f]+)\s+(\d+)\s+\w+\s+\w+\s+\w+\s+(\d+)\s+(\S.*)$', line)
        if m and int(m.group(3)) == bss_idx:
            off_map[m.group(4).strip()] = int(m.group(1), 16)
    check(name, off_map.get('susfs_bss_stomp_pad') == 0, f"stomp pad at .bss+0")
    bad = [v for v in STOMP_VARS if v in off_map and off_map[v] < 0x40]
    check(name, not bad, f"spill-window vars past +0x40 (violators: {bad})")
    for v in STOMP_VARS:
        check(name, v in off_map, f"{v} present in .bss map")

# ---- CLI carried over from the v49 payload ----
print(f"### CLI: {CLI}")
cd = open(CLI, 'rb').read()
new_sites = 0
old_sites = 0
for m in re.finditer(b'\xb8\xad\x00\x00\x00', cd):
    s = m.start()
    sc = cd.find(b'\x0f\x05', s, s + 80)
    if sc < 0:
        continue
    if cd[sc+2:sc+5] == b'\x48\x85\xc0':
        new_sites += 1
for m in re.finditer(b'\xb8\xa9\x00\x00\x00', cd):
    s = m.start()
    if cd.find(b'\x0f\x05', s, s + 80) >= 0:
        old_sites += 1
check('cli', new_sites == 9, f"nine syscall-173 sites ({new_sites})")
check('cli', old_sites == 0, f"zero old 169 sites ({old_sites})")

print()
if fails:
    print("FAILURES:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("ALL V50 CHECKS PASSED")
