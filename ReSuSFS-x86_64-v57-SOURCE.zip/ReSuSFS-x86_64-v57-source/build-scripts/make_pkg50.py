#!/usr/bin/env python3
"""make_pkg50.py - build work/pkg50 from work/pkg49 with the v50 content.

Changed vs pkg49 (the zip builder asserts exactly this set):
  module.prop                        - v26.11.50 / versionCode 128 + v50 story
  customize.sh                       - v50 install banner (prepended)
  boot-completed.sh                  - v50 self-test/transport wording (3 strings)
  README-DIAGNOSTIC.md               - v50 section prepended
  lkm/x86_64/.payload_stamp          - v26.11.50
  lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko          - clang graft
  lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko - clang graft

Everything else - post-fs-data.sh (whose version-change re-base fires
automatically for the 49->50 upgrade), utils.sh, service.sh, the CLI
binaries, the ymuuu reference payload - is byte-identical to the v49 zip.
"""
import os, re, shutil, sys

BASE = '/home/z/my-project'
SRC = f'{BASE}/work/pkg49'
DST = f'{BASE}/work/pkg50'
PAYLOAD = f'{BASE}/ReSuSFS-x86_64-port/ReSuSFS/module'

MODULE_PROP = '''id=ReSuSFS
name=ReSuSFS x86_64
version=v26.11.50-x86_64
versionCode=128
author=ReSuSFS port campaign
description=SuSFS for KernelSU (x86_64 port) | v26.11.50: THE CLANG ENTRY - the fix the field data demanded and you called: every previous build compiled the .ko with GCC on a clang-17 LTO + kCFI kernel. THE v49 FIELD VERDICT (2026-11-24 16:03): stage 2 armed the table transport, init returned 0, the preamble readback verified 0xebebffff at [entry-4] - and the box STILL froze at the first dispatched syscall(173), the same death as the preamble-less v48. Conclusion: byte-copying 4 bytes at [entry-4] is not enough; whatever the dispatch inspects about the target, the original entry passes it and our thunk did not. THE v50 FIX (two independent hardenings): (1) the landing function susfs_sc_entry is now a REAL function COMPILED BY CLANG-17 (the kernel's own compiler family) with a GENUINE kCFI preamble for the exact syscall-table prototype long (const struct pt_regs *) - clang emits the 16-byte preamble block (nop pad + movl $typeid) exactly like the kernel's own entries; (2) the installer CLONES THE ORIGINAL ENTRY'S ENTIRE 16-BYTE PREAMBLE WINDOW ([orig-16..orig-1]) into ours byte-for-byte through the proven ksu_patch_text, with byte-exact readback, BEFORE the table write - so whatever offset the dispatch checks (-4 hash, -5 opcode, or any wider pattern), our entry presents EXACTLY the bytes the original presents. SAFETY: stage-2 OBSERVE is now the minimal path - one locked counter increment (the sc_entry_count param the self-test reads) and return -EINVAL; no printk, no current read, no forwarding; the full v45-proven wrapper runs only from stage 3. The installer REFUSES the patch (and returns 0 - layer 17 stays armed, the module stays loaded) on any unproven condition: table not live, entry not the real ioperm, landing pad not intact, clone write failed - every refusal leaves a full diag receipt and a live box. GRAFT DESIGN: the v49 field object is reused byte-for-byte (wrapper body, 19 other layers, ladder, witness, vermagic, this_module, modver dummy, .bss stomp pad - all unchanged; imports identical: 124); the three overridden symbols (susfs_sc_entry, susfs_supercall_init, susfs_supercall_exit) are weakened in the base and replaced by the clang graft via ld -r - the susfs_layers[] function pointers bind to the new init/exit. LADDER: 49->50 re-bases (arm_stage=0, stage_max=3 - expect 4 reboots: 0, 1, 2=OBSERVE, 3=FULL), rungs confirm only after the self-test survives, one wedge boot maximum (stale try-marker demotion), stages 4/5 stay retired. KNOWN LIMITS, stated honestly: sus_path file-hiding and the LSM class stay retired; ksu_susfs answers only from stage 3. After any wedge send back: logs/init_trace.txt + logs/diag_last.txt + logs/boot.log + logs/kernel_facts.txt + logs/sc_selftest.txt | opt-in only, at your own risk | built-in kernel susfs auto-detected | all boot stages logged with a hang watchdog | step-by-step diagnostics via the Action button
'''

CUSTOMIZE_BANNER = '''        ui_print "[*] v26.11.50: THE CLANG ENTRY."
        ui_print "[*] Your diagnosis was right: every previous .ko was"
        ui_print "[*] GCC-built on a clang-17 LTO + kCFI kernel. v50's"
        ui_print "[*] landing function is now COMPILED BY CLANG-17 with"
        ui_print "[*] a genuine kCFI preamble for the exact syscall-table"
        ui_print "[*] prototype, and the installer CLONES the original"
        ui_print "[*] entry's full 16-byte preamble window byte-for-byte"
        ui_print "[*] (verified readback) before the table write - no more"
        ui_print "[*] guessing that only [entry-4] matters (v49 copied"
        ui_print "[*] those 4 bytes and the box still froze). Stage-2"
        ui_print "[*] observe is now minimal: counter + -EINVAL, nothing"
        ui_print "[*] else. Any unproven condition refuses the patch and"
        ui_print "[*] logs why - the box stays alive either way. 49->50"
        ui_print "[*] re-bases the ladder (4 reboots: 0, 1, 2=OBSERVE,"
        ui_print "[*] 3=FULL), one wedge boot maximum by design, stages"
        ui_print "[*] 4/5 stay retired. Everything else is the field-"
        ui_print "[*] proven v49 object grafted via ld -r: wrapper body,"
        ui_print "[*] all other layers, ladder, witness, CLI - identical."
'''

README_SECTION = '''# v26.11.50 - THE CLANG ENTRY (2026-11-25)

## What changed

- **The landing function is now compiled by clang-17.** All 27 prior builds
  were GCC products on a clang-17 LTO + kCFI kernel; the module's
  `.comment` section proves it (`GCC: (Debian 14.2.0-19) 14.2.0`). The v50
  entry (`susfs_sc_entry`) is a real clang function with a genuine kCFI
  preamble for `long (const struct pt_regs *)` - clang emits the 16-byte
  preamble block (nop padding + `movl $typeid, %eax`) exactly like the
  kernel's own syscall entries.
- **The installer clones the original entry's entire 16-byte preamble
  window.** v49 copied only the 4 bytes at `[entry-4]` (verified readback:
  0xebebffff) and the box still froze at the first dispatched syscall(173).
  Whatever the dispatch inspects - hash at -4, opcode at -5, a wider
  custom-offset pattern - the original entry passes it; v50 makes our
  entry's window byte-identical to the original's, so every check the
  original passes, ours passes. Clone + byte-exact readback happen BEFORE
  the table write.
- **Stage-2 observe is minimal.** Counter increment (`lock incl` on the
  `sc_entry_count` param) + `-EINVAL`. No printk, no `current` read, no
  forwarding, no dispatch. The full v45-proven wrapper (magic check, uid
  gate, command dispatch, payload.err answers) runs only from stage 3.
- **The installer refuses instead of guessing.** Any unproven condition
  (table not the live one, entry not the real ioperm, landing pad not
  intact, clone write failed/not sticking) logs a full receipt and leaves
  the module loaded with the transport not installed. Layer 17 returns 0
  on refusal (it is a FATAL layer; an error return would refuse the whole
  module load and un-arm every working layer).

## Graft mechanics (why the module is still the field-proven v49 object)

The v49 `.ko` is an ELF relocatable object. `build_v50_ko.sh` weakens the
three overridden symbols (`susfs_sc_entry`, `susfs_supercall_init`,
`susfs_supercall_exit`) in the base, globalizes four `.bss` state vars
(`sc_orig`, `sc_installed`, `sc_full_mode`, `susfs_sc_entry_count`), and
links the clang graft FIRST with `ld -r`: the linker keeps the first
definition of each symbol, so every reference - the `susfs_layers[]`
function pointers in `susfs_main.c` included - binds to the clang graft,
and the old (dead) definitions are dropped. Verified invariants
(`build_v50_verify.py`): vermagic byte-identical, this_module size
unchanged, imports EXACTLY the v49 124, `.bss` stomp pad at offset 0 with
all spill-window vars past +0x40, wrapper body untouched.

## Field procedure (unchanged from v49)

Flash over v49. The 49->50 upgrade re-bases the ladder automatically
(arm_stage=0, stage_max=3). Keep `enable_lkm` + `enable_force_init`
present (they are - the module never removes them unless a stage-0 boot
itself wedges). Expect 4 reboots: stage 0 (evidence) -> 1 (layers) ->
2 (OBSERVE - the first live fire through the clang entry; the self-test
reads sc_entry_count before/after) -> 3 (FULL - `ksu_susfs show version`
answers). One wedge boot maximum by design; after ANY wedge send back the
five logs (logs/init_trace.txt + logs/diag_last.txt + logs/boot.log +
logs/kernel_facts.txt + logs/sc_selftest.txt).

'''

def main():
    if os.path.exists(DST):
        shutil.rmtree(DST)
    shutil.copytree(SRC, DST)

    # 1. module.prop
    open(f'{DST}/module.prop', 'w').write(MODULE_PROP)

    # 2. customize.sh - prepend the v50 banner before the v49 banner
    cs = open(f'{DST}/customize.sh').read()
    anchor = '        ui_print "[*] v26.11.49: THE kCFI PREAMBLE FIX."'
    assert anchor in cs, 'v49 banner anchor not found in customize.sh'
    cs = cs.replace(anchor, CUSTOMIZE_BANNER + anchor, 1)
    open(f'{DST}/customize.sh', 'w').write(cs)

    # 3. boot-completed.sh - the three v50 runtime strings
    bc = open(f'{DST}/boot-completed.sh').read()
    old_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + kCFI preamble, nr 173; CLI: $SC_CLI)"'
    new_line = 'log_boot "boot-completed: supercall self-test starting (stage $ARM_STAGE mode=$SC_MODE; transport: LIVE sys_call_table entry + 16-byte cloned preamble, v50 CLANG ENTRY, nr 173; CLI: $SC_CLI)"'
    assert old_line in bc, 'self-test start line not found'
    bc = bc.replace(old_line, new_line, 1)

    old_hdr = "echo \"---- v49 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    new_hdr = "echo \"---- v50 supercall self-test @ $(date '+%Y-%m-%d %H:%M:%S') arm_stage=$ARM_STAGE mode=$SC_MODE ----\""
    assert old_hdr in bc, 'self-test header not found'
    bc = bc.replace(old_hdr, new_hdr, 1)

    old_note = "echo 'NOTE: v49 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry (the table this kernel built-in KernelSU-Next dispatches through), with the original entry kCFI type-hash replicated before the thunk; observe mode answers nothing BY DESIGN; stage 3 answers in payload.err and the syscall return.'"
    new_note = "echo 'NOTE: v50 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload) through the LIVE sys_call_table entry; the entry is a REAL clang-17 function whose 16-byte preamble window is CLONED byte-for-byte from the original entry before the table write; observe mode (stage 2) increments sc_entry_count and returns -EINVAL only; stage 3 answers in payload.err and the syscall return.'"
    assert old_note in bc, 'self-test NOTE not found'
    bc = bc.replace(old_note, new_note, 1)
    open(f'{DST}/boot-completed.sh', 'w').write(bc)

    # 4. README - prepend the v50 section
    rd = open(f'{DST}/README-DIAGNOSTIC.md').read()
    open(f'{DST}/README-DIAGNOSTIC.md', 'w').write(README_SECTION + rd)

    # 5. the grafted .kos + stamp from the staged payload
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                    f'{DST}/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
    shutil.copyfile(f'{PAYLOAD}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
                    f'{DST}/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
    open(f'{DST}/lkm/x86_64/.payload_stamp', 'w').write('v26.11.50\n')

    print('pkg50 ready:', DST)
    for root, dirs, files in os.walk(DST):
        for f in files:
            p = os.path.join(root, f)
            rel = os.path.relpath(p, DST)
            if rel in ('module.prop', 'customize.sh', 'boot-completed.sh',
                       'README-DIAGNOSTIC.md', 'lkm/x86_64/.payload_stamp',
                       'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
                       'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko'):
                print('  CHANGED', rel)

if __name__ == '__main__':
    main()
