#!/usr/bin/env python3
"""patch_footers.py - WPS compatibility post-processing for the v47 report docx.

1. In every footer XML that contains a bare PAGE field instruction, add the
   explicit Word format switch: PAGE \\* arabic \\* MERGEFORMAT (body footer).
   (The TOC section carries no page-number footer by design - report scene.)
2. Remove empty <w:pgNumType/> elements (docx-js emits them on sections without
   pageNumbers; WPS misreads them).
"""
import re
import shutil
import sys
import zipfile

path = sys.argv[1]
tmp = path + ".patched"

with zipfile.ZipFile(path, "r") as zin:
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}

changed = 0
for n in list(data.keys()):
    if re.match(r"word/footer\d*\.xml$", n):
        xml = data[n].decode("utf-8")
        new = re.sub(
            r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
            r"\1 PAGE \\* arabic \\* MERGEFORMAT \2",
            xml,
        )
        if new != xml:
            data[n] = new.encode("utf-8")
            changed += 1

doc = data["word/document.xml"].decode("utf-8")
newdoc = doc.replace("<w:pgNumType/>", "")
if newdoc != doc:
    data["word/document.xml"] = newdoc.encode("utf-8")
    changed += 1

with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
    for n in names:
        zout.writestr(n, data[n])
shutil.move(tmp, path)
print(f"patched: {changed} XML part(s)")
