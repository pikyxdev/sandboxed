#!/bin/sh
# ============================================================================
# v26.11.39 loader regression test (host).
#
# Reproduces the EXACT v38 field-device state the user's boot.log proved:
#   kernel "5.15.178+" (custom x86_64), module payload present under the
#   module dir, /data/adb/ReSuSFS_LKM EMPTY (install gate never fired),
#   enable_lkm present, ksud available.
#
# Then verifies the three v39 fixes:
#   T1: install-time gate now populates SUSFS_LKM from bundled candidates
#   T2: runtime self-heal repopulates + re-selects (android13 default)
#   T3: candidate fallback chain android13 -> vanilla -> ymuuu13 on failure
#   T4: regression proof - the UNPATCHED v38 utils.sh fails the same scenario
#       with "No x86_64 LKM available" (proves the test detects the bug)
#
# All hardcoded /data paths are substituted into a scratch copy of utils.sh;
# nothing on the host is touched (busybox shim refuses rmmod, no /data dir).
# ============================================================================
PAYLOAD="${V39_PAYLOAD:-/home/z/my-project/work/pkg39}"
V38UTILS=/home/z/my-project/work/pkg38/utils.sh
V39UTILS=/home/z/my-project/work/pkg39/utils.sh
T=/tmp/v39test
FB=$T/fakebin
FAIL=0

ok()   { echo "  [PASS] $1"; }
bad()  { echo "  [FAIL] $1"; FAIL=$((FAIL+1)); }
has()  { grep -qF "$2" "$1" 2>/dev/null && ok "$3" || bad "$3"; }
lacks(){ { ! grep -qF "$2" "$1" 2>/dev/null; } && ok "$3" || bad "$3"; }

# ---- test sandbox ----------------------------------------------------------
rm -rf "$T"; mkdir -p "$T/lkmout" "$T/persist" "$T/out" "$FB"

cat > "$FB/uname" <<'EOF'
#!/bin/sh
case "$1" in
  -m) echo "x86_64" ;;
  -r) echo "5.15.178+" ;;
  -a) echo "Linux localhost 5.15.178+ #1 SMP PREEMPT Mon Nov 9 14:34:21 CST 2026 x86_64 Android" ;;
  -s) echo "Linux" ;;
  "") echo "5.15.178+" ;;
  *)  echo "5.15.178+" ;;
esac
exit 0
EOF

cat > "$FB/getprop" <<'EOF'
#!/bin/sh
case "$1" in
  ro.product.cpu.abi)      echo "x86_64" ;;
  ro.product.cpu.abilist) echo "x86_64" ;;
  *) : ;;
esac
exit 0
EOF

# busybox shim: applet name dropped, real tool exec'd. rmmod/insmod refuse:
# the host kernel must never be touched.
cat > "$FB/busybox" <<'EOF'
#!/bin/sh
a="$1"; shift
case "$a" in
  cp|chmod|mv|rm|mkdir|ls|sed|grep|cat|zcat|unzip|head|sync)
     exec "$a" "$@" ;;
  rmmod|insmod|modprobe)
     exit 1 ;;
  *) exit 1 ;;
esac
EOF

# ksud shim: records every insmod attempt (to assert candidate ORDER);
# TEST_KSUD_MODE=ok -> rc 0, fail -> rc 1.
cat > "$FB/ksud" <<'EOF'
#!/bin/sh
echo "ksud $*" >> "${TEST_KSUD_LOG:-/dev/null}"
[ "${TEST_KSUD_MODE:-fail}" = "ok" ] && exit 0
exit 1
EOF
chmod +x "$FB/uname" "$FB/getprop" "$FB/busybox" "$FB/ksud"

# scratch copies of utils.sh with the device's hardcoded paths redirected
mk_utils() { # $1 = src utils.sh, $2 = dest
  sed -e "s|/data/adb/ReSuSFS_LKM|$T/lkmout|g" \
      -e "s|/data/adb/modules/ReSuSFS|$PAYLOAD|g" \
      -e "s|/data/adb/ReSuSFS|$T/persist|g" "$1" > "$2"
}
mk_utils "$V39UTILS" "$T/utils39.sh"
mk_utils "$V38UTILS" "$T/utils38.sh"

RUN() { # $1 = utils copy, $2 = fn, $3 = out file, $4.. = env
  env PATH="$FB:$PATH" TEST_KSUD_LOG="$T/ksud.log" TEST_KSUD_MODE="${KSUD_MODE:-fail}" \
      ${NO_MODPATH:+} MODPATH="${MODPATH:-}" \
      sh -c ". '$1'; $2" > "$3" 2>&1
}

echo "== T1: v39 install-time gate populates SUSFS_LKM from bundled candidates =="
MODPATH="$PAYLOAD" RUN "$T/utils39.sh" download_susfs_guard_lkm "$T/out/t1.txt"
for f in susfs_guard_lkm-x86_64-android13-5.15.ko \
         susfs_guard_lkm-x86_64-vanilla-5.15.ko \
         ymuuu_android13-5.15_susfs_guard_lkm.ko susfs_insmod; do
  [ -f "$T/lkmout/$f" ] && ok "installed: $f" || bad "MISSING in lkmout: $f"
done
has  "$T/out/t1.txt" "Installed bundled susfs_guard_lkm-x86_64-android13-5.15.ko" "T1: android13 installed via bundled gate"
lacks "$T/out/t1.txt" "No x86_64 LKM available" "T1: no more 'No x86_64 LKM available' dead end"

echo "== T2: v39 runtime self-heal + load with ksud OK (empty SUSFS_LKM, no MODPATH) =="
rm -rf "$T/lkmout" "$T/persist/logs"; mkdir -p "$T/lkmout"
: > "$T/persist/enable_lkm"; : > "$T/ksud.log"
KSUD_MODE=ok NO_MODPATH=1 RUN "$T/utils39.sh" load_susfs_lkm "$T/out/t2.txt"
has  "$T/persist/logs/boot.log" "self-healing (re)install" "T2: self-heal fired"
has  "$T/persist/logs/boot.log" "self-heal resolved kmi -> susfs_guard_lkm-x86_64-android13-5.15.ko" "T2: re-selected android13 default"
has  "$T/out/t2.txt" "LKM loaded successfully (ksud: susfs_guard_lkm-x86_64-android13-5.15.ko)" "T2: image load succeeded (first candidate, ksud ok)"
[ "$(grep -c 'insmod' "$T/ksud.log")" = "1" ] && ok "T2: chain stopped after first success (1 insmod attempt)" \
  || bad "T2: expected exactly 1 ksud insmod, got $(grep -c insmod "$T/ksud.log")"
lacks "$T/out/t2.txt" "No x86_64 LKM available" "T2: no dead end on runtime path"
lacks "$T/out/t2.txt" "Failed to download LKM" "T2: no download attempt"

echo "== T3: v39 candidate fallback chain (ksud fails; susfs_insmod refuses zero-addr host kallsyms) =="
rm -rf "$T/lkmout" "$T/persist/logs"; mkdir -p "$T/lkmout"
: > "$T/persist/enable_lkm"; : > "$T/ksud.log"
KSUD_MODE=fail NO_MODPATH=1 RUN "$T/utils39.sh" load_susfs_lkm "$T/out/t3.txt"
chmod 000 "$T/lkmout/susfs_insmod" 2>/dev/null   # (already skipped: -x check below)
# order assertion: ksud attempts android13 -> vanilla -> ymuuu13, legacy skipped (absent)
ORD=$(grep 'insmod' "$T/ksud.log" | sed 's|.*insmod *||' | tr '\n' '|')
[ "$ORD" = "$T/lkmout/susfs_guard_lkm-x86_64-android13-5.15.ko|$T/lkmout/susfs_guard_lkm-x86_64-vanilla-5.15.ko|$T/lkmout/ymuuu_android13-5.15_susfs_guard_lkm.ko|" ] \
  && ok "T3: fallback order android13 -> vanilla -> ymuuu13, no duplicate retry" \
  || bad "T3: wrong fallback order: $ORD"
has  "$T/out/t3.txt" "Falling through to candidate: susfs_guard_lkm-x86_64-vanilla-5.15.ko" "T3: vanilla fallback announced"
has  "$T/out/t3.txt" "Failed to load LKM" "T3: clean failure after chain exhausted (expected on host)"

echo "== T4: regression proof - UNPATCHED v38 fails the same runtime scenario =="
rm -rf "$T/lkmout" "$T/persist/logs"; mkdir -p "$T/lkmout"
: > "$T/persist/enable_lkm"; : > "$T/ksud.log"
KSUD_MODE=ok NO_MODPATH=1 RUN "$T/utils38.sh" load_susfs_lkm "$T/out/t4.txt"
has  "$T/out/t4.txt" "No x86_64 LKM available for this kernel (5.15.178+)" "T4: v38 reproduces the device's dead end (bug confirmed)"
has  "$T/out/t4.txt" "Failed to download LKM" "T4: v38 rc=1 path (matches user boot.log)"
[ "$(grep -c 'insmod' "$T/ksud.log" 2>/dev/null)" = "0" ] && ok "T4: v38 never even attempted insmod" || bad "T4: v38 attempted insmod (unexpected)"

echo
if [ "$FAIL" -eq 0 ]; then
  echo "ALL v26.11.39 LOADER TESTS PASSED"
else
  echo "$FAIL TEST(S) FAILED"
fi
exit "$FAIL"
