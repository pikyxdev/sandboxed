#!/usr/bin/env python3
"""build_v48_verify.py - fail the v48 build on any regression.

Inherits every structural check that still applies from the v43/v44/v45
verifiers (vermagic byte-exact, this_module section size, imports all
present in the field kallsyms, no thunks/panic, the SYNC setter profile,
kworker sentinel, probe params, the resolver-probe strings, the .bss stomp
pad) and swaps the v45 supercall-transport checks for the v47 ones:

  SUPERCALL TRANSPORT REDESIGN (hardened-dispatcher cold-arm redirect):
    - register_kprobe / task_work_add imports stay (pinned by imports_guard.c)
      but susfs_supercall_init NO LONGER calls register_kprobe: its relocs
      contain ksu_patch_text, not register_kprobe
    - susfs_sc_pre (the kprobe pre_handler) is GONE; susfs_sc_wrapper (the
      process-context wrapper) is present and reads the REAL pt_regs fields:
      +0x70 (di/magic1), +0x68 (si/magic2), +0x60 (dx/cmd), +0x38 (r10/payload)
      - no kernel-pointer deref is present (the wrapper's regs ARE the real regs)
    - the wrapper compares the 0xdeadbeef/0xfafafafa immediates
    - sc_call_orig is the __nocfi noinline indirect-call site
    - susfs_supercall_transport_active defined; susfs_supercall_kprobe_active gone
    - diag strings: 'transport LIVE', '__x64_sys_ioperm', 'OBSERVE-ONLY' present;
      'kprobe REGISTERED' and the task_work failure string gone
    - the scan checks are compile-time visible in strings ('scanning kernel
      text', 'E8/E9', the refuse receipts)

  CLI PATCH (supercall moved to syscall 173):
    - all nine syscall sites carry mov eax,0xad (173) with the v45 6-byte nop
      return-check still in place; zero mov eax,0xa9 sites remain
"""
import subprocess, sys, re

A13 = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15.ko'
KORG = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
CLI = '/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module/bin/x86_64/ksu_susfs'
KALL = '/home/z/my-project/upload/kernel_kallsyms.txt'

fails = []

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True)

def symbols(ko):
    out = sh(f"nm -S --defined-only {ko}")
    syms = {}
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 4:
            try:
                syms[p[3]] = (int(p[0], 16), p[1], p[2])
            except ValueError:
                pass
    return syms

def func_disasm(ko, name):
    out = sh(f"objdump -d {ko}")
    body, inside = [], False
    for line in out.splitlines():
        m = re.match(r'^[0-9a-f]+ <([^>]+)>:', line)
        if m:
            inside = m.group(1).startswith(name)
            continue
        if inside:
            body.append(line)
    return '\n'.join(body)

def check(label, cond, msg):
    print(f"  [{'OK' if cond else 'FAIL'}] {label}: {msg}")
    if not cond:
        fails.append(f"{label}: {msg}")

# .bss offsets of the v44 spill-window variables (from the shipped v44 image)
STOMP_VARS = ['susfs_diag_printk', 'susfs_probe_arm', 'susfs_probe_val',
              'susfs_force_init_val', 'susfs_init_done',
              'susfs_init_maxstep', 'fail_layer', 'susfs_sc_entry_count']

for name, ko, want_tm in (('android13', A13, 0x340), ('vanilla', KORG, 0x300)):
    print(f"### {name}: {ko}")
    d = open(ko, 'rb').read()
    i = d.find(b'vermagic=')
    vm = d[i:i+80].split(b'\x00')[0].decode()
    check(name, vm.startswith('vermagic=5.15.178+ SMP preempt modversions'), f"vermagic {vm!r}")

    secs = sh(f"readelf -SW {ko}")
    size = None
    for line in secs.splitlines():
        m = re.search(r'\.gnu\.linkonce\.this_module\s+PROGBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
        if m:
            size = int(m.group(1), 16)
    check(name, size == want_tm, f"this_module section size 0x{size:x} (want 0x{want_tm:x})")

    imports = sorted(set(l.split()[1] for l in sh(f"nm -u {ko}").splitlines() if l.strip()))
    print(f"  imports: {len(imports)}")
    kall = open(KALL).read()
    missing = [s for s in imports if f" {s}\n" not in kall]
    check(name, not missing, f"imports all in field kallsyms (missing: {missing})")
    for bad in ('panic', '__x86_return_thunk') + tuple(f'__x86_indirect_thunk_{r}' for r in ('rax','rbp','rdx','rsi','rdi','rcx','r8','r9','r10','r11','r12','r13')):
        check(name, bad not in imports, f"{bad} not imported")

    # ---- v47: supercall transport ----
    # imports pinned by imports_guard.c regardless of who calls them
    check(name, 'register_kprobe' in imports, "register_kprobe import kept (pinned by imports_guard)")
    check(name, 'stop_machine' in imports, "stop_machine imported (the patch primitive)")
    check(name, 'copy_to_kernel_nofault' in imports, "copy_to_kernel_nofault imported (the patch primitive)")
    check(name, 'native_set_fixmap' in imports, "native_set_fixmap imported (the fixmap primitive)")

    # v48: the table transport.  susfs_supercall_init now tries the LIVE
    # sys_call_table[173] entry first (sc_install_table -> susfs_fp_install)
    # and keeps the v47 arm scan as fallback.
    init_rel = sh(f"objdump -dr --disassemble=susfs_supercall_init {ko}")
    init_relocs = '\n'.join(l for l in init_rel.splitlines() if 'R_X86_64' in l)
    all_rel = sh(f"objdump -dr {ko}")
    check(name, 'register_kprobe' not in init_relocs, "supercall_init does NOT call register_kprobe")
    check(name, 'unregister_kprobe' not in init_relocs, "supercall_init does NOT call unregister_kprobe")
    check(name, 'susfs_fp_install' in all_rel,
          "susfs_fp_install is called somewhere in the module (the v48 table patch)")
    check(name, 'ksu_patch_text' in all_rel, "ksu_patch_text is called (fp entry writes + arm fallback)")

    syms = symbols(ko)
    check(name, 'susfs_sc_entry' in syms, "susfs_sc_entry defined (the endbr64 table thunk)")
    entry_dis = sh(f"objdump -d --disassemble=susfs_sc_entry {ko}")
    check(name, 'endbr64' in entry_dis, "susfs_sc_entry starts with endbr64 (the landing pad fp_install demands)")
    check(name, 'jmp' in entry_dis, "susfs_sc_entry jumps into the wrapper")
    check(name, 'susfs_sc_wrapper' in syms, "susfs_sc_wrapper defined (the transport wrapper)")
    check(name, 'sc_call_orig' in syms, "sc_call_orig defined (the __nocfi orig-call site)")
    check(name, 'susfs_sc_pre' not in syms, "kprobe pre_handler susfs_sc_pre gone")
    check(name, 'susfs_supercall_transport_active' in syms, "susfs_supercall_transport_active defined")
    check(name, 'susfs_supercall_kprobe_active' not in syms, "old susfs_supercall_kprobe_active gone")
    check(name, 'susfs_current_arm_stage' in syms, "susfs_current_arm_stage defined")
    check(name, any(s.startswith('sc_sites') for s in syms), "sc_sites state array present")

    wrap = func_disasm(ko, 'susfs_sc_wrapper')
    check(name, '0x70(' in wrap, "wrapper reads pt_regs->di at +0x70 (magic1 - the REAL regs, no deref)")
    check(name, '0x68(' in wrap, "wrapper reads pt_regs->si at +0x68 (magic2)")
    check(name, '0x60(' in wrap, "wrapper reads pt_regs->dx at +0x60 (cmd)")
    check(name, '0x38(' in wrap, "wrapper reads pt_regs->r10 at +0x38 (payload)")
    check(name, '0xdeadbeef' in wrap, "wrapper compares magic1 0xdeadbeef")
    check(name, '0xfafafafa' in wrap, "wrapper compares magic2 0xfafafafa")
    check(name, 'sc_call_orig' in wrap, "wrapper tail-calls through sc_call_orig")
    check(name, 'susfs_dispatch_cmd' in wrap or 'sc_call_orig' in wrap, "wrapper dispatches or passes through")
    check(name, re.search(r'\tret', wrap) is not None, "wrapper ends with plain ret (E9 tail-callee)")

    # the old kernel-pointer deref / access_ok pattern must be gone from the wrapper
    check(name, '0x7fff' not in wrap, "wrapper has no access_ok userspace-range constant (no pointer deref needed)")

    # ---- diag strings ----
    check(name, b'transport LIVE' in d, "diag: transport LIVE breadcrumb present")
    check(name, b'__x64_sys_ioperm' in d, "diag: cold handler name string present")
    check(name, b'OBSERVE-ONLY' in d, "diag: OBSERVE-ONLY mode string present")
    check(name, b'no kprobe is registered anywhere' in d, "diag: no-kprobe note present")
    check(name, b'kprobe REGISTERED' not in d, "diag: old kprobe REGISTERED string gone")
    check(name, b'susfs supercall: task_work_add failed' not in d,
          "diag: supercall's task_work failure string gone (prop_view/uname keep their own)")
    check(name, b'scanning kernel text' in d, "diag: fallback arm-scan receipt present")
    check(name, b'arm(s) redirected' in d, "diag: fallback install receipt present")
    check(name, b'v48 table transport' in d, "diag: v48 table-transport receipt present")
    check(name, b'ksu_syscall_dispatcher' in d, "diag: liveness-proof symbol string present")
    check(name, b'the LIVE dispatch entry' in d, "diag: table redirect receipt present")
    check(name, b'transport LIVE - sys_call_table' in d, "diag: transport LIVE names the table entry")
    check(name, b'falling back to the arm scan' in d, "diag: fallback receipt present")

    # ---- inherited: .bss stomp pad ----
    bss_idx = None
    for line in sh(f"readelf -SW {ko}").splitlines():
        m = re.match(r'\s*\[\s*(\d+)\]\s+\.bss\s+NOBITS', line)
        if m:
            bss_idx = int(m.group(1))
    if bss_idx is None:
        check(name, False, ".bss section found")
    else:
        symlist = sh(f"readelf -sW {ko}")
        off_map = {}
        for line in symlist.splitlines():
            m = re.match(r'\s*\d+:\s+([0-9a-f]+)\s+(\d+)\s+\w+\s+\w+\s+\w+\s+(\d+)\s+(\S.*)$', line)
            if m and int(m.group(3)) == bss_idx:
                off_map[m.group(4).strip()] = int(m.group(1), 16)
        pad_off = off_map.get('susfs_bss_stomp_pad')
        pad_size = None
        for line in sh(f"nm -S --defined-only {ko}").splitlines():
            q = line.split()
            if len(q) >= 4 and q[3] == 'susfs_bss_stomp_pad':
                pad_size = int(q[1], 16)
        check(name, pad_off == 0, f"susfs_bss_stomp_pad at .bss+{pad_off} (want 0)")
        check(name, pad_size == 64, f"stomp pad size {pad_size} (want 64)")
        bad = [v for v in STOMP_VARS if v in off_map and off_map[v] < 0x40]
        check(name, not bad, f"all spill-window variables past +0x40 (violators: {[(v, hex(off_map[v])) for v in bad]})")
        for v in STOMP_VARS:
            check(name, v in off_map, f"{v} present in .bss symbol map")

    # ---- inherited v44 checks (setter/kworker/probe/resolver) ----
    setter = func_disasm(ko, 'susfs_param_set_force_init')
    n_calls = setter.count('\tcall')
    print(f"  setter: {len(setter.splitlines())} insns, {n_calls} calls")
    check(name, 'mov    $0x40,%edi' in setter or 'mov    $0x40' in setter,
          "setter keeps the deferred path (WORK_CPU_UNBOUND=0x40 arg setup)")
    check(name, 'ffffffba' in setter, "setter SYNC path stores -70 (0xffffffba)")
    check(name, 'susfs_init_body' in setter, "setter SYNC path calls susfs_init_body directly")
    check(name, 'susfs_diag_logf' not in setter, "setter has no DIAG call")
    check(name, re.search(r'\tret', setter) is not None, "setter ends with plain ret")

    kw = sh(f"objdump -d --disassemble=susfs_deferred_init_fn {ko}")
    kw_body = kw.split('susfs_deferred_init_fn>:', 1)[1] if 'susfs_deferred_init_fn>:' in kw else kw
    first_insns = '\n'.join(kw_body.split('\n')[:3])
    check(name, 'ffffffce' in first_insns, "kworker first instruction stores -50 (0xffffffce)")
    check(name, 'cs jmp' not in kw, 'kworker has no return-thunk jumps')

    have_param_str = '__param_str_probe' in sh(f"nm {ko}")
    have_probe_arm = '__param_probe_arm' in sh(f"nm {ko}")
    have_probe_get = 'susfs_param_get_probe' in sh(f"nm {ko}")
    check(name, have_param_str and have_probe_arm and have_probe_get,
          "probe/probe_arm params + custom .get present")

    check(name, 'susfs_init_work' in syms, "susfs_init_work present")
    check(name, b'_printk\x00' in d, "probe candidate string '_printk' present")
    check(name, b'vprintk\x00' in d, "probe candidate string 'vprintk' present")
    check(name, b'_printk/printk/vprintk' in d, "refuse message lists all three candidates")
    check(name, b"probe '%s'=0x%lx" in d, "KLN-active breadcrumb names the winning probe (%s)")
    check(name, b"trying next candidate" in d, "per-miss breadcrumb present")

# ---- CLI patch (v47: syscall 169 -> 173) ----
print(f"### CLI: {CLI}")
cd = open(CLI, 'rb').read()
old_sites = 0
new_sites = 0
new_nops = 0
for m in re.finditer(b'\xb8\xad\x00\x00\x00', cd):
    s = m.start()
    sc = cd.find(b'\x0f\x05', s, s + 80)
    if sc < 0:
        continue
    tail = cd[sc+2:sc+2+9]
    if tail[:3] == b'\x48\x85\xc0':
        new_sites += 1
        if tail[3:9] == b'\x66\x0f\x1f\x44\x00\x00':
            new_nops += 1
for m in re.finditer(b'\xb8\xa9\x00\x00\x00', cd):
    s = m.start()
    sc = cd.find(b'\x0f\x05', s, s + 80)
    if sc >= 0:
        old_sites += 1
check('cli', new_sites == 9, f"nine supercall sites now carry eax=0xad/173 ({new_sites})")
check('cli', new_nops == 9, f"all nine return-checks remain the canonical 6-byte nop ({new_nops})")
check('cli', old_sites == 0, f"zero old eax=0xa9/169 sites remain ({old_sites})")

print()
if fails:
    print("FAILURES:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("ALL CHECKS PASSED")
