#!/usr/bin/env python3
"""Verify the v40/v41 module import table against the FIELD kernel's kallsyms dump.

Reports, per import name: MISSING (loader leaves 0 -> jump-to-0 oops) and
DUPLICATED (loader may pick the wrong occurrence -> call into arbitrary
kernel text -> silent hard wedge, matching the observed v39/v40 freeze)."""
import re, subprocess, sys, collections

KO = "/home/z/my-project/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel/susfs_guard_lkm.ko"
KALL = "/home/z/my-project/upload/kernel_kallsyms.txt"

# import names from the .ko's undefined symbol table
out = subprocess.check_output(["nm", "-u", KO], text=True)
imports = sorted(set(l.split()[1] for l in out.splitlines() if l.strip()))

# parse kallsyms: addr type name [module]
syms = collections.defaultdict(list)
with open(KALL, errors="replace") as f:
    for line in f:
        m = re.match(r"^([0-9a-fA-F]+)\s+(\S)\s+(\S+)(\s+\[(\S+)\])?\s*$", line.rstrip("\n"))
        if not m:
            continue
        addr, typ, name = m.group(1), m.group(2), m.group(3)
        if m.group(5):  # module-owned symbol, not kernel text
            continue
        syms[name].append((int(addr, 16), typ))

missing, dup = [], []
for n in imports:
    if n not in syms:
        missing.append(n)
    elif len(syms[n]) > 1:
        dup.append((n, [(hex(a), t) for a, t in syms[n]]))

print(f"imports checked: {len(imports)}  (field kallsyms kernel records: {sum(len(v) for v in syms.values())})")
print("\n== MISSING from field kallsyms (loader would leave 0): ==")
for n in missing:
    print(f"  {n}")
if not missing:
    print("  (none)")
print("\n== DUPLICATED in field kallsyms (wrong-occurrence risk): ==")
for n, lst in dup:
    print(f"  {n}: {lst}")
if not dup:
    print("  (none)")

# also verify the v40-specific new imports explicitly
print("\n== v40 new/interesting imports, explicit lookup: ==")
for n in ["panic", "queue_work_on", "system_wq", "queue_delayed_work_on",
          "cancel_delayed_work_sync", "__msecs_to_jiffies", "delayed_work_timer_fn",
          "__x86_return_thunk", "bcmp", "schedule", "filp_open", "kernel_write",
          "vfs_write", "filp_close", "filp_flush", "vfs_fsync", "filp_open"]:
    hits = syms.get(n, [])
    print(f"  {n:28s} -> {[(hex(a), t) for a, t in hits] if hits else 'MISSING'}")
