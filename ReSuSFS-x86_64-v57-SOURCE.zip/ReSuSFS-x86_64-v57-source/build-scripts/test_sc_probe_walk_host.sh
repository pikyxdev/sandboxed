#!/bin/sh
# test_sc_probe_walk_host.sh - v54.2 offline regression for sc_probe gd64_test.
#
# The v54.1 field failure (2026-11-27): the uid-drop test read ONE 4096-byte
# getdents64 batch of /data/local/tmp and required the marker to sit inside
# it.  This test proves, on the host:
#   1. the NEW walk iterates getdents64 until EOF and finds the marker in a
#      30000-entry directory (multi-batch by construction), reaching the
#      registration step (which then fails - no module on the host: expected);
#   2. the OLD v54.1 binary on the SAME directory misses the marker with
#      overwhelming probability (informational demonstration of the bug -
#      non-gating, because readdir hash order makes it probabilistic);
#   3. the NEW walk also works on a tiny single-batch directory.
#
#   4. (v54.3) the GID CANARY gates the walk: with no module on the host
#      the canary FAILS and the walk lines never print; with the host-test
#      'skipcanary' seam the walk behaves EXACTLY like the v54.2 probe
#      (the walk logic itself is unchanged by the canary).
#
# Usage: sh scripts/test_sc_probe_walk_host.sh
set -u
cd /home/z/my-project

FAIL=0
ok()  { echo "[ok] $1"; }
bad() { echo "[FAIL] $1"; FAIL=1; }

# ---- build the NEW probe (v54.2) and the OLD one (v54.1, from git) -------
# (build recipe = the sc_probe.c header recipe; this sandbox has no lld, so
# the default bfd linker is used - lld only mattered for code layout on the
# older sandbox, not for a freestanding static-pie)
NEW=work/sc_probe_v543
OLD=work/sc_probe_v542

gcc -O2 -static-pie -nostdlib -fno-stack-protector \
    -Wl,-e,_start -o "$NEW" scripts/sc_probe.c 2>work/sc_probe_v543.build.log \
  && ok "new v54.3 sc_probe built" || { bad "new sc_probe build failed"; cat work/sc_probe_v543.build.log; exit 1; }

git show HEAD:scripts/sc_probe.c > work/sc_probe_v542.c
gcc -O2 -static-pie -nostdlib -fno-stack-protector \
    -Wl,-e,_start -o "$OLD" work/sc_probe_v542.c 2>work/sc_probe_v542.build.log \
  && ok "old v54.2 sc_probe built (the walk reference)" || { bad "old sc_probe build failed"; cat work/sc_probe_v542.build.log; exit 1; }

# ---- case A: a 30000-entry directory (multi-batch by construction) -------
BIG=/tmp/gdwalk_big
rm -rf "$BIG"; mkdir -p "$BIG"
i=0
while [ $i -lt 30000 ]; do
    : > "$BIG/filler_$(printf '%06d' $i)_$(printf '%040d' $i)"
    i=$((i + 1))
done
echo x > "$BIG/resusfs_v54_gdtest_marker"
echo x > "$BIG/resusfs_v54_gdtest_control"

OUT_A="$("$NEW" gd64_test "$BIG" resusfs_v54_gdtest_marker resusfs_v54_gdtest_control skipcanary 2>&1)"
echo "---- new probe on the big dir ----"; echo "$OUT_A"

echo "$OUT_A" | grep -q "root walk entries=" \
  && ok "A1: the walk printed an entry count" || bad "A1: no entry count"
ENT=$(echo "$OUT_A" | sed -n 's/.*root walk entries=\([0-9]*\).*/\1/p' | head -1)
[ -n "$ENT" ] && [ "$ENT" -gt 1000 ] \
  && ok "A2: multi-batch walk iterated past one batch (entries=$ENT > 1000)" \
  || bad "A2: walk stopped early (entries=${ENT:-none})"
echo "$OUT_A" | grep -q "marker=found" \
  && ok "A3: the marker was FOUND in the full walk" || bad "A3: marker not found"
echo "$OUT_A" | grep -q "control=found" \
  && ok "A4: the control was FOUND in the full walk" || bad "A4: control not found"
echo "$OUT_A" | grep -q "FAIL registration rejected" \
  && ok "A5: the flow reached registration and correctly reported no-module rejection (host has no syscall-173 transport)" \
  || bad "A5: expected host registration rejection not seen"
echo "$OUT_A" | grep -q "v54_test: marker resusfs_v54_gdtest_marker ino=" \
  && ok "A6: the marker's ino was captured and printed" || bad "A6: no ino capture"

# ---- case B: the v54.2 reference walk on the same big dir ----------------
OUT_B="$("$OLD" gd64_test "$BIG" resusfs_v54_gdtest_marker resusfs_v54_gdtest_control 2>&1)"
echo "---- v54.2 reference probe on the same dir ----"; echo "$OUT_B"
echo "$OUT_B" | grep -q "root walk entries=" \
  && ok "B1: the v54.2 reference walk printed its entry count" || bad "B1: v54.2 reference walk silent"
if echo "$OUT_A" | grep -q "root walk entries=" && echo "$OUT_B" | grep -q "root walk entries="; then
    ENT_A=$(echo "$OUT_A" | sed -n 's/.*root walk entries=\([0-9]*\).*/\1/p' | head -1)
    ENT_B=$(echo "$OUT_B" | sed -n 's/.*root walk entries=\([0-9]*\).*/\1/p' | head -1)
    [ "$ENT_A" = "$ENT_B" ] \
      && ok "B2: v54.3 walk entry count IDENTICAL to v54.2 (entries=$ENT_A - the canary changed no walk behavior)" \
      || bad "B2: walk diverged (v54.3=$ENT_A v54.2=$ENT_B)"
fi



# ---- case C: a tiny single-batch directory --------------------------------
SMALL=/tmp/gdwalk_small
rm -rf "$SMALL"; mkdir -p "$SMALL"
echo x > "$SMALL/resusfs_v54_gdtest_marker"
echo x > "$SMALL/resusfs_v54_gdtest_control"
OUT_C="$("$NEW" gd64_test "$SMALL" resusfs_v54_gdtest_marker resusfs_v54_gdtest_control skipcanary 2>&1)"
echo "---- new probe on the tiny dir ----"; echo "$OUT_C"
echo "$OUT_C" | grep -q "marker=found" && echo "$OUT_C" | grep -q "control=found" \
  && ok "C1: single-batch dir still works (found both)" || bad "C1: tiny-dir walk failed"

# ---- case D: the GID CANARY (v54.3) ---------------------------------------
# with no module on the host the canary MUST fail and gate the walk
OUT_D="$("$NEW" gd64_test "$SMALL" resusfs_v54_gdtest_marker resusfs_v54_gdtest_control 2>&1)"
echo "---- v54.3 canary on the host (no module: must gate) ----"; echo "$OUT_D"
echo "$OUT_D" | grep -q "v54_test: FAIL" \
  && ok "D1: the canary run ends in FAIL on a module-less host" || bad "D1: canary did not fail on a module-less host"
if echo "$OUT_D" | grep -q "gid canary"; then
    ok "D2: the FAIL names the gid canary (setresgid worked; the transport did not answer - correct on the host)"
else
    echo "$OUT_D" | grep -q "FAIL setresgid" \
      && ok "D2: setresgid itself failed (non-root host) - the canary still gated" \
      || bad "D2: canary FAIL without a canary reason line"
fi
echo "$OUT_D" | grep -q "root walk entries=" \
  && bad "D3: the walk RAN after a failed canary (must gate!)" \
  || ok "D3: the walk never ran after the failed canary (gated, as designed)"

rm -rf "$BIG" "$SMALL"
echo "=================================================="
[ $FAIL -eq 0 ] && echo "WALK REGRESSION: ALL GATING CHECKS PASSED" || echo "WALK REGRESSION: FAILURES PRESENT"
exit $FAIL
