#!/bin/bash
# build_v51_ko.sh - v26.11.51 CLANG ACCEPT-PATH build (graft onto the v49 .ko).
#
# THE IDEA (see sc_v51.c header for the full rationale): the v50 field run
# PROVED the clang entry under fire (stage 2: counter + -EINVAL survived a
# full boot) and CONVICTED the first execution of the v49 GCC wrapper
# (stage 3 died at the self-test, the same death as v48/v49 - 3 transport
# generations, 7 wedge boots, one common factor).  v51 therefore moves the
# WHOLE accept path into the clang graft:
#
#   susfs_sc_entry        - REAL clang function (v50 shape: endbr64,
#                           genuine kCFI preamble, locked counter, observe
#                           path -22).  Full mode (stage 3) is ALL-CLANG:
#                           magic check, uid gate through a RUNTIME-
#                           CALIBRATED cred offset (init_task/init_cred
#                           pair scan - no header-derived struct offsets),
#                           and self-contained SHOW_VERSION / SHOW_VARIANT
#                           / SHOW_ENABLED_FEATURES answers via the
#                           kernel's own _copy_from_user/_copy_to_user.
#                           The v49 GCC wrapper is NEVER CALLED.
#   susfs_supercall_init  - the v50 installer verbatim (table resolve,
#                           liveness proof, gates, endbr64 check, 16-byte
#                           preamble clone, table write, readbacks) + the
#                           v51 cred-offset calibration with receipts.
#   susfs_supercall_exit  - restore path (v50 shape).
#
# Everything else - the wrapper body (dead code now), ladder, witness, all
# 19 other layers, vermagic, this_module, the __versions/modver dummy, the
# .bss stomp pad - is the v49 object, unchanged by the merge (verified by
# scripts/build_v51_verify.py).
set -e
BASE=/home/z/my-project
PORT=$BASE/ReSuSFS-x86_64-port
CC=$BASE/toolchain/clang17/usr/lib/llvm-17/bin/clang
GRAFT_SRC=$PORT/sc_v51.c
GRAFT_OBJ=$PORT/sc_v51.o
MOD=$PORT/ReSuSFS/module
V=26.11.51

export LD_LIBRARY_PATH=$BASE/toolchain/clang17/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
[ -x "$CC" ] || { echo "[!] clang-17 missing at $CC"; exit 1; }

echo "[*] v51: compiling the clang-17 graft object (entry + accept path)"
"$CC" -target x86_64-linux-gnu -c "$GRAFT_SRC" -o "$GRAFT_OBJ" \
        -O2 -fsanitize=kcfi -fcf-protection=branch \
        -fno-stack-protector -fno-pic -mno-red-zone \
        -mcmodel=kernel -mno-sse -mno-mmx -mno-80387 \
        -ffreestanding -nostdinc -fno-builtin -std=gnu11 -Wall
echo "[+] graft object: $GRAFT_OBJ ($(stat -c%s "$GRAFT_OBJ") bytes)"

echo "[*] graft object self-checks"
nm -u "$GRAFT_OBJ" | awk '{print $2}' | sort > /tmp/v51_graft_u.txt
cat /tmp/v51_graft_u.txt
# the graft may reference NOTHING outside: 4 base functions + the resolver
# + patch primitive + the kernel uaccess pair + 6 globalized/known base
# globals, exact set, no libcalls (open-coded loops only - a memset sneaking
# in would show up here and must be fixed in the source, not linked away).
cat > /tmp/v51_graft_expected.txt <<'EOF'
_copy_from_user
_copy_to_user
ksu_kallsyms_lookup_name
ksu_patch_text
sc_full_mode
sc_installed
sc_orig
susfs_armed_features
susfs_current_arm_stage
susfs_current_task_gs_off
susfs_diag_logf
susfs_fp_syscall_table
susfs_sc_entry_count
EOF
diff -u /tmp/v51_graft_expected.txt /tmp/v51_graft_u.txt
echo "[+] undefined set exact (13 symbols: 8 defined in the v49 base, 2 kernel uaccess imports already in the base's set, 3 base functions)"
nm "$GRAFT_OBJ" | grep -E ' T (susfs_sc_entry|susfs_supercall_init|susfs_supercall_exit)$'
echo "[*] entry disassembly (must be: endbr64 ... lock incl ... no susfs_sc_wrapper reference)"
objdump -d --disassemble=susfs_sc_entry "$GRAFT_OBJ" | head -30
if objdump -dr "$GRAFT_OBJ" | grep -q 'susfs_sc_wrapper'; then
        echo "[!] FATAL: the graft references susfs_sc_wrapper - the v51 contract is that the v49 GCC wrapper is NEVER called"
        exit 1
fi
echo "[+] the v49 GCC wrapper is not referenced anywhere in the graft"

graft_ko() {      # $1 = base .ko, $2 = output name
        local SRC_KO=$1 NAME=$2
        local WEAK=$(mktemp /tmp/v51_weak_XXXX.ko)
        echo "[*] v51: grafting $NAME <- $SRC_KO"
        objcopy \
                --weaken-symbol=susfs_supercall_init \
                --weaken-symbol=susfs_supercall_exit \
                --weaken-symbol=susfs_sc_entry \
                --globalize-symbol=sc_orig \
                --globalize-symbol=sc_installed \
                --globalize-symbol=sc_full_mode \
                --globalize-symbol=susfs_sc_entry_count \
                --globalize-symbol=susfs_armed_features \
                "$SRC_KO" "$WEAK"
        # graft FIRST: ld -r keeps the first definition of each symbol; the
        # weakened v49 defs of the three overridden symbols are dropped and
        # all references (susfs_layers[].init/.exit, the old dead init's
        # own code) bind to the clang graft.
        ld -r -o "$PORT/$NAME" "$GRAFT_OBJ" "$WEAK"
        rm -f "$WEAK"
        echo "[+] merged: $PORT/$NAME ($(stat -c%s "$PORT/$NAME") bytes)"
}

graft_ko "$PORT/susfs_guard_lkm-x86_64-android13-5.15.ko" \
         "susfs_guard_lkm-x86_64-android13-5.15-v51.ko"
graft_ko "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15.ko" \
         "susfs_guard_lkm-x86_64-vanilla-5.15-v51.ko"

echo "[*] v51: installing candidates into the module payload"
mkdir -p "$MOD/lkm/x86_64/candidates"
cp -f "$PORT/susfs_guard_lkm-x86_64-android13-5.15-v51.ko" \
      "$MOD/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko"
cp -f "$PORT/susfs_guard_lkm-x86_64-vanilla-5.15-v51.ko" \
      "$MOD/lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko"
echo "v$V" > "$MOD/lkm/x86_64/.payload_stamp"
ls -la "$MOD/lkm/x86_64" "$MOD/lkm/x86_64/candidates"

echo "[*] v51: CLI + insmod carried over from the field-proven v50 payload"
# The CLI source (tools/susfs_cli_x64.c) was lost with the November partial
# tree loss; the v51 CLI contract is byte-identical to v49/v50 (syscall 173 +
# payload.err + the nop'd return-checks).  Copy from work/pkg50 and verify
# the 173-site patch held.
for b in ksu_susfs susfs_insmod sc_probe; do
        if [ -f "$BASE/work/pkg50/bin/x86_64/$b" ]; then
                cp -f "$BASE/work/pkg50/bin/x86_64/$b" "$MOD/bin/x86_64/$b"
                chmod 755 "$MOD/bin/x86_64/$b"
        fi
done
ls -la "$MOD/bin/x86_64/"
python3 - "$MOD/bin/x86_64/ksu_susfs" <<'EOF'
import re, sys
cd = open(sys.argv[1], 'rb').read()
sites = 0
for m in re.finditer(b'\xb8\xad\x00\x00\x00', cd):
    s = m.start()
    sc = cd.find(b'\x0f\x05', s, s + 80)
    if sc < 0:
        continue
    if cd[sc+2:sc+5] == b'\x48\x85\xc0':
        sites += 1
assert sites == 9, f'CLI 173-riding sites: {sites} (want 9)'
old = sum(1 for m in re.finditer(b'\xb8\xa9\x00\x00\x00', cd)
          if cd.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert old == 0, f'old 169 sites remain: {old}'
print(f'[+] CLI verified: 9 syscall-173 sites, 0 old 169 sites')
EOF

echo "[+] v51 graft build complete (payload staged in $MOD)"
