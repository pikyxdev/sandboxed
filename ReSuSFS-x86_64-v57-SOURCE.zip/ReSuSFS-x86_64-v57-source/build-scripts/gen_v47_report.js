// gen_v47_report.js — ReSuSFS v47 Field Validation Report (docx)
// Skill compliance: R1 cover recipe (DM-1 palette), calcTitleLayout + calcCoverSpacing,
// allNoBorders 16838 exact wrapper, cover margin 0, 3-section numbering (cover / TOC / body),
// TableOfContents + refresh hint + PageBreak, headings via HeadingLevel, tables with
// tableHeader+cantSplit+keepNext+margins+percentage widths, ShadingType.CLEAR only.
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, AlignmentType, HeadingLevel,
  WidthType, BorderStyle, ShadingType, SectionType, TableOfContents,
  PageBreak, TableLayoutType,
} = require("docx");
const fs = require("fs");

// ---------------- palette (design-system: DM-1 Deep Cyan, tech) ----------------
const COVER = { // DM-1 cover tokens
  bg: "162235", accent: "37DCF2",
  titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078",
};
const TABLE = { // DM-1 darkened table tokens (white-page tables)
  headerBg: "1B6B7A", headerText: "FFFFFF", accentLine: "1B6B7A", innerLine: "C8DDE2", surface: "EDF3F5",
};
const INK = { primary: "0B1F2A", body: "000000", secondary: "55606A", mono: "1A2A33" };

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ---------------- cover helpers (design-system, English-width variant) ----------------
function splitTitleLines(title, charsPerLine) {
  if (title.length <= charsPerLine) return [title];
  const breakAfter = new Set([...",.;:!?", ..."-_/", ..." \t"]);
  const lines = [];
  let remaining = title;
  while (remaining.length > charsPerLine) {
    let breakAt = -1;
    for (let i = charsPerLine; i >= Math.floor(charsPerLine * 0.6); i--) {
      if (i < remaining.length && breakAfter.has(remaining[i - 1])) { breakAt = i; break; }
    }
    if (breakAt === -1) {
      const limit = Math.min(remaining.length, Math.ceil(charsPerLine * 1.3));
      for (let i = charsPerLine + 1; i < limit; i++) {
        if (breakAfter.has(remaining[i - 1])) { breakAt = i; break; }
      }
    }
    if (breakAt === -1) breakAt = charsPerLine;
    lines.push(remaining.slice(0, breakAt).trim());
    remaining = remaining.slice(breakAt).trim();
  }
  if (remaining) lines.push(remaining);
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
// English ASCII chars are ~half CJK width: charWidth = pt * 10.5 twips (estimateTextWidth
// guidance from design-system for non-CJK titles; same contract: pt from 40 down to 24,
// <= 3 lines, semantic breaks, no orphans).
function calcTitleLayoutEN(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  const charWidth = (pt) => pt * 10.5;
  const charsPerLine = (pt) => Math.floor(maxWidthTwips / charWidth(pt));
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    const cpl = charsPerLine(titlePt);
    if (cpl < 2) { titlePt -= 2; continue; }
    lines = splitTitleLines(title, cpl);
    if (lines.length <= 3) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) {
    lines = splitTitleLines(title, charsPerLine(minPt));
    titlePt = minPt;
  }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(params) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
          metaLineCount = 0, fixedHeight = 800, pageHeight = 16838,
          marginTop = 0, marginBottom = 0 } = params;
  const SAFETY = 1200;
  const usableHeight = pageHeight - marginTop - marginBottom - SAFETY;
  const titleHeight = titleLineCount * (titlePt * 23 + 200);
  const subtitleHeight = hasSubtitle ? (12 * 23 + 600) : 0;
  const englishLabelHeight = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaHeight = metaLineCount * (10 * 23 + 100);
  const implicitParaHeight = 3 * 300;
  const contentHeight = titleHeight + subtitleHeight + englishLabelHeight + metaHeight + fixedHeight + implicitParaHeight;
  const remainingSpace = usableHeight - contentHeight;
  const safeRemaining = Math.max(remainingSpace, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(safeRemaining * 0.45);
  const rawBottom = Math.floor(safeRemaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(safeRemaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ---------------- Recipe R1: Pure Paragraph Cover (Left-Aligned) ----------------
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayoutEN(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200, right: padR }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        " }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders,
        verticalAlign: "top",
        children,
      })],
    })],
  })];
}

// ---------------- body component builders ----------------
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: INK.primary,
      font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: INK.primary,
      font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
  });
}
function body(runs) {
  const children = (typeof runs === "string")
    ? [new TextRun({ text: runs, size: 24, color: INK.body, font: { ascii: "Times New Roman", eastAsia: "SimSun" } })]
    : runs;
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 120 },
    children,
  });
}
function b(text) { // bold run
  return new TextRun({ text, bold: true, size: 24, color: INK.body, font: { ascii: "Times New Roman", eastAsia: "SimSun" } });
}
function r(text) { // regular run
  return new TextRun({ text, size: 24, color: INK.body, font: { ascii: "Times New Roman", eastAsia: "SimSun" } });
}
function m(text) { // inline monospace run
  return new TextRun({ text, size: 20, color: INK.mono, font: { ascii: "Courier New", eastAsia: "SimSun" } });
}
function monoLine(text, opts = {}) { // log/command line, left accent border block
  return new Paragraph({
    alignment: AlignmentType.LEFT,
    indent: { left: 360, right: 360 },
    spacing: { line: 276, lineRule: "atLeast", after: opts.last ? 160 : 20 },
    border: { left: { style: BorderStyle.SINGLE, size: 8, color: TABLE.accentLine, space: 10 } },
    children: [new TextRun({ text, size: 18, color: INK.mono, font: { ascii: "Courier New", eastAsia: "SimSun" } })],
  });
}
function tableTitle(text) {
  return new Paragraph({
    keepNext: true,
    spacing: { before: 200, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: INK.secondary,
      font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
  });
}
function cell(text, opts = {}) {
  return new TableCell({
    margins: { top: 60, bottom: 60, left: 120, right: 120 },
    width: { size: opts.w, type: WidthType.PERCENTAGE },
    shading: opts.fill ? { type: ShadingType.CLEAR, fill: opts.fill } : undefined,
    children: [new Paragraph({
      alignment: AlignmentType.LEFT,
      spacing: { line: 276, lineRule: "atLeast" },
      children: [new TextRun({ text, bold: !!opts.bold, size: opts.size || 20,
        color: opts.color || INK.body, font: { ascii: opts.mono ? "Courier New" : "Times New Roman", eastAsia: "SimSun" } })],
    })],
  });
}
function tbl(headers, rows, widths, opts = {}) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: TABLE.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: TABLE.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: TABLE.innerLine },
      insideVertical: NB,
    },
    rows: [
      new TableRow({
        tableHeader: true, cantSplit: true,
        children: headers.map((t, i) => cell(t, { w: widths[i], bold: true, fill: TABLE.headerBg, color: TABLE.headerText, size: 20 })),
      }),
      ...rows.map((row, ri) => new TableRow({
        cantSplit: true,
        children: row.map((t, i) => cell(t, {
          w: widths[i],
          fill: ri % 2 === 1 ? TABLE.surface : undefined,
          mono: opts.monoCols ? opts.monoCols.includes(i) : false,
          size: opts.monoCols && opts.monoCols.includes(i) ? 18 : 20,
        })),
      })),
    ],
  });
}
function pageFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: { ascii: "Times New Roman" } })],
    })],
  });
}
function pageHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: TABLE.innerLine, space: 4 } },
      children: [new TextRun({ text: "ReSuSFS v47 Field Validation Report", size: 18, color: "808080", font: { ascii: "Times New Roman" } })],
    })],
  });
}

// ---------------- content ----------------
const CLI_SHA = "7a30fa745a523a4e2897023086a2ef08d773899394781d131f68676227e80e9f";
const PROBE_SHA = "9544358e75bce5541ea8f78b55a71413865334437673a20519e65db57d2cbb6d";

const ledger = [
  ["1", "6a358a87", "08:02:31", "0/7 dispatch", "0 evidence", "COMPLETE 8/8 HB"],
  ["2", "527a62f4", "08:11:11", "1/7 +imports", "0 evidence", "COMPLETE 8/8 HB"],
  ["3", "711c0207", "08:15:41", "2/7 +resolver", "0 evidence", "COMPLETE 8/8 HB"],
  ["4", "7dbe28f1", "08:19:44", "3/7 +gs_off", "0 evidence", "COMPLETE 8/8 HB"],
  ["5", "f4f419f0", "08:30:22", "4/7 +deadman", "0 evidence", "COMPLETE 8/8 HB"],
  ["6", "d06c7225", "08:32:34", "5/7 +crosscheck", "0 evidence", "COMPLETE 8/8 HB"],
  ["7", "4977cb39", "08:35:20", "6/7 +patch", "0 evidence", "COMPLETE 8/8 HB"],
  ["8", "2e0e259d", "08:38:05", "7/7 +layers", "1 layers", "COMPLETE 8/8 HB"],
  ["9", "d1e125ce", "08:42:05", "7/7 +layers", "2 transport OBSERVE", "COMPLETE 8/8 HB"],
  ["10", "44dd1f7f", "08:45:51", "7/7 +layers", "3 transport FULL", "COMPLETE 8/8 HB"],
];

const verdictRows = [
  ["Ten-boot staged climb (stability)", "PASS 10/10", "init_trace_x10.txt: 10 lines COMPLETE (init_done=1 after 0s); 10 heartbeat windows done (40s)"],
  ["v47 transport arming, observe rung", "PASS", "diag_last_x9.txt: transport LIVE, 1 arm redirected, mode=OBSERVE-ONLY, no kprobe"],
  ["v47 transport arming, accept rung", "PASS", "diag_last_x10.txt: same receipts with mode=FULL; KernelSU reboot slot untouched"],
  ["KernelSU coexistence", "PASS", "dmesg: KernelSU reboot kprobe registered successfully on every boot; zero interference"],
  ["LKM image load", "PASS", "boot_x9/x10.log: vanilla-5.15.ko live every boot (626,688 bytes, hidden from /proc/modules by design)"],
  ["Supercall channel end-to-end", "FAIL (userspace-local)", "sc_selftest_x9/x10.txt: sc_entry_count 0 before and after; all three show commands failed. Root cause in section 4"],
];

const taxRows = [
  ["susfs: show version failed", "Syscall returned 0; payload.err stayed a positive untouched value (the 126 seed)", "A consumer accepted the call but never wrote an answer", "Observed on the box, both observe and FULL boots"],
  ["... failed (no supercall answer, the module is not loaded)", "Syscall itself returned an error (-999 path in the CLI)", "Real ioperm(2) or reboot(2) executed; nobody accepted the supercall", "Expected pre-init; not the field shape"],
  ["... failed (kernel err N)", "The wrapper or a handler wrote a negative errno into payload.err", "Command reached a handler and was refused", "Not observed"],
  ["Version printed, e.g. v2.3.0", "Syscall returned 0 and payload.err = 0", "Channel answered end to end", "TARGET state after Phase A"],
];

const featRows = [
  ["Loaded (11)", "fp_hook, ksu_umount_gate, ksu_allow_gate, sus_map, sus_mount, spoof_cmdline, open_redirect, prop_view, enable_log, avc_spoof, supercall (fatal=1)"],
  ["Retired by design (9)", "lsm_hook, sus_path, create_gate, opath, dirent, uname, kstat, hide_syms, sus_unix (gated to stages 4/5, which v47 retires)"],
];

const interpRows = [
  ["sc_entry_count moved; err=0; answer printed (v2.3.0)", "Transport intercepted the call and the channel answered end to end", "Proceed to Phase B acceptance suite"],
  ["Count moved; rc=0; err still 126", "Traversal proven; accept path present but not answering this command", "Send sc_probe output and dmesg tail; wrapper-side bisect next"],
  ["Count unchanged; rc negative (e.g. -22)", "The call executed the real ioperm(2); the patched arm did not intercept", "Send sc_probe output; instrumented v48 build next"],
];

const budgetRows = [
  ["Stability ladder, substeps 0-7 + stages 0-3", "10", "DONE this round: 10/10 clean, zero wedges, zero WEDGE DOSSIER"],
  ["Phase A: CLI verification, replacement, self-test", "0", "Pending; runs on the current live stage-3 boot"],
  ["Phase B: acceptance suite (runtime lists)", "0", "Pending; same boot as Phase A"],
  ["Phase C: confirmation reboot with answered self-test", "1", "Pending"],
  ["Phase D: soak at the stage-3 ceiling", "2", "Pending"],
  ["Contingency: instrumented build if Phase A shows non-traversal", "up to 1", "Only on the third Phase-A outcome"],
];

const logRows = [
  ["boot.log", "post-fs-data + boot-completed flow", "arm_stage 3 healthy - at ladder max 3 (the v47 ceiling"],
  ["init_trace.txt", "substep/stage ladder, witness, heartbeats", "STEP 7 COMPLETE (init_done=1 after 0s; module laststep=7) + heartbeat window done (40s)"],
  ["diag_last.txt", "layer-by-layer module receipts", "supercall: transport LIVE - 1 arm(s) redirected (patched 1), mode=FULL; no kprobe registered anywhere"],
  ["sc_selftest.txt", "supercall self-test receipt", "after: sc_entry_count=3 and the three answered show commands"],
  ["dmesg (full export)", "kernel ring, wrapper receipts", "No oops/BUG; OBSERVE lines absent at stage 3 by design; answers visible via the CLI"],
];

const bootFull = [
  ["1", "6a358a874a2846b3845e3bafadd29c3e", "08:02:31", "0", "0", "ok 0 (fresh state after re-base)"],
  ["2", "527a62f400824ee3b92d9b75762ade96", "08:11:11", "1", "0", "ok 0 6a358a87..."],
  ["3", "711c0207727941af9258eab5597b46e4", "08:15:41", "2", "0", "ok 0 527a62f4..."],
  ["4", "7dbe28f1d90f44baa49ffce6691b5b83", "08:19:44", "3", "0", "ok 0 711c0207..."],
  ["5", "f4f419f089bf40b7a2e7ef0eb720e6f4", "08:30:22", "4", "0", "ok 0 7dbe28f1..."],
  ["6", "d06c72251590450580b4caf7072e17d3", "08:32:34", "5", "0", "ok 0 f4f419f0..."],
  ["7", "4977cb39e9864962b81f514a5b6f8a99", "08:35:20", "6", "0", "ok 0 d06c7225..."],
  ["8", "2e0e259db7624619aebebf82ae536602", "08:38:05", "7", "1", "ok 0 4977cb39..."],
  ["9", "d1e125ceccb642d5b79b46a5969c4b4f", "08:42:05", "7", "2", "ok 1 2e0e259d..."],
  ["10", "44dd1f7f802d4bcd83c022aca470a8bc", "08:45:51", "7", "3", "ok 2 d1e125ce..."],
];

const abiRows = [
  ["Syscall number", "173 (ioperm(2), the cold channel; reboot 169 is never touched)"],
  ["Magic pair", "0xDEADBEEF, 0xFAFAFAFA"],
  ["Show version / variant / enabled_features cmd ids", "0x555e1 / 0x555e3 / 0x555e2"],
  ["Error sentinel", "126 (ERR_CMD_NOT_SUPPORTED; userspace pre-seeds payload.err, kernel writes 0 on success)"],
  ["Version / variant strings", "v2.3.0 / GKI-LKM"],
  ["Counter", "sc_entry_count: incremented on every wrapper entry, before any magic check"],
];

// ---------------- assemble document ----------------
const coverConfig = {
  title: "ReSuSFS v47 Field Validation Report",
  subtitle: "Ten clean boots through stage 3 - the no-kprobe supercall transport is armed and stable; the channel stays dark from a stale userspace CLI, fixable in one command",
  englishLabel: "FIELD VALIDATION REPORT",
  metaLines: [
    "Target: LDPlayer 14 - Android 13 - kernel 5.15.178+ (x86_64, KernelSU built-in)",
    "Module: ReSuSFS v26.11.47-x86_64 (versionCode 125) - LKM susfs_guard_lkm",
    "Evidence: nine field log files, 10 boots, 2026-11-24 08:02-08:46 (Asia/Jakarta)",
    "Transport: hardened-dispatcher cold-arm redirect, syscall 173, zero kprobes",
  ],
  footerLeft: "ReSuSFS x86_64 port campaign",
  footerRight: "2026-11-24",
  palette: COVER,
};

const bodyChildren = [];

// ---------- 1. Executive Summary ----------
bodyChildren.push(h1("1. Executive Summary"));
bodyChildren.push(body([
  r("On 2026-11-24 the v47 transport build (module "),
  m("v26.11.47-x86_64"),
  r(", versionCode 125) completed its full staged field climb on the LDPlayer 14 target in ten consecutive boots, 08:02 to 08:46, advancing exactly one ladder rung per boot: substeps 0 through 7, then arm stages 0 through 3. Every boot returned "),
  m("init_done=1"),
  r(" within the same second as the trigger write, completed its full 40-second heartbeat window (8 of 8 beats), and wrote its ladder receipts. No WEDGE DOSSIER was written, no "),
  m("uCountStall"),
  r(" host dialog appeared, and no boot required manual recovery. The shared-kprobe-slot wedge that killed the v45 and v46 transports is architecturally eliminated in v47: the module registers no kprobe anywhere and leaves KernelSU's own reboot kprobe untouched, per its own receipts."),
]));
bodyChildren.push(body([
  r("The supercall transport armed cleanly at both transport rungs. The module found exactly one direct branch to the cold handler "),
  m("__x64_sys_ioperm"),
  r(" (syscall 173) among 235,693 branches scanned in kernel text, and redirected the dispatcher's arm at "),
  m("0xffffffff81002a8e"),
  r(" to its wrapper. The box then survived stage 2 (OBSERVE-ONLY) and stage 3 (FULL) boots - the exact class of operation that froze the box twice during the v45 campaign - with full stability and complete receipts on every boot."),
]));
bodyChildren.push(body([
  r("One defect remains, and it is userspace-local. In both self-tests the supercall entry counter stayed at 0 before and after, and all three "),
  m("ksu_susfs"),
  r(" show commands failed. Section 4 traces this to the binary at "),
  m("/data/adb/ksu/bin/ksu_susfs"),
  r(" on the box still speaking the pre-v47 reboot(169) convention: it never issues syscall 173, so the armed transport never receives a call. The shipped zip itself is verified correct. The fix is a one-command device-side CLI replacement followed by a re-run of the self-test - strictly zero reboots - then a three-reboot confirmation and soak. This report carries the full evidence chain, the fix procedure, and the remaining test plan with per-boot pass criteria."),
]));
bodyChildren.push(tableTitle("Table 1: Verdict summary"));
bodyChildren.push(tbl(["Test item", "Result", "Decisive evidence"], verdictRows, [30, 18, 52]));

// ---------- 2. Scope and Environment ----------
bodyChildren.push(h1("2. Test Scope, Environment and Method"));
bodyChildren.push(body([
  r("Object under test is the ReSuSFS v47 transport build, whose design goal is a supercall channel that never shares a hook slot with KernelSU: instead of a second kprobe on "),
  m("__x64_sys_reboot"),
  r(" (the v45 design that froze the box), the module scans kernel text for the hardened syscall dispatcher's direct branch to the cold handler "),
  m("__x64_sys_ioperm"),
  r(" and rewrites that 4-byte rel32 so calls to syscall 173 enter the module wrapper in the caller's own syscall context. The staged arming ladder advances one rung per healthy boot and self-demotes on a wedge, so any failure is bounded to one rung and one boot."),
]));
bodyChildren.push(body([
  r("Method: the ten boots were driven by the shipped ladder with no manual intervention. Each boot's evidence set (boot.log, init_trace.txt, diag_last.txt, sc_selftest.txt, dmesg) was pulled and forms the sole basis of this report; every quoted line below is verbatim from those files or from the shipped build tree. The stability claim is the conjunction of ten "),
  m("STEP N COMPLETE (init_done=1 after 0s)"),
  r(" receipts, ten completed heartbeat windows, and the absence of wedge markers anywhere in the x9/x10 evidence set (WEDGE DOSSIER, uCountStall, kernel oops or BUG lines - verified by exhaustive search of all nine files; matches appear only in the archived 2026-11-23 v46-era captures, not in this round)."),
]));
bodyChildren.push(tableTitle("Table 2: Environment"));
bodyChildren.push(tbl(["Item", "Value"], [
  ["Target box", "LDPlayer 14 emulator, Android 13"],
  ["Kernel", "5.15.178+ x86_64, KernelSU built-in (reboot kprobe registered every boot)"],
  ["Module", "ReSuSFS v26.11.47-x86_64, versionCode 125 (zip ReSuSFS-x86_64-v26.11.47.zip)"],
  ["Kernel module", "susfs_guard_lkm, vanilla-5.15 image, 626,688 bytes, hidden from /proc/modules by design"],
  ["Transport under test", "Dispatcher cold-arm redirect on syscall 173; zero kprobes; stages 4/5 retired (ceiling 3)"],
  ["Evidence window", "2026-11-24 08:02-08:46 Asia/Jakarta; 10 boots; 9 log files"],
  ["Key kernel addresses", "kln 0xffffffff810fd360; gs_off 0x1bc40; __x64_sys_reboot 0xffffffff8108faf0; __x64_sys_ioperm 0xffffffff81027650; arm site 0xffffffff81002a8e"],
], [22, 78]));

// ---------- 3. Results ----------
bodyChildren.push(h1("3. Results: The Ten-Boot Ladder"));
bodyChildren.push(body([
  r("The flash re-based the ladder to a fresh state (the receipt "),
  m("module version changed ('' -> 'v26.11.47-x86_64') - re-basing the stage ladder (arm_stage=0, stage_max=3 - the v47 ceiling, stages 4/5 retired)"),
  r(" appears on the first boot only), so this install performed the full climb: seven substep boots (each proving one more init body section), the stage-1 layer boot, the stage-2 observe boot, and the stage-3 accept boot. All ten returned the same completion shape; none stalled, none demoted, none wedged."),
]));
bodyChildren.push(tableTitle("Table 3: Boot ledger (08:02-08:46; every boot COMPLETE with 8/8 heartbeats)"));
bodyChildren.push(tbl(["#", "Boot id", "Time", "Substep", "arm_stage", "Result"], ledger, [6, 14, 12, 22, 22, 24]));
bodyChildren.push(body([
  r("The transport receipts on the two decisive boots are the core result of this round - the module armed the new transport twice, on the live kernel, with the box surviving both arming and the previously-lethal window after it. Verbatim from "),
  m("diag_last_x10.txt"),
  r(" (stage 3, FULL):"),
]));
[
  "supercall: cold handler __x64_sys_ioperm at 0xffffffff81027650 (nr 173; reboot's hot slot is NOT on this path)",
  "supercall: scanning kernel text [_stext 0xffffffff81000000, _etext 0xffffffff81c01dd9) for E8/E9 -> __x64_sys_ioperm",
  "supercall: scan found 1 arm(s) to __x64_sys_ioperm among 235693 branches",
  "supercall: arm at 0xffffffff81002a8e redirected -> susfs_sc_wrapper (orig __x64_sys_ioperm, mode=FULL)",
  "supercall: transport LIVE - 1 arm(s) redirected (patched 1), mode=FULL; no kprobe registered anywhere; KernelSU's reboot slot untouched",
].forEach((t, i, a) => bodyChildren.push(monoLine(t, { last: i === a.length - 1 })));
bodyChildren.push(body([
  r("The single patched arm sits inside the live dispatcher ("),
  m("x64_sys_call"),
  r(" at "),
  m("0xffffffff810026e0"),
  r(", arm at offset 0x3AE), and KernelSU's own reboot kprobe registered normally on every boot ("),
  m("KernelSU: reboot kprobe registered successfully"),
  r(" in dmesg) - coexistence without interference, which is exactly what the v45 arc could not achieve."),
]));
bodyChildren.push(tableTitle("Table 4: Feature layers at the stage-3 ceiling"));
bodyChildren.push(tbl(["State", "Layers"], featRows, [22, 78]));
bodyChildren.push(body([
  r("The retired set is a design decision, not a defect: v45 froze the box on those layer classes with no supercall involved, so v47 parks the ladder at stage 3. At the ceiling, the runtime-configurable feature set is sus_map, sus_mount, open_redirect, prop_view, spoof_cmdline, enable_log and avc_spoof, driven through the supercall channel once it is live (section 5)."),
]));

// ---------- 4. Defect analysis ----------
bodyChildren.push(h1("4. Defect Analysis: The Dark Channel"));
bodyChildren.push(h2("4.1 Observed failure"));
bodyChildren.push(body([
  r("On both transport boots the boot-completed self-test fired the three CLI probes and returned the same failure shape. Verbatim from "),
  m("sc_selftest_x10.txt"),
  r(" (stage 3, FULL, 08:46:06):"),
]));
[
  "---- v47 supercall self-test @ 2026-11-24 08:46:06 arm_stage=3 mode=FULL ----",
  "before: sc_entry_count=0",
  "-- ksu_susfs show version (timeout 3):",
  "susfs: show version failed",
  "-- ksu_susfs show variant (timeout 3):",
  "susfs: show variant failed",
  "-- ksu_susfs show enabled_features (timeout 3):",
  "susfs: show enabled_features failed",
  "after: sc_entry_count=0",
].forEach((t, i, a) => bodyChildren.push(monoLine(t, { last: i === a.length - 1 })));
bodyChildren.push(body([
  r("The same shape appears on the stage-2 observe boot (08:42:20, "),
  m("sc_selftest_x9.txt"),
  r("). In observe mode an unanswered CLI is expected by design; in FULL mode it is not - the module receipt for that very boot says the transport is live and accepting. The two facts cannot both be true unless the calls never reach the transport."),
]));
bodyChildren.push(h2("4.2 Evidence chain"));
bodyChildren.push(body([
  b("The counter counts every entry, unconditionally. "),
  r("The wrapper's first statement is "),
  m("susfs_diag_sc_entry_hit()"),
  r(", which increments the "),
  m("sc_entry_count"),
  r(" module parameter - before any magic or uid check, so it counts every syscall(173) that traverses the patched arm, supercall or not (kernel/susfs_supercall.c, kernel/susfs_main.c). A count of exactly zero before and after the self-test means "),
  b("not one syscall(173) reached the dispatcher arm during the test"),
  r(" - while the arm itself was verified live on the same boot."),
]));
bodyChildren.push(body([
  b("The CLI's own failure taxonomy identifies what the caller actually saw. "),
  r("In the shipped freestanding CLI (tools/susfs_cli_x64.c), the bare line "),
  m("susfs: show version failed"),
  r(" prints when the syscall returned 0 and payload.err came back a positive untouched value - the 126 ERR_CMD_NOT_SUPPORTED seed; a different suffix marks a failing syscall, and a third marks a negative kernel-written errno. The field output is the bare line, on both boots: a zero-return syscall whose payload was never written."),
]));
bodyChildren.push(tableTitle("Table 5: CLI failure lines and their meaning (from the shipped CLI source)"));
bodyChildren.push(tbl(["Line printed by the CLI", "Syscall / payload state", "Interpretation", "Field status"], taxRows, [30, 26, 24, 20]));
bodyChildren.push(body([
  b("The shipped zip is not at fault. "),
  r("The archive's own CLI ("),
  m("bin/x86_64/ksu_susfs"),
  r(", 18,088 bytes, sha256 "),
  m(CLI_SHA),
  r(") was inspected at the binary level: it contains exactly nine supercall sites riding syscall 173 and none riding 169 - the v47 patch (169 to 173, same instruction length, context-verified) is fully applied. The module side armed on the same boots. The mismatch is therefore between the box and the zip, not inside the zip."),
]));
bodyChildren.push(body([
  b("Conclusion: the CLI that ran is a pre-v47 binary riding reboot(169). "),
  r("The self-test invokes the hardcoded path "),
  m("/data/adb/ksu/bin/ksu_susfs"),
  r(". For the observed pairing - a zero-return syscall with an untouched payload, and a frozen syscall-173 counter - the invoked binary cannot be the zip's 173-riding CLI; it is an earlier build speaking the reboot(169) convention, whose calls never touch the ioperm arm. A zero return with no payload write on that path is consistent with the box's KernelSU reboot-kprobe machinery consuming the old-convention magic call; the transport itself is exonerated by its own receipts. The stale binary's origin is device-side history: the installer replaces this path only at flash time and deliberately keeps it when the existing file is a symlink, and a manager-side refresh is also possible - the Phase A hash check settles which case applies, and no further forensics is needed to proceed."),
]));

// ---------- 5. Fix and plan ----------
bodyChildren.push(h1("5. The Fix and the Remaining Test Plan"));
bodyChildren.push(h2("5.1 Phase A - device-side, zero reboots (current live boot)"));
bodyChildren.push(body([
  r("Phase A verifies the CLI, replaces it from the module's own bundled copy, and re-runs the self-test on the live stage-3 boot. The transport is already armed; nothing kernel-side needs to change. Run as root (su) after the desktop is up:"),
]));
[
  "A1  ls -la /data/adb/ksu/bin/ksu_susfs        # symlink? regular file?",
  "A1  sha256sum /data/adb/ksu/bin/ksu_susfs",
  "    # v47 CLI = 7a30fa745a523a4e2897023086a2ef08d773899394781d131f68676227e80e9f (18088 bytes)",
  "A1  cat /data/adb/ReSuSFS/arm_stage            # expect 3",
  "A1  grep -c 'mode=FULL' /data/adb/ReSuSFS/logs/diag_last.txt   # expect 1",
  "A2  cp -f /data/adb/modules/ReSuSFS/bin/x86_64/ksu_susfs /data/adb/ksu/bin/ksu_susfs",
  "A2  chmod 755 /data/adb/ksu/bin/ksu_susfs ; sha256sum /data/adb/ksu/bin/ksu_susfs   # now equal to the v47 hash",
  "A3  /data/local/tmp/sc_probe                   # ground truth, independent of any CLI",
  "A4  /data/adb/ksu/bin/ksu_susfs show version",
  "A4  /data/adb/ksu/bin/ksu_susfs show variant",
  "A4  /data/adb/ksu/bin/ksu_susfs show enabled_features",
  "A4  cat /sys/module/susfs_guard_lkm/parameters/sc_entry_count",
  "A5  dmesg | tail -40 > /data/adb/ReSuSFS/logs/dmesg_scprobe.txt",
].forEach((t, i, a) => bodyChildren.push(monoLine(t, { last: i === a.length - 1 })));
bodyChildren.push(body([
  r("Expected after A2: the three A4 commands answer "),
  m("v2.3.0"),
  r(", "),
  m("GKI-LKM"),
  r(", and the six-line enabled-features list (SUSFS_LKM_MODULES, CONFIG_KSU_SUSFS_SUS_MOUNT, CONFIG_KSU_SUSFS_ENABLE_LOG, CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG, CONFIG_KSU_SUSFS_OPEN_REDIRECT, CONFIG_KSU_SUSFS_SUS_MAP), and the counter reads at least 3. The sc_probe tool (Appendix A) rides the v47 ABI directly and prints the counter before and after, so it settles the channel even if the CLI question were still open. If the bundled copy under /data/adb/modules differs from the hash above, push the CLI from the zip's bin/x86_64 instead - the binary in the zip is the reference."),
]));
bodyChildren.push(tableTitle("Table 6: Phase A outcome interpretation"));
bodyChildren.push(tbl(["Observation", "Meaning", "Next action"], interpRows, [34, 36, 30]));
bodyChildren.push(h2("5.2 Phase B - acceptance suite (same boot, no reboot)"));
bodyChildren.push(body([
  r("With the channel answering, drive the runtime-configurable lists exactly as the runbook prescribes: add a sus_map entry and an open_redirect rule, enable mount hiding, set a spoofed cmdline, and turn on susfs logging and avc spoofing. Each accepted command returns silently (exit 0); with enable_log on, per-rule receipts land in dmesg. Retired classes fail by design: add_sus_path and set_uname must print their failure lines - that is the honest ceiling, not a defect. The per-feature observable effects (what an unprivileged process sees) are the natural next experiments once the channel is parked."),
]));
bodyChildren.push(h2("5.3 Phases C and D - confirmation and soak"));
bodyChildren.push(body([
  r("Phase C is one reboot: the ladder re-arms stage 3 automatically (the ceiling rung), and the boot-completed self-test now runs answered - expect the three show commands printing their answers inside sc_selftest.txt with "),
  m("after: sc_entry_count=3"),
  r(", and the boot.log line "),
  m("arm_stage 3 healthy - at ladder max 3 (the v47 ceiling"),
  r(". Phase D is two soak reboots with the same expectations each boot; 2 of 2 clean plus answered self-tests is the campaign goal state. Total remaining budget: three required reboots (one confirmation, two soak), zero for Phases A and B which run on the live boot, plus at most one contingency boot in the instrumented-build branch of Table 6."),
]));
bodyChildren.push(tableTitle("Table 7: Reboot budget"));
bodyChildren.push(tbl(["Phase", "Reboots", "Status"], budgetRows, [40, 12, 48]));
bodyChildren.push(h2("5.4 Evidence to send back and failure playbook"));
bodyChildren.push(body([
  r("Per boot, capture the five files below (the same set this report was built from); after Phase A also include the sc_probe output and the dmesg tail. The wedge protocol is unchanged from the runbook: if a boot freezes, capture dmesg/diag/modules while adb lives, then restart the instance - the next boot demotes itself and writes the WEDGE DOSSIER automatically; no manual ladder reset and no re-flash is ever needed."),
]));
bodyChildren.push(tableTitle("Table 8: Per-boot log capture and the one marker line to check"));
bodyChildren.push(tbl(["File", "What it carries", "Marker to check"], logRows, [18, 34, 48]));

// ---------- 6. Risks ----------
bodyChildren.push(h1("6. Risk Assessment and Outstanding Items"));
bodyChildren.push(body([
  b("First live traversal has not yet occurred. "),
  r("Stage 2/3 receipts prove the patch armed and verified, but no syscall(173) has yet executed through the wrapper on any boot - the counter is zero. Phase A produces the first live fire. On this transport a defective wrapper degrades to a task-local error return, not the v45-class box freeze (no shared kprobe slot exists to collide with), and the auto-demotion ladder bounds any residual risk to one boot."),
]));
bodyChildren.push(body([
  b("Runtime lists are per-boot. "),
  r("Entries added through the supercall live in kernel memory and reset at reboot; persistence requires the post-boot apply scripts, which the module already ships. This is expected behavior and should not be read as data loss."),
]));
bodyChildren.push(body([
  b("Stage 4/5 classes stay retired. "),
  r("sus_path, lsm_hook, uname, kstat, hide_syms and sus_unix remain dark by design after the v45 stage-4 lethality (which froze the box with no supercall involved). Reviving them is a separate, later bisect and out of scope for v47 validation."),
]));
bodyChildren.push(body([
  b("Follow-up build items (v47.1, not required for the fix). "),
  r("First, post-fs-data should verify the CLI hash each boot and self-heal it exactly as it already self-heals the LKM image stamp, so a manager-side refresh can never silently re-dowse the channel. Second, the boot-completed self-test should fall back to the module's bundled CLI when the /data/adb/ksu/bin copy does not ride 173 (the evidence collector already uses that fallback pattern). Third, two cosmetic label fixes: the collector line sc_entry_count (v45+: real kprobe hits) should read wrapper entries, and the susfs_main.c comment describing the counter as kprobe-only is stale v45 wording. None of these block Phase A."),
]));

// ---------- 7. Conclusions ----------
bodyChildren.push(h1("7. Test Conclusions"));
bodyChildren.push(body([
  r("Stability: PASS. Ten of ten boots clean through the full staged climb, substeps 0-7 and stages 0-3, with complete receipts, full heartbeat windows, zero wedge markers and zero manual interventions. The v45/v46 failure mode (a second kprobe sharing KernelSU's reboot slot) is structurally absent from this build."),
]));
bodyChildren.push(body([
  r("Transport: PASS. The dispatcher cold-arm redirect armed on both transport rungs with read-back verification, one arm patched, zero kprobes registered, KernelSU's reboot slot untouched, and the box fully alive on both boots - the previously-lethal operation class is now demonstrably survivable."),
]));
bodyChildren.push(body([
  r("Channel end-to-end: FAIL, userspace-local, root cause identified and verified against the shipped artifacts - the CLI on the box rides the old syscall-169 convention while the transport listens on 173. Verdict: "),
  b("conditional pass"),
  r(", pending the Phase A receipt (CLI replaced, self-test answered, counter moving). The campaign goal state - a working ksu_susfs show version and drivable runtime-configurable lists - is expected within the three-reboot remaining budget, and nothing in this round's evidence implicates the v47 transport itself."),
]));

// ---------- Appendix A ----------
bodyChildren.push(h1("Appendix A: sc_probe - the v47 transport probe"));
bodyChildren.push(body([
  r("sc_probe is a freestanding static-PIE x86_64 binary (no libc, no bionic dependency - the same executable class as the campaign's own field tools) that speaks the v47 ABI directly: it issues "),
  m("syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload)"),
  r(" and prints the raw return value, payload.err, string answers, and the module's sc_entry_count before and after - the counter being the wrapper's own unconditional entry count. It never touches reboot(169). Delivered alongside this report as sc_probe (binary) and sc_probe.c (source; sha256 "),
  m(PROBE_SHA),
  r("). Usage on the box:"),
]));
[
  "adb push sc_probe /data/local/tmp/sc_probe",
  "adb shell su -c 'chmod 755 /data/local/tmp/sc_probe'",
  "adb shell su -c '/data/local/tmp/sc_probe'                     # self-test: version + variant + counter",
  "adb shell su -c '/data/local/tmp/sc_probe 0x555e1 <40 hex zeros>'   # one raw supercall",
].forEach((t, i, a) => bodyChildren.push(monoLine(t, { last: i === a.length - 1 })));
bodyChildren.push(body([
  r("The self-test mode alone is sufficient for Phase A: count moved plus err=0 plus a printed answer is the end-to-end proof; the interpretation matrix is Table 6. The 40 hex zeros are the 20-byte st_susfs_sus_version payload whose last four bytes carry the err field."),
]));
bodyChildren.push(tableTitle("Table 9: v47 supercall ABI quick reference"));
bodyChildren.push(tbl(["Field", "Value"], abiRows, [34, 66]));

// ---------- Appendix B ----------
bodyChildren.push(h1("Appendix B: Full Boot Ledger and Identities"));
bodyChildren.push(body([
  r("Full boot identifiers, times and ladder markers for the ten boots, as written by init_trace.txt (all times 2026-11-24, Asia/Jakarta). The marker column shows the previous boot's success receipt each boot consumed (ok <stage> <boot id>)."),
]));
bodyChildren.push(tableTitle("Table 10: Ten-boot ladder, full identifiers"));
bodyChildren.push(tbl(["#", "Boot id (full)", "Time", "Step", "Stage", "Marker consumed"], bootFull, [5, 39, 11, 9, 9, 27]));

// ---------------- document ----------------
const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimSun" }, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 32, bold: true, color: INK.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 28, bold: true, color: INK.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
    },
  },
  sections: [
    { // Section 1: cover - margin 0, no footer, no pageNumbers
      properties: { page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
      children: buildCoverR1(coverConfig),
    },
    { // Section 2: front matter (TOC) - no page-number footer per report scene
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin },
      },
      headers: { default: pageHeader() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 480, after: 360 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32,
            font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
        new Paragraph({
          spacing: { before: 200 },
          children: [new TextRun({
            text: "Note: this Table of Contents is generated via field codes. To refresh page numbers after editing, right-click the TOC and select Update Field.",
            italics: true, size: 18, color: "888888", font: { ascii: "Times New Roman" } })],
        }),
        // NOTE: no trailing PageBreak here - the body follows as a NEXT_PAGE
        // section, which already forces the page turn (double break = blank page).
      ],
    },
    { // Section 3: body - Arabic page numbers from 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin, pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: pageHeader() },
      footers: { default: pageFooter() },
      children: bodyChildren,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("/home/z/my-project/download/ReSuSFS-v47-Field-Validation-Report.docx", buf);
  console.log("WROTE ReSuSFS-v47-Field-Validation-Report.docx", buf.length, "bytes");
});
