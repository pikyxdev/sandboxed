#!/usr/bin/env python3
"""make_v54_source_export.py - complete v54 source export for download (derived from make_v53_source_export.py).

Builds download/ReSuSFS-x86_64-v53-SOURCE.zip: every source/build input of
v26.11.53 that is NOT re-downloadable from public sources. Same shape as
the v52 export (see make_v52_source_export.py); adds the v53 graft source,
the v53 build/verify/package chain, the v53 host test, the updated
sc_probe and the v53 flashable.
"""
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile

BASE = '/home/z/my-project'
STAGE = '/tmp/v54src'
TOP = f'{STAGE}/ReSuSFS-x86_64-v54-source'
OUT_SRC = f'{BASE}/download/ReSuSFS-x86_64-v54-SOURCE.zip'


def sh(cmd, **kw):
    print(f'[cmd] {cmd}')
    return subprocess.run(cmd, shell=True, check=True, **kw)


def copy_rel(src, dst_rel):
    dst = os.path.join(TOP, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_stats(path):
    n, total = 0, 0
    for root, _d, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            if os.path.islink(fp):
                continue
            n += 1
            total += os.path.getsize(fp)
    return n, total


print('== staging ==', flush=True)
shutil.rmtree(STAGE, ignore_errors=True)
os.makedirs(TOP)

P = f'{BASE}/ReSuSFS-x86_64-port'
S = f'{BASE}/scripts'
W = f'{BASE}/work'

# 1. LKM sources + graft sources + probe + host tests
copy_rel(f'{P}/susfs4ksu-lkm-x64-5.15', 'lkm-source/susfs4ksu-lkm-x64-5.15')
for f in ('sc_v50.c', 'sc_v51.c', 'sc_v53.c', 'sc_v54.c', 'sc_v50.o', 'sc_v51.o', 'sc_v53.o', 'sc_v54.o'):
    copy_rel(f'{P}/{f}', f'lkm-source/{f}')
for f in ('sc_probe.c', 'sc_probe', 'test_sc_v51_host.c', 'test_sc_v51_host',
          'test_sc_v53_host.c', 'test_sc_v54_host.c', 'test_v54_ladder.sh'):
    copy_rel(f'{S}/{f}', f'lkm-source/{f}')

# 2. userspace sources (ksu_susfs.c at BASE root is the broken GitLab 404
# page - the REAL wire truth is the stock CLI binary in the package; ship
# both the broken file (marked) and a README note)
copy_rel(f'{S}/libredir.c', 'userspace-src/libredir.c')
copy_rel(f'{S}/port_insmod_x64.py', 'userspace-src/port_insmod_x64.py')
copy_rel(f'{BASE}/testbuild', 'userspace-src/testbuild')
open(f'{TOP}/userspace-src/README.txt', 'w').write(
    'ksu_susfs.c is NOT shipped: the only copy in the sandbox is a broken\n'
    'GitLab 404 HTML page from session 1. The wire-ABI authority is the\n'
    'stock CLI BINARY at package-v53/bin/x86_64/ksu_susfs (sha256\n'
    '7a30fa745a523a4e2897023086a2ef08d773899394781d131f68676227e80e9f,\n'
    'not stripped - disassemble sc_main for the dispatch sites). The full\n'
    'v53 wire table is recorded in memory/FINDINGS.md and in sc_v53.c.\n')

# 3. module staging tree (carries the v53 .ko payload + the new sc_probe)
copy_rel(f'{P}/ReSuSFS', 'module-template/ReRuSFS'.replace('Ru','eS'))  # keep name

# 4. the EXACT v53 flashable staging tree
copy_rel(f'{W}/pkg54', 'package-v54')

# 5. build scripts (the whole lineage + the v53 chain)
for f in sorted(os.listdir(S)):
    fp = os.path.join(S, f)
    if os.path.isfile(fp):
        copy_rel(fp, f'build-scripts/{f}')
copy_rel(f'{P}/scripts', 'build-scripts/port-scripts')
copy_rel(f'{P}/bin', 'build-scripts/port-bin')

# 6. bit-exact build outputs (v49 base, v50, v51 graft, v53 graft)
os.makedirs(f'{TOP}/binaries', exist_ok=True)
for f in ('susfs_guard_lkm-x86_64-android13-5.15.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v51.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v53.ko',
          'susfs_guard_lkm-x86_64-android13-5.15-v54.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v50.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v51.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v53.ko',
          'susfs_guard_lkm-x86_64-vanilla-5.15-v54.ko'):
    copy_rel(f'{P}/{f}', f'binaries/{f}')

# 7. kernel tree fragments (tiny overrides; the tarballs are re-fetchable)
copy_rel(f'{BASE}/linux-5.15.178', 'kernel-fragments/linux-5.15.178')
copy_rel(f'{BASE}/a13', 'kernel-fragments/a13')
copy_rel(f'{BASE}/a13-full', 'kernel-fragments/a13-full')

# 8. upstream refs
copy_rel(f'{BASE}/ReSuSFS-x86_64', 'upstream-refs/ReSuSFS-x86_64')
copy_rel(f'{BASE}/susfs_lkm_x64.zip', 'upstream-refs/susfs_lkm_x64.zip')
copy_rel(f'{BASE}/susfs4ksu_LICENSE', 'upstream-refs/susfs4ksu_LICENSE')
for f in ('branches.json', 'kp.json', 'lkm_release.json', 'test.tab.c', 'tree.json'):
    fp = f'{BASE}/{f}'
    if os.path.isfile(fp):
        copy_rel(fp, f'upstream-refs/{f}')

# 9. docs
copy_rel(f'{P}/docs-DESIGN-v54.md', 'docs/DESIGN-v54.md')
copy_rel(f'{P}/README-x86_64-PORT.md', 'docs/README-x86_64-PORT.md')
copy_rel(f'{P}/ReSuSFS/PORTING_x86_64.md', 'docs/PORTING_x86_64.md')
copy_rel(f'{P}/ReSuSFS/CHANGELOG.md', 'docs/CHANGELOG.md')
copy_rel(f'{P}/ReSuSFS/update.json', 'docs/update.json')
os.makedirs(f'{TOP}/docs/test-plans', exist_ok=True)
for f in sorted(os.listdir(f'{P}/ReSuSFS/docs/test-plans')):
    copy_rel(f'{P}/ReSuSFS/docs/test-plans/{f}', f'docs/test-plans/{f}')
copy_rel(f'{BASE}/logs', 'docs/build-logs')

# 10. field evidence
copy_rel(f'{BASE}/field-logs', 'field-logs')

# 11. the flashable + key metadata
copy_rel(f'{BASE}/download/ReSuSFS-x86_64-v26.11.54.zip',
         'flashable/ReSuSFS-x86_64-v26.11.54.zip')

# ---------------------------------------------------------------- metadata
print('== metadata ==', flush=True)
sums = [
    ('flashable/ReSuSFS-x86_64-v26.11.54.zip', sha256(f'{BASE}/download/ReSuSFS-x86_64-v26.11.54.zip')),
    ('package-v54/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
     sha256(f'{W}/pkg54/lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')),
    ('binaries/susfs_guard_lkm-x86_64-android13-5.15-v54.ko (THE v54 graft)',
     sha256(f'{P}/susfs_guard_lkm-x86_64-android13-5.15-v54.ko')),
    ('lkm-source/sc_v54.c (THE v54 graft source)', sha256(f'{P}/sc_v54.c')),
    ('lkm-source/sc_v54.o', sha256(f'{P}/sc_v54.o')),
    ('lkm-source/sc_probe.c (v54 modes)', sha256(f'{S}/sc_probe.c')),
    ('package-v54/bin/x86_64/ksu_susfs (stock CLI, ABI authority)',
     sha256(f'{W}/pkg54/bin/x86_64/ksu_susfs')),
    ('package-v54/bin/x86_64/sc_probe (v54 probe)',
     sha256(f'{W}/pkg54/bin/x86_64/sc_probe')),
    ('package-v54/bin/x86_64/susfs_insmod', sha256(f'{W}/pkg54/bin/x86_64/susfs_insmod')),
]
open(f'{TOP}/SHA256SUMS.key', 'w').write(
    '\n'.join(f'{h}  {n}' for n, h in sums) + '\n')

rows = []
for d in ('lkm-source', 'userspace-src', 'module-template', 'package-v54',
          'build-scripts', 'binaries', 'kernel-fragments', 'upstream-refs',
          'docs', 'field-logs', 'flashable'):
    n, b = tree_stats(os.path.join(TOP, d))
    rows.append((d, n, b))

readme = f'''# MANIFEST - ReSuSFS x86_64 v26.11.54 source export

Exported: 2026-11-27 (Asia/Jakarta). Sandbox: /home/z/my-project
Flashable v54 SHA256: {sums[0][1]}
(the v53.1 flashable is in download/ from the previous session; the v54
build chain needs it as the layout/change-set input.)

Contents: the v53 lineage + THE ENFORCEMENT BRIDGE (sc_v54.c graft:
private 0x55f54 gd64_arm + 0x55f55 add_resolved; sys_call_table[217]/
getdents64 -> susfs_gd64_entry with the cloned kCFI preamble; (name, ino)
rule matching with USERSPACE-resolved inodes; app-uid gate >= 10000;
fail-open filter; the gd64_stage script ladder with per-boot try/ok markers
and honest demotion; sc_probe v54 modes gd64_arm/add_resolved/gd64_test/
readback; the v54 build/verify/package chain; the v54 host test + the
offline ladder test). See docs-DESIGN-v54.md in ReSuSFS-x86_64-port.

| directory | files | bytes | contents |
|-----------|-------|-------|----------|
''' + '\n'.join(f'| {d}/ | {n} | {b} | see README-BUILD-v53 notes in build-scripts headers |'
                 for d, n, b in rows) + '''

Rebuild v54 from this archive (after restoring the layout per
build-scripts/restore_sandbox_v52.sh mapping; sc_v54.* goes to
ReSuSFS-x86_64-port/; work/pkg54 needs the v53.1 flashable from download/):
    bash scripts/fetch_clang17.sh          # the 4 Debian debs (35 MB)
    bash scripts/build_v54_ko.sh           # graft sc_v54.c onto the FROZEN v49 base
    gcc -DSC_V51_HOSTTEST -O1 -fcf-protection=branch -o /tmp/t scripts/test_sc_v54_host.c && /tmp/t
    sh scripts/test_v54_ladder.sh          # the gd64 script ladder offline
    python3 scripts/build_v54_verify.py    # ALL V54 CHECKS PASSED
    python3 scripts/build_v54_zip.py       # layout-asserted vs the v53.1 zip

The v49 BASE .ko is bit-frozen (binaries/) and is never rebuilt; the
susfs4ksu-lkm-x64-5.15 tree in lkm-source/ is INCOMPLETE (14 kernel
sources - cleaned after v49; the base .ko is the only ground truth).
The big public inputs (kernel tarball, a13 mirror) are only needed for a
base rebuild, which nothing in the v54 chain does.
'''
open(f'{TOP}/MANIFEST.md', 'w').write(readme)

if os.path.exists(OUT_SRC):
    os.remove(OUT_SRC)
with zipfile.ZipFile(OUT_SRC, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(STAGE):
        for f in sorted(files):
            fp = os.path.join(root, f)
            z.write(fp, os.path.relpath(fp, STAGE))

n, b = tree_stats(TOP)
print(f'== export ready ==')
print(f'{OUT_SRC} ({os.path.getsize(OUT_SRC)} bytes, {n} files staged)')
print(f'sha256: {sha256(OUT_SRC)}')
for d, cn, cb in rows:
    print(f'  {d:16s} {cn:4d} files {cb:9d} bytes')
