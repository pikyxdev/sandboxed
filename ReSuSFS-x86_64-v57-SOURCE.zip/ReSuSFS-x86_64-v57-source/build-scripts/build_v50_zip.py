#!/usr/bin/env python3
"""Build ReSuSFS-x86_64-v26.11.50.zip from work/pkg50 (pkg49 tree + v50 edits).

- Reproduces the v49 zip layout EXACTLY (same entries - v50 adds no files).
- The two module .kos are the clang-17 grafts; everything else in the tree
  is pkg49's except module.prop / customize.sh / boot-completed.sh /
  README / payload stamp (the asserted change set).
- Verifies: entry list identical to v49, change set exactly as expected,
  the reference payload byte-identical, v50 markers present in the .kos
  and scripts, CLI still riding syscall 173.
"""
import zipfile, os, hashlib, re

SRC = '/home/z/my-project/work/pkg50'
V49 = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.49.zip'
OUT = '/home/z/my-project/download/ReSuSFS-x86_64-v26.11.50.zip'

v49_names = zipfile.ZipFile(V49).namelist()

file_paths = []
dir_paths = []
for root, dirs, files in os.walk(SRC):
    rel = os.path.relpath(root, SRC)
    for d in dirs:
        rd = os.path.normpath(os.path.join(rel, d)).replace(os.sep, '/')
        dir_paths.append(rd + '/')
    for f in files:
        rf = os.path.normpath(os.path.join(rel, f)).replace(os.sep, '/')
        file_paths.append(rf)

dir_set = set(dir_paths)
v49_dir_set = set(n for n in v49_names if n.endswith('/'))

missing_dirs = v49_dir_set - dir_set
extra_dirs = dir_set - v49_dir_set
missing_files = set(v49_names) - set(file_paths) - v49_dir_set
extra_files = set(file_paths) - set(v49_names)

print('dirs missing:', sorted(missing_dirs) or 'none')
print('dirs extra:  ', sorted(extra_dirs) or 'none')
print('files missing:', sorted(missing_files) or 'none')
print('files extra:  ', sorted(extra_files) or 'none')
assert not missing_dirs and not extra_dirs and not missing_files and not extra_files, 'layout mismatch vs v49'

file_set = set(file_paths)
ordered = [n for n in v49_names if n in dir_set or n in file_set]
assert len(ordered) == len(v49_names)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ordered:
        if name.endswith('/'):
            z.writestr(zipfile.ZipInfo(name + ''), b'')
        else:
            z.write(os.path.join(SRC, name), name)

# ---- verification ----
z49, z50 = zipfile.ZipFile(V49), zipfile.ZipFile(OUT)
n49, n50 = z49.namelist(), z50.namelist()
assert n50 == n49, 'entry list mismatch vs v49'

changed = []
for n in n50:
    if z49.read(n) != z50.read(n):
        changed.append(n)
print('changed vs v49:', sorted(changed))
assert set(changed) == {
    'README-DIAGNOSTIC.md', 'boot-completed.sh', 'customize.sh', 'module.prop',
    'lkm/x86_64/.payload_stamp',
    'lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko',
    'lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko',
}, f'unexpected change set: {sorted(changed)}'

mp = z50.read('module.prop').decode()
assert 'version=v26.11.50-x86_64' in mp and 'versionCode=128' in mp, 'module.prop version'
assert 'THE CLANG ENTRY' in mp, 'module.prop headline'
stamp = z50.read('lkm/x86_64/.payload_stamp').decode()
assert 'v26.11.50' in stamp, 'payload stamp'
bc = z50.read('boot-completed.sh').decode()
assert 'v50 CLANG ENTRY' in bc, 'self-test names the v50 transport'
assert '16-byte cloned preamble' in bc, 'self-test names the clone'
assert 'SC_DEFER_ADVANCE' in bc, 'deferred confirmation kept'
pfd = z50.read('post-fs-data.sh').decode()
assert 're-basing the stage ladder' in pfd, 'post-fs-data re-base receipt kept'

van = z50.read('lkm/x86_64/candidates/susfs_guard_lkm-x86_64-vanilla-5.15.ko')
a13 = z50.read('lkm/x86_64/susfs_guard_lkm-x86_64-android13-5.15.ko')
for label, ko in (('vanilla', van), ('android13', a13)):
    assert b'v50 clang transport init' in ko, f'{label}: v50 init receipt'
    assert b'v50 transport LIVE' in ko, f'{label}: v50 LIVE receipt'
    assert b'preamble window cloned + verified' in ko, f'{label}: clone receipt'
    assert b'refusing (loaded, not installed)' in ko, f'{label}: refusal receipts'
    # the clang graft's genuine preamble (endianness: 90*11 b8 d9 34 2b b0)
    assert b'\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\xb8\xd9\x34\x2b\xb0\xf3\x0f\x1e\xfa' in ko, \
        f'{label}: genuine clang preamble block before the entry'
    # compiled by clang: the .comment carries clang-17, not only GCC
    assert b'clang version 17' in ko, f'{label}: .comment names clang-17'
ym = z50.read('lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')
assert hashlib.sha256(ym).hexdigest() == hashlib.sha256(z49.read(
    'lkm/x86_64/candidates/ymuuu_android13-5.15_susfs_guard_lkm.ko')).hexdigest(), \
    'reference payload must stay byte-identical'

cli = z50.read('bin/x86_64/ksu_susfs')
sites = sum(1 for m in re.finditer(b'\xb8\xad\x00\x00\x00', cli)
            if cli.find(b'\x0f\x05', m.start(), m.start() + 80) >= 0)
assert sites == 9, f'CLI 173 sites: {sites}'
print('CLI 173-riding sites:', sites)
print('zip size:', os.path.getsize(OUT))
print('sha256:', hashlib.sha256(open(OUT, 'rb').read()).hexdigest())
print('V50 ZIP OK')
