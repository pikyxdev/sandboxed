#!/bin/bash
# fetch_clang17.sh - download the exact clang-17 debs (README-BUILD-V52 sec 4)
# and extract them into toolchain/clang17/ so that
# toolchain/clang17/usr/lib/llvm-17/bin/clang exists.
set -e
BASE=/home/z/my-project
TC=$BASE/toolchain/clang17
mkdir -p "$TC/debs" "$TC"
cd "$TC/debs"

POOL=http://deb.debian.org/debian/pool/main/l/llvm-toolchain-17
# same packages the campaign used (README-BUILD-V52 sec 4, 17.0.6-22+b2);
# the pool path carries no epoch prefix here
FILES=(
  "clang-17_17.0.6-22+b2_amd64.deb"
  "libclang-common-17-dev_17.0.6-22+b2_amd64.deb"
  "libclang-cpp17t64_17.0.6-22+b2_amd64.deb"
  "libllvm17t64_17.0.6-22+b2_amd64.deb"
)
for f in "${FILES[@]}"; do
  if [ ! -f "$f" ]; then
    echo "[*] fetching $f"
    curl -fsSL -o "$f" "$POOL/$f"
  fi
done

echo "[*] extracting"
for f in "${FILES[@]}"; do
  dpkg-deb -x "$f" "$TC/root"
done

# normalize: the build script expects $TC/usr/lib/llvm-17/bin/clang
if [ ! -d "$TC/usr" ]; then
  ln -s root/usr "$TC/usr"
fi
"$TC/usr/lib/llvm-17/bin/clang" --version | head -2
echo "[+] clang-17 ready at $TC/usr/lib/llvm-17/bin/clang"
