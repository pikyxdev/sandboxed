#!/usr/bin/env python3
"""build_v55_verify.py - fail the v54 build on any regression (derived from build_v53_verify.py).

v53 = v52 + THE FIRST FEATURE RUNG.  This verifier inherits every v52
invariant (base untouched, graft properties, kCFI preamble, layers wiring,
SHOW wire lock) and adds:

  V53 FEATURE-RUNG PROPERTIES:
    - the entry dispatches the FEATURE wire ids from the STOCK CLI's own
      dispatch sites (decoded from the shipped binary, not from module
      source - the v52 lesson: internal consistency is not ABI conformance):
        0x55550 add_sus_path               -> sc_v53_add_sus_path (260B shape)
        0x55553 add_sus_path_loop          -> sc_v53_add_sus_path
        0x55561 hide_sus_mnts_for_non_su_  -> sc_v53_hide_mnts (8B shape)
        0x55f53 private readback           -> sc_v53_answer_debug_list
    - the graft's storage rides in .data (paths table, counters, dump
      buffer) and the graft contributes ZERO .bss symbols; the merged .bss
      size is byte-identical to the base's
    - no graft code references susfs_sc_wrapper (v51 contract, v53 keeps it)
    - no base-module FUNCTION is called from the accept path: the only
      extern calls in the graft text are _copy_from_user/_copy_to_user
      (kernel text) - susfs_diag_logf may appear only in the INIT/EXIT
      (installer) functions
    - the imports set is EXACTLY the v49 base set (no new imports)

  CLI: nine syscall-173 sites, zero 169 sites (carried from v49-v52).
"""
import subprocess, sys, re

A13 = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15-v55.ko'
KORG = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15-v55.ko'
A13_BASE = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-android13-5.15.ko'
KORG_BASE = '/home/z/my-project/ReSuSFS-x86_64-port/susfs_guard_lkm-x86_64-vanilla-5.15.ko'
CLI = '/home/z/my-project/ReSuSFS-x86_64-port/ReSuSFS/module/bin/x86_64/ksu_susfs'

fails = []

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True)

def symbols(ko):
    syms = {}
    for line in sh(f"nm -S --defined-only {ko}").splitlines():
        p = line.split()
        if len(p) >= 4:
            try:
                syms.setdefault(p[3], []).append((int(p[0], 16), p[2], p[1]))
            except ValueError:
                pass
    return syms

def check(label, cond, msg):
    print(f"  [{'OK' if cond else 'FAIL'}] {label}: {msg}")
    if not cond:
        fails.append(f"{label}: {msg}")

STOMP_VARS = ['susfs_diag_printk', 'susfs_probe_arm', 'susfs_probe_val',
              'susfs_force_init_val', 'susfs_init_done',
              'susfs_init_maxstep', 'fail_layer', 'susfs_sc_entry_count']

GRAFT_SYMS = ['susfs_sc_entry', 'susfs_supercall_init', 'susfs_supercall_exit',
              'sc_v51_current_uid']

V53_STORAGE = ['sc_v53_paths', 'sc_v53_next_slot', 'sc_v53_add_calls',
               'sc_v53_dups_skipped', 'sc_v53_toggle_calls',
               'sc_v53_hide_mnts_on', 'sc_v53_dump']

for name, ko, base, want_tm in (('android13', A13, A13_BASE, 0x340),
                                ('vanilla', KORG, KORG_BASE, 0x300)):
    print(f"### {name}: {ko}")
    d = open(ko, 'rb').read()
    i = d.find(b'vermagic=')
    vm = d[i:i+80].split(b'\x00')[0].decode()
    check(name, vm.startswith('vermagic=5.15.178+ SMP preempt modversions'), f"vermagic {vm!r}")

    # this_module size unchanged
    size = None
    for line in sh(f"readelf -SW {ko}").splitlines():
        m = re.search(r'\.gnu\.linkonce\.this_module\s+PROGBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
        if m:
            size = int(m.group(1), 16)
    check(name, size == want_tm, f"this_module size 0x{size:x} (want 0x{want_tm:x})")

    # imports EXACTLY the base set + the two v54 filter imports
    imports = sorted(set(l.split()[1] for l in sh(f"nm -u {ko}").splitlines() if l.strip()))
    base_imports = sorted(set(l.split()[1] for l in sh(f"nm -u {base}").splitlines() if l.strip()))
    want_imports = sorted(set(base_imports) | {'__kmalloc', 'kfree'})
    check(name, imports == want_imports,
          f"imports = v49 base + {{__kmalloc,kfree}} ({len(imports)}; extra={set(imports)-set(want_imports)}, missing={set(want_imports)-set(imports)})")
    for needed in ('__kmalloc', 'kfree', '__x64_sys_getdents64'):
        pass  # kallsyms availability was verified against field-logs/kernel_kallsyms.txt in the design note

    # merged .bss size identical to base (zero graft .bss contribution)
    def bss_size(f):
        for line in sh(f"readelf -SW {f}").splitlines():
            m = re.match(r'\s*\[\s*\d+\]\s+\.bss\s+NOBITS\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)', line)
            if m:
                return int(m.group(1), 16)
        return None
    check(name, bss_size(ko) == bss_size(base),
          f"merged .bss size {bss_size(ko)} == base {bss_size(base)} (zero graft .bss)")

    syms = symbols(ko)

    # ---- the three overridden symbols: ONE strong def each, no weak dup ----
    for s in ('susfs_sc_entry', 'susfs_supercall_init', 'susfs_supercall_exit'):
        defs = syms.get(s, [])
        weak = [l for l in sh(f"nm {ko}").splitlines() if l.endswith(f' W {s}')]
        check(name, len(defs) == 1 and defs[0][1] == 'T',
              f"{s}: single strong T def at 0x{defs[0][0]:x}" if len(defs) == 1 else f"{s}: defs={defs}")
        check(name, not weak, f"{s}: no weak duplicate survives")

    # ---- the graft's text extent (its object is first in the merge) ----
    graft_addrs = []
    for s in GRAFT_SYMS + ['sc_v51_answer_str', 'sc_v51_answer_features',
                           'sc_v51_read_window', 'sc_v51_window_equal',
                           'sc_v53_add_sus_path', 'sc_v53_hide_mnts',
                           'sc_v53_answer_debug_list',
                           'susfs_gd64_entry', 'sc_v54_gd64_arm',
                           'sc_v54_add_resolved', 'sc_v54_match']:
        for a, t, sz in syms.get(s, []):
            graft_addrs.append((a, int(sz, 16) if sz else 0))
    check(name, len(graft_addrs) >= len(GRAFT_SYMS) + 3, f"graft symbols present ({len(graft_addrs)})")
    graft_end = max(a + s for a, s in graft_addrs)

    # ---- THE v51/v53 CONTRACT: no graft code references the v49 wrapper ----
    ent = sh(f"objdump -dr --disassemble=susfs_sc_entry {ko}")
    check(name, 'susfs_sc_wrapper' not in ent, "entry never references the v49 wrapper")
    wrapper_refs = []
    for s in GRAFT_SYMS + ['sc_v51_answer_str', 'sc_v51_answer_features',
                           'sc_v53_add_sus_path', 'sc_v53_hide_mnts',
                           'sc_v53_answer_debug_list',
                           'susfs_gd64_entry', 'sc_v54_gd64_arm',
                           'sc_v54_add_resolved', 'sc_v54_match']:
        dis = sh(f"objdump -dr --disassemble={s} {ko} 2>/dev/null")
        if 'susfs_sc_wrapper' in dis:
            wrapper_refs.append(s)
    check(name, not wrapper_refs, f"no graft function references susfs_sc_wrapper (offenders: {wrapper_refs})")

    # ---- v53: the accept path calls NO base-module function --------------
    # The ACCEPT PATH = susfs_sc_entry + the statics it reaches
    # (uid reader, SHOW builders, v53 handlers).  Its PLT32 relocs must be
    # _copy_from_user/_copy_to_user ONLY (kernel text).  The INSTALLER
    # (susfs_supercall_init/_exit, calibrate inlined there) is init
    # context - it MAY call base functions (susfs_diag_logf receipts,
    # kallsyms, patch_text), exactly like v51/v52.
    # readelf -rW prints one block PER relocation section; only the
    # '.rela.text' block belongs to the merged .text.
    bad_calls = []
    accept_ranges = []
    # THE HOT PATH (runs on every getdents64): only the kernel's own
    # uaccess pair + the allocation pair (all kernel text, all direct).
    for fn in ('susfs_sc_entry', 'sc_v51_current_uid', 'sc_v51_answer_str',
               'sc_v51_answer_features', 'sc_v53_add_sus_path',
               'sc_v53_hide_mnts', 'sc_v53_answer_debug_list',
               'susfs_gd64_entry', 'sc_v54_match'):
        for a, t, sz in syms.get(fn, []):
            accept_ranges.append((a, a + (int(sz, 16) if sz else 0x400)))
    # the ARM handler + add_resolved are one-shot control commands off the
    # supercall channel: uaccess + diag receipts allowed (installer class)
    arm_ranges = []
    for fn in ('sc_v54_gd64_arm', 'sc_v54_add_resolved'):
        for a, t, sz in syms.get(fn, []):
            arm_ranges.append((a, a + (int(sz, 16) if sz else 0x400)))
    cur_sec = None
    for line in sh(f'readelf -rW {ko}').splitlines():
        m = re.match(r"Relocation section '(\S+)' at offset", line)
        if m:
            cur_sec = m.group(1)
            continue
        if cur_sec != '.rela.text':
            continue
        m = re.match(r'([0-9a-f]{16})\s+[0-9a-f]+\s+R_X86_64_PLT32\s+[0-9a-f]+\s+(\S+)', line)
        if not m:
            continue
        addr, target = int(m.group(1), 16), m.group(2)
        if any(lo <= addr < hi for lo, hi in accept_ranges) and \
           target not in ('_copy_from_user', '_copy_to_user', '__kmalloc', 'kfree'):
            bad_calls.append((hex(addr), target))
        # the arm handler is a MINI-INSTALLER by design (resolve table,
        # clone preamble, patch entry): the same extern set the installer
        # uses, all direct calls, field-proven since v50.
        if any(lo <= addr < hi for lo, hi in arm_ranges) and \
           target not in ('_copy_from_user', '_copy_to_user', 'susfs_diag_logf',
                          'susfs_fp_syscall_table', 'ksu_kallsyms_lookup_name',
                          'ksu_patch_text'):
            bad_calls.append((hex(addr), target))
    check(name, not bad_calls,
          f"hot path calls only uaccess+alloc pairs; control handlers add diag_logf (violations: {bad_calls[:6]})")

    # ---- the entry: endbr64 + lock incl + observe -22 + magics + gates ----
    check(name, 'endbr64' in ent, "entry starts with endbr64")
    check(name, 'lock incl' in ent, "entry lock-increments the counter")
    check(name, re.search(r'mov\s+\$0xffffffffffffffea,%r?a?x', ent) is not None,
          "observe path returns -22 (-EINVAL)")
    check(name, re.search(r'\$0xdeadbeef', ent) is not None, "entry checks magic1 0xdeadbeef")
    check(name, 'susfs_sc_entry_count' in ent, "counter reloc present")
    check(name, re.search(r'%gs:0x0\(', ent) is not None, "entry reads current through %gs")
    check(name, re.search(r'cmp\s+\$0x1000', ent) is not None,
          "entry plausibility-gates the task/cred pointers ($0x1000)")
    check(name, 'susfs_current_task_gs_off' in ent, "entry uses the seeded gs offset")
    graft_relocs = []
    for m in re.finditer(r'^([0-9a-f]{16})\s+[0-9a-f]+\s+R_X86_64_PLT32\s+[0-9a-f]+\s+(\S+)',
                         sh(f'readelf -rW {ko}'), re.M):
        if int(m.group(1), 16) < graft_end:
            graft_relocs.append(m.group(2))
    check(name, '_copy_from_user' in graft_relocs,
          "graft text answers through _copy_from_user")
    check(name, '_copy_to_user' in graft_relocs,
          "graft text answers through _copy_to_user")
    check(name, 'susfs_diag_logf' in graft_relocs,
          "installer logs receipts through susfs_diag_logf (init context only)")

    # ---- v54: the gd64 entry + its own kCFI preamble block ----
    gd = sh(f"objdump -dr --disassemble=susfs_gd64_entry {ko}")
    check(name, 'endbr64' in gd, "gd64 entry starts with endbr64")
    check(name, 'lock incl' in gd, "gd64 entry lock-increments its counter")
    check(name, '__kmalloc' in gd, "gd64 entry stages through __kmalloc")
    check(name, 'kfree' in gd, "gd64 entry frees through kfree")
    check(name, 'call' in gd and 'ud2' not in gd,
          "gd64 entry carries NO ud2 (v54.1: the v54 checked forward ud2'd on boot e3580bfc; forwards now ride the unchecked sc_v54_fwd)")
    check(name, 'sc_v54_fwd' in gd,
          "gd64 entry forwards through the unchecked sc_v54_fwd trampoline")
    check(name, re.search(r'\$0xcc0', gd) is not None,
          "gd64 entry allocates with GFP_KERNEL 0xcc0")
    check(name, re.search(r'\$0x2710', gd) is not None,
          "gd64 entry gates on the app uid range (0x2710 = 10000)")
    arm = sh(f"objdump -dr --disassemble=sc_v54_gd64_arm {ko}")
    check(name, re.search(r'\$0xd9', arm) is not None,
          "arm patches table[217] (0xd9 immediate)")
    check(name, 'ksu_patch_text' in arm, "arm clones/patches through ksu_patch_text")
    for id_ in ('55f54', '55f55'):
        check(name, re.search(rf'cmp.*\$0x{id_}', ent) is not None,
              f"entry dispatches private id 0x{id_}")
    gd_addr = syms['susfs_gd64_entry'][0][0]
    gd_cfi = syms.get('__cfi_susfs_gd64_entry', [])
    check(name, len(gd_cfi) == 1 and gd_cfi[0][0] == gd_addr - 16 and int(gd_cfi[0][2], 16) == 16,
          f"__cfi_susfs_gd64_entry: 16-byte preamble block at entry-16 (0x{gd_cfi[0][0]:x})" if gd_cfi else "__cfi gd64 block missing")
    check(name, gd_addr % 16 == 0, f"gd64 entry 16-byte aligned (0x{gd_addr:x})")
    # v54 storage all in .data
    d_syms = {l.split()[-1] for l in sh(f"nm -S --defined-only {ko}").splitlines()
              if len(l.split()) >= 4 and l.split()[2] in ('D', 'd')}
    for s in ('sc_v54_res', 'sc_v54_next_slot', 'sc_v54_res_adds',
              'sc_v54_res_dups', 'sc_v54_gd64_calls', 'sc_v54_gd64_filtered',
              'sc_v54_gd64_hidden', 'sc_v54_gd64_installed',
              'sc_v54_gd64_orig'):
        check(name, s in d_syms, f"v54 storage {s} in .data")

    # ---- genuine clang kCFI preamble in the 16-byte window ----
    ent_addr = syms['susfs_sc_entry'][0][0]
    cfi = syms.get('__cfi_susfs_sc_entry', [])
    check(name, len(cfi) == 1 and cfi[0][0] == ent_addr - 16 and int(cfi[0][2], 16) == 16,
          f"__cfi_susfs_sc_entry: 16-byte preamble block at entry-16 (0x{cfi[0][0]:x})" if cfi else "__cfi block missing")
    check(name, ent_addr % 16 == 0, f"entry 16-byte aligned (0x{ent_addr:x})")
    win = sh(f"objdump -s -j .text --start-address={ent_addr-16} --stop-address={ent_addr} {ko}")
    wbytes = None
    for l in win.splitlines():
        parts = l.split()
        if parts and parts[0].lower() == 'contents':
            continue
        try:
            if parts and int(parts[0], 16) == ent_addr - 16:
                wbytes = bytes.fromhex(''.join(parts[1:5]))[:16]
                break
        except ValueError:
            continue
    if wbytes is None:
        check(name, False, "preamble window bytes readable")
    else:
        check(name, wbytes[11] == 0xb8, f"movl opcode 0xb8 at [entry-5] (got 0x{wbytes[11]:02x})")
        typeid = int.from_bytes(wbytes[12:16], 'little')
        check(name, typeid == 0xb02b34d9,
              f"genuine clang typeid at [entry-4]: 0x{typeid:08x} (clang-17 for 'long (const struct pt_regs *)')")
        check(name, all(b == 0x90 for b in wbytes[0:11]), "nop padding fills [entry-16..-6)")

    # ---- the installer: relocs prove the calibration + clone + write ----
    init_rel = sh(f"objdump -dr --disassemble=susfs_supercall_init {ko}")
    relocs = []
    for l in init_rel.splitlines():
        if 'R_X86_64' not in l:
            continue
        m = re.search(r'R_X86_64_\w+\s+([^\s+-]+)', l)
        if m:
            relocs.append(m.group(1))
    check(name, 'susfs_sc_entry' in relocs, "init takes &susfs_sc_entry")
    n_patch = sum(1 for l in init_rel.splitlines() if re.search(r'R_X86_64_PLT32\s+ksu_patch_text', l))
    check(name, n_patch == 2, f"init calls ksu_patch_text twice (clone 16B + table 8B): {n_patch}")
    check(name, 'ksu_kallsyms_lookup_name' in relocs, "init resolves symbols")
    check(name, 'susfs_fp_syscall_table' in relocs, "init uses the fp-layer table cache")
    check(name, 'susfs_current_arm_stage' in relocs, "init reads the ladder rung")
    check(name, 'susfs_diag_logf' in relocs, "init writes receipts")
    check(name, 'sc_orig' in relocs or 'sc_installed' in relocs, "init wires the v49 state")
    n_look = len(re.findall(r'R_X86_64_PLT32\s+ksu_kallsyms_lookup_name', init_rel))
    check(name, n_look >= 4, f"init/calibrate kallsyms lookups: {n_look} (want >= 4: table+dispatcher+handler+init_task+init_cred)")
    for s in (b'init_task', b'init_cred'):
        check(name, s in d, f"calibration target string present: {s.decode()}")

    # ---- v53 storage: .data only, exact symbols ----
    v53_bss = [v for v in V53_STORAGE if any(t in ('b', 'B') for _, t, _ in syms.get(v, []))]
    check(name, not v53_bss, f"v53 storage not in .bss (violators: {v53_bss})")
    for v in V53_STORAGE:
        check(name, v in syms and any(t in ('d', 'D') for _, t, _ in syms[v]),
              f"{v} rides in .data (out of the spill window)")
    # the table's geometry: sc_v53_paths must be 32*258 bytes
    pa, pt, psz = syms['sc_v53_paths'][0]
    check(name, int(psz, 16) == 32 * 258, f"sc_v53_paths is 32x258 bytes (got {psz})")
    da, dt, dsz = syms['sc_v53_dump'][0]
    check(name, int(dsz, 16) == 8196, f"sc_v53_dump is 8196 bytes (got {dsz})")

    # ---- the layers[] wiring binds to the GRAFT addresses ----
    rel_all = sh(f"readelf -rW {ko}")
    graft_init = syms['susfs_supercall_init'][0][0]
    graft_exit = syms['susfs_supercall_exit'][0][0]
    m_init = re.search(r'R_X86_64_64\s+([0-9a-f]+) susfs_supercall_init \+ 0', rel_all)
    m_exit = re.search(r'R_X86_64_64\s+([0-9a-f]+) susfs_supercall_exit \+ 0', rel_all)
    check(name, m_init is not None and int(m_init.group(1), 16) == graft_init,
          "susfs_layers[].init binds to the graft init" if m_init else "layers[] init reloc missing")
    check(name, m_exit is not None and int(m_exit.group(1), 16) == graft_exit,
          "susfs_layers[].exit binds to the graft exit" if m_exit else "layers[] exit reloc missing")

    # ---- the v49 wrapper still present as dead code, and sc_call_orig ----
    check(name, 'susfs_sc_wrapper' in syms, "v49 wrapper body present (dead)")
    check(name, 'sc_call_orig' in syms, "v49 orig-forwarder present (dead)")

    # ---- globalized state vars: global B, same .bss layout as base ----
    base_syms = symbols(base)
    for v in ('sc_orig', 'sc_installed', 'sc_full_mode', 'susfs_sc_entry_count',
              'susfs_armed_features'):
        check(name, v in syms and syms[v][0][1] == 'B', f"{v} globalized (B)")
        check(name, v in base_syms and syms[v][0][0] == base_syms[v][0][0],
              f"{v} at the same .bss offset as base (0x{syms[v][0][0]:x})")

    # ---- v53 receipt strings ----
    for s in (b'v53 clang accept-path init', b'v53 calibrate', b'v53 transport LIVE',
              b'v53 feature rung', b'readback cmd 0x55f53',
              b'preamble window cloned + verified', b'preamble clone write FAILED',
              b'v53: preamble window', b'refusing (loaded, not installed)',
              b'uid gate stays uncalibrated'):
        check(name, s in d, f"diag receipt present: {s.decode()[:44]}")

    # ---- the ABI answer strings ----
    check(name, b'v2.3.0\x00' in d, "SUSFS_VERSION_STR 'v2.3.0' embedded")
    check(name, b'GKI-LKM\x00' in d, "SUSFS_VARIANT_STR 'GKI-LKM' embedded")
    check(name, b'SUSFS_LKM_MODULES' in d and b'CONFIG_KSU_SUSFS_SUS_MAP' in d,
          "feature names embedded")
    # readback dump receipts: clang -O2 constant-folds the first dump
    # literals into movabs immediates, so the marker exists as 8-byte
    # fragments in .text plus the non-constant-offset strings in .rodata
    check(name, b'v53-feat' in d and b'ure-rung' in d,
          "readback dump marker present (as movabs fragments)")
    check(name, b'slots_used=' in d and b' hide_mnts=' in d and b' truncated=' in d,
          "readback dump fields present")

    # ---- THE WIRE-DISPATCH LOCK, v52 (SHOW) -------------------------------
    entry_asm = sh(f"objdump -d --no-show-raw-insn --disassemble=susfs_sc_entry {ko}")
    ilist = []
    for l in entry_asm.splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+(.+?)\s*$', l)
        if m:
            ilist.append((int(m.group(1), 16), m.group(2)))
    def builder_for(cmd):
        """All builders reachable on the EQUALITY path of any `cmp $cmd,%eax`.

        clang -O2 emits a range-check preamble (cmp/jle, cmp/jg) BEFORE the
        equality dispatch - those cmp sites are skipped (their branch is
        not je/jne).  For each equality site, the eq-path is the je target
        (or the fall-through after jne); we collect builder symbol refs
        from the branch operand and the target block, stopping at the first
        unconditional jmp/ret (end of the basic block) so neighboring
        dispatch arms cannot leak in.  Returns the set of builders found
        (a correct dispatch yields exactly {expected})."""
        found = set()
        for i, (a, ins) in enumerate(ilist):
            if not re.match(rf'cmp\s+\$0x{cmd:x},%eax', ins):
                continue
            if i + 1 >= len(ilist):
                continue
            nxt = ilist[i + 1][1]
            # direct builder reference on the branch itself
            for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+)>', nxt):
                found.add(mb.group(1))
            mj = re.match(r'je\s+([0-9a-f]+)', nxt)
            if mj:                          # eq-path = branch target
                tgt = int(mj.group(1), 16)
                seq = [x[1] for x in ilist if tgt <= x[0] < tgt + 48]
            else:
                mn = re.match(r'jne\s+([0-9a-f]+)', nxt)
                if mn:                      # eq-path = fall-through
                    seq = [x[1] for x in ilist[i + 2:i + 8]]
                else:
                    continue                # range check (jle/jg/...) - skip
            for s in seq:
                for mb in re.finditer(r'<(sc_v51_answer_\w+|sc_v53_\w+)>', s):
                    found.add(mb.group(1))
                if re.match(r'(jmp|ret)', s):
                    break                   # end of the eq basic block
        return found
    check(name, builder_for(0x555e1) == {'sc_v51_answer_str'},
          f"wire lock: 0x555e1 -> answer_str (CLI: show version) [got {builder_for(0x555e1)}]")
    check(name, builder_for(0x555e2) == {'sc_v51_answer_features'},
          f"wire lock: 0x555e2 -> answer_features (CLI: show enabled_features) [got {builder_for(0x555e2)}]")
    check(name, builder_for(0x555e3) == {'sc_v51_answer_str'},
          f"wire lock: 0x555e3 -> answer_str (CLI: show variant) [got {builder_for(0x555e3)}]")

    # ---- THE WIRE-DISPATCH LOCK, v53 (FEATURE RUNG) -----------------------
    # ABI truth = the stock CLI's own dispatch (decoded from the shipped
    # binary, each site tied to its payload shape and fail string):
    #   0x55550 add_sus_path                260B  (path[256], err@256)
    #   0x55553 add_sus_path_loop           260B  (same shape)
    #   0x55561 hide_sus_mnts_for_non_su_procs 8B (on/off byte, err@4)
    #   0x55f53 private readback (NOT a CLI id; sc_probe's raw view)
    check(name, builder_for(0x55550) == {'sc_v53_add_sus_path'},
          f"wire lock: 0x55550 -> add_sus_path (CLI: add_sus_path, 260B) [got {builder_for(0x55550)}]")
    check(name, builder_for(0x55553) == {'sc_v53_add_sus_path'},
          f"wire lock: 0x55553 -> add_sus_path (CLI: add_sus_path_loop, 260B) [got {builder_for(0x55553)}]")
    check(name, builder_for(0x55561) == {'sc_v53_hide_mnts'},
          f"wire lock: 0x55561 -> hide_mnts (CLI: hide_sus_mnts_for_non_su_procs, 8B) [got {builder_for(0x55561)}]")
    check(name, builder_for(0x55f53) == {'sc_v53_answer_debug_list'},
          f"wire lock: 0x55f53 -> answer_debug_list (private readback, 8196B) [got {builder_for(0x55f53)}]")

    # set_uname / set_cmdline stay NOT-handled this rung (one rung at a
    # time): their CLI ids must NOT be dispatched to any builder
    for cid, lbl in ((0x55590, 'set_uname'), (0x555b0, 'set_cmdline_or_bootconfig')):
        check(name, not builder_for(cid),
              f"wire lock: 0x{cid:x} ({lbl}) stays not-handled this rung [got {builder_for(cid)}]")

    # ---- inherited v49 strings still present (dead code keeps them) ----
    for s in (b'transport LIVE', b'OBSERVE-ONLY', b'__x64_sys_ioperm'):
        check(name, s in d, f"inherited string present: {s.decode()}")

    # ---- .bss stomp pad + spill window (inherited) ----
    bss_idx = None
    for line in sh(f"readelf -SW {ko}").splitlines():
        m = re.match(r'\s*\[\s*(\d+)\]\s+\.bss\s+NOBITS', line)
        if m:
            bss_idx = int(m.group(1))
    off_map = {}
    for line in sh(f"readelf -sW {ko}").splitlines():
        m = re.match(r'\s*\d+:\s+([0-9a-f]+)\s+(\d+)\s+\w+\s+\w+\s+\w+\s+(\d+)\s+(\S.*)$', line)
        if m and int(m.group(3)) == bss_idx:
            off_map[m.group(4).strip()] = int(m.group(1), 16)
    check(name, off_map.get('susfs_bss_stomp_pad') == 0, "stomp pad at .bss+0")
    bad = [v for v in STOMP_VARS if v in off_map and off_map[v] < 0x40]
    check(name, not bad, f"spill-window vars past +0x40 (violators: {bad})")
    for v in STOMP_VARS:
        check(name, v in off_map, f"{v} present in .bss map")

    # ---- the merged module is still a loadable relocatable: section sanity ----
    for sec in ('.text', '.rela.text', '.rodata', '.data', '.bss', '__versions',
                '__param', '.modinfo'):
        check(name, f'{sec}' in sh(f'readelf -SW {ko}'), f"section present: {sec}")

# ---- CLI carried over from the v49-v52 payload ----

print("### v54.1 HOTFIX: the UNCHECKED FORWARD (v54 field root cause)")
GRAFT_OBJ = '/home/z/my-project/ReSuSFS-x86_64-port/sc_v55.o'
gdis = sh(f"objdump -d {GRAFT_OBJ}")
# 1. the whole graft must contain ZERO ud2 sites: the v54 killer was the
#    kCFI check (add -0x4(%rXX),%r10d; je; ud2) at the orig-forward call
#    sites reading the saved handler's preamble-less window.
n_ud2 = len(re.findall(r'\bud2\b', gdis))
check("v54.1-zero-ud2", n_ud2 == 0,
      f"ud2 sites in the graft object: {n_ud2} (v54 shipped with 3 = the checked forwards that killed boot e3580bfc)")
# 2. the helper exists and is an UNCHECKED trampoline: endbr64, arg shuffle,
#    tail-jmp to the saved handler - and NO hash check before the jump.
fwd = sh(f"objdump -d --disassemble=sc_v54_fwd {GRAFT_OBJ}")
check("v54.1-helper-present", 'sc_v54_fwd' in fwd, "sc_v54_fwd disassembles")
check("v54.1-helper-unchecked", ('jmp    *%rax' in fwd or 'call   *%rax' in fwd)
      and 'ud2' not in fwd and '-0x4(' not in fwd,
      "helper tail-jumps to the handler with no kCFI hash check")
# 3. the entry itself must contain NO indirect call/jmp: every forward is a
#    direct call to the helper; any remaining indirect site is a new hazard.
ent = sh(f"objdump -d --disassemble=susfs_gd64_entry {GRAFT_OBJ}")
n_ind = len(re.findall(r'(call|jmp)\s+\*', ent))
check("v54.1-entry-no-indirect", n_ind == 0,
      f"indirect call/jmp sites inside susfs_gd64_entry: {n_ind} (all forwards must ride sc_v54_fwd)")
# 4. the entry still calls the helper on all three paths.
n_fwd_calls = len(re.findall(r'(call|jmp).*<sc_v54_fwd>', ent))
check("v54.1-entry-fwd-calls", n_fwd_calls >= 2,
      f"calls/tail-jmps to sc_v54_fwd in the entry: {n_fwd_calls} "
      f"(clang merges the two identical return-tail-paths into one jmp; "
      f"the load-bearing invariants are zero-ud2 + zero-indirect)")

print(f"### CLI: {CLI}")
cd = open(CLI, 'rb').read()
new_sites = 0
old_sites = 0
for m in re.finditer(b'\xb8\xad\x00\x00\x00', cd):
    s = m.start()
    sc = cd.find(b'\x0f\x05', s, s + 80)
    if sc < 0:
        continue
    if cd[sc+2:sc+5] == b'\x48\x85\xc0':
        new_sites += 1
for m in re.finditer(b'\xb8\xa9\x00\x00\x00', cd):
    s = m.start()
    if cd.find(b'\x0f\x05', s, s + 80) >= 0:
        old_sites += 1
check('cli', new_sites == 9, f"nine syscall-173 sites ({new_sites})")
check('cli', old_sites == 0, f"zero old 169 sites ({old_sites})")

print()
if fails:
    print("FAILURES:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("ALL V55 CHECKS PASSED")
