#!/bin/bash
# build_v44_stage.sh - prepare one kernel tree and build the LKM from it.
# Usage: build_v44_stage.sh <tree-root> <label> <output-ko-name> [jobs]
# Stage-split so each step fits a 10-minute foreground tool call (background
# jobs get reaped between calls in this sandbox).
set -e
BASE=/home/z/my-project
TREE=$1 LABEL=$2 NAME=$3 JOBS=${4:-2}
LKM=$BASE/ReSuSFS-x86_64-port/susfs4ksu-lkm-x64-5.15/kernel
OUT=$BASE/ReSuSFS-x86_64-port

CURH="$TREE/arch/x86/include/asm/current.h"
if ! grep -q susfs_current_task_gs_off "$CURH" 2>/dev/null; then
        cp "$BASE/scripts/current.h.override" "$CURH"
fi

cd "$TREE"
. "$BASE/tools/env.sh"

if [ ! -f .config ]; then
        make defconfig >/dev/null
fi
./scripts/config --set-str LOCALVERSION "+" --enable MODVERSIONS \
        --enable PREEMPT --enable SMP \
        --disable MODULE_UNLOAD --disable X86_5LEVEL \
        --disable RANDOMIZE_BASE --disable HARDENED_USERCOPY \
        --disable RETPOLINE --disable RETHUNK
make olddefconfig >/dev/null
make LOCALVERSION= -j"$JOBS" modules_prepare >/dev/null
echo "[+] $LABEL tree ready (this_module will be $(grep -q ANDROID_KABI_RESERVE "$TREE/include/linux/module.h" && echo 0x340 || echo 0x300))"

make M="$LKM" clean >/dev/null 2>&1 || true
make LOCALVERSION= -j"$JOBS" M="$LKM" CC=gcc modules 2>&1 | tail -4
cp -f "$LKM/susfs_guard_lkm.ko" "$OUT/$NAME"
echo "[+] built: $OUT/$NAME ($(stat -c%s "$OUT/$NAME") bytes)"
