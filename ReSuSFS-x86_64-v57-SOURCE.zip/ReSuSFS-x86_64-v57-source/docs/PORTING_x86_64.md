# ReSuSFS x86_64 port notes

This tree is a complete x86_64 port of ReSuSFS (upstream:
<https://github.com/ahmed-alnassif/ReSuSFS>, base commit
`f73934cb759e2a1d6ef52873f1155a518169defe`, "webui: update Arabic
translations", v26.10.23 / versionCode 22). Upstream already declares
`arm64-v8a + x86_64` in `module.yaml`, but in practice installation aborted
on x86_64. This port closes that gap. Arm64 behavior is preserved
byte-for-byte; x86_64 paths are additive.

## Why upstream could not install on x86_64

ReSuSFS is a KernelSU module: shell scripts + WebUI + config text files.
Everything except two functions in `module/utils.sh` is architecture-neutral
(the WebUI, `ReSuSFS.sh`, all built-in scripts, all configs). The two
blockers were:

1. `update_susfs()` — installed the `ksu_susfs` userspace CLI by
   downloading an **arm64-only prebuilt** from
   `simonpunk/susfs4ksu`/`gki-android14-6.1`, and hard-failed
   (`"Only arm64 is supported!"`) on any other ABI. Both `customize.sh`
   (`update_susfs || exit 1`) and `action.sh` treat that as fatal, so
   installation died on x86_64.
2. The SuSFS LKM path — upstream downloads one `.ko` per KMI plus a
   `susfs_insmod` loader from `inforcqb/susfs4ksu-lkm`, which publishes
   **arm64 GKI** builds only.

## How the `ksu_susfs` CLI was ported

`ksu_susfs` is pure, arch-neutral C. It talks to the in-kernel susfs
through a magic `reboot()` syscall hijack:

```c
syscall(SYS_reboot, KSU_INSTALL_MAGIC1 /*0xDEADBEEF*/, SUSFS_MAGIC /*0xFAFAFAFA*/, CMD /*0x55550...*/, &info);
```

* `SYS_reboot` is resolved by libc headers per-arch (142 on arm64, 169 on
  x86_64); the kernel-side hook is part of susfs itself, which x86_64
  kernels with `CONFIG_KSU_SUSFS=y` implement — and so does the x86_64
  susfs LKM (its `sys_reboot` pre-handler hook).
* Every struct shared with the kernel uses `char[N]` / `int` / `bool` /
  `long long` / `unsigned long` members. arm64 and x86_64 are both LP64
  with the same alignment rules, so the byte layouts match exactly.
* The only bionic-isms (`st_atimensec`/`st_atime_nsec` struct-stat member
  names, `<android/log.h>`) exist for both ABIs in the NDK, so the upstream
  source compiles for x86_64 **unmodified**.

Upstream ships source in `ksu_susfs/jni/**` of the susfs4ksu repo but
publishes only an arm64 binary. This port vendors that source verbatim
into `tools/ksu_susfs/` (GPL-3.0, license-compatible with ReSuSFS) and
builds it for x86_64 with the Android NDK:

```sh
cd tools/ksu_susfs
NDK_ROOT=/path/to/android-ndk ./build.sh     # -> module/bin/x86_64/ksu_susfs
```

The resulting binary (bionic PIE, NDK r28c) is shipped inside the module
zip, so **x86_64 installs need no network download at all**.

Verification done in this port (see the repo's port log): the same source
was additionally built as a static host binary with two one-line compat
shims (`st_atimensec`→`st_atim.tv_nsec`, stub `android/log.h`) and
exercised with 28 functional tests on a stock x86_64 Linux kernel —
argument validation, realpath failure paths, exit codes, and the full
"kernel op not supported" degradation path all behave exactly like the
arm64 tool does on a kernel without susfs.

## Changes file by file

| File | Change |
|---|---|
| `module/utils.sh` | `get_device_abi()` added (getprop first, `uname -m` fallback — getprop stays authoritative because arm-translation layers make `uname -m` lie). `update_susfs()` is now arch-aware: arm64-v8a keeps the exact upstream download flow; x86_64 installs the bundled `module/bin/x86_64/ksu_susfs`; other ABIs fail with a clear message. `get_susfs_guard_lkm()` returns the x64-fork `.ko` name (`<kmi>_susfs_guard_lkm.ko`) on x86_64. New `download_susfs_guard_lkm_x64()` downloads the `susfs_lkm_x64.zip` release, extracts the matching `.ko` (busybox unzip, toybox/system unzip fallback), stores it under `/data/adb/ReSuSFS_LKM/`. `load_susfs_lkm()` gains an x86_64 path: skips when `/proc/susfs_path` says susfs is already live, loads through `ksud` (PATH, `/data/adb/ksu/bin/ksud`, then `/data/adb/ksud`) — there is no x86_64 `susfs_insmod`, which stays an arm64-only fallback. |
| `module/ReSuSFS.sh` | New `--force-update` flag: reinstalls the `ksu_susfs` binary and refreshes status. The WebUI's existing "force update" FAB always called this flag; upstream `ReSuSFS.sh` never implemented it, so the button printed the help text. Additive fix, wired to `update_susfs` from `utils.sh`. Help text updated. |
| `module/uninstall.sh` | Only removes `ksu_susfs` when it is a regular file. On x86_64 the susfs LKM module publishes `/data/adb/ksu/bin/ksu_susfs` as a symlink to its own CLI at every boot; that symlink belongs to the LKM module and is left alone. |
| `module/bin/x86_64/ksu_susfs` | New: the NDK-built x86_64 CLI (arm64 keeps the upstream download; nothing is bundled for arm64). |
| `tools/ksu_susfs/**` | New: vendored upstream CLI source (verbatim, GPL-3.0, see `NOTICE.md`), x86_64 `Application.mk`, `build.sh`. |
| `README.md` | x86_64 requirements/behavior section, x64 LKM provenance note, `--force-update` CLI row. |
| `docs/PORTING_x86_64.md` | This file. |
| `.gitattributes` | `module/bin/**` marked binary so git never mangles the shipped ELF. |
| `.gitignore` | Ignore `tools/ksu_susfs/libs` and `tools/ksu_susfs/obj` build outputs. |

Unchanged on purpose: `customize.sh`, `post-fs-data.sh`, `service.sh`,
`boot-completed.sh`, `late-load.sh`, `action.sh`, `sepolicy.rule`,
`META-INF/**`, all `configs/**` and built-in scripts, the entire WebUI,
`module.yaml` (already declared x86_64), `module.prop`, `update.json`,
`local-build.sh`, CI workflows. Every one of them is architecture-neutral
by inspection (no `uname -m`/ABI/`ro.product.cpu.abi` references anywhere
except the two `utils.sh` functions above).

## Runtime behavior matrix

| Setup | arm64-v8a | x86_64 |
|---|---|---|
| Kernel with built-in `CONFIG_KSU_SUSFS` | upstream: download ksu_susfs from GitLab | install bundled binary from the module |
| GKI kernel without built-in susfs | upstream: download `.ko` + `susfs_insmod` from inforcqb, load via ksud/susfs_insmod | download `susfs_lkm_x64.zip` from ymuuu, extract matching `.ko`, load via ksud |
| Custom kernel, unknown KMI | clear "no matching LKM found" message | same, x86_64-specific message |
| susfs LKM module also installed | unchanged | its `ksu_susfs` symlink at `/data/adb/ksu/bin` is detected and preserved; loader skips when `/proc/susfs_path` shows susfs already active |
| WebUI / CLI / configs | unchanged | identical (arch-neutral) |

## Rebuilding from source

```sh
# 1. build the x86_64 CLI into module/bin/x86_64/
cd tools/ksu_susfs && NDK_ROOT=$NDK ./build.sh && cd ../..

# 2. build the WebUI into module/webroot/
cd webui && pnpm install --frozen-lockfile && pnpm build && cd ..

# 3. package the flashable module zip
./local-build.sh    # -> build/ReSuSFS_<versionCode>.zip
```

`local-build.sh`, the CI release workflow, `module.yaml` and `update.json`
were already arch-neutral and untouched.

## External dependencies introduced

| What | Source | License | Why |
|---|---|---|---|
| ksu_susfs source (vendored) | gitlab.com/simonpunk/susfs4ksu @ `gki-android14-6.1`, `ksu_susfs/jni/**` | GPL-3.0 | the CLI ReSuSFS needs on x86_64; upstream publishes no x86_64 build |
| x86_64 LKM `.ko` (runtime download, not vendored) | github.com/ymuuuu/susfs4ksu-lkm-x64 `latest` release (`susfs_lkm_x64.zip`) | GPL-2.0-only (their loader) | arm64 equivalents come from inforcqb; the x64 fork is the x86_64 counterpart |

The x64 LKM release layout (`susfs_lkm_x64.zip` containing
`<kmi>_susfs_guard_lkm.ko` for the eight GKI KMIs) was verified against
release v0.1.0. If that project changes its asset layout,
`download_susfs_guard_lkm_x64()` is the single function to adjust.

## v26.11.23 addendum — LKM loading policy (LDPlayer 14 freeze fix)

v26.11.22 force-loaded the bundled `susfs_guard_lkm-x86_64-5.15.ko` (a
runtime kernel-hooking module compiled against a generic 5.15 config, not
the running custom kernel's build) and froze LDPlayer 14 ~10s after boot,
once `boot-completed.sh` pushed the susfs rules in. Policy since v26.11.23:

- `susfs_kernel_alive()` (utils.sh) — functional probe: the bundled CLI's
  exit code for `show version` is definitive (0 only when the kernel
  answers the `reboot(0xDEADBEEF, ...)` supercall; EINVAL is instant and
  harmless on kernels without susfs). This also detects built-in susfs on
  kernels without `/proc/config.gz`.
- `load_susfs_lkm()` refuses `susfs_guard_lkm-x86_64-*.ko` (the
  custom/non-GKI kernel case) unless `/data/adb/ReSuSFS/enable_lkm`
  exists, logging the decision to boot.log. GKI/KMI kernels keep the
  automatic load. Loading is also receipt-gated from `post-fs-data.sh`.
- `ReSuSFS.sh` stage-early/stage-late skip all susfs application in
  userspace-only mode (no kernel susfs reachable), and `status_report`
  dedupes its module.prop rewrite.
- A custom `.ko` compiled against the EXACT running kernel goes to
  `/data/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-<series>.ko` (it wins over
  the bundled one) plus the `enable_lkm` flag.

