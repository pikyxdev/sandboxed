# v26.11.54 — THE ENFORCEMENT BRIDGE (design note)

One rung: wire the stored sus_path rules into actual hiding. Everything
else stays field-proven v53.1 behavior.

## What "enforcement" means this rung

`getdents64` (syscall 217) listings by **app-range uids (>= 10000)** stop
containing the registered entries. Root (0), system (< 10000) and shell
(2000) keep the unfiltered view — the conservative gate for rung 1;
KSU-allowlist awareness is a later rung (needs a verified contract with
KernelSU-Next's allowlist, which is kernel memory we have no symbol
guarantee for). Open/stat/rename of a hidden path still works (same as
upstream sus_path: it hides directory ENTRIES, not access).

## Matching semantics: (name, ino) pairs — upstream's own rule

The upstream susfs4ksu android13-5.15 LKM (upstream-refs/susfs_lkm_x64.zip)
matches dirents by **(d_ino, d_name)**: its `sd_filldir` passes filldir's
5th argument (ino) plus the name to `sus_path_dirent_hidden`, whose table
walk compares both (`cmp entry->ino; strcmp entry->name`). Same name AND
same inode number = the same filesystem object, in any directory, on any
mount — which is exactly how the user's config doubles spellings
(/storage/emulated/0/TWRP and /data/media/0/TWRP are different mounts of
the same dir: each resolves to its own (name,ino) rule and both listings
get filtered).

## Why the ino is resolved in USERSPACE (the key safety decision)

The kernel-side alternatives all need struct offsets this kernel cannot
give safely:

- d_path matching needs `offsetof(struct file, f_path)` — the v49 wedge
  was EXACTLY a hardcoded task_struct.cred offset (vanilla 0x788 vs the
  real 0x7a8). The upstream android13-5.15 .ko hardcodes cred at 0x7e0
  and uid at +4 — neither matches this box (0x7a8 / +8, field-calibrated).
  No offline tree is trustworthy here, and a wrong f_path offset fed to
  d_path DEREFERENCES garbage (kernel oops), so it cannot be probed at
  runtime either.
- filp_open + `file->f_inode->i_inm` needs the same class of offsets.

So the resolution moves to the caller: the stage-late script (root) runs
`stat -c '%i'` on every configured path and registers `(basename, ino)`
through a PRIVATE supercall (0x55f55). The kernel side only ever compares
numbers that came from the dirent bytes themselves and from userspace
stat — **zero kernel struct offsets, zero dereferences of anything the
kernel did not hand us, crash-free by construction**.

Consequences (documented limitations, by design this rung):
- the stock CLI `add_sus_path` still stores strings (v53 behavior,
  readback-visible) but does NOT enforce; enforcement registration is the
  script's resolved pass over the same config + sc_probe for manual use;
- a path that does not exist at stage-late time is skipped (you cannot
  hide what does not exist; the next boot re-registers);
- subtree entries INSIDE a hidden directory are not hidden this rung
  (the root entry disappears from listings — the scan-discovery threat;
  per-descendant registration is a possible later rung).

## The transport: the proven table-patch class, second entry

`sys_call_table[217]` -> `susfs_gd64_entry`, exactly the v49/v53 recipe:
resolve the table (fp-layer cache), validate entry 217 ==
`__x64_sys_getdents64` (kallsyms), prove liveness (ksu_syscall_dispatcher
present in the table), clone the ORIGINAL entry's 16-byte kCFI preamble
window byte-for-byte into our entry's window (ksu_patch_text), write the
entry, read it back. The write is a single aligned u64 store — concurrent
getdents64 callers see either the old or the new target, both valid.

The filter calls the SAVED original handler through a typed indirect call
(the standard wrapper pattern; the outbound kCFI check compares the call
site's type hash against the original's intact preamble — symmetric with
the proven inbound clone).

## Filter flow (fail-open invariants)

On every getdents64 through the patched entry:
1. bump the counter; not installed / no resolved rules / uid not in app
   range / uid read failed -> straight to the original, unfiltered.
2. rc = original(...). rc <= 0 or rc > 256 KiB -> return rc (fail-open).
3. stage rc bytes: `__kmalloc(rc, GFP_KERNEL=0xCC0)` (5.15.178 source
   verified); alloc fail -> return rc unfiltered. copy_from_user fail ->
   kfree, return rc unfiltered (the kernel's bytes are the truth; we
   discard our staging copy).
4. walk entries (d_reclen sanity: >= 24, 8-aligned, within rc; d_name is
   NUL-terminated by filldir64 itself — `unsafe_put_user(0, dst+len)`,
   linux-5.15.178 fs/readdir.c — so names are scanned to their NUL; an
   entry without a NUL inside its reclen is kept unfiltered).
5. hide an entry iff (name, d_ino) matches a registered rule; compact
   the buffer in place (two-pointer); malformed tails are copied
   verbatim (no data loss, no wrong truncation).
6. nothing hidden -> kfree, return rc (the user buffer was never touched).
   Hidden -> copy_to_user the compacted bytes; on fault kfree and return
   -EFAULT (getdents64 is restartable); return the compacted length.

Post-call compaction has a structural advantage over the filldir-hook
approach: the kernel's f_pos already advanced past everything it
produced, so removed entries can never cause a re-list loop.

## Arming: private command + script ladder (one rung, one boot at a time)

0x55f54 (gd64_arm) does the table patch, ORs SUSFS_FEAT_SUS_PATH (bit 0)
into `susfs_armed_features` (SHOW then prints 7 flags — the visible
delta), and is idempotent. It is issued by boot-completed.sh ONLY after
the stage-3 self-test passes, gated by a new ladder marker
`/data/adb/ReSuSFS/gd64_stage` ('' -> 'try N <bootid>' -> 'ok N'):

- flash v54 -> 4 boots re-climb arm_stage 0->3 (transport re-proven with
  the new binary; gd64_stage untouched, no enforcement);
- boot 5: stage 3 healthy + self-test green -> arm (0x55f54) with
  sync-per-line receipts -> register the config paths resolved (0x55f55)
  -> run the uid-drop functional test -> watch 5s -> mark ok;
- a boot that dies AFTER the arm receipt = the filter (the receipts name
  it); the next boot demotes gd64_stage to 'disabled' and never arms
  again on this version; stage_max stays 3, box safe;
- steady state: every boot arms + registers + verifies after self-test.

## Wire additions (private, stock CLI untouched)

- 0x55f54 gd64_arm: { u32 flags(0=arm); s32 err@4 } 8B
- 0x55f55 add_resolved: { char name[256]; u64 ino@256; s32 err@264 } 268B
  validation: NUL inside name[256], len 1..255, no '/' byte, ino != 0;
  dedupe on (name, ino); 48 slots, ENOSPC beyond.
- 0x55f53 readback extended with the v54 section (stats + resolved table)
  — same 8196B shape, sc_probe is the only reader.

## Import contract change

13 -> 15 undefined symbols: + `__kmalloc`, + `kfree` (both verified in
the box's kallsyms snapshot; both called DIRECTLY — the same resolution
path `_copy_from_user` already rides, field-proven since v50).

## Verification plan (offline, before any flash)

1. clang-17 build, .comment check, exact 15-symbol undefined set,
   zero .bss in the graft, no thunk imports, vermagic 5.15.178+ SMP
   preempt modversions, struct module 0x340 (android13 candidate).
2. disasm receipts: gd64 entry endbr64, preamble clone target window,
   dispatch of 55550/55553/55561/55f53/55f54/55f55, no wrapper refs.
3. host unit tests (test_sc_v54_host.c): dirent walk/compaction on
   synthetic buffers (hidden first/middle/last/all, malformed reclen,
   no-NUL name, name+ino vs name-only), the add_resolved validation
   matrix, the readback dump bounds.
4. wire-dispatch lock: stock CLI ids unchanged vs the shipped binary.

---

## v54.1 ADDENDUM (2026-11-27, after the v54 field run)

**Field verdict of v54:** the rung armed cleanly on boot 4 (id e3580bfc,
10:33:48) and the box died on the FIRST getdents64 milliseconds later.
No arm receipt, no uid-drop test, no stage-late.  The gd64_stage ladder
found the stale 'try' next boot and disabled enforcement exactly as
designed; the stage-3 transport (6 features) stayed live through boots
5-6.  Six logs in upload/v54-field/.

**Root cause (proven from the field diag + our own disassembly):**
the forward `((long (*)(const struct pt_regs *))orig)(regs)` compiles
under clang-17 -fsanitize=kcfi into a CHECKED indirect call:

    mov $0x4fd4cb27,%r10d ; add -0x4(%rax),%r10d ; je ; ud2 ; jmp *%rax

It reads the 4 bytes before the saved __x64_sys_getdents64 and requires
the pt_regs-fn hash 0xB02B34D9.  THIS KERNEL'S __x64_sys_* targets
carry no kCFI preamble — the v53 ioperm arm receipt proves the pattern
(orig window = previous function's epilogue + padding, no b8-hash), and
the stock kernel boots, so its own table dispatch calls targets
UNCHECKED.  Our checked forward read garbage and ud2'd.  Nothing offline
could catch it: host tests build with GCC (no kCFI at all) and the
verifier asserted OUR preamble (the incoming check), never a module call
site against a real preamble-less target.  Lesson recorded: a kCFI
kernel does NOT imply syscall-table targets are kCFI-checked call sites
— verify the calling convention of every function pointer you must call,
not only of every pointer that calls you.

**Fix (v54.1, module v26.11.55):** all forwards ride sc_v54_fwd(), a
noinline `no_sanitize("kcfi")` trampoline (endbr64; mov %rdi,%rax; mov
%rsi,%rdi; jmp *%rax) — the kernel's own convention for table targets.
Disasm-verified: zero ud2 sites in the whole graft (v54 had exactly 3),
zero indirect sites left in susfs_gd64_entry.  build_v55_verify.py adds
four permanent checks (zero ud2 object-wide; helper unchecked; entry
indirect-free; entry forwards through the helper).  271/271 verifier,
45/45 host, 10/10 ladder.  Import set byte-identical to v54's
(field-resolved).  Change set vs the v54 zip: module.prop + both .kos +
.payload_stamp.  The arm receipt now also dumps the getdents64 orig
window bytes (field proof of the preamble-less target, like v53's).
