# ReSuSFS x86_64 port — for LDPlayer 14 (kernel 5.15.178+)

**Current build: `ReSuSFS-x86_64-v26.11.43.zip`** — tri-channel trigger +
console breadcrumbs. THE v42 FIELD RESULT: with the setter reduced to bare
schedule_work, a proven-clean vanilla image load and substep 0 armed, the box
still died INSIDE the force_init write (<5s, write receipt never landed, first
heartbeat never landed, witness @0s read fine, no PARAM READ TIMEOUT, no -50
sentinel). v39/v40/v41 showed the same signature; the only context in which
the dispatch verifiably RAN was the POST-FS-DATA trigger (v35-v37), never the
boot-completed trigger — and the .set is the FIRST module FUNCTION CALL of the
whole boot (all other param traffic rides stock kernel param_ops code). v43
therefore:

1. **SYNC TRIGGER (default, trigger_mode=sync): `echo 2 > force_init` calls
   `susfs_init_body()` DIRECTLY in the .set** — with init_maxstep=0 that is
   stores + vsnprintf only: NO workqueue, NO wake-up, NO scheduling
   machinery. If even that freezes the box, the sysfs write machinery itself
   is guilty; if it survives where the deferred path froze, the queue_work
   path is guilty. `1` keeps the v42 deferred path byte-for-byte
   (trigger_mode=set); `get` still dispatches through the probe .get;
   `early` still writes at post-fs-data.
2. **CONSOLE BREADCRUMBS: both paths printk(KERN_EMERG "XYZDIAG2: .set
   ENTERED …") first** — no param_lock, ring + console (tty0): the LDPlayer
   window itself shows the last point reached if the box dies. The script
   arms diag_printk=1 and snapshots a dmesg baseline before the trigger.
3. **VANILLA IS THE DEFAULT CANDIDATE** — the only image that loads CLEAN in
   the field (the v42 android13 image ENOEXECs every attempt; it stays
   shippable, selected via /data/adb/ReSuSFS/lkm_candidate).

Build: `scripts/build_v43_ko.sh` (both trees, HOST GCC, recycle-proof
re-extraction), verified by `scripts/build_v43_verify.py`.
Build: `ReSuSFS-x86_64-v26.11.43.zip` in download/.

---

**Historical note — the v42 build (kept for context; its attribution contract
is what produced the v43 design above).** The v39/v40/v41 field boots all
froze the box AT the `force_init` sysfs write — the FIRST module code the
whole boot executes — with the v41 witness blind (its param reads need the
same `mod->param_lock` the stuck write path holds). A full static post-mortem
of those images against the uploaded field `kernel_kallsyms.txt` found every
checkable thing clean (setter machine code, 124/124 imports in kallsyms,
`params.c`/`moduleparam.h` byte-identical between kernel.org 5.15.178 and
android13-5.15-2025-03, benign `.bss` heads) but two hard defects, which v42
fixed outright:

1. **STRUCT MODULE SIZE MISMATCH (ABI).** The running kernel's `struct module`
   is the ANDROID one (`scmversion` + 4 `ANDROID_KABI_RESERVE`s = 0x340 bytes),
   while every kernel.org-built image since v26.11.26 shipped a 0x300-byte
   `.gnu.linkonce.this_module` — the kernel initializes its own larger struct
   INSIDE that section at load, writing 0x40 bytes past it into the module's
   `.bss`. The v42 `android13` candidate was built against the EXACT running
   lineage (AOSP `kernel_common-ASB-2025-03-05_13-5.15`, verified 5.15.178 —
   `a13-full/` here, from the aosp-mirror tarball), so `struct module` is the
   kernel's own. The `vanilla` candidate keeps the kernel.org 0x300 section
   (its overflow was field-proven benign on the gcc layout: the spill lands on
   the zero-initialized ints at the head of `.bss` and the v43 builds keep that
   layout unchanged).

The ladder (init_seq 0..7, arm_stage 0..4, next-boot stand-down, WEDGE
DOSSIER, payload stamp self-heal, now v26.11.43) is unchanged from v38–v42 and
field-proven. Same two-step opt-in: `touch /data/adb/ReSuSFS/enable_lkm`
(zombie image, proven safe) + `touch /data/adb/ReSuSFS/enable_force_init`
(post-boot init experiment). After any wedge send back:
`logs/init_trace.txt + logs/diag_last.txt + logs/boot.log +
logs/kernel_facts.txt` (+ `logs/dmesg_freeze.txt` if the heartbeats kept
beating).

---

**Historical note — v26.11.38..41 era (kept for context).** v37 proved even a
stage-0 evidence boot (imports guard + kallrecon SCAN + DIAG printk) could
wedge, and the trigger ran during boot — which is why boots froze at 50%.
v38: (1) `susfs_init` runs only in `boot-completed.sh`, AFTER the system is up
(a wedge can never freeze the boot animation again), gated by a NEW second
opt-in flag `/data/adb/ReSuSFS/enable_force_init` (with only `enable_lkm` the
module stays in its proven-safe zombie image state); (2) the kallrecon memory
scan is OFF by default (`kr_scan=0`): `boot-completed.sh` seeds the resolver
with the kernel's own `kallsyms_lookup_name` address + `current_task`
per-CPU offset from `/proc/kallsyms` via the `kr_seed` param
(`kln=0x… gsoff=0x…` — the "seed v2" form; the table-variables form could
never be built on this kernel because the kallsyms table variables are not
listed in `/proc/kallsyms`), and the module only VALIDATES the seed instead
of scanning, refusing (-ENODATA) with neither seed nor `kr_scan=1`; (3) module
printk is OFF by default (`diag_printk=0`) — crumbs go to the `diag_log` param
only; (4) Phase-0 kernel recon every boot → `logs/kernel_facts.txt`
(+`kernel_kallsyms.txt`, +`kernel_config.txt`): compiler string, IKCONFIG
config, kallsyms layout markers, KSU variant, BTF dir — collected BEFORE any
LKM action so even a wedged boot leaves them on disk; (5) THREE LKM
candidates, selected via `/data/adb/ReSuSFS/lkm_candidate` (default
`android13`): `android13` — built against AOSP kernel/common at tag
`ASB-2025-03-05_13-5.15` (= 5.15.178; the android13-5.15-2025-03 branch
itself is deleted server-side — only branches from 2025-07 on remain); `vanilla`
— the kernel.org 5.15.178 build; `ymuuu13` — ymuuuu's prebuilt GKI
android13-5.15 x64 ko. Both local builds share the empirically config-matched
option set (RETPOLINE/STACKPROTECTOR/HARDENED_USERCOPY/X86_5LEVEL/
RANDOMIZE_MEMORY/MODULE_UNLOAD off, MODVERSIONS on with the normalized dummy)
and the `arch/x86/include/asm/current.h` %gs override (the only kernel-tree
patch — copy `scripts/current.h.override` into any new tree before building).

This package ports **ReSuSFS** (the KernelSU SuSFS manager module and WebUI,
upstream: https://github.com/ahmed-alnassif/ReSuSFS, v26.10.23) to **x86_64**,
targeting **LDPlayer 14 (14.0.36.0) with kernel 5.15.178+**.

Upstream ReSuSFS is arm64-only in practice:

- `module/utils.sh: update_susfs()` aborts when `ro.product.cpu.abi` is not
  `arm64-v8a` ("Only arm64 is supported!"), and `customize.sh` runs
  `update_susfs || exit 1`, so installation dies on any x86_64 device;
- the `ksu_susfs` userspace tool is downloaded as an arm64 binary from GitLab;
- the SuSFS LKM flow only knows arm64 GKI KMI releases (no `5.15.178+` custom
  kernel, and no x86_64 builds).

This port fixes all three layers for x86_64 and bundles everything the module
needs on LDPlayer 14.

## Package contents

```
ReSuSFS-x86_64-port/
├── ReSuSFS/                                  the ported ReSuSFS repo (module scripts fixed in v26.11.22)
│   ├── module/                                KernelSU module (ported scripts + x86_64 payload)
│   │   ├── bin/x86_64/ksu_susfs               bundled x86_64 CLI (replaces the arm64 download)
│   │   ├── bin/x86_64/susfs_insmod            bundled x86_64 loader (ported from upstream tools)
│   │   └── lkm/x86_64/susfs_guard_lkm-x86_64-5.15.ko   bundled x86_64 LKM (vermagic 5.15.178+)
│   ├── webui/                                 WebUI source (unchanged, arch-independent)
│   └── module/webroot/                        built WebUI (vite output, as upstream CI does)
├── ReSuSFS-x86_64-v26.11.22.zip               ready-to-flash KernelSU module (the fixed build)
├── susfs4ksu-lkm-x64-5.15/                    the x86_64 SuSFS LKM source tree (verified build)
│   ├── kernel/susfs_guard_lkm.ko              built for kernel.org 5.15.178 x86_64
│   └── tools/susfs_insmod_x64.c               x86_64 port of the freestanding loader
├── scripts/                                   build + verification scripts
│   ├── build_lkm_x86_64.sh                    reproducible LKM/CLI/loader build
│   ├── test_module_install.sh                 e2e mock KernelSU flash (21 assertions)
│   ├── test_kmi_resolution.sh                 KMI/name resolution tests
│   └── port_insmod_x64.py                     the loader syscall-layer port tool
└── README-x86_64-PORT.md                      this file
```

## v26.11.22 — install fix

**Symptom** (flashing v26.10.23-x86_64 in the KernelSU manager on LDPlayer 14):

```
[!] No bundled x86_64 LKM for this kernel (5.15.178+)
[!] Build one from the ported tree (see README-X86_64-PORT.md)
[!] and place it at /data/adb/ReSuSFS_LKM/susfs_guard_lkm-x86_64-5.15.ko
[!] bundled ksu_susfs binary missing from module (/data/adb/modules/ReSuSFS/bin/x86_64/)
Error: Failed to install module script
```

**Root cause** — one bug, two symptoms. During `customize.sh`, KernelSU
extracts the module to the *staging* dir `/data/adb/modules_update/ReSuSFS`
(exported as `$MODPATH`) and only moves it to `/data/adb/modules/ReSuSFS`
after the installer script exits 0. v26.10.23's `utils.sh` hard-coded
`MODDIR=/data/adb/modules/ReSuSFS`, so during installation every
"is the bundled payload there?" check — `update_susfs()`'s bundled
`ksu_susfs` and `install_susfs_guard_lkm_x86_64()`'s bundled `.ko` —
looked at the old install dir, found nothing, printed the two `[!]` lines,
and `update_susfs`'s non-zero exit made `customize.sh` abort; the manager
reported "Failed to install module script" and removed the module.

**Fix** (module/utils.sh):

- `MODDIR` (and every `module_root`) now resolves from `$MODPATH` at
  install time, falling back to `/data/adb/modules/ReSuSFS` at runtime —
  the bundled LKM/CLI checks now see the freshly extracted payload;
- `load_susfs_lkm()` tries ksud on `PATH`, `/data/adb/ksu/bin/ksud`,
  `/data/adb/ksud`, and then the bundled `susfs_insmod` (any arch);
- GKI x86_64 kernels route to the ymuuu multi-KMI zip; custom kernels
  (LDPlayer's `5.15.178+`) use the bundled `.ko`; a user-supplied LKM in
  `/data/adb/ReSuSFS_LKM` always wins; arm64 flow unchanged;
- `module.prop` bumped to `v26.11.22-x86_64` with `versionCode=99` so an
  upstream arm64-only update can never silently replace this port.

**Upgrading from the failed flash:** just install
`ReSuSFS-x86_64-v26.11.22.zip`. The aborted v26.10.23 attempt left
`/data/adb/ReSuSFS` (configs) and an empty `/data/adb/ReSuSFS_LKM` behind —
both are fine: the installer auto-answers "keep configs" on x86_64 and
refills the LKM dir. Nothing on the device needs manual cleanup.

## The x86_64 stack on LDPlayer 14

```
KernelSU (or KernelSU-Next / BakaSU, with ksud)      root + module system
        │
        ▼
susfs_guard_lkm.ko  (x86_64, 5.15.178+)               SuSFS in-kernel, loaded as an LKM
   loaded by: ksud insmod  →  fallback: susfs_insmod  (absolutizes symbols via
   /proc/kallsyms, rewrites SHN_UNDEF→SHN_ABS, patches vermagic in place on retry)
        │
        ▼
/proc/susfs_* nodes + reboot(0xDEADBEEF, 0xFAFAFAFA, cmd, payload) supercall
        │
        ▼
ksu_susfs CLI (x86_64, freestanding, bundled)        same classic command surface
        │
        ▼
ReSuSFS module (ported scripts) + WebUI               configs, scripts, scheduling, UI
```

Requirements on the device: Android x86_64 (LDPlayer 14), kernel 5.15.x, a
KernelSU-compatible root that provides `ksud` and `/data/adb/ksu/bin`,
`CONFIG_KPROBES=y` in the running kernel (standard on Android kernels), and
`/proc/kallsyms` readable as root (standard; `susfs_insmod` lowers
`kernel.kptr_restrict` briefly and restores it).

## Install (LDPlayer 14)

1. Root the emulator with a KernelSU-compatible solution first (ReSuSFS needs
   the module system). The module is manager-agnostic, but `ksud insmod` is
   preferred when available; the bundled `susfs_insmod` works without it.
2. Flash `ReSuSFS-x86_64-v26.11.22.zip` in the manager, reboot.
3. At `post-fs-data` the module:
   - detects x86_64, installs the bundled `ksu_susfs` CLI to
     `/data/adb/ksu/bin/ksu_susfs` (+ `susfs`/`sus` symlinks);
   - copies the bundled `susfs_guard_lkm-x86_64-5.15.ko` to
     `/data/adb/ReSuSFS_LKM/` together with `susfs_insmod`;
   - loads the LKM (`ksud insmod`, then `susfs_insmod` fallback);
   - applies the early-stage SuSFS config; late stage runs at boot-completed.
4. Check: `ksu_susfs show version` → `v2.3.0`, `ksu_susfs show variant` →
   `GKI-LKM`, `ReSuSFS --status` → active with the enabled-features list.

A successful flash now ends with `SUSFS updated successfully!` and the
`creating symlink in /data/adb/ksu/bin` line — no `[!]` warnings, no
"Failed to install module script".

`module.prop` carries `versionCode=99` so an upstream arm64-only update
will not silently replace this port.

## What was ported (ReSuSFS repo)

| File | Change |
|---|---|
| `module/utils.sh` | **v26.11.22:** `MODDIR`/`module_root` resolve from `$MODPATH` during `customize.sh` (KernelSU's staging dir) so the bundled payload checks pass on first flash — this was the install-abort bug; `load_susfs_lkm()` gains the `/data/adb/ksu/bin/ksud` + `/data/adb/ksud` fallbacks and uses the bundled `susfs_insmod` for any arch. New `get_device_abi()` (ABI first, `uname -m` fallback); `update_susfs()` installs the bundled x86_64 CLI instead of the arm64 GitLab download and keeps an LKM-provided `ksu_susfs` symlink intact (arm64 path unchanged); `check_susfs_support()` also detects an already-loaded LKM (`/proc/susfs_path`, `/sys/module/susfs_guard_lkm`); `get_susfs_guard_lkm()` resolves GKI names for both arches (inforcqb naming for arm64, ymuuu naming for x86_64) and custom non-GKI x86_64 releases (`5.15.178+` → `susfs_guard_lkm-x86_64-5.15.ko`); new `install_susfs_guard_lkm_x86_64()` copies the bundled `.ko` + loader (user-supplied LKM in `/data/adb/ReSuSFS_LKM` wins); `download_susfs_guard_lkm()` routes x86_64 through the bundled install first, the ymuuu multi-KMI zip for GKI x86_64 |
| `module/customize.sh` | `detect_key_press()` auto-selects the safe default on x86_64 (emulators have no volume keys; the upstream timeout path aborts config updates there) |
| `module/module.prop` | version → `v26.11.22-x86_64`, `versionCode=99`, description mentions the port |
| `update.json` | version → `v26.11.22-x86_64`, versionCode 99 (block upstream auto-update regression) |
| `module/bin/x86_64/*`, `module/lkm/x86_64/*` | new bundled x86_64 payload (see below) |
| everything else (ReSuSFS.sh, WebUI, configs, sepolicy, …) | unchanged — arch-independent |

### What was ported (kernel side, `susfs4ksu-lkm-x64-5.15/`)

Based on `ymuuuu/susfs4ksu-lkm-x64` (the community x86_64 port of
`inforcqb/susfs4ksu-lkm`, which ports `simonpunk/susfs4ksu` to an LKM):

- the whole tree builds against **kernel.org linux-5.15.178, ARCH=x86_64,
  CC=gcc** with a single addition: `KCFLAGS=-std=gnu11` (5.15 builds with
  `-std=gnu89`; the kallrecon C uses C99 loop declarations — clang accepts
  them, gcc does not);
- `susfs_guard_lkm.ko` produced with **vermagic `5.15.178+ SMP preempt
  mod_unload`** (CONFIG_LOCALVERSION="+" matches LDPlayer's release string);
- `tools/susfs_insmod.c` was arm64-only (aarch64 syscall numbers + `svc #0`):
  `tools/susfs_insmod_x64.c` ports the syscall layer to the x86_64 ABI
  (numbers, register constraints, `syscall` instruction, `_start` entry);
  ELF/kallsyms/vermagic logic is unchanged from upstream.

The module is absolutized at load time (`ksud insmod` or `susfs_insmod`
rewrite every SHN_UNDEF symbol to SHN_ABS with its kallsyms address), so it
does not need Module.symvers from LDPlayer's private kernel build. If the
vermagic differs, `susfs_insmod` patches `.modinfo` in place and retries.

## Rebuilding (reproducible)

On a Debian-ish x86_64 host with gcc, flex, bison, bc, libelf-dev, pnpm:

```sh
# 1. kernel tree (once)
wget https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.15.178.tar.xz
tar -xf linux-5.15.178.tar.xz
cd linux-5.15.178
# modpost: tolerate symbols the module resolves at runtime (same patch the
# upstream CI applies)
sed -i -E 's/^([[:space:]]*)check_exports\(mod\);/\1\/\/ check_exports(mod);/' scripts/mod/modpost.c
sed -i -E 's/^([[:space:]]*)s->module = exp->module;/\1\/\/ s->module = exp->module;/' scripts/mod/modpost.c
sed -i 's/^static void check_exports(/static void __attribute__((unused)) check_exports(/' scripts/mod/modpost.c
make O=$PWD/../kbuild-x64 x86_64_defconfig
./scripts/config --file ../kbuild-x64/.config -e KPROBES -d PREEMPT_VOLUNTARY -e PREEMPT \
        -e SECURITY -e SECURITY_SELINUX -e MODULES -e MODULE_UNLOAD -e HARDENED_USERCOPY \
        -e KALLSYMS -d LOCALVERSION_AUTO --set-str LOCALVERSION "+"
make O=$PWD/../kbuild-x64 modules_prepare -j$(nproc)

# 2. LKM (the ONE x86_64/5.15 fix is KCFLAGS=-std=gnu11)
make O=$PWD/../kbuild-x64 M=<path-to>/susfs4ksu-lkm-x64-5.15/kernel \
     ARCH=x86_64 CC=gcc KCFLAGS="-std=gnu11" modules -j$(nproc)

# 3. userspace tools (freestanding, no NDK needed)
gcc -O2 -nostdlib -static-pie -fno-stack-protector -fno-builtin -Wl,-e,_start \
    -o ksu_susfs <...>/susfs4ksu-lkm-x64/tools/susfs_cli_x64.c
gcc -O2 -nostdlib -static-pie -fno-stack-protector -fno-builtin -Wl,-e,_start \
    -o susfs_insmod <...>/susfs4ksu-lkm-x64-5.15/tools/susfs_insmod_x64.c

# 4. webui + module zip
cd <port>/ReSuSFS/webui && pnpm install --frozen-lockfile && pnpm build
cd ../module && zip -9 -r ../ReSuSFS-x86_64-v26.11.22.zip .
```

`scripts/build_lkm_x86_64.sh` in this package automates steps 1-3 exactly as
they were run for this build.

## Verification performed (and honest limits)

Verified here, with artifacts in this package:

- **end-to-end mock install** (`scripts/test_module_install.sh`, 21
  assertions, all passing): reproduces the KernelSU flash on an
  LDPlayer-14-like device (x86_64, `uname -r` `5.15.178+`, staging at
  `/data/adb/modules_update`, `ui_print` provided, busybox/getprop faked):
  `customize.sh` exits 0, the bundled `.ko` + loader + CLI install
  byte-identical, configs persist, re-flash keeps user edits, the LKM load
  works via ksud and via the `susfs_insmod` fallback, and neither of the two
  `[!]` failures from the v26.10.23 flash log is produced;
- unit/deep suites for `utils.sh` (30 assertions): KMI resolution for all
  GKI releases on both arches + LDPlayer's `5.15.178+`, arm64 flow intact,
  x86_64 GKI zip fetch + extract, user-supplied LKM precedence, missing
  payload aborts cleanly;
- `susfs_guard_lkm.ko` **compiles clean** against kernel.org 5.15.178 x86_64
  (gcc 14, defconfig + Android-style options, LOCALVERSION "+"); ELF64 x86-64;
  vermagic `5.15.178+ SMP preempt mod_unload`; 141 runtime-resolved imports,
  matching the upstream LKM design;
- `ksu_susfs` (x86_64 CLI) builds and executes: correct x86_64 syscall ABI,
  graceful "module not loaded" path, full command surface matching every
  command `ReSuSFS.sh` uses;
- `susfs_insmod_x64` builds and executes (usage/errno paths verified);
- all ported module scripts pass syntax checks (the single dash-only
  complaint in `customize.sh` is upstream's own process-substitution
  bashism, present verbatim upstream, parsed fine by the device shell —
  the v26.10.23 flash log proves it — and never executed on the x86_64
  path);
- WebUI builds with the upstream pipeline (vite → `module/webroot`).

Not verifiable in this sandbox (no LDPlayer instance):

- actual `insmod` on LDPlayer's private 5.15.178+ build. The port is
  designed for that case (runtime symbol absolutization + vermagic fixup),
  and the same mechanism is live-tested upstream on x86_64 emulator GKI
  kernels, but LDPlayer's exact kernel config is unpublished. If loading
  fails, check the loader log output, confirm `/proc/kallsyms` shows real
  addresses as root, and rebuild the `.ko` from this tree with your exact
  kernel release (`scripts/build_lkm_x86_64.sh` accepts a `LOCALVERSION`).
- SuSFS runtime effectiveness (sus_path hiding etc.) on LDPlayer — depends on
  the running kernel having kprobes and the hook targets available, which is
  the standard Android kernel configuration.

## Credits & licenses

- ReSuSFS by ahmed-alnassif (GPLv3) — https://github.com/ahmed-alnassif/ReSuSFS
- susfs4ksu by simonpunk — https://gitlab.com/simonpunk/susfs4ksu
- susfs4ksu-lkm by inforcqb (GPL-2.0) — https://github.com/inforcqb/susfs4ksu-lkm
- susfs4ksu-lkm-x64 by ymuuuu (GPL-2.0) — https://github.com/ymuuuu/susfs4ksu-lkm-x64
- kallrecon / HooKern by Dere3046 (GPL-2.0)

This port keeps the original licenses; the port changes are documented in
this README and in change comments inside the module scripts themselves.

---

## v26.11.23 — SAFE build (boot-completed freeze on LDPlayer 14, fixed)

v26.11.22 installed and booted, but froze ~10s after the home screen
appeared. Root cause (audited from the shipped scripts/binary): the bundled
`susfs_guard_lkm-x86_64-5.15.ko` is a runtime kernel-hooking module compiled
against a generic 5.15 config — NOT against LDPlayer 14's actual kernel build
— and v26.11.22 force-loaded it on every boot. Worse, the built-in-susfs
detection required `/proc/config.gz` (absent on LDPlayer), so the LKM could
also be stacked on top of a kernel that already had built-in susfs. The
hooks went hot when `boot-completed.sh` pushed ~50 susfs rules into the
kernel; the wedged hook layer froze the whole system — unrecoverable from
userspace, which is why it hung on every boot. v26.11.23 fixes it:

- **the custom-kernel LKM load is strictly opt-in**
  (`touch /data/adb/ReSuSFS/enable_lkm`): the safeguard in
  `load_susfs_lkm()` refuses `susfs_guard_lkm-x86_64-*.ko` on non-GKI
  kernels by default and logs the decision; GKI/KMI kernels keep the
  automatic load (upstream prebuilts, verified per KMI)
- **built-in susfs is detected functionally**: `susfs_kernel_alive()` asks
  the kernel through the ksu_susfs supercall (`reboot(0xDEADBEEF, ...)`
  answers EINVAL instantly on kernels without susfs — safe everywhere).
  Built-in susfs => full features, no LKM at all
- **userspace-only mode**: no kernel susfs + no LKM => install and boot
  stay stable, script/cron/prop features work, `stage-early`/`stage-late`
  skip the susfs application, and module.prop says `userspace-only`
  (status_report gained a dedupe so the 30s status loop no longer
  rewrites module.prop on every pass)
- all user scripts commented out, all toggles blank — nothing kernel-side
  runs at boot until susfs is confirmed alive
- every boot stage logged to `/data/adb/ReSuSFS/logs/boot.log`, timestamped,
  `sync`-ed per line (survives a hard instance restart), mirrored to dmesg
- hang watchdog: every stage runs under a receipt; a stage that never
  finished on the previous boot is auto-skipped (quarantined after two), so
  a hang can never trap the emulator in a boot loop
- every `ksu_susfs` supercall is timeout-bounded (10s), every insmod
  attempt is timeout-bounded (60s), the whole LKM load is receipt-gated
- fixed: `apply_cmdline_bootconfig` no longer hands the kernel the
  comment-only stock file (it used to spoof /proc/cmdline with comment text)
- fixed: the installer's `detect_key_press` used the bashism
  `read -t < <(getevent ...)` — now POSIX-safe (`timeout | awk`)
- fixed: module.prop status rewrites no longer break on `/`-containing
  strings (sed delimiter collision — rewritten via grep+printf+cat)
- flashing over v26.11.22 force-resets the persistent configs to the safe
  defaults (old ones backed up to `/data/adb/ReSuSFS.bak.<ts>`)

`diagnose.sh` (module root, also wired to the module's Action button)
applies each feature ONE step at a time — passive supercalls, uname,
kstat, sus_path, sus_path_loop (`/dev/pts`), sus_map + a real
`/proc/self/maps` read, mount-hiding toggle, then all 12 upstream user
scripts individually — writing START/DONE/ALIVE per step to
`/data/adb/ReSuSFS/logs/diagnose.log`. If a step freezes the box, force
restart: the watchdog skips it next time and the last START line without
DONE/ALIVE names the culprit. boot.log + diagnose.log (+ dmesg) are the
evidence for a targeted kernel-side fix. The log self-identifies its state
up front (kernel susfs ALIVE vs userspace-only), so rc!=0 "not supported"
lines on a stock kernel are expected, not failures.

Verification: the shipped zip was extracted and driven through a
simulated Android environment (fake /data tree, stubbed `getprop`/`uname`/
`ksud`/`busybox`, real bundled CLI on a stock kernel): install flow,
safeguard refusal, opt-in load, built-in detection, both boot stages,
watchdog skip logic, and the full diagnose run — **41/41 assertions pass
against the exact zip that ships**.
