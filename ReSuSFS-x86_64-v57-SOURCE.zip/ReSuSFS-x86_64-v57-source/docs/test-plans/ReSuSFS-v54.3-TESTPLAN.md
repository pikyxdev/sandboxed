# ReSuSFS v54.3 (v26.11.57) TESTPLAN — THE UID-READ FIX

Date: 2026-11-27. Flash: `ReSuSFS-x86_64-v26.11.57.zip` (SHA256
`eb700c585f8a5c8e3956db9fd329a598247db4e2df14e696a25b49372328906f`)
OVER v26.11.56, no wipe, no instance re-clone.

## What v54.3 fixes and why we believe it

The v26.11.56 field run (7 boots, 12:18–12:42) proved: flash genuine
(sc_probe sha `f68f6a84…` matched the package), ladder re-climbed 0→3,
**arm OK at 12:27:57**, receipt archive worked, status line printed
`features: 7` — and the uid-drop test STILL failed one second after the
arm, same terminal line as v54.1.

Static audit found the real defect, header-verified against BOTH trees
this .ko family targets (torvalds v5.15 and aosp android13-5.15
`include/linux/cred.h`, byte-identical):

```
struct cred { atomic_t usage;   /* +0, 4 bytes */
              kuid_t   uid;     /* +4 */
              kgid_t   gid;     /* +8 */ ... }
```

The module read the uid at **cred+8 — the GID**. Every field caller so
far was root:root, so BOTH uid==0 gates (transport root gate AND gd64
filter app-gate) passed **by coincidence**, and the calibration's
"verified against init_cred" was vacuous (init_cred is all zeros across
every id slot; the u64 usage read also passes under both layouts). The
test drops only the uid (`setresuid(101234)`, gid stays 0) → the filter
read gid 0 → pass-through → the marker stayed visible → FAIL with
`calls>0 filtered=0 hidden=0`. This also explains v54.1: the
single-batch walk bug was real but SECONDARY — both bugs end in the same
terminal line.

Change set (proven by reference-diff disassembly vs the field-run
v26.11.55/.56 object — the ONLY code deltas):
1. `sc_v51_current_uid()`: reads `uid@cred+4` (both call sites: the
   transport root gate and the gd64 filter gate — the helper is inlined
   into both).
2. `sc_v51_calibrate()`: honest window — u32 usage@+0, id words
   +4..+0x2c (the old window started at +8 and skipped the REAL uid
   slot).
3. sc_probe gd64_test runs a **GID CANARY** before the walk: root drops
   ONLY its gid to 54321 and asks `show_version` through the live
   transport. A uid-keyed gate answers (canary OK); the old gid-keyed
   gate rejects exactly that call (canary FAIL names it in the receipt).
4. Walk logic and ladder logic byte-identical to v54.2 (proved: entry
   counts equal offline; non-comment script lines identical).

Offline evidence: 45+9 host checks (three new v54.3 cases FAIL against
the old graft: field shape uid 101234+gid 0 must hide; canary shape
uid 0+gid 54321 must NOT hide; root+gid 54321 transport call must
answer), 293 binary-verifier checks (gate bytes, imports=15, zero ud2,
vermagic, wire locks, sha256 locks), 21 ladder checks, walk regression
all green.

## Before flashing — one piece of evidence to push (no reboot)

If possible, push the v54.2 receipt BEFORE flashing:
`adb pull /data/adb/ReSuSFS/logs/gd64_receipt_2920320baa584cfab8dbf53c31f165b8.txt`
It should read (per the v56 boot.log): root walk found, `add_resolved
rc=0 err=0`, root view present, **app-uid view marker=present**,
`FAIL (see the views above)`, post-test readback `calls>0 filtered=0
hidden=0`. That CONFIRMS the diagnosis with field data. If it shows
something else (registration rejected / calls=0 / control ABSENT),
DON'T flash — send it and the fix is re-cut. The flash below is still
safe to run either way (fail-open design), but the receipt decides
whether v54.3 is the right medicine.

## Field test — 5 reboots (fresh ladder: the version bump re-bases)

Hypothesis: with the uid read at cred+4, the filter gate sees uid
101234 for the dropped-uid walk and hides the registered marker; the
transport root gate still answers root callers (uid 0). Expected:
boot 4 = first `v54 ENFORCEMENT VERIFIED` in history, KSU Manager
shows **7 features** from boot 4 onward.

| Boot | Expected boot.log line | Meaning |
| --- | --- | --- |
| 1 (flash) | `module version changed ('v26.11.56-x86_64' -> 'v26.11.57-x86_64') - re-basing the stage ladder` | ladders re-based: arm_stage=0, gd64 marker cleared |
| 1–3 | `init-trace: STEP 7/7 ... arm_stage=0/1/2/3` climbing | substep ladder re-climb (no en route freeze expected — .ko change is 3 instructions) |
| 4 | `v54 gd64 ladder: arming the getdents64 filter` → `v54 gd64 arm OK` → receipt `v54_test: gid canary OK (...)` → `v54_test: PASS (enforcement end-to-end)` → `v54 ENFORCEMENT VERIFIED (uid-drop test PASS...)` | THE PASS — canary proves the gate keys on uid; app-uid view loses the marker |
| 4 (stage-late) | `[*] v54: resolved registration` lines with real counts | the config sus_paths registered resolved |
| 5 | same arm + canary + PASS sequence again | steady state |

Pass criteria (ALL must hold):
1. Boot 4 and 5 print `v54 ENFORCEMENT VERIFIED (uid-drop test PASS...)`.
2. The archived receipt `logs/gd64_receipt_<boot_id>.txt` contains
   `gid canary OK` and `app-uid view entries=... marker=ABSENT
   control=present`.
3. Status line after stage-late: `[+] v2.3.0 | GKI-LKM | features: 7`
   and KSU Manager shows 7 features.
4. dmesg clean of oops/ud2; box stable; `ksu_susfs show version` still
   answers (the fixed transport root gate must still accept root).

Fail branches and what each means (the receipt names the branch):
- `FAIL gid canary (the transport gate still reads GID at cred+8)` →
  the old .ko is still loaded (flash didn't take, or the box picked a
  cached image) — check `post-fs-data: LKM candidate` + the sc_probe
  sha line, send the six logs, do NOT re-flash blindly.
- canary OK but `app-uid view ... marker=present` with
  `filtered=0` → gate reads uid correctly but the filter path didn't
  engage — send the receipt; next suspect is rule visibility at call
  time (readback `resolved slots_used` will say).
- `FAIL registration rejected` → the 0x55f55 path — send the receipt.
- `calls=0` in the post-test readback → getdents64 never reached our
  entry (dispatch) — send the receipt + dmesg.
- Freeze/panic after the arm → wedge recovery (rm enable_lkm +
  reboot), send all six logs; the ladder auto-disables next boot.

Wedge recovery (unchanged): `adb root; adb shell rm
/data/adb/ReSuSFS/enable_lkm; adb reboot` (or re-clone the instance).

## After the field run

Send: the six logs + any `gd64_receipt_*.txt` under
`/data/adb/ReSuSFS/logs/`. The sandbox will file the verdict in
memory/FINDINGS.md and cut the next rung (open/stat semantics, 32-bit
getdents, or set_uname — in that order of value).
