# ReSuSFS v54.2 (v26.11.56) FIELD TEST PLAN — the test fix + receipt persistence

## What happened to v54.1 (READ FIRST)

You flashed v26.11.55 over v54, ran 6 reboots, KSU Manager stayed at
**6 features**.  The fetched logs (upload/v55-field/, six files, all read)
prove a HUGE partial win plus one test-side failure:

- Boots 1-3 (11:15 → 11:22) re-climbed the stage ladder 0→2.
- Boot 4 (11:25:46) reached stage 3, self-test FULL green, then at
  **11:26:24**: `v54 gd64 arm OK (table[217] -> susfs_gd64_entry, preamble
  cloned)`.  **The v54 kCFI panic is FIXED** — the box survived the arm,
  the filter ran with a live registered rule for ~3 minutes until your
  next reboot, and the stage-late status line even printed
  `[+] v2.3.0 | GKI-LKM | features: 7` at 11:26:28.  You did see 7
  features for one boot.
- One second after the arm (same clock second), the rung's own uid-drop
  self-test printed `v54 gd64 uid-drop test FAILED` → the ladder DISABLED
  the enforcement rung (a filter that fails its own test must not run).
- Boots 5-8 (11:29 → 11:39) all print `v54 gd64 ladder DISABLED` and show
  6 features.  That is the 6 you are seeing: the stage-3 transport is
  healthy; the enforcement rung is switched off by its own verdict.

## Root cause (reproduced offline, not just deduced)

The v54.1 uid-drop test read **ONE 4096-byte getdents64 batch** of
/data/local/tmp and required the marker file to sit inside that batch
(`v54_find_entry(dbuf, n, marker, &ino) != 1` → "FAIL marker not present in
the root listing").  On a busy directory the marker lands anywhere in
readdir hash order — a 30000-entry host directory makes the OLD binary
print the exact field failure while the NEW walk finds the marker
(scripts/test_sc_probe_walk_host.sh, run this session):

```
---- old v54.1 probe on the big dir ----
v54_test: FAIL marker not present in the root listing     <-- the field failure class
---- new probe on the same dir ----
v54_test: root walk entries=30004 marker=found control=found
v54_test: marker resusfs_v54_gdtest_marker ino=297807
```

Why nothing caught it offline: the v54 host tests exercised the FILTER
with synthetic 3-entry buffers (single batch by construction) — no test
ever ran the TEST ITSELF against a listing bigger than one batch.

A second gap made the failure undiagnosable: the test's detailed output
(views + gd64 stats) went only into `logs/sc_selftest.txt`, which every
next boot's self-test OVERWRITES.  By the time we fetched the logs, boot
4's receipt was gone.  That is a process bug and it is fixed too.

## The fix (v54.2, module v26.11.56) — USERSPACE ONLY, kernel untouched

**The two .kos are BYTE-IDENTICAL to the field-run v26.11.55**
(sha256-asserted at packaging: `bf8516fb…` android13, `5014323b…`
vanilla).  The kernel side is field-proven: arm OK, no panic, filter
harmless with a live rule.  What changes:

1. **sc_probe gd64_test v2 — full-directory walk.**  Every view (root
   before registration, root after, app-uid 101234) walks the WHOLE
   directory: 32 KB getdents64 batches until the kernel returns 0.  Each
   view prints its entry count, so the receipt is self-diagnosing
   (`app-uid view entries=<e2-1>` proves the filter engaged and hid one).
   The verdict no longer depends on readdir order, hash layout, or
   directory size.
2. **Receipt persistence.**  boot-completed.sh archives the arm+test
   receipt to `logs/gd64_receipt_<boot_id>.txt` immediately after the arm
   AND after the test.  A future failure names its own failing check even
   after later boots overwrite sc_selftest.txt.
3. **module.prop v26.11.56 / versionCode 135** — the flash re-bases the
   ladders automatically (arm_stage=0, the 'disabled' gd64 marker
   cleared), exactly like your 55-over-54 flash did.

Offline gates (all green this session): walk regression
(30000-entry dir: new finds, old misses, tiny dir still works),
18/18 ladder tests (now including "FAIL → receipt archived with the
views"), zip verification (change set exactly module.prop +
boot-completed.sh + sc_probe + .payload_stamp; both .kos sha256-identical
to v55; wire-dispatch lock; zero-ud2 + unchecked-helper re-check on the
shipped bytes; stock CLI untouched).

## Flash v26.11.56 over v26.11.55 — 5 reboots, ~2 min apart

The ladder re-bases on the version change, so this is the full climb
again (your v55 run proved this exact path: 0, 1, 2=OBSERVE, 3=FULL+arm).

| Boot | Expect in boot.log | Meaning |
|------|--------------------|---------|
| 1 | `module version changed ('v26.11.55-x86_64' -> 'v26.11.56-x86_64') - re-basing the stage ladder` + `writing arm_stage=0` | clean re-base, gd64 marker cleared |
| 2 | `writing arm_stage=1` | substep ladder climbing |
| 3 | `writing arm_stage=2`, self-test OBSERVE-ONLY | transport warming |
| 4 | `writing arm_stage=3`, self-test FULL, then `v54 gd64 arm OK ... receipt archived`, then **`v54 ENFORCEMENT VERIFIED (uid-drop test PASS: ...)`**, stage-late `[>] v54 add_resolved ...` lines, status `[+] v2.3.0 \| GKI-LKM \| features: 7` | **THE RUNG.**  This is the PASS line |
| 5 | same sequence again (steady state re-arms + re-tests + re-registers every boot), KSU Manager shows **7 features** | persistence confirmation |

Hypothesis under test: the v54.1 disable was the single-batch test
artefact; the kernel filter is already correct.  Reboot count: 5 (4 to
climb, 1 to confirm steady state) — your box is at 8 boots on v55, a
flash re-base resets the ladder, no extra boots needed.

## PASS criteria (any one of these lines)

- `boot-completed: v54 ENFORCEMENT VERIFIED (uid-drop test PASS: app-uid
  listings lose the registered entry, root keeps everything)` — boot 4
- stage-late `[>] v54 add_resolved <path>` lines (the config rules
  registered resolved)
- `features: 7` in the status line / KSU Manager (SUS_PATH armed)

## Failure modes and what each outcome means

| Receipt | Meaning | Next action |
|---------|---------|-------------|
| `v54_test: root walk entries=N marker=MISSING` | the marker file could not be created or seen even as root (storage/SELinux issue on /data/local/tmp) — NOT a filter problem | send logs; we move the test dir |
| `v54_test: FAIL registration rejected (rc/err)` | the 0x55f55 wire broke | send the archived receipt; module-side fix next rung |
| `root view marker=ABSENT` | the filter touched root (uid gate) — would contradict the green root-gated self-test in the same boot | send receipt; uid-gate audit |
| `app-uid view entries=<same as root> marker=present` | the filter did NOT engage for the app call (uid read at filter time) | send receipt; the receipt also carries the gd64 stats (calls/filtered) so this is immediately decidable |
| `app-uid view marker=ABSENT control=ABSENT` | the filter over-hid or the listing broke | send receipt; compact-loop audit |
| freeze during the arm (next boot: `stale 'try' marker`) | the v54 death class — NOT expected, v54.1 survived this exact step in the field | send logs; recovery: `adb root; adb shell rm /data/adb/ReSuSFS/enable_lkm; adb reboot` |
| `v54 gd64 arm REJECTED (err != 0)` | the arm validations refused (table clobbered etc.) | send the archived receipt |

Whatever happens, **the archived receipt `logs/gd64_receipt_<boot_id>.txt`
plus the usual six logs make the next step decidable without another
blind run.**

## After PASS

Enforcement is live: your susfs_config.txt paths are hidden from app
uids every boot (resolved (name,ino) rules, re-registered each boot).
Next rung candidates: set_uname/set_cmdline rung, KSU-allowlist uid
exemption, getdents(78) if anything on the box still uses it.
