# ReSuSFS v26.11.52 Field Test Plan — THE CMD-TABLE FIX

## What changed (and nothing else)

Your v51 run proved the whole stack works: the ladder completed all 10 boots
(substeps 0-7, arm_stage 1-3, zero wedges) and `ksu_susfs show version`
**answered `v2.3.0` for the first time on this box**. `show variant` and
`show enabled_features` failed because the module's two command ids were
**swapped** versus the stock CLI's wire ABI:

| cmd (wire) | the stock CLI's command | payload shape |
|-----|-------------------------|---------------|
| 0x555e1 | show version | 20 bytes (str[16] + err@16) |
| 0x555e2 | show enabled_features | 8196 bytes (str[8192] + err@8192) |
| 0x555e3 | show variant | 20 bytes (str[16] + err@16) |

v51 answered 0x555e2 with the 20-byte variant string (the CLI read `err` at
+8192, still its own preset 126 -> "failed") and dumped 8196 feature bytes at
0x555e3 (the CLI read `err` at +16 -> feature-name bytes -> "failed").

v52 corrects the two constants. Same clang accept path, same calibrated uid
gate, same ladder. New safeguards: a build-time **wire-dispatch lock**
(disassembles the shipped .ko and requires e2->features / e3->variant in the
machine code), literal-id host test cases, and **sc_probe now installs to
/data/adb/ksu/bin and runs in every self-test** (it always had the right
table; its exec bit was the reason it never ran before).

## Test A — quick verify on your CURRENT box (4 reboots)

Flash `ReSuSFS-x86_64-v26.11.52.zip` **over the existing install** (keep
`enable_lkm` + `enable_force_init`). The 51->52 upgrade re-bases the stage
ladder automatically; the substep ladder stays at 7. Reboot 4 times:

1. reboot 1 -> arm_stage 0 (evidence + layers)
2. reboot 2 -> arm_stage 1
3. reboot 3 -> arm_stage 2 (OBSERVE - the proven rung)
4. reboot 4 -> arm_stage 3 (FULL - the answers)

## Test B — clean-room (your standard 10-reboot run)

Fresh LDPlayer instance, flash v52, 10 reboots. The substep ladder also
starts from 0: boots 1-8 climb substeps 0-7 (stage 1 at boot 8), boot 9 =
stage 2 (OBSERVE), boot 10 = stage 3 (FULL).

## Expected stage-3 self-test output (boot-completed, ~40s after boot)

```
-- ksu_susfs show version (timeout 3):
v2.3.0
-- ksu_susfs show variant (timeout 3):
GKI-LKM
-- ksu_susfs show enabled_features (timeout 3):
SUSFS_LKM_MODULES
CONFIG_KSU_SUSFS_SUS_MOUNT
CONFIG_KSU_SUSFS_ENABLE_LOG
CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
CONFIG_KSU_SUSFS_OPEN_REDIRECT
CONFIG_KSU_SUSFS_SUS_MAP
---- sc_probe (/data/adb/ksu/bin/sc_probe, raw syscall view, independent of any CLI) ----
... show_version cmd=0x555e1 -> syscall rc=0, payload.err=0 (answered) ...
... show_variant cmd=0x555e3 -> syscall rc=0, payload.err=0 (answered) ...
```

The status line should read:
`[+] v2.3.0 | GKI-LKM | n <features>` (variant printed, no "failed").

## If anything hangs

One wedge boot maximum by design (stale try-marker demotion, next boot
stands down). Send back the five logs:
`logs/init_trace.txt + logs/diag_last.txt + logs/boot.log +
logs/kernel_facts.txt + logs/sc_selftest.txt`

## Known limits (unchanged this rung)

Feature commands (`add_sus_path`, `set_uname`, ...) answer not-handled (CLI
keeps 126) - the susfs list application lights up rung by rung from v53.
