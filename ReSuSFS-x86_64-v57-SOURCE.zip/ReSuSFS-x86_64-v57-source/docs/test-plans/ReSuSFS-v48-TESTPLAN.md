# ReSuSFS x86_64 v26.11.48 — Field Test Runbook (the short one)

Target box: **LDPlayer 14 (Android 13, kernel `5.15.178+` x86_64, KernelSU-Next built-in)**
Module zip: `ReSuSFS-x86_64-v26.11.48.zip` (versionCode 126)

**Total reboots required: 1.** The v47→v48 upgrade is a transport fix: the ladder
is PRESERVED (your box is parked at stage 3, the ceiling), so there is no
re-base and no re-climb. The first v48 boot re-arms the transport at the parked
rung — on the dispatch path this kernel actually executes — and the self-test
runs in FULL mode on that very boot.

What v48 fixes (both root causes of the dark v47 channel, proven from your
x9/x10 logs + the KernelSU-Next source):

1. **Kernel side.** Your kernel's built-in KernelSU-Next patched
   `do_syscall_64`/`x64_sys_call` at boot so every syscall dispatches through
   `sys_call_table[nr]` — v47's patched dispatcher arm was dead code
   (`sc_entry_count` 0 on both transport boots). v48 patches the LIVE
   `sys_call_table[173]` entry instead, after a liveness check that finds
   KernelSU-Next's own `ksu_syscall_dispatcher` in the table.
2. **Userspace side.** The `ksu_susfs` your box ran was the STOCK
   reboot(169)-riding binary (a symlink the old installer rule kept) — it can
   never ride the 173 transport. v48 force-installs the module's own
   173-riding CLI (one-time backup at `/data/adb/ReSuSFS/ksu_susfs.pre-v48.bak`)
   and re-verifies the bytes every boot.

---

## Phase A — zero reboots, on the box as it sits right now (optional, 2 minutes)

This banks the pre-flash kernel-side proof. `sc_probe` speaks the supercall
ABI directly (no CLI involved):

```sh
adb push sc_probe /data/local/tmp/sc_probe
adb shell su -c 'chmod 755 /data/local/tmp/sc_probe; /data/local/tmp/sc_probe'
```

Expected on the current v47 boot (dead-arm transport):

```
ReSuSFS v47 transport probe (syscall 173 / 0xDEADBEEF / 0xFAFAFAFA)
sc_entry_count before: <unchanged>
show_version cmd=0x555e1 -> syscall rc=0xffffffffffffffea     (-22 = -EINVAL)
   payload.err=126 (0=ok/answered; 126=seed untouched, not answered)
...
sc_entry_count after: <same value>
```

That exact shape (real ioperm answering `-EINVAL` through the table while the
v47 wrapper count never moves) is the kernel-side confirmation of the v48
diagnosis before you flash anything. If you skip Phase A, nothing is lost.

## Phase B — flash v48 and boot ONCE (the decisive boot)

1. KernelSU manager → Install from storage → `ReSuSFS-x86_64-v26.11.48.zip`.
   During the flash the installer force-replaces the stale `ksu_susfs` (this
   is fix #2 firing; the old stock binary is backed up).
2. Reboot. Wait ~60–90 s after the home screen.
3. The one quick check:

```sh
adb shell su -c '/data/adb/ksu/bin/ksu_susfs show version'
```

**PASS = it prints `v2.3.0`.** That is the campaign goal line — the supercall
channel answering end to end. Also expected, same boot:

```sh
adb shell su -c '/data/adb/ksu/bin/ksu_susfs show variant'             # GKI-LKM
adb shell su -c '/data/adb/ksu/bin/ksu_susfs show enabled_features'    # 6-line list
adb shell su -c 'cat /sys/module/susfs_guard_lkm/parameters/sc_entry_count'   # >= 3
```

**The receipts that prove WHY it now works** (in `diag_last.txt`, in order):

```
supercall: v48 table transport: sys_call_table at 0xffffffff8205f1d0, table[173]=0xffffffff81027650, kallsyms __x64_sys_ioperm=0xffffffff81027650, ksu_syscall_dispatcher at 0xffffffff8170dc00 found in 1 entry
supercall: table[173] redirected -> susfs_sc_entry (orig __x64_sys_ioperm, mode=FULL) - the LIVE dispatch entry on this KernelSU-Next kernel
supercall: transport LIVE - sys_call_table[173] entry, mode=FULL; no kprobe registered anywhere; KernelSU's reboot slot untouched
```

And in `boot.log`:

```
post-fs-data: transport-fix upgrade ('v26.11.47-x86_64' -> 'v26.11.48-x86_64') - rung semantics unchanged, ladder PRESERVED (...)
post-fs-data: ksu_susfs at /data/adb/ksu/bin/ksu_susfs does not match the module's v48 CLI (...) - replacing it (previous copy backed up at ...)
```

**FAIL shapes:**
- `ksu_syscall_dispatcher not found in the table - the table may be inert ... falling back to the arm scan` — the liveness proof refused; the module fell back to the v47 arm (known-dead here). Send the logs; that receipt names the next move.
- A freeze at/after the self-test — cold-start the instance; the ladder demotes and writes the WEDGE DOSSIER exactly as before. Send the five logs.

## Phase C — acceptance suite (same boot, no reboot)

```sh
adb shell su -c '/data/adb/ksu/bin/ksu_susfs enable_log 1'
adb shell su -c 'echo test > /data/local/tmp/t; /data/adb/ksu/bin/ksu_susfs add_sus_map /data/local/tmp/t'
adb shell su -c 'echo x > /data/local/tmp/f; /data/adb/ksu/bin/ksu_susfs add_open_redirect /data/local/tmp/t /data/local/tmp/f 0'
adb shell su -c '/data/adb/ksu/bin/ksu_susfs hide_sus_mnts_for_non_su_procs 1'
adb shell su -c '/data/adb/ksu/bin/ksu_susfs set_cmdline_or_bootconfig /data/adb/ReSuSFS/configs/cmdline_or_bootconfig.txt'
adb shell su -c '/data/adb/ksu/bin/ksu_susfs enable_avc_log_spoofing 1'
# retired classes still fail BY DESIGN (sus_path / set_uname / kstat):
adb shell su -c '/data/adb/ksu/bin/ksu_susfs add_sus_path /data/local/tmp/nope'   # -> fails
```

Each accepted command returns silently (rc 0); with `enable_log 1` the module
logs the rule additions in dmesg — the per-rule receipt.

## Optional boot 2 — stability confirmation

One more reboot to confirm the table transport re-arms cleanly across a
reboot cycle and the answers persist. Not required for the verdict.

## Log capture (after boot 1)

```sh
for f in boot.log init_trace.txt diag_last.txt sc_selftest.txt kernel_facts.txt; do
    adb shell su -c "cat /data/adb/ReSuSFS/logs/$f" > v48-boot1-$f
done
adb shell su -c 'dmesg' > v48-boot1-dmesg.log
```

`sc_selftest.txt` now carries the CLI sha256 and a sc_probe block
(`rc=0`, `payload.err=0`, counter moving) — the full end-to-end receipt.

---

## What the ceiling honestly includes (unchanged from v47)

Runtime-configurable at stage 3: **sus_map, sus_mount, open_redirect,
prop_view, spoof_cmdline, enable_log, avc_spoof**. Retired by field verdict
(v45 froze the box on their own layers, no supercall involved): **sus_path
file-hiding, the LSM class, uname, kstat, hide_syms**. That is a design
decision, not a bug you are testing for.
