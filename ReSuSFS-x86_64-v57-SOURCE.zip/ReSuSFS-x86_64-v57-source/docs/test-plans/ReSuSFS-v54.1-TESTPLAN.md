# ReSuSFS v54.1 (v26.11.55) FIELD TEST PLAN — the unchecked-forward hotfix

## What happened to v54 (READ FIRST)

You flashed v26.11.54, ran 6 reboots, KSU Manager stayed at **6 features**.
The fetched logs (upload/v54-field/, six files, all read) prove:

- Boots 1-4 (10:30:15 → 10:33:13) re-climbed the stage ladder to plan;
  boot 4's self-test was green, stage 3 healthy, marker 'ok'.
- Boot 4 (id `e3580bfc`) at **10:33:48** printed the last line it ever
  printed: "v54 gd64 ladder: arming the getdents64 filter".  No arm
  receipt, no uid-drop test, no stage-late section.  The next boot's
  post-fs-data begins 16 s later.
- Boot 5 found the stale 'try 1 e3580bfc...' marker → the ladder
  DISABLED the enforcement rung (its designed clean attribution: a death
  inside the rung never touches the stage-3 transport).  Boots 5-6
  healthy, 6 features.  **The ladder did exactly its job.**

## Root cause (proven offline from the field evidence)

The arm handler ran to completion (v53 recipe, all validations passed,
table[217] patched, verified).  Milliseconds later the first real
getdents64 entered `susfs_gd64_entry` and died at the forward:

```
  b8:  mov  $0x4fd4cb27,%r10d    ; expected pt_regs-fn hash (0xB02B34D9 negated)
  be:  add  -0x4(%rax),%r10d     ; read the 4 bytes BEFORE the saved handler
  c2:  je   ok
  c4:  ud2                        ; <-- kernel panic on the first getdents64
  c6:  jmp  *%rax
```

The module is built with clang-17 `-fsanitize=kcfi`, so the module-side
`orig(regs)` forward is a CHECKED indirect call.  But this kernel's
`__x64_sys_*` targets carry **no kCFI preamble** — field-proven by the
v53 arm receipt in diag_last.txt (ioperm orig window `[-16..-1)` =
`415e415c 49c35d5f fff4c6c7 ebebffff` = the previous function's
epilogue + padding).  The kernel's own dispatch calls table targets
UNCHECKED — that is why the stock kernel boots at all.  A checked
module-side forward reads epilogue garbage → mismatch → ud2 → panic.

Why nothing caught it offline: the host tests build with GCC (GCC emits
no kCFI checks at all), and the .ko verifier asserted OUR preamble (the
incoming check) — no test ever evaluated a module call site against a
real preamble-less target.

## The fix (v54.1, module v26.11.55)

Every forward to the saved handler rides `sc_v54_fwd()`: a noinline
`__attribute__((no_sanitize("kcfi")))` trampoline —

```
   0:  endbr64
   4:  mov  %rdi,%rax        ; fn
   7:  mov  %rsi,%rdi        ; regs -> first arg
   a:  jmp  *%rax            ; UNCHECKED - the kernel's own convention
```

Verified on the built object: **zero ud2 sites in the whole graft**
(v54 shipped with exactly 3 = the three forward paths), zero indirect
call/jmp sites left inside `susfs_gd64_entry` (clang merged the two
identical return-tail-paths into one jmp + one call).  New verifier
checks lock this in forever (build_v55_verify.py, 271 checks).
Behavior-transparent everywhere else: 45/45 host tests and 10/10 ladder
tests pass unchanged; the import set is byte-identical to the v54 set
that already resolved on the box; the scripts and sc_probe are
byte-identical (change set = module.prop + both .kos + .payload_stamp).

The arm receipt now also dumps the orig window bytes for getdents64
(field proof of the preamble-less window, like the v53 ioperm receipt).

## Flash + 5 reboots (no wipe)

Flash `ReSuSFS-x86_64-v26.11.55.zip` over v54 (or over v53.1 — same
result), then reboot.  The version change re-bases the ladder
automatically (arm_stage=0, stage_max=3, substeps stay 7; the disabled
gd64 marker from the v54 run is cleared by the re-base).

- Boot 1: stage 0 (re-base) — receipts "arm_stage 0 healthy"
- Boot 2: stage 1
- Boot 3: stage 2
- Boot 4: stage 3 + stage marker 'ok' — **the v54 boot 4 death point.
  This boot must now SURVIVE past the arm**: the difference is one
  unchecked trampoline.
- Boot 5: the enforcement rung — arm + uid-drop test + config
  registration (on boot 4 the ladder arms as soon as the marker is 'ok';
  if your boot 4 section shows "v54 ENFORCEMENT VERIFIED", boots 4 and 5
  collapse into one and the ladder is done early — that is a PASS too).
- Boot 6 (optional): steady state (arm + register + verify again).

Total: 5 reboots (4 for the re-climb + 1 for the enforcement rung).

**Important:** let each boot settle ~2 minutes (boot-completed runs at
~35-60 s; the v54 field reboots at ~60 s cadence were fine, but do not
reboot inside the first 90 s — the v54 death could not be distinguished
from a mid-script reboot partly because of the tight cadence).

## PASS receipts (boot 4 or 5, in boot.log / sc_selftest.txt)

1. `v54.1 ENFORCEMENT RUNG loaded (not armed): the forward ... is
   kCFI-UNCHECKED` — the v54.1 module is in.
2. `v54 gd64 arm OK (table[217] -> susfs_gd64_entry ...)` — the arm
   returned (the v54 boot died between the patch and this line).
3. `v54.1 ENFORCEMENT LIVE - table[217] -> susfs_gd64_entry (orig=0x...;
   orig window [-16..-1): xx xx xx xx ...)` — module-side receipt; the
   window bytes are the field proof of the preamble-less target.
4. `v54 ENFORCEMENT VERIFIED (uid-drop test PASS: app-uid listings lose
   the registered entry, root keeps everything)` — the filter works.
5. Stage-late: `[>] v54 add_resolved ...` lines registering the config
   paths (26 expected, missing ones skipped and retried next boot).
6. KSU Manager: **7 features** (SUS_PATH armed).  sc_probe readback:
   `gd64: installed=1`, `hidden >= 1` after the uid-drop test.
7. Box stays alive and stable (the whole point of the fix).

## FAIL modes and what the box does automatically

| Symptom at boot 4/5 | Meaning | Automatic behavior | Next action |
|---|---|---|---|
| Same death as v54 (last line = "arming", next boot "stale 'try'") | the unchecked forward did NOT fix it (new failure mode in the filter path) | ladder marks disabled; stage-3 transport stays live | send the six logs; do NOT re-flash |
| `v54 gd64 arm REJECTED ...` receipt | a validation refused (table/entry/handler mismatch) | ladder marks disabled, box healthy | send logs; readback will name the check |
| uid-drop test FAIL receipt | the filter forwards but does not hide (rules/ino mismatch) | ladder marks disabled, box healthy | send logs + `sc_probe readback` output |
| Box wedges at any point | freeze elsewhere | `adb root; adb shell rm /data/adb/ReSuSFS/enable_lkm; adb reboot` (or re-clone the instance) | send the six logs |
| All green but 6 features | SHOW bit not set | none (cosmetic) | send sc_selftest.txt |

## Manual confirmation (after PASS)

- Non-root file manager (or `adb shell run-as`/am start as an app uid):
  a registered path's directory entry is gone from listings; root still
  sees it; open/stat of the hidden path still works (sus_path semantics
  hide ENTRIES, not access).
- `sc_probe readback`: `gd64 stats: calls=N filtered=M hidden>=1`.

## Recovery (unchanged)

`adb root; adb shell rm /data/adb/ReSuSFS/enable_lkm; adb reboot` — or
re-clone the instance.  The v54.1 zip also simply re-flashes over v53.1.
