# ReSuSFS v26.11.54 — THE ENFORCEMENT BRIDGE — field test plan

## What this build is

v53.1 (field-proven FULL PASS, 2026-11-27) + the getdents64 enforcement
rung.  No base change, no new module params, no new stage: the same
stage-0..3 ladder, plus a PRIVATE arm command (0x55f54) the scripts issue
only after the stage-3 self-test passes.  Import set 13 -> 15
(__kmalloc, kfree).  See docs-DESIGN-v54.md for the full rationale.

## Flash-over (in place, NO wipe of /data/adb/ReSuSFS)

Flash ReSuSFS-x86_64-v26.11.54.zip over v53.1, then reboot 5 times.

The version change re-bases the stage ladder automatically (arm_stage=0,
stage_max=3, substeps stay at 7, the gd64_stage marker is cleared).

| boot | arm_stage | what happens | pass lines (boot.log) |
|------|-----------|--------------|----------------------|
| 1 | 0 | evidence-only init | "arm_stage 0 healthy (init done + boot completed) - next boot arms stage 1/3" |
| 2 | 1 | resolve-only + proc layers | "arm_stage 1 healthy ... next boot arms stage 2/3" |
| 3 | 2 | supercall OBSERVE | "arm_stage 2 healthy ... 3/3"; diag: "(stage 2, mode=OBSERVE-ONLY...)" |
| 4 | 3 | supercall FULL - v53 self-test | "arm_stage 3 healthy - at ladder max 3"; sc_selftest.txt: SHOW v2.3.0 / GKI-LKM / 6 flags; add_sus_path/loop + hide_sus_mnts exit=0; readback: "v54 ENFORCEMENT RUNG loaded (not armed)" |
| 5 | 3 | THE NEW RUNG: gd64 arm + test + registration | "v54 gd64 arm OK (table[217] -> susfs_gd64_entry...)" then "v54 ENFORCEMENT VERIFIED (uid-drop test PASS...)" then stage-late "[>] v54 add_resolved <name> ino=<n> (<path>)" for every existing config path |

Total: 5 reboots (4 for the re-climb + 1 for the enforcement rung).
A 6th reboot confirms steady state (arm + register + verify every boot).

## What to check on boot 5+ (the receipts)

logs/sc_selftest.txt:
- "---- v54 gd64_arm @ ..." then "gd64_arm ... payload.err=0"
- "---- v54 readback (arm state) ----" with:
  "---- v54 enforcement rung ----", "gd64: installed=1", stats line
  (calls=/filtered=/hidden=/alloc_fail=/copy_fail=), resolved rules list,
  "resolved slots_used=N/48"
- "---- v54 gd64_test @ ..." with:
  "v54_test: root view marker=present control=present"
  "v54_test: app-uid view marker=ABSENT control=present"
  "v54_test: PASS (enforcement end-to-end)"
- after stage-late, the readback's resolved table lists your config
  entries (TWRP etc.) with their inodes

boot.log:
- "boot-completed: v54 ENFORCEMENT VERIFIED (uid-drop test PASS: app-uid
  listings lose the registered entry, root keeps everything) - stage-late
  will register the config paths resolved"
- stage-late: "[>] v54 add_resolved TWRP ino=<n> (/storage/emulated/0/TWRP)"
  per existing config path; "[!] v54 skip missing path: ..." for absent
  ones (normal)

KernelSU Manager: the module now shows 7 features (SUS_PATH armed).

## Manual confirmation from the box (optional, zero reboots)

- adb shell ls /storage/emulated/0          (root/shell view: EVERYTHING visible - by design)
- from a NON-root app (any file manager without root): TWRP/MT2/... are
  GONE from the listing; direct open of the known path still works
  (upstream sus_path semantics - entries are hidden, not access)
- adb shell /data/adb/ksu/bin/sc_probe readback   (the live stats:
  hidden= counter grows as apps list the dirs)

## Failure modes (what the box does by itself)

| symptom | mechanism | next boot | what you do |
|---------|-----------|-----------|-------------|
| boot 1-4 freezes | the stage ladder's honest attribution (v53.1 logic) | retry or demote per the existing rules | send the six logs |
| boot 5 freezes AFTER "v54 gd64 arm OK" but before "ENFORCEMENT VERIFIED" | the arm receipt is the last sync'd line; the gd64_stage marker stays 'try' | next boot sees the stale 'try' -> writes 'disabled', NEVER arms again this version; stage-3 transport stays live (its marker was already 'ok') | send the six logs; the box is safe with enforcement off |
| arm REJECTED (err=-22 in sc_selftest.txt) | refusal gates (transport down / table[217] clobbered / flags!=0); the readback names the reason in dmesg | marker -> 'disabled' immediately | send dmesg.txt + sc_selftest.txt |
| uid-drop test FAILS (marker visible to uid 101234) | filter logic or the (name,ino) rule did not match; enforcement disabled by the script (a filter that fails its own test must not run) | stays 'disabled' | send sc_selftest.txt - the readback counters (calls/filtered/hidden) localize it |
| app breaks (Play Store, camera, file picker crash) | the filter touched something it should not have | rungs can be disabled manually: adb shell echo disabled > /data/adb/ReSuSFS/gd64_stage (next boot: enforcement off, everything else stays) | report which app; the readback's hidden= and the app's uid are in the logs |

## Wedge recovery (unchanged)

adb root; adb shell rm /data/adb/ReSuSFS/enable_lkm; adb reboot
(or re-clone the instance).

## After v54 passes

- v55 candidates: set_uname (0x55590) + set_cmdline rung; KSU-allowlist
  uid exemption (needs a verified symbol contract); per-descendant
  registration for subtree hiding; getdents(78) compat coverage.
