# ReSuSFS x86_64 v26.11.49 — Field Test Runbook (the kCFI preamble climb)

Target box: **LDPlayer 14 (Android 13, kernel `5.15.178+` x86_64, KernelSU-Next built-in)**
Module zip: `ReSuSFS-x86_64-v26.11.49.zip` (versionCode 127)

**Total reboots required: 4** (the ladder re-bases on the v48→v49 version
change — deliberately: the transport itself changed, so every rung re-validates
under the live-fire self-test). Boots 1–3 are low-risk; boot 4 (stage 3) is the
one that matters. **If any stage-2/3 boot wedges, the NEXT boot demotes the
ladder automatically — power-cycle once, let it climb back, and send logs. The
v48-style infinite wedge loop is structurally impossible now.**

---

## What v49 fixes (root cause of the five v48 freezes, convicted from your logs)

**Why every v48 boot froze ~2–5 s after the launcher appeared.** The last
boot.log line of all five boots was `supercall self-test starting` — the box
died at the **first `syscall(173)` ever dispatched through the patched
`sys_call_table[173] = susfs_sc_entry`**. Your v47 boots (x9/x10) sent the
same syscalls through the same call site with the original entry and returned
unharmed — so the call site inspects its target before calling.

This kernel is a clang-17 LTO build with **kCFI** enforced (your kallsyms
carries `is_cfi_preamble_symbol` and `cfi_suffix`). The live dispatch path is
KernelSU-Next's `my_x64_sys_call` — which is **not** `__nocfi` — so its
`ksu_syscall_table[nr](regs)` is type-checked on every dispatch: every real
entry carries a **4-byte type hash immediately before its address**. v48's
raw-asm thunk had none → the check read garbage at `[susfs_sc_entry - 4]` →
compare failed → kernel died, 5/5 boots, frozen launcher = the last
framebuffer.

**The fix.** `susfs_sc_entry` now has a 4-byte preamble slot at exactly
`entry − 4`. At install time the module copies the 4 bytes that precede the
**original** `__x64_sys_ioperm` entry — by construction the exact type hash
this call site already accepts — into that slot (verified read-back), and only
then patches the table. On a kernel without kCFI the copied word is inert dead
bytes. Safe under both regimes; satisfies both KernelSU-Next dispatch shapes.

**The wedge-loop hole, closed.** Each v48 boot had already written its ladder
`ok` marker *before* the self-test, so the next boot re-armed stage 3 every
time. v49 defers the confirmation of any transport-armed boot until *after*
the self-test survives; a wedge leaves the `try` marker stale and the ladder
demotes itself on the next boot.

---

## Phase 0 — if the box is currently wedged at v48 (read this first)

The v48 boot loop needs no manual un-brick if you can flash: **flashing v49 is
itself the fix** — the first v49 post-fs-data sees the version change, re-bases
`arm_stage=0`, and the transport stays disarmed until boot 3.

If you cannot flash in the live window (~60 s after launcher), un-brick with
either of:

```sh
# via adb while the box is up (any time in the live window):
adb shell su -c 'rm /data/adb/ReSuSFS/enable_lkm /data/adb/ReSuSFS/enable_force_init'
#   (boot fully clean; re-add both flags after v49 is installed:
#    touch /data/adb/ReSuSFS/enable_lkm /data/adb/ReSuSFS/enable_force_init)

# or from recovery: mount /data, then
rm /data/adb/modules/ReSuSFS/disable 2>/dev/null   # ensure module enabled
rm /data/adb/ReSuSFS/enable_lkm /data/adb/ReSuSFS/enable_force_init
```

Deleting `enable_lkm` alone leaves the module installed but inert (the
proven-safe zombie image state) — root and everything else keep working.

---

## Phase A — flash (reboot 1: stage 0, evidence boot)

1. Flash `ReSuSFS-x86_64-v26.11.49.zip` in the KernelSU manager.
2. Reboot. Watch the launcher come up and **stay up**.
3. After ~90 s pull the receipts:

```sh
adb shell su -c 'grep -E "version changed|re-basing|LKM load|self-test" /data/adb/ReSuSFS/logs/boot.log | tail -8'
```

Expected markers: `module version changed ('v26.11.48-x86_64' -> 'v26.11.49-x86_64') - re-basing the stage ladder (arm_stage=0, stage_max=3 ...)`, the vanilla candidate loading, substep-7 init at stage 0 completing, **no self-test** (stage 0 < 2). Box stays healthy — 10 layers stay dark at this rung.

## Phase B — reboots 2 and 3 (stage 1 gates, stage 2 = transport OBSERVE + first live fire)

Reboot 2 (stage 1): the fp/umount/allow gates arm. After ~90 s:

```sh
adb shell su -c 'tail -4 /data/adb/ReSuSFS/logs/boot.log'
```

Expect `arm_stage 1 healthy - next boot arms stage 2/3`.

Reboot 3 (stage 2 — **the first live fire through the patched entry**): the
transport installs in OBSERVE mode and the self-test issues the first real
`syscall(173)`. After ~120 s:

```sh
adb shell su -c 'cat /data/adb/ReSuSFS/logs/sc_selftest.txt; echo; grep -E "DEFERRED|self-test" /data/adb/ReSuSFS/logs/boot.log | tail -6'
```

Success criteria (all four):
1. The box is alive (you just ran adb on it) — the preamble works.
2. `sc_selftest.txt` shows `before: sc_entry_count=0` and **`after: sc_entry_count=3`** (or ≥3) — the wrapper is being entered through the patched entry.
3. Each `ksu_susfs show ...` prints its **suffixed** failure line (observe mode passes through to ioperm by design — the answer comes at stage 3).
4. boot.log shows `ladder confirmation DEFERRED until the supercall self-test survives (v49)` followed by `arm_stage 2 healthy (init done + supercall self-test SURVIVED ...) - next boot arms stage 3/3`.

Also grab the diag receipts (they name the replicated hash):

```sh
adb shell su -c 'grep -A2 "v49 table transport" /data/adb/ReSuSFS/logs/diag_last.txt'
```

Expected: `kcfi PRESENT (is_cfi_preamble_symbol at 0x...)`, `entry preamble 0x........ (siblings same=... diff=0)`, `kcfi preamble replicated into the thunk (0x........ ...)`, then `table[173] redirected -> susfs_sc_entry (orig __x64_sys_ioperm, kcfi 0x........, mode=OBSERVE-ONLY)`.

**If this boot wedges** (launcher frozen, adb dead): power-cycle once. The
next boot prints the WEDGE DOSSIER and caps `stage_max=1` (transport retired
automatically). Send the logs listed in Phase E — the dossier plus
`sc_selftest.txt` will show exactly how far the first dispatch got.

## Phase C — reboot 4 (stage 3 = transport FULL — the payoff boot)

Reboot. After ~120 s:

```sh
adb shell su -c 'cat /data/adb/ReSuSFS/logs/sc_selftest.txt'
```

**The success shape — for the first time on this box:**

```
---- v49 supercall self-test @ ... arm_stage=3 mode=FULL ----
before: sc_entry_count=<n>
-- ksu_susfs show version (timeout 3):
v2.3.0                       <-- THE ANSWER, in payload.err + the syscall return
-- ksu_susfs show variant (timeout 3):
GKI-LKM                      <-- THE ANSWER
-- ksu_susfs show enabled_features (timeout 3):
SUSFS_LKM_MODULES
CONFIG_KSU_SUSFS_SUS_MOUNT
CONFIG_KSU_SUSFS_SUS_MAP
...                          <-- the armed feature list
after: sc_entry_count=<n+3>
```

Then the channel is yours at runtime:

```sh
adb shell su -c 'ksu_susfs show version; ksu_susfs show enabled_features'
```

And runtime configuration (sus_mount/sus_map/open_redirect/prop_view/cmdline
rules) now works through the same channel — the 10 armed layers are
configurable for the first time.

## Phase D — soak (no reboots)

Use the box normally for 30+ minutes: launcher, apps, the manager, the
file explorer with the allowlisted uid. The patched entry now carries live
traffic on every syscall-173; anything odd, grab:

```sh
adb shell su -c 'dmesg > /data/adb/ReSuSFS/logs/dmesg_soak.txt; cat /sys/module/susfs_guard_lkm/parameters/sc_entry_count'
```

## Phase E — what to send back

- If everything worked: `boot.log`, `sc_selftest.txt`, `diag_last.txt` from the stage-3 boot (one paste is enough).
- If anything wedged: `logs/init_trace.txt` + `logs/diag_last.txt` + `logs/boot.log` + `logs/kernel_facts.txt` + `logs/sc_selftest.txt` — the WEDGE DOSSIER at the top of the next boot's boot.log names the exact rung.

---

### Why 4 reboots and not 1

The v47→v48 upgrade skipped re-validation ("rung semantics unchanged") and the
box paid for it five wedged boots in a row. v48→v49 changes the installed
entry itself, so each rung is re-proven under the self-test before the ladder
trusts it — and the deferred confirmation means a bad rung can cost at most
**one** wedged boot, never a loop.
