# ReSuSFS v53.1 TEST PLAN — honest wedge attribution (script-only hotfix)

## What v53.1 is (and is NOT)

- **NOT a module change.** All three .kos are byte-identical to v53
  (vanilla `a7cdba36…`, android13 `a9022989…`, ymuuu `859942da…`).
  The kernel-side behavior (transport, SHOW answers, feature rung) is
  exactly what the v53 TESTPLAN describes.
- **A scripts-only fix** in `post-fs-data.sh` + `module.prop`
  (version `v26.11.53.1-x86_64`, versionCode 132), triggered by the
  v53 field run of 2026-11-27.

## Why (the v53 field verdict, evidence in field-logs/v53-field/)

The v53 ladder (fresh install, 2026-11-27 07:29–07:49) ran substeps 0–6
clean, then the boot 8 `aab0e489…` dispatched STEP 7 with arm_stage=1 and
**froze before init ever ran**:

- `trace()` syncs after every line, so receipts are durable: the last
  receipt is `diag_printk=1 armed` (07:39:07); the `writing force_init=2`
  receipt that precedes the trigger write is ABSENT → **force_init was
  never written** → no module code ever ran on that boot.
- The +5s heartbeat is absent → the box was dead/frozen within ~5 s of
  the last receipt, with the module in the v38-proven **inert zombie**
  state (arm_stage / init_maxstep / diag_printk / kr_seed are all stock
  int/string params; only force_init=.set and probe=.get run module code).
- The old wedge handler demoted `stage_max` 3→0 on that false premise;
  every later boot ran unarmed → "susfs not working".
- The module binary is exonerated by construction for THIS freeze: same
  instruction sequence (v51 vs v53 disassembly diff: every stage-1 path
  identical, only `susfs_supercall_init` differs = the graft, stage-2
  code that did not run), and the freeze predates any stage-1 execution.

Root cause of the freeze itself: unattributable from the logs (no
pstore/ramoops on this kernel) — most plausibly a host/emulator-level
flake. The v53.1 ladder now treats such freezes as what they are.

## The v53.1 logic (offline-tested, scripts/test_v531_attribution.sh)

On a stale `try N` marker, extract the frozen boot's own init_trace
section:

- contains `writing force_init` → **real wedge** → demote as before
  (stage_max = N−1; stage-0 stand-down unchanged).
- does NOT contain it → **box-level freeze with init never triggered** →
  NOT stage-attributable → **retry the same rung unchanged**
  (`freeze_retries` counter; a 2nd consecutive freeze demotes to stay
  safe; any healthy `ok` boot resets the counter).
- The WEDGE DOSSIER now also collects `/sys/fs/pstore/*` +
  `/proc/last_kmsg` tails and prints the FREEZE DRILL (see below).

## Flash procedure and ladder

Flash `ReSuSFS-x86_64-v26.11.53.1.zip` over v53 (KernelSU module update).
The version change re-bases the stage ladder automatically:
arm_stage→0, stage_max→3, marker cleared; **the substep ladder stays at
seq=7** (do not wipe /data/adb/ReSuSFS — that would restart the 8-boot
substep climb).

- Reboot 1 (the flash reboot): stage 0, expect `STEP 7 COMPLETE` +
  `arm_stage 0 healthy - next boot arms stage 1/3`.
- Reboot 2: **stage 1 (the retried rung)** — the rung that froze last time,
  now with honest attribution if it freezes again.
- Reboot 3 (only if 2 healthy): stage 2 = OBSERVE (transport live, SHOW
  answers still err=126 by design; `sc_entry_count` moves).
- Reboot 4 (only if 3 healthy): stage 3 = FULL + the v53 self-test.

## Pass/fail receipts per boot

| Boot | PASS looks like | FAIL looks like |
|---|---|---|
| 1 (stage 0) | `STEP 7 COMPLETE`, `next boot arms stage 1/3` | any freeze → v53.1 logic classifies it (see below) |
| 2 (stage 1) | `STEP 7 COMPLETE` in ≤5 s, layers 0,1,2,10–16 `loading layer` lines in diag, `next boot arms stage 2/3` | freeze WITHOUT force_init receipt → `NOT stage-attributable: retrying rung 1` (auto-retry, reboot again); freeze WITH force_init receipt → real stage-1 wedge, demote, send logs |
| 3 (stage 2) | `supercall transport LIVE` diag line, CLI `show` still fails, `sc_entry_count` moves 0→3 | same classification rules |
| 4 (stage 3) | `ksu_susfs show version` → `v2.3.0`, variant → `GKI-LKM`, enabled_features list; `add_sus_path` / `add_sus_path_loop` / `hide_sus_mnts…` exit 0 silently; sc_probe readback prints the v53 feature-rung dump (`add_calls=… slots_used=…/32`) | same classification rules |

Total: **4 reboots** if everything passes (5 if one non-attributable
freeze is retried).

## FREEZE DRILL (if the box ever freezes — do this BEFORE hard reset)

```
adb shell su -c 'dmesg > /data/adb/ReSuSFS/logs/dmesg_freeze.txt; \
  cat /sys/module/susfs_guard_lkm/parameters/diag_log > /data/adb/ReSuSFS/logs/diag_freeze.txt; \
  cat /proc/modules > /data/adb/ReSuSFS/logs/modules_freeze.txt; sync'
```
and read the LDPlayer window for `XYZDIAG` EMERG breadcrumbs. If adb is
dead, hard-reset (or re-clone) — the v53.1 dossier will classify the
freeze honestly on the next boot either way.

## After stage 3 passes

The v53 TESTPLAN's stage-3 expectations apply unchanged (the feature
rung: add_sus_path/add_sus_path_loop stored, hide_sus_mnts recorded,
readback via sc_probe). v54 scope stays as planned: set_uname +
set_cmdline_or_bootconfig, then the enforcement-bridge design.

## Logs to send back

`logs/boot.log`, `logs/init_trace.txt`, `logs/diag_last.txt`,
`logs/kernel_facts.txt`, `logs/sc_selftest.txt` — plus
`logs/dmesg_freeze.txt` if the drill ran.
