# ReSuSFS v26.11.53 Field Test Plan — THE FIRST FEATURE RUNG

Built 2026-11-27 from the v52-proven base. Zip:
`download/ReSuSFS-x86_64-v26.11.53.zip`
SHA256 `17e4a41717d9501ec03b6f45b1bd66a3d2d67b566ef516d5f267397eaab782ee`
(568098 bytes; layout entry-identical to the v52 zip; changed files exactly:
module.prop, customize.sh, boot-completed.sh, README-DIAGNOSTIC.md,
the two graft .kos, .payload_stamp, bin/x86_64/sc_probe).

## 1. What v53 is (and is not)

The v52 clean-room run proved the whole SHOW channel. v53 keeps that
transport byte-for-byte (same clang-17 entry, same cloned 16-byte kCFI
preamble, same magic + calibrated-uid gate, same ladder) and adds the
FIRST FEATURE commands, using the stock CLI's own wire ids (decoded from
the shipped ksu_susfs binary, machine-checked at build time by the
extended wire-dispatch lock):

| cmd | command | v53 behavior |
|-----|---------|--------------|
| 0x55550 | add_sus_path | validate -> dedupe -> store (32-slot .data table) -> err=0 |
| 0x55553 | add_sus_path_loop | same, marked loop |
| 0x55561 | hide_sus_mnts_for_non_su_procs | toggle recorded -> err=0 |
| 0x55f53 | (private, sc_probe only) | readback dump: table + counters + toggle |

Error answers: bad path shape -> err=-22, overlong -> -36, table full ->
-28, duplicate -> err=0 (idempotent). `set_uname` (0x55590) and
`set_cmdline_or_bootconfig` (0x555b0) deliberately stay not-handled (next
rung). The stored paths are NOT yet enforced — accept+store is this rung.

Why it should not be able to wedge the box: the new handlers run only at
stage 3 behind the proven gates; they are clang-17 code inside the graft
(zero new imports — 13-symbol set asserted; zero .bss — storage in .data,
spill window untouched; zero base-module calls — only the kernel's own
_copy_from_user/_copy_to_user, already field-proven by the SHOW answers);
no locks, no allocation, no logging from the accept path; one capped
lock-xadd for slot allocation.

## 2. Test A — in-place flash-over (52 -> 53), 4 reboots

Flash v53 over v52. The module detects the version change
(`v26.11.52` -> `v26.11.53`) and re-bases the ladder automatically:
arm_stage=0, then 1, 2 (OBSERVE), 3 (FULL). **4 reboots**, ~2 min apart
as usual. The substep ladder does not re-run (substeps already complete).

| boot | expected rung | pass lines (boot.log) |
|------|---------------|----------------------|
| 1 | arm_stage 0 (re-base) | `module version changed ('v26.11.52-x86_64' -> 'v26.11.53-x86_64') - re-basing the stage ladder`, STEP COMPLETE, boot completed |
| 2 | arm_stage 1 (layers) | DIAG layers load, `arm_stage 1 healthy - next boot arms stage 2/3` |
| 3 | arm_stage 2 (OBSERVE) | self-test runs, `sc_entry_count` moves, SHOW answers still fail (observe = by design), `arm_stage 2 healthy` |
| 4 | arm_stage 3 (FULL) | **THE DECISIVE BOOT — see section 3** |

## 3. The stage-3 receipt (sc_selftest.txt, boot 4)

In order, all inside `---- v53 supercall self-test ... ----`:

```
-- ksu_susfs show version:            v2.3.0              (unchanged)
-- ksu_susfs show variant:            GKI-LKM             (unchanged)
-- ksu_susfs show enabled_features:   the armed list      (unchanged:
                                                          SUSFS_LKM_MODULES +
                                                          sus_mount/enable_log/
                                                          spoof_cmdline/
                                                          open_redirect/sus_map)
---- v53 FEATURE RUNG ----
-- add_sus_path /data/local/tmp/.resusfs_v53_selftest      (no output)
   exit=0                                                  <-- FIRST EVER
-- add_sus_path_loop /data/local/tmp/.resusfs_v53_selftest_loop
   exit=0
-- hide_sus_mnts_for_non_su_procs 1                        (no output)
   exit=0
-- regression: show version:          v2.3.0              (still answering)
---- sc_probe ... ----
show_version  cmd=0x555e1 -> rc=0 err=0, answer v2.3.0
show_variant  cmd=0x555e3 -> rc=0 err=0, answer GKI-LKM
v53_feature_readback cmd=0x55f53 -> rc=0 err=0
answer: v53-feature-rung add_calls=3 dups=0 toggle_calls=1 hide_mnts=1
[0] /data/local/tmp/.resusfs_v53_selftest
[1] /data/local/tmp/.resusfs_v53_selftest_loop (loop)
slots_used=2/32 loops=1
```

PASS = every line above present, zero Oops/BUG/panic/Call Trace, box
alive after the readback.

## 4. Test B — clean-room (optional, only if Test A wedges oddly)

Fresh instance (uninstall + reinstall, or wiped /data/adb/ReSuSFS) =
full 10-boot climb (substeps 0-7, then arm 1-3), same stage-3 receipt.

## 5. Per-outcome actions

| outcome | meaning | next action |
|---------|---------|-------------|
| All pass, zero wedges | feature channel proven end-to-end | v54: set_uname + set_cmdline_or_bootconfig, then the enforcement bridge design |
| add_* prints `susfs: add_sus_path failed (kernel err -N)` | handler ran, validation/storage refused: -22 shape, -36 overlong, -28 full | send sc_selftest.txt; no reflash needed — the receipt contains the errno |
| add_* still 126 (`failed`, no kernel err) | command never reached the dispatch (wire id mismatch — build-lock says it cannot be ids) | send sc_selftest.txt + diag_last.txt; check `feature before/after` counters moved |
| Box wedges at boot 4 self-test | first feature dispatch died (would contradict the all-clang/uaccess-only design) | recovery: `adb root; adb shell rm /data/adb/ReSuSFS/enable_lkm; adb reboot`; send the five logs — the wedge boot's own receipts stop at the exact call |
| Wedge earlier (boot 1-3) | NOT v53's code (feature path only runs at stage 3) — base regression | same recovery; send the five logs |

## 6. After PASS: real apply flows (optional, no reboots)

```
adb shell su -c 'sh /data/adb/modules/ReSuSFS/ReSuSFS.sh --apply-sus-paths'
adb shell su -c 'sh /data/adb/modules/ReSuSFS/ReSuSFS.sh --apply-toggles late'
/data/adb/ksu/bin/sc_probe          # readback now shows YOUR paths
```

Every line of sus_paths.txt should print `[>] add_sus_path <path>` with
no `failed` after it; the readback lists them.

## 7. The five logs to send after ANY anomaly

`logs/init_trace.txt`, `logs/diag_last.txt`, `logs/boot.log`,
`logs/kernel_facts.txt`, `logs/sc_selftest.txt`
