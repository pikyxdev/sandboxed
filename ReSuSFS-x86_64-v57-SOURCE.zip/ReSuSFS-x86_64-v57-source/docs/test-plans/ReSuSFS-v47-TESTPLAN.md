# ReSuSFS x86_64 v26.11.47 — Field Test Runbook

Target box: **LDPlayer 14 (Android 13, kernel `5.15.178+` x86_64, KernelSU built-in)**
Module zip: `ReSuSFS-x86_64-v26.11.47.zip` (versionCode 125)
Everything below was extracted from the actual shipped code — every expected log
line quoted here is a verbatim format string from the v47 module / shell ladder,
and every symbol/address was checked against YOUR field kallsyms dump
(`kernel_kallsyms.txt`).

---

## 0. The answer first: how many reboots

**4 reboots after flashing v47.** Each healthy boot advances the ladder exactly
one rung, and the box's `init_seq` is already 7 (the field state after the v45
campaign), so the substep ladder does NOT re-climb. The flash itself installs
the files; the first reboot after flashing IS ladder boot 1.

| Reboot | arm_stage | What that boot runs | What it PROVES | The one line to grep after it |
|---|---|---|---|---|
| 1 (install boot) | 0 / 3 | evidence boot: resolver + crosschecks, layer loop with all 20 layers SKIPPED | v47 module loads and inits cleanly on the new build | `next boot arms stage 1/3` |
| 2 | 1 / 3 | the 10 field-proven layers (sus_map, sus_mount, cmdline, open_redirect, prop_view, enable_log, avc_spoof + resolve-only fp_hook, ksu_umount_gate, ksu_allow_gate) | stage-1 set still healthy on the v47 build (regression check) | `next boot arms stage 2/3` |
| 3 | 2 / 3 | **THE TRANSPORT BOOT**: the module scans kernel text for the dispatcher's ioperm arm(s), patches the 4-byte rel32, self-test fires the FIRST live supercalls through syscall 173 — in OBSERVE mode (answers nothing) | the cold-arm redirect installs, executes, and survives a live supercall fire — the exact moment v45/v46 died at, now on a path with NO shared kprobe slot | `sc OBSERVE: susfs supercall seen` (dmesg) + `transport LIVE` (diag) + `next boot arms stage 3/3` |
| 4 | 3 / 3 | **THE ACCEPT BOOT**: transport switches to FULL; the self-test's `ksu_susfs show version / variant / enabled_features` now get ANSWERED | the supercall channel is fully live — `ksu_susfs` answers, runtime configuration commands land | `at ladder max 3 (the v47 ceiling` |

If a boot wedges, add 1–2 boots: the ladder demotes itself and writes the WEDGE
DOSSIER on the next boot automatically — you never re-flash, never manually
reset anything. If `init_seq` on your box is NOT 7 (check in step 1), add
`(7 − init_seq)` extra boots at the start — the ladder climbs one substep per
boot and `boot.log` names the next rung after every single boot, so you can
always just follow the receipts.

> **Field correction (2026-11-24, boots 08:02–08:20):** this install flashed
> with a FRESH state — the receipt says `module version changed ('' ->
> 'v26.11.47-x86_64')`, so `init_seq` was 0, not 7, and the box is doing the
> full climb. Exact count from the shipped ladder code: substeps 0→6 take 7
> boots; the substep-6 completion receipt ALSO arms stage 1 for the next boot,
> so boot 8 = layer loop @ stage 1, boot 9 = transport (stage 2), boot 10 =
> accept (stage 3). **10 healthy boots total; after the four banked boots
> (substeps 0–3, all PASS), 6 reboots remain.** The quick formula above
> overcounts by one because the substep-7 boot *is* the stage-1 boot.

> **Read this line twice:** stages 4/5 are PERMANENTLY retired on this kernel
> (v45 froze the box on their own layers with no supercall involved). The
> v47 ceiling is stage 3. `sus_path` file-hiding, the LSM class, uname and
> kstat stay dark — that is a design decision, not a bug you are testing for.

---

## 1. Before the first reboot (one adb session, no reboot yet)

Flash first: KernelSU manager → Install from storage → select
`ReSuSFS-x86_64-v26.11.47.zip` → let it install. Then, with the box still up
(the flash does not reboot by itself if you decline the reboot prompt), or
right after the flash from the manager's shell:

```sh
# module is the new build
adb shell su -c 'head -5 /data/adb/modules/ReSuSFS/module.prop'
#    expect: version=v26.11.47-x86_64  versionCode=125

# ladder state (expect 7; if not, see the note above)
adb shell su -c 'cat /data/adb/ReSuSFS/init_seq'

# the two opt-in flags (they likely already exist — touch is idempotent)
adb shell su -c 'touch /data/adb/ReSuSFS/enable_lkm /data/adb/ReSuSFS/enable_force_init'

# clear any stale stand-down marker (idempotent)
adb shell su -c 'rm -f /data/adb/ReSuSFS/no_init_this_boot'

# the patched CLI is in place (this is what will ride syscall 173)
adb shell su -c 'ls -l /data/adb/ksu/bin/ksu_susfs'
```

Then reboot (this is ladder boot 1).

---

## 2. What each boot looks like — timing

Every boot runs the same skeleton:

1. `post-fs-data.sh` (early boot): kernel recon → LKM image load (zombie) →
   ladder re-base/demotion bookkeeping.
2. System boots to desktop.
3. `boot-completed.sh` (right after home screen): seeds the resolver, writes
   `arm_stage` / `init_maxstep`, triggers `force_init=2` (the v43 SYNC
   channel, field-proven), polls `init_done` for 25 s while a 40 s heartbeat
   runs, then (stage ≥ 2) the supercall self-test fires.

**So: wait ~60–90 seconds after the home screen appears**, then run the check
command. The trigger, witness, and self-test have all completed by then.

---

## 3. Boot-by-boot procedure and expected log sequence

After each boot, the one quick check is:

```sh
adb shell su -c 'tail -n 15 /data/adb/ReSuSFS/logs/boot.log'
```

Read the "next boot arms stage N/3" (or "at ladder max") line it prints, save
the full logs locally (cheat-sheet in section 6), then reboot again.

### Boot 1 — stage 0/3, the re-base boot

What happens: post-fs-data sees the module version changed and re-bases the
stage ladder (`arm_stage=0`, `stage_max=3`), the LKM image loads, the resolver
seeds, the init body runs at substep 7 with every layer skipped.

**Expected `boot.log` sequence (the parts that matter):**

```
=== post-fs-data START (kernel: 5.15.178+, module: v26.11.47-x86_64) ===
post-fs-data: kernel_recon starting (gated, 60s)
post-fs-data: kernel_recon rc=0
[*] Loading susfs_guard_lkm-x86_64-vanilla-5.15.ko (ksud: ...)
[+] LKM loaded successfully (ksud: susfs_guard_lkm-x86_64-vanilla-5.15.ko)
post-fs-data: LKM load rc=0
post-fs-data: susfs LKM image is LIVE (image loaded)
post-fs-data: module version changed ('v26.11.45-x86_64' -> 'v26.11.47-x86_64') - re-basing the stage ladder (arm_stage=0, stage_max=3 - the v47 ceiling, stages 4/5 retired; stale marker cleared); the substep ladder stays
----- LKM live evidence (v26.11.28) ----
... (pre-init supercall live test: all three CLI calls fail — expected, init has not run yet) ...
post-fs-data: stage-early starting (gated, 120s)
=== post-fs-data DONE ===
=== boot-completed ===
boot-completed: seeding resolver (v2: kln/gsoff preferred, tables if visible)
boot-completed: kr_seed(v2) = <a seed string or the not-written receipt>
boot-completed: substep seq=7 armed (init_maxstep=7 arm_stage=0/3; ladder: 0=dispatch 1=+imports 2=+resolver 3=+gs_off 4=+deadman 5=+crosscheck 6=+patch 7=+layers; max=3)
init-trace: STEP 7/7 DISPATCHING (arm_stage=0/3 ...)
init-trace: trigger_mode=sync: writing force_init=2 ...
init-trace: force_init=2 write returned (sync body ran to completion inside the write)
boot-completed: substep 7 init COMPLETE (init_done=1 after Ns)
boot-completed: arm_stage 0 healthy (init done + boot completed) - next boot arms stage 1/3
boot-completed: stage-late starting (gated, 120s)
=== boot-completed DONE ===
```

(The exact old-version string in the "version changed" line depends on what is
on your box — v45 or v46; either way the receipt says the re-base happened.)

**Expected `diag_last.txt` (module receipts, abridged):** the layer loop logs
`DIAG step 6.x: layer N (name) SKIPPED (needs stage M > arm_stage 0)` for all
20 layers, then `DIAG step 7: layer loop done; self-hide/relabel SKIPPED`,
`loaded. This module is filtered out of /proc/modules ...`, and
`DIAG step 9: susfs_init_body RETURNING 0 (maxstep=7 laststep=7 init_done=1)`.

**PASS:** `next boot arms stage 1/3` + desktop up + `init_trace.txt` shows 8
heartbeats and `STEP 7 COMPLETE`.
**FAIL shapes:** `nok` (init did not finish in 25 s — just reboot again, same
rung retried); a real freeze → section 5.

---

### Boot 2 — stage 1/3, the ten-layer regression boot

Same skeleton; now the layer loop loads the 10 field-proven layers instead of
skipping them. Kernel text is NOT touched at this rung.

**Expected `boot.log`:**

```
post-fs-data: susfs LKM image is LIVE (image loaded)
...
init-trace: STEP 7/7 DISPATCHING (arm_stage=1/3 ...)
boot-completed: substep 7 init COMPLETE (init_done=1 after Ns)
boot-completed: arm_stage 1 healthy (init done + boot completed) - next boot arms stage 2/3
```

**Expected `diag_last.txt`:** `DIAG step 6.x: loading layer N (fp_hook, fatal=0)`
… for the stage-1 layers, `SKIPPED (needs stage M > arm_stage 1)` for the ten
stage-4/5 layers, and — the line that matters for boot 3 — the **supercall
layer is still SKIPPED at this rung** (`SKIPPED (needs stage 2 > arm_stage 1)`).

**PASS:** `next boot arms stage 2/3`.

---

### Boot 3 — stage 2/3, THE TRANSPORT BOOT (observe)

This is the rung that replaces the exact moment the box died twice in v45/v46:
the first live supercall fire. On v47 that fire goes through the dispatcher's
COLD ioperm(2) arm (syscall 173) — no kprobe anywhere, KernelSU's reboot slot
not on the path.

**Expected `boot.log`:** same skeleton with
`init-trace: STEP 7/7 DISPATCHING (arm_stage=2/3 ...)`, then:

```
boot-completed: substep 7 init COMPLETE (init_done=1 after Ns)
boot-completed: arm_stage 2 healthy (init done + boot completed) - next boot arms stage 3/3
boot-completed: supercall self-test starting (stage 2 mode=OBSERVE-ONLY; transport: dispatcher cold-arm redirect, nr 173)
---- v47 supercall self-test @ 2026-11-24 hh:mm:ss arm_stage=2 mode=OBSERVE-ONLY ----
before: sc_entry_count=0
-- ksu_susfs show version (timeout 3):
susfs: show version failed (no supercall answer, the module is not loaded)
-- ksu_susfs show variant (timeout 3):
susfs: show variant failed (no supercall answer, the module is not loaded)
-- ksu_susfs show enabled_features (timeout 3):
susfs: show enabled_features failed (no supercall answer, the module is not loaded)
after: sc_entry_count=3
NOTE: v47 transport rides syscall(173, 0xDEADBEEF, 0xFAFAFAFA, cmd, &payload); observe mode answers nothing BY DESIGN (the CLI prints its not-supported line); stage 3 answers in payload.err and the syscall return.
boot-completed: supercall self-test done (receipt: /data/adb/ReSuSFS/logs/sc_selftest.txt)
```

**The three CLI "failed" lines are EXPECTED here.** Observe mode answers
nothing by design — the PROOF the transport is live is the OTHER two receipts:

- `after: sc_entry_count=3` (was 0 before: three supercalls entered the
  wrapper, executed, and passed through to the original handler cleanly)
- the dmesg OBSERVE lines.

**Expected `diag_last.txt` (the transport receipts, in order):**

```
supercall: init entered, abi_layout_check next
supercall: cold handler __x64_sys_ioperm at 0xffffffff81027650 (nr 173; reboot's hot slot is NOT on this path)
supercall: scanning kernel text [_stext 0xffffffff81000000, _etext 0xffffffff81c01dd9) for E8/E9 -> __x64_sys_ioperm
supercall: scan found N arm(s) to __x64_sys_ioperm among MMMMMM branches
supercall: arm at 0x........ redirected -> susfs_sc_wrapper (orig __x64_sys_ioperm, mode=OBSERVE-ONLY)     [one line per arm]
supercall: transport LIVE - N arm(s) redirected (patched N), mode=OBSERVE-ONLY; no kprobe registered anywhere; KernelSU's reboot slot untouched
supercall delivery redirects the hardened dispatcher's cold ioperm(2) arm (nr 173) to susfs_sc_wrapper - no kprobe is registered anywhere, KernelSU's reboot slot is untouched; answers are written into payload.err by the wrapper in the caller's own syscall context
DIAG step 9: susfs_init_body RETURNING 0 (maxstep=7 laststep=7 init_done=1)
```

The addresses above are from your kallsyms dump: `_stext=0xffffffff81000000`,
`_etext=0xffffffff81c01dd9`, `__x64_sys_ioperm=0xffffffff81027650`. Expect
**N = 1–3 arms** — your kernel has the dispatcher at `x64_sys_call`
(0xffffffff810026e0) PLUS an LTO-duplicated fragment `my_x64_sys_call`
(0xffffffff8170db90); the scan covers both, that is by design.

**Expected `dmesg` (the decisive lines, kernel timestamps vary):**

```
[  NNN.NNNNNN] susfs_guard_lkm: sc OBSERVE: susfs supercall seen (cmd=0x555e1 uid=0) - stage 2 observes only, not answering
[  NNN.NNNNNN] susfs_guard_lkm: sc OBSERVE: susfs supercall seen (cmd=0x555e3 uid=0) - stage 2 observes only, not answering
[  NNN.NNNNNN] susfs_guard_lkm: sc OBSERVE: susfs supercall seen (cmd=0x555e2 uid=0) - stage 2 observes only, not answering
```

(cmd order: `0x555e1` show version, `0x555e3` show variant, `0x555e2` show
enabled_features. If they land within the same rate-limit burst, one or two may
be coalesced — the count receipt in `sc_selftest.txt` is the authoritative one.)

**PASS = ALL FOUR:**
1. desktop up, `next boot arms stage 3/3` in boot.log
2. `transport LIVE - N arm(s) redirected ... mode=OBSERVE-ONLY` in diag_last.txt
3. `after: sc_entry_count=3` in sc_selftest.txt
4. `sc OBSERVE: susfs supercall seen` in dmesg

That combination is the thing the whole v45→v47 arc was built to reach: a live
supercall fired through a hook this kernel does not share with KernelSU, with
the box still alive.

**FAIL shapes (section 5 for recovery):** box freezes at/after the trigger
window; or `NO direct arm to __x64_sys_ioperm found - refusing` in diag (clean
refusal — no patch was made, boot continues, init noks; that receipt is the
input a v48 table-entry patch would need); or `transport LIVE` present but
`sc_entry_count` stays 0 (patch landed, CLI didn't ride it — check
`/data/adb/ksu/bin/ksu_susfs` is the v47 one).

---

### Boot 4 — stage 3/3, THE ACCEPT BOOT (the ceiling)

The transport arms in FULL mode. The same self-test now gets ANSWERED.

**Expected `boot.log`:**

```
init-trace: STEP 7/7 DISPATCHING (arm_stage=3/3 ...)
boot-completed: substep 7 init COMPLETE (init_done=1 after Ns)
boot-completed: arm_stage 3 healthy - at ladder max 3 (the v47 ceiling: 10 layers live + the cold-arm supercall transport live; runtime configuration of the susfs lists works via ksu_susfs)
boot-completed: supercall self-test starting (stage 3 mode=FULL; transport: dispatcher cold-arm redirect, nr 173)
---- v47 supercall self-test @ 2026-11-24 hh:mm:ss arm_stage=3 mode=FULL ----
before: sc_entry_count=0
-- ksu_susfs show version (timeout 3):
v2.3.0
-- ksu_susfs show variant (timeout 3):
GKI-LKM
-- ksu_susfs show enabled_features (timeout 3):
SUSFS_LKM_MODULES
CONFIG_KSU_SUSFS_SUS_MOUNT
CONFIG_KSU_SUSFS_ENABLE_LOG
CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
CONFIG_KSU_SUSFS_OPEN_REDIRECT
CONFIG_KSU_SUSFS_SUS_MAP
after: sc_entry_count=3
NOTE: ...
boot-completed: supercall self-test done (receipt: /data/adb/ReSuSFS/logs/sc_selftest.txt)
```

The feature list is exactly the armed-at-stage-≤3 set (sus_path/uname/kstat/
hide_syms are stage-4/5 classes — retired — and stay absent; that is the honest
output, not a failure).

**Expected `diag_last.txt`:** same receipts as boot 3 but with
`mode=FULL` on the `redirected` and `transport LIVE` lines.

**dmesg:** no `sc OBSERVE` lines anymore (the wrapper accepts silently); if you
later send a command for a retired feature you will see
`susfs_guard_lkm: sc: cmd 0x55550 not handled (feature not armed?)` — expected
for sus_path/uname/kstat commands.

**PASS = THE CAMPAIGN GOAL:** `at ladder max 3 (the v47 ceiling` + the three
CLI answers above. `ksu_susfs` is fully live.

---

## 4. After parking at the ceiling — the acceptance suite

Run these from an adb root shell, in order (all of these are answered by armed
layers at stage 3):

```sh
adb shell su -c '/data/adb/ksu/bin/ksu_susfs show version'              # v2.3.0
adb shell su -c '/data/adb/ksu/bin/ksu_susfs show variant'             # GKI-LKM
adb shell su -c '/data/adb/ksu/bin/ksu_susfs show enabled_features'    # the 6-line list

# runtime-configurable commands — each returns silently (rc 0) when accepted:
adb shell su -c '/data/adb/ksu/bin/ksu_susfs add_sus_map /data/local/tmp/testfile'
adb shell su -c 'echo "test" > /data/local/tmp/fake; /data/adb/ksu/bin/ksu_susfs add_open_redirect /data/local/tmp/target /data/local/tmp/fake 0'
adb shell su -c '/data/adb/ksu/bin/ksu_susfs hide_sus_mnts_for_non_su_procs 1'
adb shell su -c '/data/adb/ksu/bin/ksu_susfs set_cmdline_or_bootconfig /data/local/tmp/cmdline.txt'
adb shell su -c '/data/adb/ksu/bin/ksu_susfs enable_log 1'             # turns susfs logging on
adb shell su -c '/data/adb/ksu/bin/ksu_susfs enable_avc_log_spoofing 1'

# RETIRED features — these fail BY DESIGN at the ceiling (stage-4/5 classes):
adb shell su -c '/data/adb/ksu/bin/ksu_susfs add_sus_path /data/local/tmp/x'   # -> "susfs: add_sus_path failed ..."
adb shell su -c '/data/adb/ksu/bin/ksu_susfs set_uname 5.15.178 test'         # -> fails (uname layer retired)
```

With `enable_log 1` on, the module's own logging is live and rule additions
show up in dmesg — that is the per-rule receipt. The observable *hiding
effects* per feature (what a non-root process actually sees) are the natural
next experiments once the channel is parked; the acceptance suite above is
what proves the runtime-configurable channel itself works end-to-end.

After the ceiling is confirmed, send the logs back (section 6) — that set is
the campaign deliverable for "SusFS working properly on x86_64" as far as this
kernel's retired classes allow, and the basis for deciding whether a v48
(arm-level bisect of the retired stage-4 layers, one rung at a time) is worth
attempting.

---

## 5. If a boot wedges — the wedge protocol

Nothing changes compared to v45/v46, and you never touch the ladder manually:

1. **If adb is still alive** (desktop frozen but shell responds — check with
   `adb shell su -c 'echo alive'`): capture the decisive evidence BEFORE
   rebooting:

   ```sh
   adb shell su -c 'dmesg > /data/adb/ReSuSFS/logs/dmesg_freeze.txt; cat /sys/module/susfs_guard_lkm/parameters/diag_log > /data/adb/ReSuSFS/logs/diag_freeze.txt; cat /proc/modules > /data/adb/ReSuSFS/logs/modules_freeze.txt; sync'
   ```
   (`init_trace.txt`'s witness TIMEOUT receipts print this same command when
   it happens.)

2. **If adb is dead too:** restart the instance in LDPlayer (power-cycle).
   The next boot's post-fs-data finds the stale `try N <boot_id>` marker,
   writes the **WEDGE DOSSIER into boot.log** (init_trace receipts + the
   salvaged diag snapshot), demotes to a stage-0 evidence boot, and caps the
   ladder BELOW the wedging rung — permanently for that rung.

3. Pull and send back the five logs (+ the freeze captures if you got them):

   ```sh
   for f in boot.log init_trace.txt diag_last.txt kernel_facts.txt sc_selftest.txt; do
       adb shell su -c "cat /data/adb/ReSuSFS/logs/$f" > "v47-wedge-$f"
   done
   adb shell su -c 'cat /data/adb/ReSuSFS/logs/dmesg_freeze.txt' > v47-wedge-dmesg.txt   # if captured
   ```

What the signatures mean:

| Signature | Meaning |
|---|---|
| freeze during boot 3's trigger window, heartbeats STOP | the transport rung (scan/patch/first fire) wedged — the decisive receipts are in diag_last.txt up to the last `supercall:` line; next boot caps stage_max at 1 (transport off) and the box is safe |
| clean boot 3, freeze during boot 4 | transport PROVEN (stage 2 clean), the accept path convicted — next boot caps at 2 (observe-only transport stays live, accepts off) |
| `supercall: NO direct arm to __x64_sys_ioperm found - refusing` | clean refusal, NO patch made, no risk — this kernel's dispatcher is not direct-call shaped where it matters; that receipt is exactly the input a v48 table-entry patch needs |
| `supercall: ksu_patch_text FAILED ...` / `write did not stick` | the text-write primitive refused — no patch made, safe; the receipt names the site |
| `nok` receipts but boots complete | init slow/stalled, NOT a wedge — just reboot again, the same rung retries |
| witness `PARAM READ TIMEOUT` receipts, heartbeats BEATING | module param traffic deadlocked but kernel alive — run the capture command in (1) before rebooting |

---

## 6. Log capture cheat-sheet (per boot)

Run after each boot (60–90 s after home screen), keeping per-boot copies:

```sh
# quick ladder check (the "next boot arms stage N/3" line):
adb shell su -c 'tail -n 15 /data/adb/ReSuSFS/logs/boot.log'

# full capture for boot N (replace N):
adb shell su -c 'cat /data/adb/ReSuSFS/logs/boot.log'        > v47-bootN-boot.log
adb shell su -c 'cat /data/adb/ReSuSFS/logs/init_trace.txt'   > v47-bootN-init_trace.txt
adb shell su -c 'cat /data/adb/ReSuSFS/logs/diag_last.txt'  > v47-bootN-diag_last.txt
adb shell su -c 'dmesg'                                      > v47-bootN-dmesg.log
adb shell su -c 'cat /data/adb/ReSuSFS/logs/sc_selftest.txt' > v47-bootN-sc_selftest.txt
# once (any boot):
adb shell su -c 'cat /data/adb/ReSuSFS/logs/kernel_facts.txt' > v47-kernel_facts.txt
```

Upload the set for boots 3 and 4 for certain (those two carry the verdict),
plus any wedge boot's set.

---

## 7. Why this ladder is shaped the way it is (one paragraph, for the record)

v45's field verdict: a second kprobe on `__x64_sys_reboot` — sharing the slot
KernelSU's own reboot kprobe rides — froze the box ~1–2 s after the first live
fire, twice, at two different stages. v47's transport registers NO kprobe at
all: the module scans kernel text for the hardened dispatcher's
direct-branch arms to `__x64_sys_ioperm` (syscall 173 — cold, nothing in
Android issues it) and rewrites each 4-byte rel32 through `ksu_patch_text`
(fixmap + `copy_to_kernel_nofault` under `stop_machine`) so the arm
tail-jumps into the module's wrapper, which runs in real syscall process
context (answers land in `payload.err` and the syscall return). This is the
same patch class KernelSU itself ships for x86_64 hardened-dispatcher kernels
(`KSU_X86_PATCH_SYSCALL_DISPATCHER`, KernelSU 3.3.0+ — "dynamically patches
the hardened syscall dispatcher at runtime so the syscall hook can work"),
and your own kernel carries the bookkeeping for it
(`x64_sys_call_patch_addr` / `x64_sys_call_patch_orig_insn` in your kallsyms
dump). The CLI's nine syscall sites were patched 169 → 173 to match. Stage 2
(observe) and stage 3 (accept) stay separate rungs so a wedge at either still
names the guilty half. sys_call_table writes are inert on this kernel
(dispatch is `x64_sys_call`, a direct-call switch — `sys_call_table[]` is "no
longer used for system calls"), which is why stage 5's class was retired
rather than repaired.

---

## 8. Summary of the whole campaign run for v47

```
flash v47  ->  reboot (boot 1: stage 0)  ->  check: "next boot arms stage 1/3"
           ->  reboot (boot 2: stage 1)  ->  check: "next boot arms stage 2/3"
           ->  reboot (boot 3: stage 2, OBSERVE — first live supercall fires)
                 PASS proof: dmesg "sc OBSERVE: susfs supercall seen"
                           + diag "transport LIVE - N arm(s) redirected"
                           + sc_selftest "after: sc_entry_count=3"
           ->  reboot (boot 4: stage 3, ACCEPT — the ceiling)
                 PASS proof: ksu_susfs show version  -> v2.3.0
                           ksu_susfs show variant   -> GKI-LKM
                           ksu_susfs show enabled_features -> the 6-line list
                           boot.log "at ladder max 3 (the v47 ceiling"
           ->  acceptance suite (section 4)  ->  send logs back
```

Any wedge anywhere: capture if adb lives, restart the instance otherwise, pull
the five logs, send them back. The ladder takes care of its own demotion.
