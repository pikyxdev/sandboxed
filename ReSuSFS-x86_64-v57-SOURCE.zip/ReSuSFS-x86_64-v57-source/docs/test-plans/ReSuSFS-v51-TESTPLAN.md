# ReSuSFS v26.11.51 — THE CLANG ACCEPT PATH — Field Test Plan

**Zip:** `ReSuSFS-x86_64-v26.11.51.zip` (557,094 bytes, sha256 `e42f547b2f9cad1389babfc803dfec2768376d324ca8d2dcfe1b9e6f36da3a6b`)

## What your 10-reboot v50 run actually proved (read this first)

Your logs were decisive, and the ladder worked exactly as designed:

| Boot | Rung | Result |
|---|---|---|
| 1–7 | substeps 0–6 | all COMPLETE |
| 8 | substep 7 @ stage 1 (10 layers) | COMPLETE — `ok 1` |
| 9 | stage 2 — TRANSPORT INSTALL + OBSERVE | **COMPLETE — the clang entry survived live fire** (counter++, `-EINVAL` answers, full 40s heartbeat window, clean handoff) |
| 10 | stage 3 — FULL mode | **WEDGED at 94%** — last log line: `supercall self-test starting`, i.e. the death is at the FIRST `ksu_susfs show version` = the FIRST EXECUTION of the v49 GCC wrapper `susfs_sc_wrapper` |
| 11 | auto stand-down | `try 3` marker read → demoted to stage 0, stage_max capped at 2, box healthy — **your data and system are fine** |

The wrapper conviction is now 3-for-3 across transport generations: v47's
transport never went live, and v48 (5/5), v49 (1/1) and v50-stage3 (1/1)
all died at the wrapper's first execution. The only table-reached module
code that ever survived is the v50 clang ENTRY in observe mode — which
never calls the wrapper.

## Why it dies (the binary analysis)

`susfs_sc_wrapper`'s common path has exactly one never-field-proven memory
access: **`current->cred` at a hardcoded header offset (0x788)** compiled
from vanilla 5.15.178 `task_struct` layout. Your kernel is LDPlayer's
custom `5.15.178+` (Android clang-17, +LTO +PGO +BOLT) — its struct layouts
match no published tree. The module's 20+ other `0x788` readers all sit in
code that never ran at runtime (the passive gate layers, the retired
stage-4/5 layers, the feature handlers), and the module carries **no
`__ex_table`** — a wrong-slot read dereferenced as a pointer is an
unhandled kernel fault on a panic-on-oops kernel. That is a sufficient
wedge mechanism, and v51 removes the entire class.

(The stage-3 install receipts also settled the old kCFI theory: the
original `__x64_sys_ioperm[-4]` word is `0xebebffff` — neighbor code
bytes, not a type hash. kCFI was never the mechanism; the sibling-scan
receipt "same=0 diff=6" already said so.)

## What v51 changes

**The v49 GCC wrapper is never called.** The whole accept path is
clang-17, grafted onto the field-proven v49 object exactly like v50:

1. **Entry** — the v50 shape byte-for-byte (proven at your stage-2 boot).
2. **Magic check** on the same pt_regs offsets the ABI defines.
3. **uid gate through a RUNTIME-CALIBRATED cred offset** — no
   header-derived struct offsets on the syscall path:
   - scan `init_task` (kallsyms: `0xffffffff822127c0` on your box) for the
     one adjacent `(real_cred, cred)` pair both equal to `&init_cred`
     (`0xffffffff82238f30`) — true for the idle task for the whole boot;
   - verify `struct cred`'s uid offset against init_cred's own bytes
     (usage small-positive at +0, uid..fsgid at +8..+0x28 all zero);
   - every step leaves a diag receipt; ANY failure just refuses to answer
     (box alive, receipts say why).
4. **SHOW_VERSION / SHOW_VARIANT / SHOW_ENABLED_FEATURES answered
   in-graft** through the kernel's own `_copy_from_user`/`_copy_to_user`
   (both in your kernel's kallsyms; SMAP/SMEP are off per your cmdline).
   The 8196-byte features answer is chunked at 256 bytes — no big stack
   frames on the syscall path.
5. **Feature commands answer not-handled this rung** — the CLI keeps its
   pre-seeded 126 sentinel, exits nonzero, and the apply scripts skip
   gracefully. Forwarding them to the v49 handlers is the NEXT rung
   (v52+), one class at a time.

Layout hardening (the build verifier caught it during the v51 build): the
graft contributes **zero `.bss`** — its two state vars ride in `.data` —
so the merged `.bss` stays byte-identical to the field-proven image and
the android struct-module spill window (`.bss[0..0x40)`, the v44 evidence)
keeps landing on the sacrificial stomp pad, not on v51's calibration vars.

Also: the loader now tries the **vanilla image first** — the android13
image ENOEXECs on your box on every attempt (one wasted insmod + the
scary "Skipping invalid relocation" kernel warning per boot). That noise
is gone.

Verification status: 32/32 host unit tests (calibration, answer layouts,
chunk straddling, gating); 88/88 binary checks per candidate .ko, re-run
against the artifact extracted from the final zip; imports still exactly
the v49 set of 124; vermagic/this_module/.bss layout byte-identical.

## Procedure — 4 reboots (the substep ladder stays at 7; only the stage ladder re-bases)

The 50→51 flash re-bases the stage ladder automatically (arm_stage=0,
stage_max=3). Keep `enable_lkm` + `enable_force_init` present.

| Reboot | Runs | Log will say | Risk |
|---|---|---|---|
| 1 | stage 0 evidence boot | `init done at arm_stage 0` … `next boot arms stage 1/3` | none — this exact state just booted clean |
| 2 | stage 1 (the 10 layers) | `next boot arms stage 2/3` | none — passed twice before in the field |
| 3 | stage 2 — TRANSPORT INSTALL + OBSERVE | `supercall: v51 transport LIVE` + self-test with `sc_entry_count > 0`, show version still "failed" BY DESIGN | none — the proven rung |
| 4 | stage 3 — FULL | **`ksu_susfs show version` ANSWERS** | the critical boot |

On reboot 4, the self-test receipt (`logs/sc_selftest.txt`) should show:

```
-- ksu_susfs show version (timeout 3):
v2.3.0
-- ksu_susfs show variant (timeout 3):
GKI-LKM
-- ksu_susfs show enabled_features (timeout 3):
SUSFS_LKM_MODULES
CONFIG_KSU_SUSFS_SUS_MOUNT
CONFIG_KSU_SUSFS_ENABLE_LOG
CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
CONFIG_KSU_SUSFS_OPEN_REDIRECT
CONFIG_KSU_SUSFS_SUS_MAP
after: sc_entry_count=<before + the self-test's calls>
```

and the diag receipts to look for in `logs/diag_last.txt`:

```
supercall: v51 calibrate: task_struct.cred at +0x??? (the v49 wrapper's
  hardcoded header offset was 0x788 - DIFFERENT/identical, ...)
supercall: v51 transport LIVE - ... uid gate CALIBRATED
```

That calibrate receipt is also the wedge-attribution evidence: if the
offset comes back ≠ 0x788, the old hardcoded read was reading a
non-pointer slot — the wedge mechanism confirmed. If it comes back
= 0x788, the cred read was innocent and the killer was elsewhere in the
GCC wrapper — v51 avoids that entire code path either way, and v52 will
bisect the feature handlers one class at a time.

## If reboot 4 wedges

Power-cycle ONCE — the ladder demotes and caps itself (one wedge boot
maximum by design, exactly like this run). Then send the five logs:

- `logs/init_trace.txt`
- `logs/diag_last.txt` (the wedge dossier in boot.log embeds the last two)
- `logs/boot.log`
- `logs/kernel_facts.txt`
- `logs/sc_selftest.txt`

Note what a wedge at this rung would mean: the only new code on the
syscall path is clang, reads only calibrated/plausible pointers, and calls
only the kernel's own uaccess helpers — a wedge would point at the
transport-context itself (or the uaccess imports), which would be a
decisive new fact for v52.

## After reboot 4 succeeds

The transport is live end-to-end for the first time on this box, and
`ReSuSFS.sh --stage-early/late` will detect kernel susfs (show version
exit 0). The apply scripts will then issue their feature commands — each
answers not-handled this rung (126), each script skips gracefully, and
each such call exercises the proven entry + the clang gate. Expect
`[*]`/`[>]` lines with per-command "not supported" outputs in the boot
log — that is the designed v51 behavior, not a regression.

The next rung (v52) forwards feature commands to the v49 handlers one
class at a time — sus_map first (its layer is armed and its handler is
small), then sus_mount / cmdline / enable_log / avc_spoof, then the rest
— each with the same one-wedge-maximum ladder.
