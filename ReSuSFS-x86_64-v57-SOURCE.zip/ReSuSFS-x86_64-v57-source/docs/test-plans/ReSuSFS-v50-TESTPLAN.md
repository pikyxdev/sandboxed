# ReSuSFS v26.11.50 — THE CLANG ENTRY — Field Test Plan

**Zip:** `ReSuSFS-x86_64-v26.11.50.zip` (551,073 bytes, sha256 `3e10f20d297250719a0491927711a373aace886443a9cc3891a7835206628266`)

## Why this version exists (30-second recap)

All 27 prior builds compiled the `.ko` with **GCC 14.2** — you asked whether
that was the problem, and the evidence says yes: the kernel is clang-17
LTO + kCFI, and kCFI metadata only exists in clang's vocabulary. v48
(no preamble) and v49 (4 copied bytes) both froze at the first dispatched
syscall(173). v50 fixes the entry class itself:

1. **The landing function is a real clang-17 function** with a genuine
   kCFI preamble for the exact syscall-table prototype
   (`long (const struct pt_regs *)`) — same compiler family, same codegen
   discipline as the kernel's own entries.
2. **The installer clones the original entry's entire 16-byte preamble
   window** byte-for-byte (verified readback) before the table write — so
   whatever the dispatch inspects, our entry presents exactly the bytes
   the original presents. No offset guessing.
3. **Stage-2 observe is minimal**: counter increment + `-EINVAL`. Nothing
   else runs on the first live fire.
4. **The installer refuses instead of guessing**: any unproven condition
   leaves the module loaded, the transport not installed, and a full diag
   receipt. No refusal path can freeze the box.

Everything else (wrapper, ladder, witness, 19 other layers, CLI) is the
field-proven v49 object, grafted via `ld -r`. Imports: identical 124.
Vermagic: identical. this_module: identical.

## Procedure — CORRECTED 2026-11-25 after the first 4 field boots

The original table below said "4 reboots" — that assumed the substep ladder
carried over from v49. It did not: your install log shows the flash re-based
the ladder ("module version changed ('' -> 'v26.11.50') - re-basing the stage
ladder (arm_stage=0, stage_max=3 ...; stale marker cleared)"), so the module
climbs ALL 8 substeps first, then arm_stage 1 -> 2 -> 3. **10 boots total;
6 remain from substep 3/7 (confirmed healthy in your 09:01-09:08 logs).**

| Reboot | Runs | Log will say | Risk |
|---|---|---|---|
| done 1-4 | substeps 0-3 (dispatch, imports, resolver, gs_off) | STEP 0..3 COMPLETE | none — all passed |
| 5 | substep 4 (+deadman: built-in-susfs check) | STEP 4 COMPLETE | none (2 kallsyms lookups) |
| 6 | substep 5 (+crosscheck: import addresses) | STEP 5 COMPLETE | none |
| 7 | substep 6 (+patch helper resolve) | "next boot runs the LAYER LOOP at arm_stage 1" | none |
| 8 | substep 7 @ arm_stage 1 — the 10 stage-1 layers (proc nodes, symbol resolves) | "next boot arms stage 2/3" | none (no table writes) |
| 9 | **arm_stage 2 — THE TRANSPORT INSTALL: 16-byte preamble clone + table[173] -> clang entry; first live fire (OBSERVE: counter + -EINVAL)** | "supercall: v50 transport LIVE" in diag; self-test receipt | **the critical boot** |
| 10 | arm_stage 3 — FULL mode | `ksu_susfs show version` ANSWERS | done |

Important on reboot 9: `ksu_susfs show version` will STILL print "failed" —
that is OBSERVE mode BY DESIGN (-EINVAL). The success signals on that boot
are: the box stays alive AND `sc_entry_count` > 0. If it freezes: power-cycle
ONCE — the ladder demotes and caps itself (one wedge maximum by design) —
then send the five logs listed below.

After reboot 10, verify:

```sh
ksu_susfs show version        # expect: v2.3.1-gki (per the v49 diag string)
ksu_susfs show variant
ksu_susfs show enabled_features
cat /data/adb/ReSuSFS/arm_stage /data/adb/ReSuSFS/stage_max   # 3 3
cat /sys/module/susfs_guard_lkm/parameters/sc_entry_count      # > 0
```

## What each outcome means

- **Stage 2 self-test survives, counter incremented, stage 3 answers** —
  the transport is live; kernel-level susfs is working. Done.
- **Stage 2 survives but stage 3 CLI still fails** — check
  `grep -E 'v50|refus' /data/adb/ReSuSFS/logs/diag_last.txt`: a refusal
  receipt names the exact unproven condition; the box stayed alive by
  design. Send the logs.
- **A wedge at stage 2 or 3** (power-cycle once — the ladder demotes and
  caps itself; one wedge maximum by design) — send back the five logs:
  `logs/init_trace.txt`, `logs/diag_last.txt`, `logs/boot.log`,
  `logs/kernel_facts.txt`, `logs/sc_selftest.txt`. The v50 receipts log
  BOTH 16-byte windows (original's and ours) before the patch, so the
  exact byte-level difference will be visible from the logs alone.

## Odds, stated honestly

Better than even, not guaranteed. The two hardenings close every failure
theory the field data supports — but v48/v49 both died through gates that
looked sufficient on paper. If this wedge, the receipts will finally name
the mechanism in byte-level detail, and per the standing agreement that is
the last version unless you ask for more.
