## v26.11.56 (v54.2) - THE TEST FIX + RECEIPT PERSISTENCE (userspace only) - 2026-11-27

**v54.1 field verdict:** the arm SUCCEEDED and the box SURVIVED (boot 4,
11:26:24: `v54 gd64 arm OK`; the v54 kCFI panic is fixed - the filter ran
~3 min with a live registered rule and the status line even printed
`features: 7`), but the uid-drop self-test FAILED one second after the arm
and the gd64 ladder disabled the rung; boots 5-8 healthy at 6 features.
**Root cause (reproduced offline, not just deduced):** the v54.1 test read
ONE 4096-byte getdents64 batch of /data/local/tmp and required the marker
to sit inside it; on a 30000-entry host dir the OLD binary prints the
exact field failure ("marker not present in the root listing") while the
NEW full-directory walk finds it (scripts/test_sc_probe_walk_host.sh).
Second gap: the test receipt went only into logs/sc_selftest.txt, which
the next boot's self-test overwrites - boot 4's evidence was destroyed
before anyone could read the failing check.  **Fix (both .kos
BYTE-IDENTICAL to the field-run v26.11.55, sha256-asserted):** (1) sc_probe
gd64_test v2 walks the WHOLE directory (32K batches until getdents64
returns 0) for all three views and prints per-view entry counts;
(2) boot-completed.sh archives the arm+test receipts to
logs/gd64_receipt_<boot_id>.txt right after each step; (3) module.prop
v26.11.56/versionCode 135 re-bases the ladders on flash.  Offline gates:
walk regression (30000-entry: new finds / old misses / tiny dir ok),
18/18 ladder tests (incl. FAIL->receipt-archived-with-views), zip verify
(change set exactly 4 files, .ko byte-identity, wire lock, zero-ud2
re-check, CLI untouched).  Field plan: ReSuSFS-v54.2-TESTPLAN.md
(5 reboots; every failure mode now names its own failing check).

## v26.11.55 (v54.1) - THE ENFORCEMENT BRIDGE, unchecked-forward hotfix - 2026-11-27

**v54 field verdict:** armed cleanly on boot 4, died ~1 s later on the first
getdents64; the gd64_stage ladder disabled enforcement (clean attribution),
stage-3 transport stayed live (6 features).  **Root cause:** the module-side
forward to the saved __x64_sys_getdents64 was a kCFI-CHECKED indirect call
(clang-17 -fsanitize=kcfi: `add -0x4(%rax),%r10d; ud2`) but this kernel's
syscall-table targets carry NO kCFI preamble (v53 ioperm arm receipt proves
the pattern; the kernel's own dispatch calls them unchecked).  Checked
forward read epilogue garbage -> ud2 -> panic.  **Fix:** every forward rides
sc_v54_fwd(), a noinline no_sanitize("kcfi") trampoline = the kernel's own
unchecked convention.  Zero ud2 sites in the graft (v54 shipped 3); four new
permanent verifier checks (271 total); 45/45 host + 10/10 ladder unchanged;
import set byte-identical to the field-resolved v54 set; change set vs v54
zip: module.prop + both .kos + .payload_stamp.  Arm receipt now dumps the
getdents64 orig window.  Field plan: ReSuSFS-v54.1-TESTPLAN.md (5 reboots).

# v26.11.54 - THE ENFORCEMENT BRIDGE (2026-11-27)

The rung that makes susfs actually HIDE.  On the field-proven v53.1
transport (4-boot ladder FULL PASS, 2026-11-27): a second LIVE
sys_call_table entry - getdents64, nr 217 - whose filter removes
registered (name, ino) entries from directory listings for app-range
uids (>= 10000).  Root, system (< 10000) and adb shell keep the full
view.  Matching is upstream susfs4ksu's own rule (same name AND same
inode = the same filesystem object, any directory, any mount), decoded
from its android13-5.15 LKM.  The inode is resolved USERSPACE-side
(stage-late stat + sc_probe, private cmd 0x55f55) so the kernel touches
NO struct offset - the v49 wedge was a hardcoded cred offset, and no
offline tree matches this box (vanilla 0x788, upstream a13 0x7e0, real
calibrated 0x7a8).  The filter fails OPEN everywhere; post-call
compaction can never loop (f_pos already advanced).  Arming is
script-gated (private 0x55f54, only after the stage-3 self-test passes)
by the gd64_stage ladder: per-boot try -> arm -> uid-drop test -> ok;
a stale try or a failed test DISABLES enforcement without touching the
stage-3 transport.  Imports 13 -> 15 (__kmalloc, kfree); zero .bss;
the v49 GCC wrapper still never called.  SHOW prints 7 features when
armed.  Offline: 264 build checks, 45/45 host tests, 10/10 ladder tests
(the ladder test caught a real grep bug in the arm receipt check before
the field).

## [v26.11.49-x86_64] - 2026-11-24

### The kCFI preamble fix: the five v48 first-dispatch deaths, convicted and closed

- **field result (v48, five boots, 2026-11-24 11:00-11:11).** Every boot
  completed init (`RETURNING 0`, `transport LIVE`, 10 layers) and died 2-5
  seconds later; the last boot.log line of every boot was "supercall
  self-test starting" - death at the FIRST `syscall(173)` dispatched through
  the patched `sys_call_table[173] = susfs_sc_entry`. The witness and the 5s
  heartbeats died with it; the launcher froze on the last framebuffer; five
  consecutive boots, identical signature. Because each boot had already
  written its `ok` ladder marker before the self-test, the next boot re-armed
  stage 3 every time - a self-sustaining wedge loop (the box needed manual
  power-cycles between all five).
- **root cause (triangulated, not guessed).** The v47 boots x9/x10 issued the
  same syscalls through the same call site with the ORIGINAL entry and
  returned -EINVAL unharmed - so the call site inspects its target. This
  clang-17 LTO kernel enforces kCFI (kallsyms: `is_cfi_preamble_symbol`,
  `cfi_suffix`; the module's own `__nocfi` conventions were built for it),
  and the LIVE dispatch path is KernelSU-Next's `my_x64_sys_call`
  (kernel/hook/x86_64/syscall_hook.c) - NOT `__nocfi` - so its
  `ksu_syscall_table[nr](regs)` is type-checked: every legitimate entry
  carries the 4-byte type hash immediately BEFORE its address. v48's
  raw-asm thunk had no preamble; the first dispatch compared
  `[susfs_sc_entry - 4]` (arbitrary module text) against the expected hash,
  failed, and killed the kernel. (The alternative KSU patch target
  `my_do_syscall_64` IS `__nocfi` - but a `__nocfi` site cannot kill, and
  the field proves something did; the v49 entry satisfies both shapes.)
- **the kernel fix (`kernel/susfs_supercall.c`).** `susfs_sc_entry` now has a
  4-byte kCFI preamble slot (`susfs_sc_kcfi_preamble`) at exactly `entry-4`,
  zeroed in the shipped image. At install time the module reads the 4 bytes
  at `[original table[173] entry - 4]` - by construction the exact type hash
  this call site already accepts - cross-samples sibling entries for the
  receipt, replicates the hash into its own slot through `ksu_patch_text`
  (module .text is RO after load; verified read-back), and only then patches
  the table entry. Refusal receipts cover every failure (layout break, write
  fail, read-back miss). On a kernel WITHOUT kCFI the replicated word is
  inert dead bytes - safe under both regimes. The liveness scan now also
  logs the table index holding `ksu_syscall_dispatcher`.
- **the ladder hardening (the wedge-loop hole, closed).** Two changes.
  (1) v47->v48 carried the ladder over; v48->v49 RE-BASES it (arm_stage=0,
  stage_max=3): the transport changed, every rung re-validates - the climb
  is 4 boots (0 evidence, 1 gates, 2 transport OBSERVE + live-fire
  self-test, 3 transport FULL + answered `ksu_susfs show version`).
  (2) boot-completed now DEFERS the ladder confirmation of any
  transport-armed boot (stage >= 2) until AFTER the supercall self-test
  survives: a wedge there leaves the `try` marker stale and post-fs-data's
  existing demotion caps the ladder below the rung on the next boot - one
  wedge boot maximum, never a loop.
- **pipeline.** build_v49_ko.sh (the v48 pipeline + fresh CLI build + the
  v45 nop patch + the v47 173 patch, both idempotent), build_v49_verify.py
  (every inherited structural check + the preamble layout/zero-word/v49
  receipt checks; the CLI lands byte-identical to v48's field-proven
  build), build_v49_zip.py (layout identical to v48; exactly the intended
  9-file change set; both .kos new; ymuuu reference untouched).

## [v26.11.45-x86_64] - 2026-11-23

### The supercall redesign: the wedge convicted, the transport rebuilt on the field-proven shape

- **field result (v44, 2026-11-23 21:34-22:39).** The substep ladder climbed
  clean through substep 7 at arm_stage 1 (10 layers live, full 40s heartbeat
  windows, `RETURNING 0` every boot). arm_stage 2 (supercall) then wedged the
  box ~3s after init completed - at stage-late's first `ksu_susfs` supercall -
  and arm_stage 3 repeated it within ~1s of the body returning. Both were
  hard hangs (the witness and the 5s heartbeats died with the kernel), and the
  ladder demoted itself to a stage-0 evidence boot and capped stage_max at 2,
  exactly as designed.
- **defect 1 - wrong arg location (functional).** On x86_64 the syscall
  wrapper `__x64_sys_reboot(const struct pt_regs *)` receives ONE parameter:
  a pointer to the real pt_regs. The v44 entry handler read `regs->di` as
  magic1 - a kernel pointer - and rejected every supercall it ever saw. The
  v26.11.28 removal of the "arm64 quirk deref" was simply wrong; KernelSU's
  own PT_REAL_REGS macro does the deref on every arch.
- **defect 2 - the kretprobe transport (the wedge).** The KernelSU on this
  box is a SukiSU-Nova-lineage build (dmesg `KernelSU: reboot kprobe
  registered successfully`; `ksu_supercalls_init` /
  `ksu_supercall_handle_ioctl` in the field kallsyms) whose OWN reboot kprobe
  - a PLAIN kprobe answering its fd-install supercall via
  task_work(TWA_RESUME), never touching regs, trampolines or return addresses -
  has ridden `__x64_sys_reboot` through every boot under full traffic without
  one incident. v44's kretprobe joined that slot carrying a return-address
  trampoline, a regs->ax override and a rethook return handler, and the box
  died at the first traffic through it, twice, at two stages.
- **the v45 supercall layer** (`kernel/susfs_supercall.c`): a plain kprobe
  whose pre_handler derefs the wrapper's pt_regs* (the SukiSU pattern),
  accepts only root-issued 0xDEADBEEF/0xFAFAFAFA commands whose feature is
  armed, and answers EXCLUSIVELY through task_work running before the syscall
  returns to userspace. The answer travels in payload.err, never in the
  return value (the original `__se_sys_reboot` still returns -EINVAL for our
  magics, which is harmless: 0xDEADBEEF != 0xFEE1DEAD). `ksu_susfs` was
  retaught to read payload.err: the nine `syscall; test rax,rax; jne fail`
  branches in the shipped binary are the canonical 6-byte nop
  (scripts/patch_ksu_cli_v45.py), so the CLI keeps its 126 no-answer
  sentinel semantics.
- **bonus defect fixed - the .bss stomp.** The running kernel's ANDROID
  struct module is 0x340 bytes; every kernel.org-built image ships a
  0x300-byte `.gnu.linkonce.this_module`, so each insmod wrote 0x40 bytes of
  struct-module tail INTO .bss[0..0x40) - readelf puts susfs_diag_printk,
  probe_arm, probe_val, force_init_val, init_done, init_maxstep, fail_layer
  and sc_entry_count in that window. The field caught it red-handed:
  sc_entry_count read "10" on EVERY boot, including fresh zombies whose probe
  was never registered. v45 adds a 64-byte GLOBAL pad as the first-linked
  object's only .bss symbol (`kernel/stomp_pad.c`, first in the Makefile
  objs): verified post-build at .bss+0 with every control variable past
  +0x40.
- **ladder renumbered for the bisect the wedges demanded.** stage 2 =
  supercall kprobe OBSERVE-ONLY (register + log traffic; proves the slot
  coexists with KernelSU's own reboot kprobe under live traffic), stage 3 =
  supercall ACCEPT (the task_work answer path goes live - a wedge HERE
  convicts the answer path alone), stage 4 = +lsm_hook/sus_path/uname/
  hide_syms (was 3), stage 5 = +create_gate/opath/dirent/kstat/sus_unix
  (was 4; FULL susfs). stage_max is now 5, whitelisted in both boot scripts,
  and a module-version change re-bases the stage ladder automatically
  (arm_stage 0, stage_max 5, stale marker cleared; the substep ladder stays)
  so the v44 demotion cap on the box does not clamp the new rungs.
- **new receipt: the supercall self-test.** Right after every stage>=2
  trigger, boot-completed runs one bounded `ksu_susfs show version/variant`
  (timeout 3) and logs the output plus the sc_entry_count delta to
  logs/sc_selftest.txt and boot.log - a supercall datapoint at a controlled
  moment even if the boot never reaches stage-late.


## [v26.11.44-x86_64] - 2026-11-23

### The resolver probe fix (substep 2 refusal, root-caused from field greps)

- **context: v42/v43 (unlogged interim releases).** v42 fixed the struct
  module size mismatch (0x340 vs 0x300) and built both candidates with GCC
  (RETPOLINE/RETHUNK off); v43 split the dispatch channel from the queueing
  path: `echo 2 > force_init` (trigger_mode=sync) calls `susfs_init_body`
  DIRECTLY in the `.set`, and both paths print a raw `KERN_EMERG`
  XYZDIAG2 breadcrumb that survives both a param deadlock and a dead box.
- **finding (v43 field, 2026-11-23 20:03-20:10): the SYNC trigger is
  proven safe.** Boots 1e6581f5 and e4f859d9 ran substeps 0 (dispatch)
  and 1 (+imports) to completion (init_done=1, rc=0) with the vanilla
  image loaded clean; the deferred-path wedge of v39-v42 never reproduced.
  Substep 2 (+resolver) refused by design and the box stayed healthy
  (stage-late still ran).
- **finding (critical, user-supplied greps): the refusal was a bad probe
  NAME, not a bad seed.** `grep -w kallsyms_lookup_name` returned
  `ffffffff810fd360 t kallsyms_lookup_name` - the seed address was exactly
  right and had already passed the module's own sprint_symbol validation.
  `grep -w printk` returned ZERO lines, while the same 101248-line
  snapshot lists `_printk` at ffffffff810b6d00 and `vprintk` at
  ffffffff810b9de0: this GKI-style clang-17 LTO kernel simply has no
  `printk` kallsyms entry. The old `kr_kln_activate` probe asked for the
  one name the kernel does not have, `kln` correctly answered 0x0, and the
  resolver refused a WORKING resolver.
- **fix: probe candidates.** `kr_kln_activate` now tries `_printk` first
  (the GKI 5.15 reality), then `printk` (vanilla kernels), then `vprintk`;
  the first hit validates KLN mode, and the activation breadcrumb names
  WHICH probe answered. No other site looked up `printk` by name - the
  imports crosscheck SKIPS names kallsyms does not list (by design), and
  the module's own printk calls resolve through the ksymtab at load time,
  which the field dmesg proves works.
- **fix (cosmetic): recon stops claiming `kernel_config.txt`.** The v43
  boot log said "(+kernel_config.txt)" while the file never existed
  (no /proc/config.gz on this kernel); the summary line is now conditional,
  so field greps stop chasing a phantom file.
- **unchanged:** SYNC force_init=2 default, vanilla candidate default,
  substep ladder 0..7 one rung per healthy boot, arm_stage 0..4, two-step
  opt-in, next-boot stand-down after a wedge. Expected next boots:
  substep 2 KLN mode ACTIVE -> 3 gs_off -> 4 deadman -> 5 crosscheck ->
  6 patch -> 7 layers, then the arm_stage ladder, then supercall answers.

## [v26.11.41-x86_64] - 2026-11-23

### The v40 field freeze, attributed as far as the evidence reaches (kernel watchdog removed, codegen reverted, sentinel witness)

- **finding (critical): the v40 box froze AT the force_init sysfs write.**
  The uploaded field boot.log + init_trace.txt show the last receipts as
  `writing force_init=1 (dispatching the deferred kworker)` and
  `boot-completed: triggering force_init` - both written BEFORE the `echo`
  - while `force_init write returned` (written AFTER it) and every poller
  line are absent. The echo never returned; the box needed a manual instance
  restart ~2 minutes later. That write is the FIRST module code the whole
  boot executes: under the ksud zombie load `do_init_module` never ran the
  module init, and the earlier param writes (kr_seed, arm_stage,
  init_maxstep) are pure kernel `param_ops_*` code, not module code. The v39
  boot froze at the same boundary with essentially the same image (its
  import set is byte-identical to the v26.11.26-37 proven image).
- **finding: every import of every image era is present AND unique in the
  field kallsyms.** All 125 v40 imports (incl. `panic`,
  `queue_delayed_work_on`, `cancel_delayed_work_sync`,
  `__msecs_to_jiffies`, `system_wq`, `queue_work_on`,
  `__x86_return_thunk`, `bcmp`) verified against the uploaded
  kernel_kallsyms.txt (99296 kernel records): zero missing, zero
  duplicated. A wrong-occurrence or zero resolution is therefore not the
  mechanism; the load itself succeeding on boot B is also consistent (a
  SHN_UNDEF left by the loader would have failed the load with "Unknown
  symbol").
- **finding: the v40 image is the only one built with return thunks.**
  The v40 .ko compiles all 446 function returns as `cs jmp
  __x86_return_thunk` (RETHUNK=y, NDK r28c clang); the v26.11.26-37 image
  that ran module code live at the v35 trigger AND the v39 image both
  return with plain `ret`. The vanilla proven profile is what actually
  executed in the field.
- **finding: the recovery path is field-proven.** Boot C (the boot after
  the wedge) detected the stale `try` marker, printed the WEDGE DOSSIER,
  removed enable_lkm + enable_force_init, suppressed the trigger, and came
  up clean with the zombie image.
- **change: the kernel-side panic-on-stall watchdog is REMOVED.** It never
  fired (the box froze without rebooting), ran inside the very boundary it
  existed to instrument, and was the only unproven-call path in substep 0
  (`schedule_delayed_work`/`cancel_delayed_work_sync` ->
  `queue_delayed_work_on`/`cancel_delayed_work_sync`/
  `__msecs_to_jiffies`, plus the brand-new `panic` import). Recovery is the
  proven next-boot stand-down. `panic` and its import are gone.
- **change: the image is rebuilt with RETPOLINE=n RETHUNK=n.** Zero
  return thunks, plain `ret`s - the codegen profile the field actually
  proved with module code executing. `__x86_return_thunk` also drops out
  of the import set (123 remain, all verified present+unique). Vermagic
  unchanged: `5.15.178+ SMP preempt modversions`.
- **change: sentinel codes + background witness.** `init_laststep` now
  walks `-100` (setter entered - the first module code), `-101` (work
  queued), `0` (kworker inside the body), `1..7` (substeps).
  boot-completed.sh starts a background witness BEFORE the force_init echo
  (the v40 poller started after the echo that never returned) that mirrors
  every value change into init_trace.txt with a sync per receipt, so the
  next freeze names its exact boundary on disk: stuck at `-1` = before any
  module code (kernel sysfs machinery), `-100` = in the setter, `-101` =
  at the queue_work dispatch, `0` = in the kworker, `N` = in substep N.
- **change: the collector's force_init misread is fixed.** force_init is
  0200 (write-only) by design; the v40 collector printed the read's EACCES
  as "param not exposed - fallback image". Presence is now checked with
  `-e`, and `wd_timeout_s` is reported as removed.
- **test: v41 regression suite (14 tests, host).** scripts/test_v41_ladder.sh
  covers seed v2 (3 forms), substep dispatch with sentinel receipts
  (including the post-echo receipt the v40 field box never produced), nok
  same-rung retry, seq-6/seq-7 advancement, stand-down dossier, stage
  demotion + cap, suppression, payload stamp refresh + self-heal, sentinel
  receipts surviving into the dossier, and the collector readout. ALL PASS.

## [v26.11.39-x86_64] - 2026-11-23

### The v38 silent no-load fix (found in the field boot.log)

- **fix (critical): the bundled LKM is now actually installed and loaded.**
  The field device's v26.11.38 `boot.log` proved the LKM never loaded at
  all: every boot logged `LKM candidates missing - using legacy
  susfs_guard_lkm-x86_64-5.15.ko` -> `[*] LKM or susfs_insmod missing,
  downloading...` -> `[!] No x86_64 LKM available for this kernel
  (5.15.178+)` -> `LKM load rc=1`, diagnose answered `kernel susfs: NOT
  ALIVE`, and `/proc/modules` had no susfs entry. Root cause: v38 renamed
  the bundled payload to three candidates
  (`susfs_guard_lkm-x86_64-android13-5.15.ko`, `...-vanilla-...`,
  `ymuuu_...`, two under `lkm/x86_64/candidates/`) but left the install
  gate in `download_susfs_guard_lkm()` keyed to a file named EXACTLY
  `${kmi}` - which on a custom kernel resolves to the legacy
  `susfs_guard_lkm-x86_64-5.15.ko` that no longer existed. The gate never
  fired, `install_susfs_guard_lkm_x86_64()` never ran,
  `/data/adb/ReSuSFS_LKM` stayed empty forever, and the v38 two-step
  experiment was never actually tested (the boot was fine only because
  nothing kernel-side ran).
- **fix: install gate recognizes any bundled candidate.** The gate now
  fires when the exact `${kmi}` OR any of the bundled x86_64 candidates
  exists in the module payload, so a v39 flash populates
  `/data/adb/ReSuSFS_LKM` (all three .ko + `susfs_insmod`) at install
  time.
- **fix: runtime self-heal.** `load_susfs_lkm()` now repopulates an empty
  `/data/adb/ReSuSFS_LKM` straight from the module dir payload and
  re-selects the candidate (honoring `lkm_candidate`) - a v38 device
  recovers on the next boot WITHOUT a reflash.
- **fix: candidate fallback chain.** An x86_64 load failure now falls
  through `android13` (default) -> `vanilla` (the v26.11.26-37 image,
  proven image-load on this kernel family) -> `ymuuuu13` in the SAME boot
  instead of giving up after one ENOEXEC. Pinned `lkm_candidate` values
  stay strict single-shot. Every attempt is 20s-bounded; the post-fs-data
  `lkm-load` gate was raised 90s -> 150s to cover the whole chain.
- **test: 19-assertion host regression suite** (`scripts/test_v39_loader.sh`)
  simulating the exact field state (kernel `5.15.178+`, empty
  `/data/adb/ReSuSFS_LKM`, payload present): install gate, self-heal,
  fallback order, and a T4 regression proof that the unpatched v38 script
  reproduces the device's dead end while v39 does not.
- field evidence also confirmed via the user's `kernel_kallsyms.txt`:
  zero `__crc_*` symbols -> the kernel has `CONFIG_MODVERSIONS=n`, so
  the candidates' `__versions` sections are inert data and all three
  builds pass the version gate (the loader chain covers import-set
  differences).

## [v26.11.23-x86_64] - 2026-11-22

### x86_64 port (LDPlayer 14 freeze fix)

- **fix (critical): the susfs LKM is no longer auto-loaded on custom
  (non-GKI) x86_64 kernels.** v26.11.22 force-loaded the bundled
  `susfs_guard_lkm-x86_64-5.15.ko` - a runtime kernel-hooking module
  compiled against a generic 5.15 config, not against LDPlayer 14's
  actual kernel build - on every boot. The system booted fully and then
  froze ~10s after the home screen appeared, exactly when
  boot-completed's stage-late pushed ~50 susfs rules into the kernel and
  the media scanner / status loop started exercising the hooks. A
  kernel-level freeze is unrecoverable from userspace, so loading the LKM
  on a custom kernel is now strictly opt-in:
  `touch /data/adb/ReSuSFS/enable_lkm`. GKI/KMI kernels keep the
  automatic load (upstream prebuilts, verified per KMI).
- **fix: built-in kernel susfs is now detected functionally.** The old
  detection required `/proc/config.gz` (absent on LDPlayer), so a
  KernelSU kernel with built-in susfs was indistinguishable from a stock
  kernel and the LKM could be stacked on top of it - two hooking layers
  on the same syscalls. `susfs_kernel_alive()` now asks the kernel through
  the ksu_susfs supercall (`reboot(0xDEADBEEF, ...)` answers EINVAL
  instantly on kernels without susfs, so the probe is safe everywhere):
  built-in susfs => full features with no LKM at all.
- **feat: userspace-only mode.** With no kernel susfs and no LKM, the
  module stays installed and stable: stage-early/stage-late skip the susfs
  application, the module.prop status line reads `userspace-only`, and
  script/cron/prop features keep working.
- **feat: persistent boot instrumentation.** Every boot stage logs to
  `/data/adb/ReSuSFS/logs/boot.log` (timestamped, sync-ed after every
  line, mirrored to /dev/kmsg) so a frozen system still leaves readable
  evidence after a hard instance restart.
- **feat: hang watchdog.** Every stage runs under a receipt: a stage
  that never finished on the previous boot is skipped automatically
  (after two hangs it is quarantined), so a userspace hang can never
  trap the module in a boot loop.
- **fix: all supercalls timeout-bounded** (`rs_run`), `service.sh`'s
  status loop runs at a 30s cadence, exits when the module is disabled,
  and no longer rewrites module.prop on every pass (status_report
  dedupes).
- **fix: `set_cmdline_or_bootconfig` skips documentation-only files** -
  the stock default file is comments; passing it on would have spoofed
  /proc/cmdline with comment text for every non-su process.
- **safe defaults:** all postfs/bootcompleted user scripts ship
  commented out; config toggles blank; upgrading from v26.11.22
  force-resets the old aggressive config (backed up to
  `/data/adb/ReSuSFS.bak.<ts>`).
- **feat: `diagnose.sh` bisector** - applies each feature one step at a
  time, receipt-gated, logged to `diagnose.log`; the Action button runs
  it. On kernels without susfs it states up front that steps 01-08 are
  expected to answer "not supported".

## [v26.10.23] - 2026-10-23


### 🧹 Chores

- bump version to 26.10.23 (@ahmed-alnassif)

## [v26.10.21] - 2026-10-21


### 🌐 WebUI

- **fix:** fix the editor throwing an error when it closes (@ahmed-alnassif)

### 🧩 Module

- **refactor:** skip config prompts on fresh installs with no configs (@ahmed-alnassif)
- **fix:** default CONFIGURE to true so ReSuSFS dir isn't left empty (@ahmed-alnassif)

### ✨ Features

- update the module icon (@ahmed-alnassif)

### 📚 Documentation

- update README for LKM support, scheduling and UserHub (@ahmed-alnassif)
- update ReSuSFS description (@ahmed-alnassif)

### ⚙️ CI/CD

- use -9 max compression for smaller release zip to speed up user downloads (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.21 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump marked in /webui in the webui-deps group (#26)

## [v26.10.16] - 2026-10-16


### 🧩 Module

- **feat:** prompt before updating configs (@ahmed-alnassif)
- **fix:** remove hidden_api_policy to avoid enabling hidden API access, note: update your configuration in this update (close: #25) (@ahmed-alnassif)
- **feat:** full SuSFS LKM support with auto-download and load on boot (@ahmed-alnassif)
- **fix:** make download_file resilient to slow and unstable networks (@ahmed-alnassif)
- **fix:** verify LKM load via loader exit code instead of lsmod (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.16 (@ahmed-alnassif)

## [v26.10.13] - 2026-10-13


### 🌐 WebUI

- **fix:** route all editor close paths through one dirty-check, fixes back gesture skipping the unsaved-changes prompt and the title staying stuck after closing (fix: #23) (@ahmed-alnassif)
- **l10n:** update translations (#21) (@weblate)
- **fix:** stop the unsaved changes prompt from showing twice (@ahmed-alnassif)
- **fix:** keep the unsaved changes prompt from exiting the module on back (@ahmed-alnassif)

### ✨ Features

- add an icon for KernelSU modules (@ahmed-alnassif)

### 🔧 Fixes

- add icon metadata to module.yaml (@ahmed-alnassif)

### 📚 Documentation

- update banner image (@ahmed-alnassif)
- add a new logo (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.13 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 7 updates (#24)

## [v26.10.11] - 2026-10-11


### ✨ Features

- add module.yaml to add ReSuSFS to KernelSU manger (@ahmed-alnassif)

### 🔧 Fixes

- back button now works correctly for menus and dialogs (@ahmed-alnassif)
- one asset per release (@ahmed-alnassif)

### 📚 Documentation

- migrate ReSukiSU to BakaSU (@ahmed-alnassif)

### 🧹 Chores

- bump version to v26.10.11 (@ahmed-alnassif)

## [v2.3.0-f55930f] - 2026-10-05


### 🧩 Module

- **fix:** remove hot install since ReSuSFS requires a full reboot after installing or updating (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-f55930f (@ahmed-alnassif)

## [v2.3.0-1e6fb20] - 2026-10-05


### 🌐 WebUI

- **feat:** add clear button to log viewers (@ahmed-alnassif)
- **feat:** add color highlighting to log viewers (@ahmed-alnassif)
- **feat:** add color highlighting to terminal output by [symbol] tags (@ahmed-alnassif)
- **feat:** color a script's own output lines inside the cron log viewer, not just the start/end lines (@ahmed-alnassif)
- add Arabic translation setting and correct ar-SA (@ahmed-alnassif)
- migrate from crowdin to weblate (@ahmed-alnassif)
- **fix:** show a script's full output in its cron log, not just the start/end lines (@ahmed-alnassif)

### 🧩 Module

- **fix:** use status symbol instead success for script exit (@ahmed-alnassif)

### 📚 Documentation

- migrate from crowdin to weblate (@ahmed-alnassif)

### ⚙️ CI/CD

- migrate from crowdin to weblate (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-1e6fb20 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 3 updates (#22)

## [v2.3.0-99af3c2] - 2026-10-03


### 🌐 WebUI

- **fix:** move @lezer/common override to pnpm-workspace.yaml, fixes syntax highlighting broken by a duplicate package version (@ahmed-alnassif)
- update package.json metadata (version, author, license) (@ahmed-alnassif)
- **fix:** make @lezer/common fix self-updating instead of a hardcoded version (@ahmed-alnassif)
- **feat:** show each script's last cron run time and result in UserHub (@ahmed-alnassif)
- **feat:** add button to view a script's own cron run history (@ahmed-alnassif)
- **feat:** add schedule logs fab button (@ahmed-alnassif)
- **fix:** make the rest of the terminal usable after making it visible (@ahmed-alnassif)
- **fix:** don't show schedule log fab in SuSFS tab (@ahmed-alnassif)

### 🧩 Module

- **feat:** log start/end time and exit code for every cron-run script (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-99af3c2 (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 6 updates (#19)

## [v2.3.0-eb224b2] - 2026-09-25


### 🌐 WebUI

- add translation link instead of documentation (closes #8) (@ahmed-alnassif)
- **feat:** make back button/gesture close dialogs, the editor, and terminals instead of exiting the app immediately (closes #18) (@ahmed-alnassif)

### ⚙️ CI/CD

- **fix:** don't upload local translations (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-eb224b2 (@ahmed-alnassif)

## [v2.3.0-edb5e2f] - 2026-09-23


### 🧩 Module

- ask for configs backup only when they exist (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-edb5e2f (@ahmed-alnassif)

### 🤖 Automated

- webui: new Crowdin translations by GitHub Action (#15)
- webui(deps): Bump the webui-deps group in /webui with 4 updates (#16)
- webui(deps): Bump the webui-deps group in /webui with 4 updates (#17)

## [v2.3.0-d348051] - 2026-09-12


### 🌐 WebUI

- **refactor:** add UserHub next to home tab (@ahmed-alnassif)
- **style:** change UserHub icon (@ahmed-alnassif)
- **feat:** add available languages to selector (@ahmed-alnassif)

### 📚 Documentation

- add GKID as the recommended kernel for full SuSFS support (@ahmed-alnassif)

### ⚙️ CI/CD

- fix Crowdin XML config to skip name attributes (@ahmed-alnassif)
- improve Crowdin workflow with official action pattern and proper branch handling (@ahmed-alnassif)
- use the correct secret variable for crowdin (@ahmed-alnassif)
- fix syntax error (@ahmed-alnassif)
- **crowdin:** don't start the workflow in every doc push (@ahmed-alnassif)
- **crowdin:** upload local translations (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-d348051 (@ahmed-alnassif)

### 🤖 Automated

- webui/locales: sync translation from Crowdin (#11)
- New Crowdin translations by GitHub Action (#12)
- webui: new Crowdin translations by GitHub Action (#14)

## [v2.3.0-47be13c] - 2026-09-11


### 🌐 WebUI

- **fix:** don't let other elements cover the editor (@ahmed-alnassif)
- **fix:** fix About version lookup and link handlers (@ahmed-alnassif)
- **refactor:** donations card in more tab (@ahmed-alnassif)
- **perf:** stop rebuilding every visible UserHub row on each search keystroke/tag click, reuse built elements via a persistent map, tighten IntersectionObserver margin (@ahmed-alnassif)
- **fix:** make UserHub load faster and feel smoother (@ahmed-alnassif)
- **fix:** stop scripts from losing their tags and the list shaking while scrolling (@ahmed-alnassif)

### 📚 Documentation

- add Crowdin badge (@ahmed-alnassif)
- add KernelSU Next warning to README (@ahmed-alnassif)
- fix formatting (@ahmed-alnassif)
- add KernelSU Next warning to changelog (@ahmed-alnassif)

### ⚙️ CI/CD

- move crowdin sync to dev, publish locales-dist branch (@ahmed-alnassif)
- simplify crowdin workflow to single branch (@ahmed-alnassif)
- drop locales.zip artifact (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-47be13c (@ahmed-alnassif)

### 📦 Other

- drop: remove KernelSU Next support (@ahmed-alnassif)

### 🤖 Automated

- webui/locales: sync translation from Crowdin (#5)
- webui/locales: sync translation from Crowdin (#6)

> [!Important]
> **KernelSU Next is not recommended.**
>
> KernelSU Next is currently **unmaintained** and has been observed engaging in anti-competitive behavior, including blacklisting the official ReSuSFS module without technical justification. This is not a security decision, it is a control decision.
>
> Using an unmaintained kernel root solution can lead to:
>
> - **Instability** and unexpected crashes.
> - **Bootloops** that can leave your device unusable.
> - **Security vulnerabilities** that will never be patched.
> - **Broken module compatibility** as the ecosystem moves forward.
>
> To protect your device and ensure you receive official support:
>
> - Use **KernelSU**: The upstream, official root solution.
> - Use **BakaSU**: A trusted, community-respected fork.
>
> ReSuSFS is the only official SuSFS module for KernelSU. It is fully supported on KernelSU and BakaSU only.
>
> Do not use KernelSU Next. Choose stability. Choose freedom. Choose official support.

---

## [v2.3.0-bc8e52b] - 2026-09-09


### 🌐 WebUI

- **fix:** replace hardcoded donation address with a link to the GitHub support page, remove now-unused clipboard-copy logic (@ahmed-alnassif)

### ✨ Features

- add custom sponsorship URL to FUNDING.yml (@ahmed-alnassif)

### 📚 Documentation

- I think it's working fine with/without SuSFS (@ahmed-alnassif)
- add ReSuSFS banner (@ahmed-alnassif)
- update donation info (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-bc8e52b (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump @codemirror/view in /webui in the webui-deps group (#4)
- ci(deps): Bump crowdin/github-action from 2 to 3 (#3)

## [v2.3.0-f851a6e] - 2026-09-06


### 🌐 WebUI

- **fix:** export full config directory without filtering (@ahmed-alnassif)
- **feat:** add user-friendly cron schedule field to UserHub script rows (@ahmed-alnassif)

### 🧩 Module

- **feat:** add sync_cron_scripts() via busybox crond, synced on boot-completed (@ahmed-alnassif)
- **fix:** prevent duplicate crond processes in sync_cron_scriptsci(fix): improve disk cleanup and swap to prevent build kill (@ahmed-alnassif)

### ⚙️ CI/CD

- add Dependabot (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-f851a6e (@ahmed-alnassif)

### 🤖 Automated

- webui(deps): Bump the webui-deps group in /webui with 6 updates (#2)

## [v2.3.0-4d61c95] - 2026-09-05


### 🌐 WebUI

- **feat:** add script tags, filter bar, and inline editor (@ahmed-alnassif)

### 🧩 Module

- **feat:** improve config persistence handling (@ahmed-alnassif)
- **feat:** update scripts configuration handling (@ahmed-alnassif)
- **feat:** add ksu-settings script to bootcompleted (@ahmed-alnassif)

### ✨ Features

- add backup confirmation prompt before config handling (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-4d61c95 (@ahmed-alnassif)

## [v2.3.0-5ec5ad8] - 2026-09-05


### 🌐 WebUI

- fix UserHub tab loading/refreshing lag (@ahmed-alnassif)
- **fix:** write backup tar log to Download dir and ensure it exists before export (@ahmed-alnassif)
- **fix:** escape shell vars in backup script and move tar log to ReSuSFS dir (@ahmed-alnassif)
- **perf:** only refresh UserHub's script list when scripts actually change, not on every tab switch (@ahmed-alnassif)
- **feat:** add sort options to UserHub (name A-Z/Z-A, enabled first, recently/oldest modified) via header button (@ahmed-alnassif)
- **feat:** add search button to UserHub (@ahmed-alnassif)
- **feat:** add Telegram support group link to More, and a shared-configs hint to Home's backup card (@ahmed-alnassif)

### 📚 Documentation

- highlight strong hiding by default in readme (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-5ec5ad8 (@ahmed-alnassif)

## [v2.3.0-5556867] - 2026-09-04


### 🧩 Module

- **fix:** correct ksud command in uname spoofing script (@ahmed-alnassif)
- **fix:** set ksu features correctly (@ahmed-alnassif)
- **fix:** use full KMI tag and correct hash length in uname spoofing (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-5556867 (@ahmed-alnassif)

## [v2.3.0-145b96d] - 2026-09-04


### 🌐 WebUI

- regenerate pnpm-lock.yaml after adding syntax highlighting dependencies (@ahmed-alnassif)
- **feat:** add shell syntax highlighting to the code editor via CodeMirror language support (@ahmed-alnassif)

### 🧩 Module

- **fix:** correct kstat backend to support static and dynamic spoofing (@ahmed-alnassif)
- **fix:** simplify uname apply to replace values while preserving user comments (@ahmed-alnassif)
- **feat:** add spoofing and hiding scripts for cmdline, uname, paths, maps, mounts, props, settings, and kstat (@ahmed-alnassif)

### 📚 Documentation

- add built-in scripts documentation and update features, userhub, backup, and description sections (@ahmed-alnassif)

### ⚙️ CI/CD

- add build category (@ahmed-alnassif)

### 🏗️ Build

- add lockfile auto-regeneration fallback to local-build.sh when frozen install fails (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-145b96d (@ahmed-alnassif)

## [v2.3.0-9244d05] - 2026-09-03


### 🧩 Module

- **fix:** don't disable the module in every reboot (@ahmed-alnassif)
- **fix:** prevent setScriptStage from adding entries when disabling (@ahmed-alnassif)
- update module.prop description (@ahmed-alnassif)

### 📚 Documentation

- fix changelog (@ahmed-alnassif)
- my plan (@ahmed-alnassif)
- fix formatting (@ahmed-alnassif)

### ⚙️ CI/CD

- **fix:** prepend changelog entries instead of appending (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-9244d05 (@ahmed-alnassif)
## [v2.3.0-4171ba3] - 2026-09-03


### 🌐 WebUI

- add backup/restore in the home page at bottom (@ahmed-alnassif)
- **userhub:** add script metadata display, disable support with ! prefix, and automatic header migration (@ahmed-alnassif)
- **fix:** stop UserHub stage toggle from misfiring on programmatic .selected assignment (@ahmed-alnassif)
- **fix:** hide reboot button while a terminal or editor is open, only show it on normal page views (@ahmed-alnassif)
- **feat:** add reboot FAB next to close-terminal, shown once a running action/script finishes (@ahmed-alnassif)
- **fix:** hide reboot-terminal-btn when the terminal is closed, not just when a new run starts (@ahmed-alnassif)
- **fix:** make reboot terminal button clickable by fixing pointer-events and z-index stacking (@ahmed-alnassif)

### 🧩 Module

- **refactor:** use one directory for configs files (@ahmed-alnassif)
- **feat:** enhance config handling to support folders and any file types (@ahmed-alnassif)
- **fix:** exit when SuSFS download failed (@ahmed-alnassif)

### 📚 Documentation

- add my official telegram group (@ahmed-alnassif)
- update CLI output (@ahmed-alnassif)

### ⚙️ CI/CD

- **fix:** update module issue in the manager (@ahmed-alnassif)
- **feat:** add Telegram upload with commit and CI links (@ahmed-alnassif)
- **fix:** Telegram upload configuration (@ahmed-alnassif)
- **fix:** Telegram MarkdownV2 escaping (@ahmed-alnassif)
- **fix:** escape repository name for Telegram MarkdownV2 (@ahmed-alnassif)
- **fix:** escape CI number in Telegram MarkdownV2 (@ahmed-alnassif)
- add clickable repo link to Telegram caption (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-4171ba3 (@ahmed-alnassif)

## [v2.3.0-f454264] - 2026-09-01


### 🌐 WebUI

- add UserHub tab for creating, editing, running, and deleting user shell scripts (@ahmed-alnassif)
- add reboot button with confirmation dialog to header (@ahmed-alnassif)
- switch backup/restore from JSON to busybox tar archives (@ahmed-alnassif)
- add enabled scripts count to home summary, tapping it jumps to UserHub (@ahmed-alnassif)

### 🧩 Module

- fix exit with 1 if the download failed (@ahmed-alnassif)
- fix: prompt once for differing configs, auto-copy missing files (@ahmed-alnassif)
- add ReSuSFS.sh/post-fs-data.sh/boot-completed.sh support for running UserHub scripts at post-fs-data and boot-completed stages (@ahmed-alnassif)

### 📚 Documentation

- correct uname file format (@ahmed-alnassif)
- update README intro to cover UserHub, backup/restore, and reboot button (@ahmed-alnassif)

### ⚙️ CI/CD

- add detailed changelog using python (@ahmed-alnassif)
- add automated CHANGELOG.md update on release (@ahmed-alnassif)
- fetch full git history in release workflow to fix broken version-change detection (@ahmed-alnassif)
- **release:** fix PREVIOUS_VERSION being written to GITHUB_ENV before it was assigned (@ahmed-alnassif)

### 🧹 Chores

- bump version to v2.3.0-f454264 (@ahmed-alnassif)
